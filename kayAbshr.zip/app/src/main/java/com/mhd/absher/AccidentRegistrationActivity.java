package com.mhd.absher;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;

public class AccidentRegistrationActivity extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.accident_registration);
        getWindow().getDecorView().setLayoutDirection(1);
        ImageView imageView = (ImageView) findViewById(R.id.btnCloseAccident);
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AccidentRegistrationActivity.this.finish();
                }
            });
        }
        Button button = (Button) findViewById(R.id.btnRegisterAccidentAction);
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText((Context) AccidentRegistrationActivity.this, (CharSequence) a.a("jfieiuDkjcsN4PKNwvWQjfuejBiN/J6H4OaM6vSyjNBm9ZWN856C4P50noHg+o3M9Zd7emg="), 0).show();
                }
            });
        }
    }
}
