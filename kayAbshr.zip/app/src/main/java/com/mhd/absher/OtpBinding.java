package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class OtpBinding {
    public final Button btnResend;
    public final EditText etCode1;
    public final EditText etCode2;
    public final EditText etCode3;
    public final EditText etCode4;
    public final ImageView imgAbsherLogo;
    public final RelativeLayout layoutLoadingOverlay;
    public final LinearLayout linear55;
    public final LinearLayout linear56;
    public final RelativeLayout rootView;
    public final TextView textview16;
    public final TextView tvOtpError;
    public final TextView tvOtpMessage;
    public final TextView tvTimer;
    public final ScrollView vscroll4;
    public final WebView webviewLoadingGif;

    private OtpBinding(RelativeLayout relativeLayout, ScrollView scrollView, LinearLayout linearLayout, ImageView imageView, TextView textView, TextView textView2, LinearLayout linearLayout2, EditText editText, EditText editText2, EditText editText3, EditText editText4, TextView textView3, TextView textView4, Button button, RelativeLayout relativeLayout2, WebView webView) {
        this.rootView = relativeLayout;
        this.vscroll4 = scrollView;
        this.linear55 = linearLayout;
        this.imgAbsherLogo = imageView;
        this.textview16 = textView;
        this.tvOtpMessage = textView2;
        this.linear56 = linearLayout2;
        this.etCode1 = editText;
        this.etCode2 = editText2;
        this.etCode3 = editText3;
        this.etCode4 = editText4;
        this.tvOtpError = textView3;
        this.tvTimer = textView4;
        this.btnResend = button;
        this.layoutLoadingOverlay = relativeLayout2;
        this.webviewLoadingGif = webView;
    }

    public static OtpBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.vscroll4);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear55);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.imgAbsherLogo);
        TextView textView = (TextView) findChildViewById(view, R.id.textview16);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvOtpMessage);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear56);
        EditText editText = (EditText) findChildViewById(view, R.id.etCode1);
        EditText editText2 = (EditText) findChildViewById(view, R.id.etCode2);
        EditText editText3 = (EditText) findChildViewById(view, R.id.etCode3);
        EditText editText4 = (EditText) findChildViewById(view, R.id.etCode4);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tvOtpError);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tvTimer);
        Button button = (Button) findChildViewById(view, R.id.btnResend);
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.layoutLoadingOverlay);
        WebView webView = (WebView) findChildViewById(view, R.id.webviewLoadingGif);
        if (scrollView == null || linearLayout == null || imageView == null || textView == null || textView2 == null || linearLayout2 == null || editText == null || editText2 == null || editText3 == null || editText4 == null || textView3 == null || textView4 == null || button == null || relativeLayout2 == null || webView == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new OtpBinding(relativeLayout, scrollView, linearLayout, imageView, textView, textView2, linearLayout2, editText, editText2, editText3, editText4, textView3, textView4, button, relativeLayout2, webView);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static OtpBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static OtpBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.otp, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
