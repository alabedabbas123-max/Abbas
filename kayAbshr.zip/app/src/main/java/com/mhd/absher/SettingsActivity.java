package com.mhd.absher;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.a.a.a.a.a;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SettingsActivity extends AppCompatActivity {
    private SettingsBinding binding;

    private void initialize(Bundle bundle) {
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initializeLogic() {
        getWindow().getDecorView().setLayoutDirection(1);
        SharedPreferences sharedPreferences = getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0);
        final SharedPreferences sharedPreferences2 = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        SharedPreferences sharedPreferences3 = getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
        String string = sharedPreferences2.getString(a.a("OzUrSHkn"), "");
        if (string.isEmpty()) {
            string = sharedPreferences2.getString(a.a("OzUrSA=="), "");
        }
        if (string.isEmpty()) {
            string = sharedPreferences2.getString(a.a("MyEqQXY0OSM="), "");
        }
        if (string.isEmpty()) {
            string = sharedPreferences.getString(a.a("NjUlRV0xCzNeXScLKExVMA=="), "");
        }
        if (string.isEmpty()) {
            string = a.a("jfOenuDyjcP0v3WM//S9jeVm9YuN7Z+n4Pp0n6jg+I3D9Zd1jOH0vI34n6ng8o3C");
        }
        String string2 = sharedPreferences.getString(a.a("JjUwSFwKPSJyViA5JEhK"), "");
        if (string2.isEmpty()) {
            string2 = sharedPreferences2.getString(a.a("PDAIWFU3MTQ="), "");
        }
        if (string2.isEmpty()) {
            string2 = a.a("Z2dwGQhgZXYYAA==");
        }
        String string3 = sharedPreferences.getString(a.a("ICcjX3E4NSFI"), "");
        String string4 = string3.isEmpty() ? sharedPreferences.getString(a.a("NjUlRV0xCzNeXScLL0BZMjE="), "") : string3;
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        scrollView.setBackgroundColor(Color.parseColor(a.a("dhJxawATFQ==")));
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout.setPadding(35, 40, 35, 60);
        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        relativeLayout.setPadding(10, 10, 10, 20);
        TextView textView = new TextView(this);
        textView.setText(a.a("jfOfqeDyjP/1l43znoLg8ozs"));
        textView.setTextSize(22.0f);
        textView.setTextColor(-16777216);
        textView.setTypeface(null, 1);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(11);
        textView.setLayoutParams(layoutParams);
        TextView textView2 = new TextView(this);
        textView2.setText(a.a("jfOel+HRjOH0ug=="));
        textView2.setTextSize(16.0f);
        textView2.setTextColor(Color.parseColor(a.a("dmZ0HwpnZg==")));
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(9);
        textView2.setLayoutParams(layoutParams2);
        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SettingsActivity.this.finish();
            }
        });
        relativeLayout.addView(textView);
        relativeLayout.addView(textView2);
        linearLayout.addView(relativeLayout);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.setMargins(0, 0, 0, 10);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, 2);
        layoutParams4.setMargins(20, 0, 20, 0);
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams5.setMargins(10, 25, 10, 12);
        TextView textView3 = new TextView(this);
        textView3.setText(a.a("jf6frODyjPP0sozQZvWfjNCegODmjOH1kA=="));
        textView3.setTextSize(14.0f);
        textView3.setTextColor(Color.parseColor(a.a("dmMHGnliFQ==")));
        textView3.setLayoutParams(layoutParams5);
        linearLayout.addView(textView3);
        View cardView = new CardView(this);
        cardView.setRadius(18.0f);
        cardView.setCardElevation(2.0f);
        cardView.setCardBackgroundColor(-1);
        cardView.setLayoutParams(layoutParams3);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(1);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(0);
        linearLayout3.setPadding(25, 25, 25, 25);
        linearLayout3.setGravity(16);
        LinearLayout linearLayout4 = new LinearLayout(this);
        linearLayout4.setOrientation(1);
        linearLayout4.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        final TextView textView4 = new TextView(this);
        textView4.setText(string);
        textView4.setTextSize(16.0f);
        textView4.setTextColor(-16777216);
        textView4.setTypeface(null, 1);
        final TextView textView5 = new TextView(this);
        textView5.setText(a.a("jeWfr+HQdJ6K4dGNwfSwjN6ehBg=") + string2);
        textView5.setTextSize(13.0f);
        textView5.setTextColor(Color.parseColor(a.a("dmNxGg9iYw==")));
        textView5.setPadding(0, 6, 0, 0);
        linearLayout4.addView(textView4);
        linearLayout4.addView(textView5);
        final ImageView imageView = new ImageView(this);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(110, 110));
        imageView.setImageResource(android.R.drawable.ic_menu_gallery);
        if (!string4.isEmpty()) {
            try {
                byte[] bArrDecode = Base64.decode(string4, 0);
                Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArrDecode, 0, bArrDecode.length);
                if (bitmapDecodeByteArray != null) {
                    imageView.setImageBitmap(bitmapDecodeByteArray);
                }
            } catch (Exception e) {
            }
        }
        linearLayout3.addView(linearLayout4);
        linearLayout3.addView(imageView);
        linearLayout2.addView(linearLayout3);
        View view = new View(this);
        view.setLayoutParams(layoutParams4);
        view.setBackgroundColor(Color.parseColor(a.a("dhJ2awgTZA==")));
        linearLayout2.addView(view);
        LinearLayout linearLayout5 = new LinearLayout(this);
        linearLayout5.setOrientation(0);
        linearLayout5.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout5.setPadding(25, 25, 25, 25);
        linearLayout5.setGravity(16);
        TextView textView6 = new TextView(this);
        textView6.setText(a.a("jNGfpeD+jcQN4PaM7vWMjeU="));
        textView6.setTextSize(15.0f);
        textView6.setTextColor(Color.parseColor(a.a("dmZ0HwpnZg==")));
        textView6.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout5.addView(textView6);
        TextView textView7 = new TextView(this);
        textView7.setText(a.a("aQ=="));
        textView7.setTextSize(16.0f);
        textView7.setTextColor(Color.parseColor(a.a("dhV2bAgUZA==")));
        linearLayout5.addView(textView7);
        linearLayout2.addView(linearLayout5);
        cardView.addView(linearLayout2);
        linearLayout.addView(cardView);
        TextView textView8 = new TextView(this);
        textView8.setText(a.a("jfOfqeD7jPP0sI3hn6fg/HSfpeDyjcL1m4zRnorh0w=="));
        textView8.setTextSize(14.0f);
        textView8.setTextColor(Color.parseColor(a.a("dmMHGnliFQ==")));
        textView8.setLayoutParams(layoutParams5);
        linearLayout.addView(textView8);
        View cardView2 = new CardView(this);
        cardView2.setRadius(18.0f);
        cardView2.setCardElevation(2.0f);
        cardView2.setCardBackgroundColor(-1);
        cardView2.setLayoutParams(layoutParams3);
        LinearLayout linearLayout6 = new LinearLayout(this);
        linearLayout6.setOrientation(1);
        LinearLayout linearLayout7 = new LinearLayout(this);
        linearLayout7.setOrientation(0);
        linearLayout7.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout7.setPadding(25, 25, 25, 25);
        linearLayout7.setGravity(16);
        TextView textView9 = new TextView(this);
        textView9.setText(a.a("jfOfqeD2jOr0v43mnoQYjfOfqeHQjc71k4zWnoQ="));
        textView9.setTextSize(15.0f);
        textView9.setTextColor(Color.parseColor(a.a("dmZ0HwpnZg==")));
        textView9.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout7.addView(textView9);
        TextView textView10 = new TextView(this);
        textView10.setText(a.a("aQ=="));
        textView10.setTextSize(16.0f);
        textView10.setTextColor(Color.parseColor(a.a("dhV2bAgUZA==")));
        linearLayout7.addView(textView10);
        linearLayout6.addView(linearLayout7);
        View view2 = new View(this);
        view2.setLayoutParams(layoutParams4);
        view2.setBackgroundColor(Color.parseColor(a.a("dhJ2awgTZA==")));
        linearLayout6.addView(view2);
        ColorStateList colorStateList = null;
        ColorStateList colorStateList2 = null;
        if (Build.VERSION.SDK_INT >= 23) {
            colorStateList = new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked}, new int[]{-16842912}}, new int[]{Color.parseColor(a.a("dmR0FQARZQ==")), Color.parseColor(a.a("dhZ2b30WYQ=="))});
            colorStateList2 = new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked}, new int[]{-16842912}}, new int[]{Color.parseColor(a.a("dhZ1aA0TFw==")), Color.parseColor(a.a("dhcAaQARFw=="))});
        }
        LinearLayout linearLayout8 = new LinearLayout(this);
        linearLayout8.setOrientation(0);
        linearLayout8.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout8.setPadding(25, 20, 25, 20);
        linearLayout8.setGravity(16);
        LinearLayout linearLayout9 = new LinearLayout(this);
        linearLayout9.setOrientation(1);
        linearLayout9.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView11 = new TextView(this);
        textView11.setText(a.a("jf6frODsjcz0vHWNw/WBjeWfrBiN85+p4d2M6vS/"));
        textView11.setTextSize(15.0f);
        textView11.setTextColor(Color.parseColor(a.a("dmZ0HwpnZg==")));
        textView11.setTypeface(null, 1);
        TextView textView12 = new TextView(this);
        textView12.setText(a.a("jNGelODkjccN4PKNwvSwjfifqhiN4J6c4OJ0n6ng8oz19ZKN7Z6c4PKM8A3g8o3C9LCN/56K4PONxA3g8o3C9YmM1p+o4d+M7w3h3Yzh9YuN/p6D4PqM4fS9dY3D9LCN/5+vGI33noXg4Yz3DeHdjOH0vI3xnoXh14zh9Zl1jP/0vIzdZvWSjeeegeHfjcIN4PKNwvWXjfqfpeHR"));
        textView12.setTextSize(12.0f);
        textView12.setTextColor(Color.parseColor(a.a("dmx+FQBtbA==")));
        textView12.setPadding(0, 8, 0, 0);
        linearLayout9.addView(textView11);
        linearLayout9.addView(textView12);
        Switch r22 = new Switch(this);
        r22.setChecked(false);
        if (Build.VERSION.SDK_INT >= 23) {
            r22.setThumbTintList(colorStateList);
            r22.setTrackTintList(colorStateList2);
        }
        linearLayout8.addView(r22);
        linearLayout8.addView(linearLayout9);
        linearLayout6.addView(linearLayout8);
        View view3 = new View(this);
        view3.setLayoutParams(layoutParams4);
        view3.setBackgroundColor(Color.parseColor(a.a("dhJ2awgTZA==")));
        linearLayout6.addView(view3);
        LinearLayout linearLayout10 = new LinearLayout(this);
        linearLayout10.setOrientation(0);
        linearLayout10.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout10.setPadding(25, 20, 25, 20);
        linearLayout10.setGravity(16);
        LinearLayout linearLayout11 = new LinearLayout(this);
        linearLayout11.setOrientation(1);
        linearLayout11.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView13 = new TextView(this);
        textView13.setText(a.a("jf6elOD/jcz0vXWM4fS8jeGfpeDkjO8="));
        textView13.setTextSize(15.0f);
        textView13.setTextColor(Color.parseColor(a.a("dmZ0HwpnZg==")));
        textView13.setTypeface(null, 1);
        TextView textView14 = new TextView(this);
        textView14.setText(a.a("jNGelODkjccN4PKNwvSwjfifqhiN4J6c4OJ0n6ng8oz19ZKN7Z6c4PKM8A3g8o3C9LCN/56K4PONxA3g8o3C9YmM1p+o4d+M7w3h3Yzh9YuN/p6D4PqM4fS9dY3D9LCN/5+vGI33noXg4Yz3DeHdjOH0vI3xnoXh14zh9Zl1jP/0vIzdZvWSjeeegeHfjcIN4PKNwvWXjfqfpeHR"));
        textView14.setTextSize(12.0f);
        textView14.setTextColor(Color.parseColor(a.a("dmx+FQBtbA==")));
        textView14.setPadding(0, 8, 0, 0);
        linearLayout11.addView(textView13);
        linearLayout11.addView(textView14);
        Switch r23 = new Switch(this);
        r23.setChecked(true);
        if (Build.VERSION.SDK_INT >= 23) {
            r23.setThumbTintList(colorStateList);
            r23.setTrackTintList(colorStateList2);
        }
        linearLayout10.addView(r23);
        linearLayout10.addView(linearLayout11);
        linearLayout6.addView(linearLayout10);
        cardView2.addView(linearLayout6);
        linearLayout.addView(cardView2);
        TextView textView15 = new TextView(this);
        textView15.setText(a.a("jfOfqeD/jcf1jozen6ng8ozs"));
        textView15.setTextSize(14.0f);
        textView15.setTextColor(Color.parseColor(a.a("dmMHGnliFQ==")));
        textView15.setLayoutParams(layoutParams5);
        linearLayout.addView(textView15);
        View cardView3 = new CardView(this);
        cardView3.setRadius(18.0f);
        cardView3.setCardElevation(2.0f);
        cardView3.setCardBackgroundColor(-1);
        cardView3.setLayoutParams(layoutParams3);
        LinearLayout linearLayout12 = new LinearLayout(this);
        linearLayout12.setOrientation(1);
        linearLayout12.setPadding(25, 25, 25, 25);
        TextView textView16 = new TextView(this);
        textView16.setText(a.a("jfOfqeHRjPz1kXV0npTg5Izu9LJ9jOH0vI35norh0Y3M9ZF8"));
        textView16.setTextSize(15.0f);
        textView16.setTextColor(-16777216);
        TextView textView17 = new TextView(this);
        textView17.setText(a.a("jN6enuD/jOj1l4zRZvWfjNCeh+DijO70sozWZvS8je6ehBiN85+p4PmNwfWfjeZm9Z+M0J6A4PKNwvSyjf1oDeHRjOz1gozen6fg5HSfqeDvjO8N4PKNwvWSjeOeheHfjcQ="));
        textView17.setTextSize(12.0f);
        textView17.setTextColor(-7829368);
        textView17.setPadding(0, 8, 0, 15);
        TextView textView18 = new TextView(this);
        textView18.setText(a.a("jf6el+Hfjcz1iXWM4fS8jNCel+D8dJ+o4dN0norh0Yzh9YGN+56K4PqM4fWS"));
        textView18.setTextSize(14.0f);
        textView18.setTextColor(Color.parseColor(a.a("dmQFGnlhFQ==")));
        textView18.setTypeface(null, 1);
        linearLayout12.addView(textView16);
        linearLayout12.addView(textView17);
        linearLayout12.addView(textView18);
        cardView3.addView(linearLayout12);
        linearLayout.addView(cardView3);
        TextView textView19 = new TextView(this);
        textView19.setText(a.a("jfOfqeD/jcT0sIzen6g="));
        textView19.setTextSize(14.0f);
        textView19.setTextColor(Color.parseColor(a.a("dmMHGnliFQ==")));
        textView19.setLayoutParams(layoutParams5);
        linearLayout.addView(textView19);
        View cardView4 = new CardView(this);
        cardView4.setRadius(18.0f);
        cardView4.setCardElevation(2.0f);
        cardView4.setCardBackgroundColor(-1);
        cardView4.setLayoutParams(layoutParams3);
        LinearLayout linearLayout13 = new LinearLayout(this);
        linearLayout13.setOrientation(1);
        linearLayout13.setPadding(25, 25, 25, 25);
        TextView textView20 = new TextView(this);
        textView20.setText(a.a("jeefp+D/jcMN4OyM9/WOdYzq9L2M3p6UGI3zn6ng/43O9Z+N5Z+n4Pt0noXg8o3C9ZKN856c4d+M6A3g8o3C9L2M3p+p4PKM6fSy"));
        textView20.setTextSize(12.0f);
        textView20.setTextColor(-7829368);
        textView20.setPadding(0, 0, 0, 15);
        RadioGroup radioGroup = new RadioGroup(this);
        RadioButton radioButton = new RadioButton(this);
        radioButton.setText(a.a("jfOfqeD/jOH1iYzenoMYjfOfqeHQjcz0vI3znoLh3w=="));
        radioButton.setChecked(true);
        RadioButton radioButton2 = new RadioButton(this);
        radioButton2.setText(a.a("jfOfqeD/jOH1iYzenoMYjfOfqeHSjOr1iYze"));
        if (Build.VERSION.SDK_INT >= 21) {
            ColorStateList colorStateList3 = new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked}, new int[]{-16842912}}, new int[]{Color.parseColor(a.a("dmR0FQARZQ==")), Color.parseColor(a.a("dmNzGg1iYQ=="))});
            radioButton.setButtonTintList(colorStateList3);
            radioButton2.setButtonTintList(colorStateList3);
        }
        radioGroup.addView(radioButton);
        radioGroup.addView(radioButton2);
        linearLayout13.addView(textView20);
        linearLayout13.addView(radioGroup);
        cardView4.addView(linearLayout13);
        linearLayout.addView(cardView4);
        View cardView5 = new CardView(this);
        cardView5.setRadius(18.0f);
        cardView5.setCardElevation(2.0f);
        cardView5.setCardBackgroundColor(-1);
        cardView5.setLayoutParams(layoutParams3);
        LinearLayout linearLayout14 = new LinearLayout(this);
        linearLayout14.setOrientation(0);
        linearLayout14.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout14.setPadding(25, 25, 25, 25);
        linearLayout14.setGravity(16);
        TextView textView21 = new TextView(this);
        textView21.setText(a.a("jfOegODljccN4dKNzvSyjf6frhiN85+p4OSNxPS9jN6ehA=="));
        textView21.setTextSize(15.0f);
        textView21.setTextColor(Color.parseColor(a.a("dmZ0HwpnZg==")));
        textView21.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout14.addView(textView21);
        TextView textView22 = new TextView(this);
        textView22.setText(a.a("aQ=="));
        textView22.setTextSize(16.0f);
        textView22.setTextColor(Color.parseColor(a.a("dhV2bAgUZA==")));
        linearLayout14.addView(textView22);
        cardView5.addView(linearLayout14);
        linearLayout.addView(cardView5);
        TextView textView23 = new TextView(this);
        textView23.setText(a.a("jfOfqeD6jP/0vQ=="));
        textView23.setTextSize(14.0f);
        textView23.setTextColor(Color.parseColor(a.a("dmMHGnliFQ==")));
        textView23.setLayoutParams(layoutParams5);
        linearLayout.addView(textView23);
        View cardView6 = new CardView(this);
        cardView6.setRadius(18.0f);
        cardView6.setCardElevation(2.0f);
        cardView6.setCardBackgroundColor(-1);
        cardView6.setLayoutParams(layoutParams3);
        LinearLayout linearLayout15 = new LinearLayout(this);
        linearLayout15.setOrientation(1);
        LinearLayout linearLayout16 = new LinearLayout(this);
        linearLayout16.setOrientation(0);
        linearLayout16.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout16.setPadding(25, 25, 25, 25);
        linearLayout16.setGravity(16);
        TextView textView24 = new TextView(this);
        textView24.setText(a.a("jf6fpeDyjPP0vHWNw/WBjNKeig=="));
        textView24.setTextSize(15.0f);
        textView24.setTextColor(Color.parseColor(a.a("dmZ0HwpnZg==")));
        textView24.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout16.addView(textView24);
        TextView textView25 = new TextView(this);
        textView25.setText(a.a("aQ=="));
        textView25.setTextSize(16.0f);
        textView25.setTextColor(Color.parseColor(a.a("dhV2bAgUZA==")));
        linearLayout16.addView(textView25);
        linearLayout15.addView(linearLayout16);
        View view4 = new View(this);
        view4.setLayoutParams(layoutParams4);
        view4.setBackgroundColor(Color.parseColor(a.a("dhJ2awgTZA==")));
        linearLayout15.addView(view4);
        LinearLayout linearLayout17 = new LinearLayout(this);
        linearLayout17.setOrientation(0);
        linearLayout17.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout17.setPadding(25, 25, 25, 25);
        linearLayout17.setGravity(16);
        TextView textView26 = new TextView(this);
        textView26.setText(a.a("jfOfqeHQjOv1n437nobg/HSeiuHRjcP1kI3znpng5Izv"));
        textView26.setTextSize(15.0f);
        textView26.setTextColor(Color.parseColor(a.a("dmZ0HwpnZg==")));
        textView26.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout17.addView(textView26);
        TextView textView27 = new TextView(this);
        textView27.setText(a.a("aQ=="));
        textView27.setTextSize(16.0f);
        textView27.setTextColor(Color.parseColor(a.a("dhV2bAgUZA==")));
        linearLayout17.addView(textView27);
        linearLayout15.addView(linearLayout17);
        View view5 = new View(this);
        view5.setLayoutParams(layoutParams4);
        view5.setBackgroundColor(Color.parseColor(a.a("dhJ2awgTZA==")));
        linearLayout15.addView(view5);
        LinearLayout linearLayout18 = new LinearLayout(this);
        linearLayout18.setOrientation(0);
        linearLayout18.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout18.setPadding(25, 25, 25, 25);
        linearLayout18.setGravity(16);
        TextView textView28 = new TextView(this);
        textView28.setText(a.a("jeefp+DyjPX1kXWM4fS8jfqemOHdjPP0so39"));
        textView28.setTextSize(15.0f);
        textView28.setTextColor(Color.parseColor(a.a("dmZ0HwpnZg==")));
        textView28.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout18.addView(textView28);
        TextView textView29 = new TextView(this);
        textView29.setText(a.a("aQ=="));
        textView29.setTextSize(16.0f);
        textView29.setTextColor(Color.parseColor(a.a("dhV2bAgUZA==")));
        linearLayout18.addView(textView29);
        linearLayout15.addView(linearLayout18);
        cardView6.addView(linearLayout15);
        linearLayout.addView(cardView6);
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, 110);
        layoutParams6.setMargins(10, 40, 10, 40);
        TextView textView30 = new TextView(this);
        textView30.setText(a.a("jf6enuD5jcz0vHWM4fS8jfqenOHdjOo="));
        textView30.setTextSize(16.0f);
        textView30.setTextColor(Color.parseColor(a.a("dmQFGnlhFQ==")));
        textView30.setGravity(17);
        textView30.setLayoutParams(layoutParams6);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(16.0f);
        gradientDrawable.setStroke(3, Color.parseColor(a.a("dmQFGnlhFQ==")));
        gradientDrawable.setColor(-1);
        textView30.setBackground(gradientDrawable);
        textView30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view6) {
                SettingsActivity.this.getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0).edit().clear().apply();
                SettingsActivity.this.getSharedPreferences(a.a("ICcjX3w0ICc="), 0).edit().clear().apply();
                SettingsActivity.this.getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0).edit().clear().apply();
                Toast.makeText(SettingsActivity.this.getApplicationContext(), a.a("jf6fqBiN/p6e4PmNzPS8dYzh9LyN+p6c4d2M6g3g/Y3A9ZSN856A"), 0).show();
                Intent intent = new Intent((Context) SettingsActivity.this, (Class<?>) MainActivity.class);
                intent.addFlags(268468224);
                SettingsActivity.this.startActivity(intent);
                SettingsActivity.this.finish();
            }
        });
        linearLayout.addView(textView30);
        scrollView.addView(linearLayout);
        setContentView(scrollView);
        String string5 = sharedPreferences.getString(a.a("ICcjX2swNzRITBww"), "");
        if (string5.isEmpty()) {
            string5 = sharedPreferences3.getString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), "");
        }
        if (string5.isEmpty()) {
            string5 = sharedPreferences2.getString(a.a("ICcjX3MwLQ=="), "");
        }
        if (!string5.isEmpty()) {
            string2 = string5;
        }
        if (string2.isEmpty()) {
            return;
        }
        FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(string2).addListenerForSingleValueEvent(new ValueEventListener() {
            public void onCancelled(DatabaseError databaseError) {
            }

            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String strValueOf = "";
                    if (dataSnapshot.hasChild(a.a("OzUrSHkn")) && dataSnapshot.child(a.a("OzUrSHkn")).getValue() != null) {
                        strValueOf = String.valueOf(dataSnapshot.child(a.a("OzUrSHkn")).getValue());
                    } else if (dataSnapshot.hasChild(a.a("OzUrSA==")) && dataSnapshot.child(a.a("OzUrSA==")).getValue() != null) {
                        strValueOf = String.valueOf(dataSnapshot.child(a.a("OzUrSA==")).getValue());
                    } else if (dataSnapshot.hasChild(a.a("MyEqQXY0OSM=")) && dataSnapshot.child(a.a("MyEqQXY0OSM=")).getValue() != null) {
                        strValueOf = String.valueOf(dataSnapshot.child(a.a("MyEqQXY0OSM=")).getValue());
                    }
                    String key = dataSnapshot.getKey();
                    if (dataSnapshot.hasChild(a.a("PDAIWFU3MTQ=")) && dataSnapshot.child(a.a("PDAIWFU3MTQ=")).getValue() != null) {
                        key = String.valueOf(dataSnapshot.child(a.a("PDAIWFU3MTQ=")).getValue());
                    }
                    if (!strValueOf.isEmpty() && !strValueOf.equals(a.a("OyEqQQ=="))) {
                        textView4.setText(strValueOf);
                        sharedPreferences2.edit().putString(a.a("OzUrSHkn"), strValueOf).apply();
                    }
                    if (!key.isEmpty() && !key.equals(a.a("eHlr")) && !key.equals(a.a("OyEqQQ=="))) {
                        textView5.setText(a.a("jeWfr+HQdJ6K4dGNwfSwjN6ehBg=") + key);
                        sharedPreferences2.edit().putString(a.a("PDAIWFU3MTQ="), key).apply();
                    }
                    if (!dataSnapshot.hasChild(a.a("ICcjX3E4NSFI")) || dataSnapshot.child(a.a("ICcjX3E4NSFI")).getValue() == null) {
                        return;
                    }
                    String strValueOf2 = String.valueOf(dataSnapshot.child(a.a("ICcjX3E4NSFI")).getValue());
                    if (strValueOf2.isEmpty() || strValueOf2.equals(a.a("OyEqQQ=="))) {
                        return;
                    }
                    sharedPreferences2.edit().putString(a.a("ICcjX3E4NSFI"), strValueOf2).apply();
                    try {
                        byte[] bArrDecode2 = Base64.decode(strValueOf2, 0);
                        Bitmap bitmapDecodeByteArray2 = BitmapFactory.decodeByteArray(bArrDecode2, 0, bArrDecode2.length);
                        if (bitmapDecodeByteArray2 != null) {
                            imageView.setImageBitmap(bitmapDecodeByteArray2);
                        }
                    } catch (Exception e2) {
                    }
                }
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = SettingsBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        FirebaseApp.initializeApp(this);
        initializeLogic();
    }
}
