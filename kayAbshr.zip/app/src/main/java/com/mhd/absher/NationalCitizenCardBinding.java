package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class NationalCitizenCardBinding {
    public final RelativeLayout documentCardCitizen;
    public final FrameLayout frameLayout4;
    public final ImageView imgCitizenCardBg;
    public final ImageView imgCitizenQrcode;
    public final ImageView imgCitizenUserPhoto;
    public final RelativeLayout relativelayout6;
    public final RelativeLayout rootView;
    public final TextView tvCitizenBirthDate;
    public final TextView tvCitizenBirthDateEn;
    public final TextView tvCitizenBirthPlace;
    public final TextView tvCitizenCopyNumber;
    public final TextView tvCitizenExpiryDate;
    public final TextView tvCitizenExpiryDateEn;
    public final TextView tvCitizenIdNumber;
    public final TextView tvCitizenIdNumberEn;
    public final TextView tvCitizenNameAr;
    public final TextView tvCitizenNameEn;

    private NationalCitizenCardBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, RelativeLayout relativeLayout3, ImageView imageView, ImageView imageView2, FrameLayout frameLayout, ImageView imageView3, TextView textView, TextView textView2, TextView textView3, TextView textView4, TextView textView5, TextView textView6, TextView textView7, TextView textView8, TextView textView9, TextView textView10) {
        this.rootView = relativeLayout;
        this.documentCardCitizen = relativeLayout2;
        this.relativelayout6 = relativeLayout3;
        this.imgCitizenCardBg = imageView;
        this.imgCitizenUserPhoto = imageView2;
        this.frameLayout4 = frameLayout;
        this.imgCitizenQrcode = imageView3;
        this.tvCitizenCopyNumber = textView;
        this.tvCitizenNameAr = textView2;
        this.tvCitizenNameEn = textView3;
        this.tvCitizenIdNumber = textView4;
        this.tvCitizenIdNumberEn = textView5;
        this.tvCitizenBirthDate = textView6;
        this.tvCitizenBirthDateEn = textView7;
        this.tvCitizenExpiryDate = textView8;
        this.tvCitizenExpiryDateEn = textView9;
        this.tvCitizenBirthPlace = textView10;
    }

    public static NationalCitizenCardBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.documentCardCitizen);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.relativelayout6);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.img_citizen_card_bg);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.img_citizen_user_photo);
        FrameLayout frameLayout = (FrameLayout) findChildViewById(view, R.id.frame_layout4);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.img_citizen_qrcode);
        TextView textView = (TextView) findChildViewById(view, R.id.tv_citizen_copy_number);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tv_citizen_name_ar);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tv_citizen_name_en);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tv_citizen_id_number);
        TextView textView5 = (TextView) findChildViewById(view, R.id.tv_citizen_id_number_en);
        TextView textView6 = (TextView) findChildViewById(view, R.id.tv_citizen_birth_date);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tv_citizen_birth_date_en);
        TextView textView8 = (TextView) findChildViewById(view, R.id.tv_citizen_expiry_date);
        TextView textView9 = (TextView) findChildViewById(view, R.id.tv_citizen_expiry_date_en);
        TextView textView10 = (TextView) findChildViewById(view, R.id.tv_citizen_birth_place);
        if (relativeLayout2 == null || relativeLayout3 == null || imageView == null || imageView2 == null || frameLayout == null || imageView3 == null || textView == null || textView2 == null || textView3 == null || textView4 == null || textView5 == null || textView6 == null || textView7 == null || textView8 == null || textView9 == null || textView10 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new NationalCitizenCardBinding(relativeLayout, relativeLayout2, relativeLayout3, imageView, imageView2, frameLayout, imageView3, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static NationalCitizenCardBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static NationalCitizenCardBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.national_citizen_card, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
