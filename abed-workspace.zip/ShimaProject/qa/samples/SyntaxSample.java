package example;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

/** عينة صحيحة نحويًا تغطي بنى جافا الشائعة والحديثة: يجب ألا يُبلّغ عنها فاحص الجمل أي خطأ. */
public class SyntaxSample<T extends Comparable<? super T>> {
  @SuppressWarnings({"unchecked", "rawtypes"})
  private final Map<String, List<int[]>> index = new HashMap<>();
  private static final int[][] GRID = {{1, 2,}, {3}};

  interface Callback {
    int COUNT = 2;

    void run(String... args) throws Exception;

    default String name() {
      return "callback";
    }
  }

  record Point(int x, int y) implements Comparable<Point> {
    Point {
      if (x < 0) throw new IllegalArgumentException("x");
    }

    @Override
    public int compareTo(Point other) {
      return Integer.compare(x, other.x);
    }
  }

  enum Mode {
    FAST(1) {
      @Override
      int speed() {
        return 2;
      }
    },
    SLOW(3);

    final int value;

    Mode(int value) {
      this.value = value;
    }

    int speed() {
      return value;
    }
  }

  static <R> R pick(Object o, Function<Object, R> f) throws IOException {
    String text = """
        multi "line" \""" text
        block
        """;
    int total = switch (o.hashCode() % 3) {
      case 0 -> 1;
      case 1 -> {
        yield 2;
      }
      default -> 3;
    };
    final int snapshot = total;
    Runnable r = () -> System.out.println(text + snapshot);
    BiFunction<Integer, Integer, Integer> add = (a, b) -> a + b;
    Object cast = (Comparable<String>) (Object) "x";
    Function<Integer, int[]> make = int[]::new;
    if (o instanceof String s && !s.isEmpty()) {
      r.run();
    }
    outer:
    for (int i = 0, j = 10; i < j; i++, j--) {
      if (i == 2) continue outer;
      if (i > 5) break outer;
    }
    int shifted = total >> 1;
    shifted >>>= 1;
    boolean bounded = shifted >= 0 && shifted <= 9;
    try (StringReader in = new StringReader(text)) {
      in.read();
    } catch (IOException | RuntimeException e) {
      throw e;
    } finally {
      total++;
    }
    List<String> names = new ArrayList<>();
    names.forEach(System.out::println);
    Class<?>[] types = {String.class, int[].class, Map.Entry[].class};
    Object anonymous = new Object() {
      @Override
      public String toString() {
        return "anon";
      }
    };
    char letter = '\'';
    String escaped = "tab\t\"quoted\"\\";
    long big = 1_000_000L + 0x7F + 0b1010 + 017;
    double exp = 1.5e-3 + 0x1.8p1;
    return f.apply(bounded ? names : null) == null ? null : f.apply(cast);
  }

  sealed interface Shape permits Circle, Square {}

  record Circle(double radius) implements Shape {}

  non-sealed static class Square implements Shape {}
}
