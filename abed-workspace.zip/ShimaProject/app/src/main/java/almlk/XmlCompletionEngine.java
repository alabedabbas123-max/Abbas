package almlk;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

/**
 * محرك إكمال XML سياقي — المرحلتان 3 و4.
 *
 * <p>يميز موضع المؤشر ثلاث حالات كما في المرجع: داخل <b>قيمة سمة</b> (بين اقتباسين)، داخل
 * <b>اسم سمة</b> (بعد وسم وقبل {@code =})، أو عند <b>اسم وسم</b> (بعد {@code <}). لكل حالة
 * قائمة قيم ملائمة للسياق، والترشيح بالبادئة **يشمل الأرقام** فلا يُعترض إدخال رقم ولا يُستبدل
 * بحروف.
 *
 * <p>جافا صرفة بلا أي مكتبة خارجية؛ الكتالوج مبني ذاتيًا من سمات/وسوم أندرويد الشائعة.
 */
public final class XmlCompletionEngine {

  private XmlCompletionEngine() {}

  // ─────────────────────────── الواجهة ───────────────────────────

  /** قائمة الاقتراحات حسب سياق المؤشر. */
  public static List<String> complete(String text, int cursor) {
    int at = clamp(cursor, text.length());
    Context context = analyze(text, at);
    LinkedHashSet<String> values = new LinkedHashSet<>();
    switch (context.kind) {
      case VALUE:
        values.addAll(valueSuggestions(context.attribute, context.prefix));
        break;
      case ATTRIBUTE:
        values.addAll(attributeSuggestions(context.tag, context.prefix));
        break;
      case TAG:
        values.addAll(tagSuggestions(context.prefix));
        break;
      default:
        return new ArrayList<>();
    }
    List<String> out = new ArrayList<>();
    String prefix = context.prefix.toLowerCase(Locale.US);
    for (String value : values) {
      if (prefix.isEmpty() || value.toLowerCase(Locale.US).startsWith(prefix)) out.add(value);
    }
    if (out.size() > 60) return new ArrayList<>(out.subList(0, 60));
    return out;
  }

  /** بداية الرمز الحالي الذي سيُستبدل عند الالتزام — تشمل الأرقام والنقط و@ و# و/ و:. */
  public static int completionStart(String text, int cursor) {
    int at = clamp(cursor, text.length());
    Context context = analyze(text, at);
    return context.tokenStart;
  }

  // ─────────────────────────── التحليل ───────────────────────────

  enum Kind { NONE, VALUE, ATTRIBUTE, TAG }

  private static final class Context {
    Kind kind = Kind.NONE;
    String tag = "";
    String attribute = "";
    String prefix = "";
    int tokenStart;
  }

  private static int clamp(int value, int max) {
    return value < 0 ? 0 : Math.min(value, max);
  }

  /** يحدد الحالة واسم الوسم والسمة والبادئة وبداية الرمز للموضع المعطى. */
  static Context analyze(String text, int at) {
    Context context = new Context();
    context.tokenStart = at;

    // ابحث عن آخر '<' غير مغلق قبل المؤشر → نحن داخل وسم.
    int tagStart = -1;
    for (int i = at - 1; i >= 0; i--) {
      char c = text.charAt(i);
      if (c == '>') break;
      if (c == '<') { tagStart = i; break; }
    }
    if (tagStart < 0) return context; // خارج أي وسم: لا إكمال

    String head = text.substring(tagStart, at);

    // اسم الوسم بعد '<'
    int nameStart = tagStart + 1;
    if (nameStart < text.length() && text.charAt(nameStart) == '/') nameStart++;
    int nameEnd = nameStart;
    while (nameEnd < at && isNameChar(text.charAt(nameEnd))) nameEnd++;
    context.tag = text.substring(nameStart, Math.min(nameEnd, at));

    // هل المؤشر داخل قيمة مقتبسة؟ ابحث عن آخر '"' قبل المؤشر ضمن الوسم.
    int lastQuote = head.lastIndexOf('"');
    int lastEq = head.lastIndexOf('=');
    if (lastQuote >= 0 && lastQuote > lastEq && countQuotes(head, lastQuote) % 2 == 0) {
      // داخل قيمة: البادئة من بعد آخر اقتباس فردي الافتتاح.
      int valueStart = tagStart + lastQuote + 1;
      context.kind = Kind.VALUE;
      context.attribute = attributeNameBefore(text, tagStart + lastQuote);
      context.prefix = text.substring(valueStart, at);
      context.tokenStart = valueStart;
      return context;
    }

    // بعد '<اسم' ومسافة → اسم سمة.
    if (at > nameEnd && Character.isWhitespace(text.charAt(at - 1))
        || (at > nameEnd && head.length() > nameEnd - tagStart
            && Character.isWhitespace(head.charAt(nameEnd - tagStart)))) {
      context.kind = Kind.ATTRIBUTE;
      int wordStart = at;
      while (wordStart > nameEnd && isAttrChar(text.charAt(wordStart - 1))) wordStart--;
      context.prefix = text.substring(wordStart, at);
      context.tokenStart = wordStart;
      return context;
    }

    // ملاصق لـ'<' → اسم وسم.
    if (at <= nameEnd) {
      context.kind = Kind.TAG;
      context.prefix = text.substring(nameStart, at);
      context.tokenStart = nameStart;
      return context;
    }

    // داخل اسم سمة جزئي (يلتصق بحرف)
    if (at > nameEnd) {
      context.kind = Kind.ATTRIBUTE;
      int wordStart = at;
      while (wordStart > tagStart + 1 && isAttrChar(text.charAt(wordStart - 1))) wordStart--;
      context.prefix = text.substring(wordStart, at);
      context.tokenStart = wordStart;
    }
    return context;
  }

  private static int countQuotes(String s, int upTo) {
    int n = 0;
    for (int i = 0; i < upTo; i++) if (s.charAt(i) == '"') n++;
    return n;
  }

  /** اسم السمة الواقع قبل موضع الاقتباس (للحصول على نوع القيمة). */
  private static String attributeNameBefore(String text, int quotePos) {
    int end = quotePos;
    while (end > 0 && (text.charAt(end - 1) == '=' || Character.isWhitespace(text.charAt(end - 1)))) {
      end--;
    }
    int start = end;
    while (start > 0 && isAttrChar(text.charAt(start - 1))) start--;
    String name = text.substring(start, end);
    int colon = name.indexOf(':');
    return colon >= 0 ? name.substring(colon + 1) : name;
  }

  private static boolean isNameChar(char c) {
    return Character.isLetterOrDigit(c) || c == '.' || c == '_' || c == '-';
  }

  private static boolean isAttrChar(char c) {
    return Character.isLetterOrDigit(c) || c == ':' || c == '_' || c == '-';
  }

  // ─────────────────────────── القوائم ───────────────────────────

  private static List<String> valueSuggestions(String attribute, String prefix) {
    List<String> values = new ArrayList<>();
    String attr = attribute == null ? "" : attribute;
    if (attr.equals("layout_width") || attr.equals("layout_height")
        || attr.equals("width") || attr.equals("height") || attr.equals("minWidth")
        || attr.equals("minHeight")) {
      values.add("wrap_content");
      values.add("match_parent");
      values.add("fill_parent");
      values.addAll(dimensions(prefix));
      return values;
    }
    if (attr.equals("orientation")) { values.add("horizontal"); values.add("vertical"); return values; }
    if (attr.equals("visibility")) { values.add("visible"); values.add("invisible"); values.add("gone"); return values; }
    if (attr.equals("layout_gravity") || attr.equals("gravity")) {
      values.add("center"); values.add("center_horizontal"); values.add("center_vertical");
      values.add("left"); values.add("right"); values.add("top"); values.add("bottom");
      values.add("start"); values.add("end"); values.add("fill");
      return values;
    }
    if (attr.equals("scaleType")) {
      values.add("centerInside"); values.add("centerCrop"); values.add("fitCenter");
      values.add("fitXY"); values.add("center"); values.add("matrix");
      return values;
    }
    if (isBooleanAttr(attr)) { values.add("true"); values.add("false"); return values; }
    if (attr.equals("id")) { values.add("@+id/"); values.add("@id/"); return values; }
    if (attr.equals("text") || attr.equals("hint") || attr.equals("title")) {
      values.add("@string/"); return values;
    }
    if (attr.equals("src") || attr.equals("background") || attr.equals("drawable")) {
      values.add("@drawable/"); values.add("@android:drawable/"); values.add("@color/"); return values;
    }
    if (attr.equals("textColor") || attr.equals("backgroundTint") || attr.endsWith("Color")) {
      values.add("#"); values.add("#FF"); return values;
    }
    if (attr.equals("layout_below") || attr.equals("layout_above") || attr.equals("layout_toRightOf")
        || attr.equals("layout_toLeftOf") || attr.equals("layout_alignParentTop")) {
      values.add("@id/"); values.add("true"); values.add("false"); return values;
    }
    // عام: أبعاد + منطقية + مراجع
    values.addAll(dimensions(prefix));
    values.add("true"); values.add("false");
    values.add("@string/"); values.add("@drawable/"); values.add("@id/");
    return values;
  }

  /** أبعاد حرة تقبل الأرقام: إن بدأت البادئة برقم تُشتق قوالب بوحدات شائعة. */
  private static List<String> dimensions(String prefix) {
    List<String> out = new ArrayList<>();
    String digits = leadingNumber(prefix);
    if (!digits.isEmpty()) {
      out.add(digits + ".0dip");
      out.add(digits + "dip");
      out.add(digits + "dp");
      out.add(digits + "sp");
      out.add(digits + "px");
    } else {
      out.add("50.0dip");
      out.add("100.0dip");
      out.add("1dp");
      out.add("8dp");
      out.add("16dp");
    }
    return out;
  }

  private static String leadingNumber(String prefix) {
    StringBuilder out = new StringBuilder();
    for (int i = 0; i < prefix.length(); i++) {
      char c = prefix.charAt(i);
      if (Character.isDigit(c) || c == '.') out.append(c);
      else break;
    }
    return out.toString();
  }

  private static boolean isBooleanAttr(String attr) {
    return attr.equals("clickable") || attr.equals("focusable") || attr.equals("enabled")
        || attr.equals("checked") || attr.equals("singleLine") || attr.equals("selected")
        || attr.equals("longClickable") || attr.equals("focusableInTouchMode");
  }

  private static List<String> attributeSuggestions(String tag, String prefix) {
    LinkedHashSet<String> values = new LinkedHashSet<>();
    values.add("android:id");
    values.add("android:layout_width");
    values.add("android:layout_height");
    values.add("android:background");
    values.add("android:padding");
    values.add("android:layout_margin");
    values.add("android:visibility");
    String t = tag == null ? "" : tag;
    if (t.equals("LinearLayout")) { values.add("android:orientation"); values.add("android:weightSum"); }
    if (t.equals("RelativeLayout")) {
      values.add("android:layout_below"); values.add("android:layout_above");
      values.add("android:layout_toRightOf"); values.add("android:layout_centerInParent");
    }
    if (t.equals("TextView") || t.equals("Button") || t.equals("EditText") || t.equals("CheckBox")
        || t.equals("RadioButton") || t.equals("Switch")) {
      values.add("android:text"); values.add("android:textColor"); values.add("android:textSize");
    }
    if (t.equals("EditText")) { values.add("android:hint"); values.add("android:inputType"); }
    if (t.equals("ImageView") || t.equals("ImageButton")) { values.add("android:src"); values.add("android:scaleType"); }
    values.add("android:gravity");
    values.add("android:layout_gravity");
    return new ArrayList<>(values);
  }

  private static List<String> tagSuggestions(String prefix) {
    List<String> values = new ArrayList<>();
    values.add("LinearLayout"); values.add("RelativeLayout"); values.add("FrameLayout");
    values.add("ConstraintLayout"); values.add("ScrollView"); values.add("TextView");
    values.add("Button"); values.add("EditText"); values.add("ImageView"); values.add("ImageButton");
    values.add("CheckBox"); values.add("RadioButton"); values.add("Switch"); values.add("SeekBar");
    values.add("ProgressBar"); values.add("Spinner"); values.add("ListView"); values.add("View");
    return values;
  }
}
