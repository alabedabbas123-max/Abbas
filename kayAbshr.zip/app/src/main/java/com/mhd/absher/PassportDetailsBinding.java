package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class PassportDetailsBinding {
    public final ImageView btnBack;
    public final LinearLayout detailsLayout;
    public final LinearLayout headerRow;
    public final ImageView imageview2;
    public final TextView ivArrow;
    public final ImageView ivLeftSmallIcon;
    public final LinearLayout linear39;
    public final LinearLayout linear40;
    public final LinearLayout linear41;
    public final LinearLayout linear42;
    public final LinearLayout linear43;
    public final LinearLayout linear44;
    public final LinearLayout linear76;
    public final LinearLayout linear77;
    public final LinearLayout linear79;
    public final RelativeLayout relativelayout8;
    public final RelativeLayout rootPassportDetails;
    public final ScrollView scrollContent;
    public final Space space78;
    public final Space space86;
    public final TextView textview127;
    public final TextView textview128;
    public final TextView textview129;
    public final TextView textview130;
    public final TextView textview131;
    public final TextView textview132;
    public final TextView textview133;
    public final TextView textview134;
    public final RelativeLayout topBar;
    public final TextView tvCardTitle;
    public final TextView tvCity;
    public final TextView tvExpiryDate;
    public final TextView tvIssueDate;
    public final TextView tvPassportNumber;
    public final TextView tvStatus;
    public final TextView tvTitle;
    public final TextView tvType;
    public final View view38;

    private PassportDetailsBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, ScrollView scrollView, LinearLayout linearLayout, LinearLayout linearLayout2, TextView textView2, TextView textView3, Space space, LinearLayout linearLayout3, LinearLayout linearLayout4, ImageView imageView2, TextView textView4, TextView textView5, View view, LinearLayout linearLayout5, RelativeLayout relativeLayout3, LinearLayout linearLayout6, TextView textView6, TextView textView7, ImageView imageView3, LinearLayout linearLayout7, TextView textView8, TextView textView9, LinearLayout linearLayout8, TextView textView10, TextView textView11, LinearLayout linearLayout9, TextView textView12, TextView textView13, LinearLayout linearLayout10, TextView textView14, TextView textView15, LinearLayout linearLayout11, TextView textView16, TextView textView17, Space space2) {
        this.rootPassportDetails = relativeLayout;
        this.topBar = relativeLayout2;
        this.btnBack = imageView;
        this.tvTitle = textView;
        this.scrollContent = scrollView;
        this.linear76 = linearLayout;
        this.linear77 = linearLayout2;
        this.textview127 = textView2;
        this.textview128 = textView3;
        this.space78 = space;
        this.linear79 = linearLayout3;
        this.headerRow = linearLayout4;
        this.imageview2 = imageView2;
        this.tvCardTitle = textView4;
        this.ivArrow = textView5;
        this.view38 = view;
        this.detailsLayout = linearLayout5;
        this.relativelayout8 = relativeLayout3;
        this.linear39 = linearLayout6;
        this.textview129 = textView6;
        this.tvPassportNumber = textView7;
        this.ivLeftSmallIcon = imageView3;
        this.linear40 = linearLayout7;
        this.textview130 = textView8;
        this.tvType = textView9;
        this.linear41 = linearLayout8;
        this.textview131 = textView10;
        this.tvIssueDate = textView11;
        this.linear42 = linearLayout9;
        this.textview132 = textView12;
        this.tvExpiryDate = textView13;
        this.linear43 = linearLayout10;
        this.textview133 = textView14;
        this.tvCity = textView15;
        this.linear44 = linearLayout11;
        this.textview134 = textView16;
        this.tvStatus = textView17;
        this.space86 = space2;
    }

    public static PassportDetailsBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBar);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBack);
        TextView textView = (TextView) findChildViewById(view, R.id.tvTitle);
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.scrollContent);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear76);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear77);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview127);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview128);
        Space space = (Space) findChildViewById(view, R.id.space78);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear79);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.headerRow);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview2);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tvCardTitle);
        TextView textView5 = (TextView) findChildViewById(view, R.id.ivArrow);
        View viewFindChildViewById = findChildViewById(view, R.id.view38);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.detailsLayout);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.relativelayout8);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.linear39);
        TextView textView6 = (TextView) findChildViewById(view, R.id.textview129);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tvPassportNumber);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.ivLeftSmallIcon);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.linear40);
        TextView textView8 = (TextView) findChildViewById(view, R.id.textview130);
        TextView textView9 = (TextView) findChildViewById(view, R.id.tvType);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.linear41);
        TextView textView10 = (TextView) findChildViewById(view, R.id.textview131);
        TextView textView11 = (TextView) findChildViewById(view, R.id.tvIssueDate);
        LinearLayout linearLayout9 = (LinearLayout) findChildViewById(view, R.id.linear42);
        TextView textView12 = (TextView) findChildViewById(view, R.id.textview132);
        TextView textView13 = (TextView) findChildViewById(view, R.id.tvExpiryDate);
        LinearLayout linearLayout10 = (LinearLayout) findChildViewById(view, R.id.linear43);
        TextView textView14 = (TextView) findChildViewById(view, R.id.textview133);
        TextView textView15 = (TextView) findChildViewById(view, R.id.tvCity);
        LinearLayout linearLayout11 = (LinearLayout) findChildViewById(view, R.id.linear44);
        TextView textView16 = (TextView) findChildViewById(view, R.id.textview134);
        TextView textView17 = (TextView) findChildViewById(view, R.id.tvStatus);
        Space space2 = (Space) findChildViewById(view, R.id.space86);
        if (relativeLayout2 == null || imageView == null || textView == null || scrollView == null || linearLayout == null || linearLayout2 == null || textView2 == null || textView3 == null || space == null || linearLayout3 == null || linearLayout4 == null || imageView2 == null || textView4 == null || textView5 == null || viewFindChildViewById == null || linearLayout5 == null || relativeLayout3 == null || linearLayout6 == null || textView6 == null || textView7 == null || imageView3 == null || linearLayout7 == null || textView8 == null || textView9 == null || linearLayout8 == null || textView10 == null || textView11 == null || linearLayout9 == null || textView12 == null || textView13 == null || linearLayout10 == null || textView14 == null || textView15 == null || linearLayout11 == null || textView16 == null || textView17 == null || space2 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new PassportDetailsBinding(relativeLayout, relativeLayout2, imageView, textView, scrollView, linearLayout, linearLayout2, textView2, textView3, space, linearLayout3, linearLayout4, imageView2, textView4, textView5, viewFindChildViewById, linearLayout5, relativeLayout3, linearLayout6, textView6, textView7, imageView3, linearLayout7, textView8, textView9, linearLayout8, textView10, textView11, linearLayout9, textView12, textView13, linearLayout10, textView14, textView15, linearLayout11, textView16, textView17, space2);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static PassportDetailsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static PassportDetailsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.passport_details, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootPassportDetails;
    }
}
