# دراسة شاملة لميزات ملف `dex.zip` من مستودع `shima` (تقرير مرجعي)

> نوع التقرير: **دراسة مرجعية ثابتة** (قراءة فقط) لملف مُرفَق من المستخدم.
> المصدر: `https://github.com/alabedabbas123-max/shima/blob/main/dex.zip`
> لم يُشغَّل أي شيء من الملف، ولم يُستورد إلى مساحة العمل، ولم يُنسخ منه أي كود إلى مشروع ShimaProject.
> الملفات المؤقتة للدراسة كانت في `/tmp/dexstudy` (خارج مساحة العمل) وتُحذف بعد كتابة التقرير.

---

## 0. الملخص التنفيذي

- **ما هو الملف؟** أرشيف يحوي ثلاثة ملفات DEX (`classes.dex` و`classes2.dex` و`classes3.dex`) بحجم مفكوك 22.2 ميغابايت وإصدار DEX `035`. كل الملفات **سليمة**: التوقيع SHA-1 والمجموع Adler-32 وحجم الملف وترتيب البايتات كلها متطابقة.
- **هوية المحتوى:** تطبيق **AIDE (بيئة تطوير Android على الجهاز)**. حزمته الرسمية `com.s1243808733.aide`، وحزمه الداخلية `com.aide.*`. وتظهر في نصوصه نسخ المنتج: *AIDE - Android IDE for Java/C++*، و*AIDE Web*، و*AIDE for Phonegap*، و*AIDE for OUYA*، وحزمة *AIDE NDK Support*.
- **حجم التركيب:** 19,481 صنفًا، و140,493 تعريف دالة (منها 130,855 بتعليمات فعلية)، و71,871 تعريف حقل، و161,737 مرجعًا لدوال، و96,911 توقيعًا مختلفًا من واجهات برمجية مُستدعاة.
- **أهم الميزات (مؤكدة من الأدلة):**
  1. **محرر كود متقدم** مع تلوين نحوي وإكمال وتنقل وبحث واستبدال، واختصارات لوحة مفاتيح (89 اختصارًا).
  2. **محرك تحليل منفصل** يعمل كخدمة عبر واجهات AIDL، ويقدّم الإكمال والتمييز والتنقل وإعادة الهيكلة وبحث الاستخدامات والأخطاء. (التشغيل في عملية مستقلة غير مؤكد من هذا الأرشيف لغياب المانيفست.)
  3. **سلسلة بناء كاملة على الجهاز**: مترجم جافا `javac` مضمّن، و`aapt` لموارد Android، و`dx` لتحويل الصنف إلى DEX، ودمج multidex، وتوقيع APK، وتصغير الكود والموارد (ProGuard وAndResGuard)، وتشفير النصوص كخيار متقدم.
  4. **تشغيل الكود داخل التطبيق** عبر `DexClassLoader` لتشغيل برامج Java المترجَمة.
  5. **مُصحِّح (Debugger)** يعتمد وكيل **ADRT** يُحقن في التطبيق المُصحَّح، مع نقاط توقف، وخطوات (Step In/Over/Out)، وعرض الحقول، وسجل Logcat.
  6. **التحكم بالإصدارات Git** عبر خدمة خارجية (AIDL)، وعميل SSH/SFTP مدمج (JSch)، ومزامنة **Dropbox**.
  7. **مصمّمو واجهات**: مصمّم XML بصري، ومصمّم HTML/Web يعرض المعاينة عبر **خادم HTTP محلي**، ومصمّم PhoneGap، ومستعرض لموارد Android.
  8. **وحدة تعلّم Trainer** فيها نحو 1,323 مورد نصي لدورات (Java وAndroid وGame) مع مهام ونجاح وفشل وأصوات.
  9. **ترخيص واشتراكات** عبر خدمة ترخيص AIDL وحسابات Google ومفاتيح Premium، مع **إعلانات** (AdMob) و**تحليلات** (Firebase وBaidu وAppFour) و**تقارير أعطال** (Crashlytics).
  10. **منصات وإضافات** بنوايا (Intents): AIDE Web وPhoneGap وNDK وC++ وOUYA.
- **نتائج منهجية مهمة:**
  - حزمة `abcd` (2,793 صنفًا) تحوي الجزء الداخلي المُعمّى من التطبيق، وتضم الأصناف `U` و`Vl` و`Tl` و`La` و`Da` و`Mr` و`hb` التي كانت مفقودة من أرشيف المرجع السابق. هذا يفتح دراسة أعمق لمحرك التحليل لاحقًا (وفق البروتوكول).
  - **لا يوجد `AndroidManifest.xml` في الأرشيف**، لذلك لا يمكن من هذا الملف تحديد الصلاحيات المعلنة فعليًا ولا المكونات المسجَّلة.
  - معظم نصوص الصلاحيات (37 نصًا) تأتي من **ثوابت مكتبة utilcode** ومكتبات الإعلانات والتحليلات، وليست دليلًا على ما يطلبه التطبيق نفسه.
  - نسبة كبيرة من الدوال تُستدعى بأسماء تعمية (`j6` و`DW` و`zza` وغيرها) وتُعد ضوضاءً منهجية لا تُقرأ كميزات.

---

## 1. المصدر والمنهج والحدود

### 1.1 المصدر والتحقق
| البند | القيمة |
|---|---|
| المستودع | `alabedabbas123-max/shima` (فرع `main`) |
| محتويات المستودع | 5 ملفات: `README.md` (عنوان فقط)، و`dex.zip`، و`kay_id.zip`، و`res.zip`، و`shima_4_3_0.zip`. **الدراسة تشمل `dex.zip` فقط.** |
| حجم `dex.zip` | 8,638,284 بايت (ويطابق "8.24 MB" في صفحة GitHub) |
| SHA-256 | `10471081defe74eb326db0f66ee1b7515344309b8c63649546408fd464ed0bae` |
| محتوى الأرشيف | 4 إدخالات: مجلد `dex/` وثلاثة ملفات DEX. الحجم المفكوك 22,180,904 بايت، والمضغوط 8,637,712 بايت. |
| سلامة الأرشيف | لا مسارات غير آمنة (Zip-Slip)، ولا ملفات مشفّرة. |

### 1.2 التحقق من ملفات DEX
| الملف | الحجم (بايت) | الإصدار | التوقيع SHA-1 | Adler-32 | حجم الملف | الترتيب |
|---|---:|---|---|---|---|---|
| `classes.dex` | 10,001,828 | 035 | ✔ | ✔ | ✔ | ✔ |
| `classes2.dex` | 7,683,316 | 035 | ✔ | ✔ | ✔ | ✔ |
| `classes3.dex` | 4,495,760 | 035 | ✔ | ✔ | ✔ | ✔ |

### 1.3 المنهج
1. **قراءة بنية DEX مباشرة** بمحلّل كُتب خصيصًا لهذه الدراسة بلغة Python (قراءة فقط، بلا تنفيذ). يقرأ الترويسة وجداول النصوص والأنواع والنماذج والحقول والدوال والأصناف، ويفكّ بيانات الصنف والدوال.
2. **فك تعليمات Dalvik** لكل دالة فيها شيفرة (130,855 دالة) والتحقق من أن الفك ينتهي تمامًا عند حجم التعليمات المعلَن. **النتيجة: صفر حالات عدم تطابق**، وهذا دليل على صحة فك التعليمات ومجدوليتها.
3. **استخراج المراجع** من كل دالة: الدوال المُستدعاة (`invoke`)، والحقول المُقرأة والمكتوبة، والأنواع المُنشأة أو المفحوصة، والنصوص الحرفية المستعملة.
4. **ربط الميزات بالأدلة**: أسماء الأصناف، ومن يستدعي ماذا، وأسماء موارد `AideR` (وهي تكشف الشاشات والقوائم والأوامر)، والنصوص الحرفية.
5. **تصنيف الثقة** لكل استنتاج:
   - **مؤكد:** يستند إلى استدعاء فعلي أو مرجع بنيوي أو نص مستعمل في الشيفرة.
   - **مستنتج:** يستند إلى اسم الصنف أو اسم المورد فقط.
   - **غير مؤكد:** يحتاج دراسة أعمق.

### 1.4 الحدود
- لا يوجد تفكيك إلى كود Java مقروء، لذلك لا يُدّعى فهم تفاصيل الخوارزميات.
- لم يُشغَّل التطبيق، ولا توجد بيانات تشغيل.
- الأسماء مُعمّاة في حزمة `abcd` وكثير من الأصناف (17.5% من الأصناف أسماؤها حرف واحد).
- الأرشيف لا يحوي `AndroidManifest.xml` ولا قيم الموارد (`resources.arsc`)، فلا تُعرف قيم النصوص، ولا الصلاحيات، ولا الإصدار بيقين.

---

## 2. الهوية والتركيب

### 2.1 الهوية (مؤكدة)
- حزمة التطبيق الرسمية: `com.s1243808733.aide` (يحوي `AideMainActivity`، و`AideR` وهو صنف الموارد).
- حزم داخلية: `com.aide.ui` و`com.aide.engine` و`com.aide.common` و`com.aide.uidesigner` و`com.aide.appwizard` و`com.aide.licensing`.
- نصوص المنتج: "AIDE - Android IDE for Java/C++" و"AIDE Web - Html, Css, JavaScript" و"AIDE for Phonegap" و"AIDE for OUYA" و"AIDE NDK Support package".
- **الإصدار:** غير مؤكد من هذا الملف.

### 2.2 أرقام عامة (مؤكدة من بنية DEX)
| المقياس | `classes.dex` | `classes2.dex` | `classes3.dex` | المجموع |
|---|---:|---:|---:|---:|
| الأصناف | 9,043 | 6,922 | 3,516 | **19,481** |
| تعريفات الدوال | 58,078 | 53,332 | 29,083 | **140,493** |
| الدوال بتعليمات (فُكَّت) | 53,640 | 49,928 | 27,287 | **130,855** |
| الدوال بلا شيفرة (مجردة/أصلية) | 4,438 | 3,404 | 1,796 | 9,638 |
| تعريفات الحقول | 33,575 | 28,296 | 10,000 | 71,871 |
| مراجع الدوال (method_ids) | 64,000 | 64,005 | 33,732 | 161,737 |
| النصوص (string_ids) | 39,701 | 48,463 | 30,279 | 118,443 |
| الأنواع (type_ids) | 10,891 | 8,845 | 4,406 | 24,142 |

**أرقام الاستدعاءات (مؤكدة):** 96,911 توقيعًا مختلفًا مُستدعى، و31,008 نصًا حرفيًا مُستعملًا في الشيفرة، و243 دالة مُعلنة كأصلية (native) في 16 صنفًا، منها 116 في LuaJava و82 في `sun.misc.Unsafe` من JDK المضمّن.

### 2.3 توزيع الأصناف حسب الأصل (مؤكد من أسماء الحزم)
| المجموعة | عدد الأصناف | الملاحظة |
|---|---:|---|
| كود AIDE الخاص (`com.aide.*`) | 1,144 | الواجهة 729، والمحرك 122، والمشترك 120، ومصمم الواجهات 106، ومعالج المشاريع 47، والترخيص 19 |
| كود AIDE (`com.s1243808733.*`) | 1,090 | منها 605 صنفًا من مكتبة `dx`/dexlib مُعاد تضمينها تحت حزمة المطوّر [مستنتج]، و377 للتطبيق نفسه، و78 أدوات مساعدة |
| الحزمة المُعمّاة `abcd` | 2,793 | الجزء الداخلي المُعمّى الذي يستدعي واجهات SSH وDropbox وADRT والترخيص والتخزين |
| مكتبات Google (Play Services وAdMob والقياس وGuava وGson وFirebase) | ≈ 5,359 | `com.google.*` |
| دعم Android (androidx وandroid.support وJetifier) | ≈ 2,700 | مكتبات الواجهة والتوافق |
| مترجم جافا المضمَّن (`com.sun.tools` وJDK) | ≈ 700 | `javac` وأدوات JDK (تُضمّن للترجمة على الجهاز) |
| Groovy ومحلّله (ANTLR) | 713 | `org.codehaus.groovy` وgroovyjarjarantlr |
| مكتبات أخرى مُسمّاة (إعلانات وصور وأدوات وSSH وتحليلات...) | ≈ 2,839 | تفصيلها في القسم 6 |
| حزم مُعمّاة لا تُنسب بدقة (`a.*` و`org.a` و`org.c` و`com.a`) | ≈ 1,850 | تحتاج دراسة إضافية |

---

## 3. مكونات أندرويد المُعرَّفة (مؤكدة من وراثة الأصناف)

تُحسب هنا الأصناف المسجَّلة على مستوى الصنف الأعلى (بلا الأصناف الداخلية) لحزم AIDE:

| النوع | العدد | الأمثلة |
|---|---:|---|
| **Activities** | 32 | `MainActivity`، و`AideMainActivity`، و`AppWizardActivity`، و`CommitActivity`، و`GotoBrowserActivity`، و`HelpViewActivity`، و`HighlightActivity`، و`IconActivity`، و`ManifestActivity`، و`OutputConsoleActivity`، و`RunJavaActivity`، و`RunJavaScriptActivity`، و`RunNativeExecutableActivity`، و`RunTrainerJavaActivity`، و`AndroidTrainerActivity`، و`TrainerCourseActivity`، و`ShopExpertPopupActivity`، و`ShopLearningPopupActivity`، و`WebDesignActivity`، و`PhonegapDesignActivity`، و`XmlLayoutDesignActivity`، و`AndroidRActivity`، و`WebTranslateActivity` |
| **Services** | 4 | `CodeAnalysisEngineService` (المحرك)، و`ExternalGitService` (Git)، و`ExternalPackagingService` (التغليف)، و`LicenseUpdateService` (الترخيص) |
| **Broadcast Receivers** | 8 | `ADRTReceiver` (المُصحِّح)، و`TrainerRuntimeReceiver`، و`TrainerNotificationAlarmReceiver`، و`PromoNotificationAlarmReceiver`، و`PackageUpgradedBroadcastReceiver`، و`UserPresentBroadcastReceiver`، و`LicenseUpdateBootReceiver`، و`LicenseUpdateAlarmReceiver` |
| **Application** | 2 | `AIDEApplication`، و`App` |
| **Fragments** | 9 | شاشات الموارد (`FragmentColor`، و`FragmentDrawable`، و`FragmentString`، و`FragmentTheme`...) |
| **شاشات التفضيلات** | 7 | `ApplicationPreferencesFragment`، و`CodestylePreferencesFragment`، و`CompilerPreferencesFragment`، و`DropboxPreferencesFragment`، و`EditorPreferencesFragment`، و`SourceControlPreferencesFragment`، و`KeyBindingsPreferencesFragment` |
| **Content Providers** | 0 (في حزم AIDE) | يُستعمل `FileProvider` من مكتبة الدعم |

---

## 4. كتالوج الميزات بالتفصيل

> الترميز: **[مؤكد]** = دليل بنيوي أو استدعاء فعلي. **[مستنتج]** = من اسم الصنف أو المورد. **[غير مؤكد]** = يحتاج دراسة أعمق.

### 4.1 المحرر وتجربة الكتابة
- **عرض الكود وتحريره** [مؤكد]: `OEditor` و`CodeEditText` (ومعه ثلاث حاويات تمرير) و`SplitView` لتقسيم الشاشة و`WrappingSlidingDrawer` درجًا منزلقًا و`CompletionListView` لقائمة الإكمال.
- **مكوّن نص مفتوح المصدر** [مؤكد]: حزمة `com.myopicmobile.textwarrior` (61 صنفًا) تُستدعى كعرض (View) في المحرر.
- **التلوين النحوي وألوان السمات** [مؤكد]: حزمة `com.s1243808733.aide.highlight` (ColorDefault وColorIndigo وColors وHighlightActivity...). وأسماء السمات `ActivityThemeDesignerDark/Light`.
- **أوامر التحرير الأساسية** [مؤكد من أسماء الأوامر]: نسخ، وقص، ولصق، وتراجع، وإعادة، وتحديد، وتحرير، ووضع تحرير، وتنقّل.
- **الحفظ التلقائي** [مؤكد من الموارد]: `pref_autosave_entries` و`pref_autosave_values`. [مستنتج] للتفعيل والفاصل الزمني.
- **المسافة البادئة** [مؤكد من الموارد]: `pref_tabsize_entries` و`pref_tabsize_values`.
- **اختصارات لوحة المفاتيح** [مؤكد]: 89 مفتاح `keybind_*`، ومعها `KeyStrokeDetector` و`KeyStrokeEditText` و`CustomKeysListView`، وشريط مفاتيح سريع `quickkeysbar`.
- **منتقي الأحرف الخاصة** [مؤكد من اسم الاختصار]: `keybind_show_char_picker`.
- **مساعدة صوتية (تحويل النص إلى كلام)** [مؤكد]: `TextToSpeechHelper` يستدعي `TextToSpeech` (شوهد في الاستدعاءات).
- **منتقي الألوان** [مؤكد]: `ColorPickerView` و`dialog_color_picker`، ومكتبة `net.margaritov` للألوان.
- **التراجع المدمج** [مؤكد]: `UndoManager` (في المشترك).

### 4.2 التحليل والإكمال والتنقل والبحث
- **محرك تحليل منفصل** [مؤكد]: خدمة `CodeAnalysisEngineService` تتكلم مع التطبيق عبر `ICodeAnalysisEngineService`، وتُشغَّل كخدمة بإشعار مرافق [مستنتج من استدعاء مرتبط بالإشعار]. يستدعيها 57 صنفًا على الأقل. وعزلها في عملية مستقلة غير مؤكد من الأرشيف.
- **مستمعو المحرك (AIDL)** [مؤكد]: إكمال، وتمييز، وتنقل، وإعادة هيكلة، وبحث استخدامات، وأخطاء، وبناء، وفتح ملف، وتحديد رمز.
- **نماذج المحرك** [مؤكد من الأسماء]: `EngineSolution` و`EngineSolutionProject` و`SourceEntity` و`SyntaxError` و`FileHighlightings` و`FindResult` و`Modification`.
- **عرض الأخطاء** [مؤكد]: `ErrorBrowser` و`AIDEErrorsView` و`AIDEAnalysisProgressBar` وشاشة `error_popup`. ويوجد نصوص `view_errors` و`view_no_errors`.
- **الإكمال** [مؤكد]: `CompletionAdapter` و`ApiInfo` و`ApiVersion` و`ClassApi` (بيانات واجهات Android حسب الإصدار) مع شاشة `completion_list`.
- **الانتقال إلى الرمز** [مؤكد]: `GotoBrowserActivity` و`ActivityGotoLayout`، وأوامر `go_to` و`goto_line` و`go_to_definition` و`go_to_element`، واختصارات `goto_class` و`goto_symbol` و`goto_next_error` و`goto_pre_error`.
- **التنقل السابق واللاحق** [مؤكد من الاختصارات]: `keybind_go_back` و`keybind_go_forward`.
- **البحث** [مؤكد]: في الملف (`find_in_file`)، وفي المشروع (`find_in_project`)، ونصيًا (`find_textually`)، وبحث الاستخدامات (`find_usages`) والموسّع (`find_extended_usages`). وتوجد `SearchBrowser` و`FindResultTextView` وشاشة `replace` للاستبدال النصي (`replace_textually`).
- **متصفح الملفات** [مؤكد]: `FileBrowser` و`FileBrowserAdapter` و`FileItemManager` و`FileOptions` وقائمة `filebrowser_context_menu`.

### 4.3 إعادة الهيكلة والتوليد
- **إعادة التسمية** [مؤكد]: `command_rename` و`files_rename`، وترتبط بمستمع إعادة الهيكلة `IRefactoringListener` [مستنتج].
- **استخراج دالة** [مؤكد]: `extract_method` (+ اختصار `keybind_extract_method`).
- **استخراج موارد** [مؤكد]: `extract_resources`.
- **تضمين متغير وإدخال متغير** [مؤكد]: `inline_variable` و`introduce_variable`.
- **توليد بانٍ وGetters/Setters** [مؤكد]: `create_constructor` و`create_setters_and_getters` (+ `keybind_constructor` و`keybind_setters`).
- **Try/Catch تلقائي** [مؤكد]: `surround_with_trycatch` (+ `keybind_try_catch`).
- **تعليق/إلغاء تعليق الكود** [مؤكد]: `outcomment_code` و`unoutcomment_code`.
- **إصلاح سريع** [مؤكد]: أمر `fix`، وهو مرتبط بقائمة مقترحات.

### 4.4 التنسيق والاستيرادات والأسلوب
- **مُنسّق Google Java Format مضمّن** [مؤكد]: حزمة `com.google.googlejavaformat` (141 صنفًا) تُستدعى (مثل `Formatter.formatSource`)، ويوجد حدث `CodeFormatEvent`.
- **خيارات أسلوب الكتابة** [مؤكد من الإعدادات]: مجموعات `java_indent`، و`java_space_options`، و`java_wrap_options`، و`java_nl_options`، و`java_import`، وأيضًا `xml_indent`، و`html_indent`، و`css_indent`، و`js_indent`، و`c_indent`.
- **تنظيم الاستيرادات** [مؤكد]: `organize_imports` واختصار `keybind_organize_imports`.
- **تعلّم نمط الكود** [مؤكد من الأوامر]: `learn_code_style` و`configure_code_style`.

### 4.5 المشاريع والقوالب والمعالج
- **أنواع المشاريع** [مؤكد من الأوامر]: مشروع Android (مع Java وC++)، ومشروع Java، ومشروع JavaScript، ومشروع موقع Web، ومشروع PhoneGap، ومشروع ملف تنفيذي أصلي (`files_open_*_project`).
- **معالج إنشاء المشروع** [مؤكد]: `ProjectDialog` و`TemplateAdapter` و`TemplateView`، مع بيانات تصنيفات `CategoryList` و`Category`.
- **معالج التطبيقات** [مؤكد]: `AppWizardActivity` و`AppWizardDesignActivity` وحزمة `com.aide.appwizard` (47 صنفًا).
- **إنشاء الملفات والأصناف** [مؤكد]: `CreateClassDialog` و`CreateXMLDialog` (أوامر `files_add_new_class` و`files_add_new_xml`).
- **تحويل المشروع** [مؤكد]: `ConverProject`.
- **المكتبات والـJAR** [مؤكد]: `files_add_library_to_project` و`files_remove_library_from_project` و`files_set_as_androidjar` ونصوص `dialog_add_to_project_existing_jar_file`.
- **خصائص المشروع** [مؤكد]: `files_project_properties`.
- **جلسة الملفات المفتوحة** [مؤكد]: `OpenedFiles`.

### 4.6 البناء والتجميع والتوزيع
- **موارد Android (aapt)** [مؤكد]: `AaptService` (مع 42 توقيعًا مرتبطًا)، ونصوص `aapt call elapsed` و`aapt failed!`.
- **تحويل الصنف إلى DEX (dx)** [مؤكد]: حزمة `com.s1243808733.android.dx` (3,391 توقيعًا مرتبطًا) وتشمل `dexer.Main` ونصوص `dx version`.
- **دمج Multidex** [مؤكد]: `ApkDexMergeUtils` و`DexMergerEvent` وحزمة `multidex` الخاصة بـClassReferenceListBuilder.
- **مترجم جافا المضمَّن** [مؤكد الوجود]: `javax.tools.ToolProvider` و`com.sun.tools.javac` (4,034 توقيعًا مرتبطًا، 561 صنفًا). ونصوص `javac Filer` و`javac Messager` و`javac ProcessingEnvironment` تدل على مكوّنات معالجة التعليقات. [مستنتج] لطريقة ربطه بمسار البناء.
- **بناء Gradle** [مؤكد من الأوامر والأصناف]: `GradleBuilder` و`GradleProject` و`GradleBuilEvent` ونصوص `gradle assembleDebug` و`gradle assembleRelease` و`gradle build` و`gradle clean`.
- **محلّل Groovy** [مستنتج]: حزمة `org.codehaus.groovy` (489 صنفًا) و`groovyjarjarantlr` (224) وتُستدعى بنحو 1,698 توقيعًا (مع ضوضاء). يُرجَّح استعمالها لقراءة سكربتات Gradle.
- **تبعيات Maven** [مؤكد]: `DependencieDialog` و`DependencieAdapter` و`ArtifactMapping` و`ItemView`، ومستودعات `repo.maven.apache.org` و`jcenter.bintray.com` و`dl.google.com`، ومسار محلي `/.aide/maven`.
- **توقيع APK** [مؤكد]: شاشة `createkeystore` لإنشاء مخزن مفاتيح، وفئة إعدادات `preference_category_apk_sign`، ومكتبة توقيع `kellinwood` (تُستدعى من `sigblock`).
- **تصغير الكود (ProGuard)** [مؤكد]: `AIDEUtils.isUseProguard()` و`proguard_title`.
- **تصغير الموارد (AndResGuard)** [مؤكد]: `AndResGuard.proguard` و`delectResourcesAps`، مع مكتبة ResourceProguard.
- **تشفير النصوص (StringFog)** [مؤكد]: إعداد متقدم `AdvancedSetting.isEnableStringFog()`، وتنفيذه على ملفات الصنف الناتجة عبر `StringFog.doFog(File)`.
- **تصدير APK** [مؤكد من الشاشة]: `exportapk`.
- **تثبيت وإزالة التطبيقات** [مؤكد]: `InstallDialogFragment` و`UnInstallDialogFragment` و`UnInstallTask`، ونص أمر الصدفة `pm install -r`.
- **خيارات البناء** [مؤكد]: متغيرات البناء `command_build_variants`، وإعادة البناء `refresh_build`، وتشغيل أمر `RunCommandDialog`.
- **مخرجات البناء** [مؤكد]: `OutputConsole` و`OutputConsoleActivity` و`BuildInfo`.
- **تغليف خارجي** [مؤكد]: خدمة `ExternalPackagingService` عبر AIDL.
- **النشر** [مؤكد]: أمر `publish_project`، ويرتبط بتغليف الإصدار.

### 4.7 التشغيل والتصحيح والسجلات
- **تشغيل Java داخل التطبيق** [مؤكد]: `RunJavaActivity` تستدعي `DexClassLoader`، ويستدعيه أيضًا الصنف `build.android.P`. وترتبط بالشاشة نفسها أسماء وكيل ADRT [مستنتج أن الوكيل يُحقن في البرنامج المُشغَّل].
- **تشغيل JavaScript** [مستنتج]: `RunJavaScriptActivity`.
- **تشغيل ملفات تنفيذية أصلية** [مستنتج]: `RunNativeExecutableActivity`.
- **المُصحِّح (Debugger)** [مؤكد]:
  - وكيل **ADRT** (حزمة `adrt`: `ADRT` و`ADRTSender` و`ADRTThread` و`ADRTReflector` و`ADRTLogCatReader`...). ويظهر اسمه في شاشة تشغيل Java، ويُرجَّح أنه يُضاف إلى البرنامج المُصحَّح [مستنتج].
  - بثوث الأوامر: `com.adrt.CONNECT` و`DISCONNECT` و`SET_BREAKPOINTS` و`BREAKPOINT_HIT` و`STEP_IN` و`STEP_OVER` و`STEP_OUT` و`RESUME` و`STOP` و`KILL` و`GET_FIELDS` و`FIELDS` و`LOGCAT_ENTRIES`.
  - شاشات `Debugger` و`DebugView` و`DebugBrowser` وأوامر `breakpoint` و`step_in` و`step_out` و`step_over` و`debugger`.
  - إعداد متقدم `advanced_setting_enable_adrt`.
- **Logcat** [مؤكد]: `LogCatBrowser`. ويُستدعى `Runtime.exec` من `ADRTLogCatReader`، ونص `logcat -v threadtime` موجود (ويُرجَّح أنه أمر القراءة) [مستنتج]. وأوامر التصفية: حسب الأولوية، والعملية، والوسم، والتطبيق الحالي، وأوامر إيقاف واستئناف ومسح. ونية `VIEW_LOGCAT_ENTRY` لفتح سطر سجل.
- **الأخطاء وتقارير التعطل** [مؤكد]: `CrashUtils` و`CrashActiviy` مع Crashlytics وFabric.

### 4.8 التحكم بالإصدارات والمزامنة
- **Git عبر خدمة خارجية** [مؤكد]: `ExternalGitService` عبر `IExternalGitService` و`IExternalGitServiceListener` (18 و14 إشارة). والحزمة `com.aide.ui.scm` (101 صنف) تضم `GitStatus` و`GitConfiguration` و`DiffView` و`ModifiedFile` و`ModifiedFileListEntry`، وشاشة `CommitActivity`، وشاشات `gitclonerepository` و`gitcommitdata`، وقائمة `git_context_menu`.
- **أوامر Git** [مؤكد من الأوامر]: الفروع (`git_branches`)، والتبديل (`git_checkout_branch`)، والإيداع (`git_commit`)، وإنشاء فرع (`git_create_branch`)، وحذف فرع (`git_delete_branch`)، ودمج فرع (`git_merge_branch`)، والسحب (`git_pull`)، والدفع (`git_push`)، والاستنساخ (`files_clone_git_repository`).
- **بروتوكولات Git عبر SSH** [مؤكد من النصوص]: `git-upload-pack` و`git-receive-pack` و`git+ssh` و`ssh-rsa` و`ssh-dss`.
- **SSH/SFTP** [مؤكد]: مكتبة JSch (147 صنفًا، 632 توقيعًا مرتبطًا بـ91 صنفًا، منها 338 ضوضاءً). ويُنشأ `JSch` مرة واحدة من `abcd` (صنف `tI`).
- **Dropbox** [مؤكد]: SDK من الإصدار 1 (`com.dropbox.client2`)، وشاشة المصادقة `AuthActivity`، وشاشة التفضيلات `DropboxPreferencesFragment`، وشاشة `downloaddropbox`، وأوامر `files_sync_dropbox_folder` و`files_download_dropbox_folder`، ونص خطأ "Broken AIDE dropbox sync info".

### 4.9 المصممون وأدوات الواجهات
- **مصمم XML بصري** [مؤكد]: `XmlLayoutDesignActivity` وحزمة `com.aide.uidesigner` (106 صنفًا، أصناف بادئتها `Proxy*` مثل `ProxyTextView` و`ProxyRelativeLayoutParams`)، وشاشات `designer` و`designer_sizedialog` و`designer_widgetlist_*` و`designer_viewlist_entry`، وأمر `design`.
- **مصمم Web/HTML** [مؤكد]: `WebDesignActivity` وحزمة `com.aide.ui.htmluidesigner` (25 صنفًا).
- **خادم HTTP محلي للمعاينة** [مؤكد]: صنف `htmluidesigner.v` يفتح `ServerSocket` ويرد برأس `Server: AIDE`، مع شاشة `webpreview`.
- **مصمم PhoneGap** [مؤكد]: `PhonegapDesignActivity`.
- **مستعرض موارد Android** [مؤكد]: `AndroidRActivity` وشاشات `FragmentColor` و`FragmentDrawable` و`FragmentString` و`FragmentTextAppearance` و`FragmentTheme` و`FragmentThemePreview` و`FragmentMain`.
- **محرر الأيقونات** [مؤكد]: `IconActivity` مع مهمة تحميل الأيقونات، ورابط تطبيق أيقونات خارجي.
- **محرر المانيفست** [مؤكد]: `ManifestActivity` مع `ManifestAdapter` و`SearchAdapter` لاختيار الصلاحيات. ونص `com.aide.merger.AndroidManifestMerger` يدل على دمج المانيفست [مستنتج].

### 4.10 التعلّم والتدريب (Trainer)
- **شاشات الدورات** [مؤكد]: `AndroidTrainerActivity` و`TrainerCourseActivity` و`RunTrainerJavaActivity`، والحالة `TrainerState`، والمستقبِلات `TrainerRuntimeReceiver` و`TrainerNotificationAlarmReceiver`.
- **محتوى الدورات** [مؤكد من أسماء الموارد]: نحو **1,323** مورد نصي بالبادئة `course_`: دورات Java (572 موردًا)، وAndroid (551)، والألعاب (200). وتتكرر فيها مهام ونجاح وفشل لكل درس.
- **أصوات التدريب** [مؤكد من الموارد الخام]: `click` و`fail` و`success_lesson` و`success_task` و`task`.
- **قوائم التدريب** [مؤكد]: `trainer_options_menu` و`main_trainer_options_menu`.
- **نصوص التدريب الإضافية** [مؤكد]: 51 مورد `trainer_*`، مثل `trainer_ask_a_question` و`trainer_next_exercise`.

### 4.11 المساعدة والتوثيق والتحديثات
- **المساعدة** [مؤكد]: `HelpViewActivity` وقائمة `help_options_menu`.
- **التوثيق** [مؤكد]: أمر `documentation` و`download_docs` (تنزيل وثائق Android عبر `dl-ssl.google.com`) و`community`.
- **ما الجديد** [مؤكد]: `WhatsNewDialog` ومورد `dialog_whatsnew_item`، وأصول `whatsnew/aide-whatsnew.txt` و`aide-web-whatsnew.txt` و`aide-phonegap-whatsnew.txt`.

### 4.12 الإعدادات والتخصيص
- **شاشات الإعدادات** [مؤكد]: `preferences_headers` و`preferences_application` و`preferences_codestyle` و`preferences_compiler` و`preferences_dropbox` و`preferences_editor` و`preferences_sourcecontrol` و`preferences_advanced_setting`، مع `PreferencesActivity` و`AboutActivity`.
- **فئات الإعدادات (24 فئة)** [مؤكد]: التفضيلات الخاصة بـ APK signing، وC/C++ indent، والإكمال، وCSS، وDex، والخط، وGit، وGradle، والمساعدة، وHTML indent، وJava (الاستيراد والمسافات والالتفافات والأسطر)، وJS indent، ولوحة المفاتيح، والكود الأصلي NDK، والتشغيل، والحفظ، وSDK، والمسافات، وXML indent.
- **اللغة** [مؤكد من المصفوفات]: `pref_language_entries` و`pref_language_values`.
- **الإعدادات المتقدمة** [مؤكد]: `AdvancedSetting` ومنها `advanced_setting_enable_adrt` وتفعيل تشفير النصوص `isEnableStringFog()`، ونص `advanced_settings`.
- **ثيمات الواجهة** [مؤكد]: `dark_theme` و`light_theme` مع أنماط `ActivityThemeDesignerDark/Light`.

### 4.13 الترخيص والاشتراكات والمتجر
- **خدمة ترخيص مخصّصة** [مؤكد]: `IAideLicensingService` و`IAideLicenseResultListener` و`LicenseUpdateService` و`LicenseUpdateAlarmReceiver` و`LicenseUpdateBootReceiver`، وحزمة `com.aide.licensing` (19 صنفًا).
- **قراءة حسابات Google ومعرّف الجهاز داخل وحدة الترخيص** [مؤكد]: `AccountManager.getAccountsByType` وطريقة `TelephonyManager.getDeviceId/getImei` تُستدعيان من `com.aide.licensing.i`.
- **مفاتيح الاشتراك Premium** [مؤكد]: نصوص `com.aide.premium.key` و`com.aide.java.premium.key` و"AIDE Premium key outdated".
- **التحقق من الشراء داخل التطبيق** [مؤكد]: نص "AIDE does not have in-app billing permission". ويحوي `abcd` استدعاءً لتسجيل شراء عبر خدمة الاشتراكات الخارجية (المضيف `api.appfour.com`).
- **عناصر متجر ومميزات مدفوعة** [مؤكد]: `ShopExpertPopupActivity` و`ShopLearningPopupActivity` و36 مورد `shop_*`، و`PremiumCheckBoxPreference` و`PremiumEditTextPreference`، وأمر `unlock_all_features`، وشارات `badge_sale` و`badge_best_value` و`badge_seven_day_free_trial`.
- **ترويج** [مؤكد]: `PromoNotificationAlarmReceiver` ومورد `promo_dialog`.

### 4.14 الإعلانات والتحليلات والإشعارات
- **إعلانات** [مؤكد]: حزمة AdMob (`com.google.android.gms.ads`) وعناوين `googleads.g.doubleclick.net` و`pagead2.googlesyndication.com` و`imasdk.googleapis.com`، وموارد `ad_banner_editor` و`ad_interstitial_run_android` و`ad_interstitial_run_java`.
- **تحليلات** [مؤكد]: قياسات Firebase/Google (`app-measurement.com`)، وBaidu MobStat (عناوين `dxp.baidu.com` و`hmma.baidu.com` و`openrcv.baidu.com` و`datax.baidu.com`)، وAppFour Backbone (عناوين `api.appfour.com` و`backbone-cdn/direct/ingest.appfour.com`، وأصناف `DefineAnalytics` و`EventData` و`InAppProduct` و`Market`...).
- **تقارير الأعطال** [مؤكد]: Crashlytics وFabric (`e.crashlytics.com` و`settings.crashlytics.com`).
- **إشعارات التحديث** [مؤكد]: `notify_title_new_aide` و`notify_text_new_ver` و`PackageUpgradedBroadcastReceiver` ونص "AIDE is outdated".

### 4.15 الترجمة والخدمات الخارجية
- **ترجمة بمحركات خارجية** [مؤكد]: `WebTranslateActivity` و`YouDaoTranslation` (خدمة YouDao) و`BeanYandex` (Yandex) وقاموس QQ (`dictweb.translator.qq.com`)، و`TranslateTable` و`TranslateUtils` في الإكمال.
- **ملاحظة أمنية:** يحوي الملف مفاتيح واجهات خاصة بالخدمات الخارجية. لا تُنقل قيمها في هذا التقرير، ويُكتفى بأسماء الخدمات.

### 4.16 المنصات والإضافات (نقاط التكامل)
- **إضافات بنوايا** [مؤكد]: `com.aide.web` (33 ذكرًا)، و`com.aide.phonegap` (19)، و`com.aide.ndk` (7)، و`com.aide.cpp`، و`com.aide.designer`، و`com.aide.trainer.java`. يُرجَّح أنها تفتح إضافات منفصلة.
- **منصة OUYA** [مؤكد]: حزمة `tv.ouya.console.api` (42 صنفًا)، والمورد الخام `ouya_key`، ونص "AIDE for OUYA".
- **دعم NDK** [مؤكد]: `InstallNdk` (مهمة تثبيت الـNDK)، ونص "android-ndk-aide"، ونص "The AIDE NDK Support package is outdated".
- **نظام تغليف وتوزيع Wear** [مستنتج]: موارد `android_wear_development` و`common_android_wear_*`.
- **حزمة WeChat** [غير مؤكد الوظيفة]: `com.tencent.mm` (43 صنفًا) ويضم أيضًا أدوات ResourceProguard وفك موارد (androlib).

---

## 5. الواجهات الداخلية والبث والنيّات

### 5.1 واجهات AIDL (مؤكدة)
| الواجهة | الدور | عدد الإشارات |
|---|---|---:|
| `ICodeAnalysisEngineService` | واجهة المحرك الرئيسية | 62 |
| `ICodeCompletionListener` / `IHighlightingListener` / `INavigationListener` / `IRefactoringListener` / `IUsageSearcherListener` / `IEngineErrorListener` / `IEngineListener` / `IGotoSymbolListener` / `IBuildListener` / `IOpenFileInterface` | مستمعو المحرك وواجهة فتح الملفات | 5 إلى 8 لكل واجهة |
| `IExternalGitService` / `IExternalGitServiceListener` | خدمة Git الخارجية | 18 / 14 |
| `IExternalPackagingService` / `IExternalPackagingServiceListener` | خدمة التغليف الخارجية | 6 / 7 |
| `IAideLicensingService` / `IAideLicenseResultListener` | خدمة الترخيص | 4 / 5 |

### 5.2 بثوث البرمجة (مؤكدة)
- **المُصحِّح:** `com.adrt.CONNECT` و`DISCONNECT` و`SET_BREAKPOINTS` و`BREAKPOINT_HIT` و`STEP_IN` و`STEP_OVER` و`STEP_OUT` و`RESUME` و`STOP` و`KILL` و`GET_FIELDS` و`FIELDS` و`LOGCAT_ENTRIES`.
- **السجل:** `com.aide.runtime.VIEW_LOGCAT_ENTRY`.
- **النظام:** `BATTERY_CHANGED` و`ACTION_POWER_CONNECTED/DISCONNECTED` و`SCREEN_ON/OFF` و`USER_PRESENT` و`USER_UNLOCKED` و`SHUTDOWN` و`MEDIA_BUTTON` و`MEDIA_SCANNER_SCAN_FILE`.

### 5.3 النيّات (Intents) المستعملة (مؤكدة)
- **الملفات:** `GET_CONTENT` و`OPEN_DOCUMENT` و`OPEN_DOCUMENT_TREE` و`CREATE_DOCUMENT` و`PICK`، وهذا يدل على دعم وصول المستندات (SAF).
- **المشاركة والفتح:** `SEND` و`SEND_MULTIPLE` و`VIEW` و`EDIT` و`INSERT` و`DELETE` و`DIAL` و`CALL` و`PROCESS_TEXT`.
- **الإضافات:** `com.aide.web` و`com.aide.phonegap` و`com.aide.ndk` و`com.aide.cpp` و`com.aide.designer` و`com.aide.trainer.java`.

---

## 6. المكتبات والمكوّنات المضمّنة (مستخلصة من أسماء الحزم والاستدعاءات)

| المكوّن | عدد الأصناف | الدور المستنتج | مستوى الثقة |
|---|---:|---|---|
| Google Play Services وAdMob وقياس Google | ≈ 3,023 | إعلانات وقياس وخدمات | مؤكد |
| Guava (`com.google.common`) | 1,885 | مكتبة مجموعات | مؤكد |
| Gson (`com.google.gson`) | 180 | تحويل JSON | مؤكد (620 توقيعًا مرتبطًا) |
| Google Java Format | 141 | تنسيق كود Java | مؤكد |
| Firebase | 96 | قياس وخدمات Firebase | مؤكد |
| دعم Android (androidx وandroid.support وJetifier) | ≈ 2,700 | مكتبات الواجهة | مؤكد |
| Glide (`com.bumptech.glide`) | 395 | تحميل الصور | مؤكد (1,449 توقيعًا) |
| Baidu MobStat | ≈ 314 | إحصاءات | مؤكد (1,515 توقيعًا، ونسبة كبيرة منها ضوضاء) |
| utilcode (`com.blankj.utilcode` + `utilcode`) | ≈ 460 | أدوات مساعدة (صلاحيات، أمر صدفة، شبكة، هاتف، فلاش) | مؤكد |
| Crashlytics وFabric | ≈ 240 | تقارير الأعطال | مؤكد |
| ASM (`org.objectweb.asm`) | 166 | توليد وتحليل بايت كود | مؤكد (1,088 توقيعًا) |
| JSch (`com.jcraft.jsch`) | 147 | SSH وSFTP | مؤكد |
| Groovy وANTLR | 713 | تحليل سكربتات Gradle [مستنتج] | مستنتج |
| dom4j | 190 | معالجة XML | مؤكد |
| xUtils (`org.xutils`) | 190 | HTTP وقاعدة بيانات وصور | مؤكد |
| Apache Commons (`org.apache`) | 127 | أدوات | مؤكد |
| AndroidSVG (`com.caverock`) | 125 | عرض SVG | مؤكد |
| StringFog (`com.github.megatronking`) | 116 | تشفير النصوص | مؤكد |
| TextWarrior (`com.myopicmobile`) | 61 | عرض نص قابل للتمرير | مؤكد |
| AppFour Backbone (`com.appfour`) | 54 | تحليلات وشراء داخل التطبيق وإشعارات | مؤكد |
| OUYA SDK (`tv.ouya`) | 42 | منصة OUYA | مؤكد |
| `com.a4455jkjh` | 44 | NDK ومنتقي الألوان وشاشات الصلاحيات | مؤكد |
| Lua وLuaJava (`com.androlua`، `com.luajava`) | 7 + 14 | محرّر Lua ومُغلّف JNI (116 دالة أصلية في LuaState) | مؤكد |
| `com.s1243808733.android` (dx/dexlib) | 605 | تحويل DEX ودمجه | مؤكد |
| `com.sun.tools` وJDK (`javac` وأدوات) | ≈ 700 | مترجم Java على الجهاز | مؤكد |
| sun.misc وsun.reflect | ≈ 290 | أصناف JDK داخلية (مع دوال أصلية) | مؤكد |
| kellinwood (zipsign) | 2 | توقيع APK | مؤكد |
| ADRT | 2 (+ داخل `abcd`) | وكيل المُصحِّح | مؤكد |
| مكتبة Tencent (`com.tencent`) | 43 | ResourceProguard وفك موارد وWeChat | مستنتج |
| `abcd` | 2,793 | المنطق الداخلي المُعمّى | مؤكد (وجود)، غير مؤكد (الوظيفة التفصيلية) |

---

## 7. القدرات الحساسة (لأغراض الفهم والتصميم فقط)

| القدرة | الدليل | الملاحظة |
|---|---|---|
| تنفيذ أوامر الصدفة | `Runtime.exec` و`ProcessBuilder` يُستدعيان من 18 صنفًا، منها `ADRTLogCatReader` (للسجل)، و`ShellUtils` (utilcode)، و`htmluidesigner` و`abcd` | مؤكد. تفاصيل الاستعمال داخل `abcd` غير مؤكدة. |
| تحميل كود ديناميكي | `DexClassLoader` و`PathClassLoader` يُستدعيان من 5 أصناف، منها `RunJavaActivity` | مؤكد. وظيفة تشغيل Java داخل التطبيق. |
| تحميل مكتبات أصلية | `System.loadLibrary` (3 أصناف) و243 دالة مُعلنة أصلية | مؤكد. تشمل LuaJava وNDK وCrashHandler، ومعظم الدوال الأصلية من JDK المضمّن. |
| الانعكاس Reflection | `Class.forName` و`Method.invoke` (322 صنفًا مُستدعيًا) | مؤكد. مرتبط بالمُصحِّح وبتحليل الأصناف. |
| معرّف الجهاز | `TelephonyManager.getDeviceId/getImei` من `com.aide.licensing.i` و`Baidu` | مؤكد. مرتبط بالترخيص. |
| حسابات Google | `AccountManager.getAccountsByType` من `com.aide.licensing.i` و`abcd` | مؤكد. مرتبط بالترخيص. |
| الاتصال بالشبكة وSSL | HttpURLConnection وSSLSocket وHttpsURLConnection (84 صنفًا) | مؤكد. |
| تشفير | javax.crypto (49 صنفًا) وKeyStore (6 أصناف) | مؤكد. |
| SSH/SFTP | JSch (91 صنفًا) | مؤكد. |
| الملفات والتخزين | `java.io.File` (486 صنفًا) و`Environment` (32 صنفًا) | مؤكد. |
| خادم HTTP محلي | `ServerSocket` في `htmluidesigner.v` | مؤكد. للمعاينة. |
| مراقبة العمليات | `ActivityManager.getRunningAppProcesses/getRunningTasks` (22 صنفًا) | مؤكد. يُرجَّح للمُصحِّح والسجل. |
| الكاميرا والفلاش | `Camera.open` من `FlashlightUtils` (utilcode) فقط | مستنتج: ليست ميزة كاميرا في التطبيق. |
| نصوص تدل على الجذر | `su` و`/system/bin/failsafe/` | نصوص موجودة؛ لم يُثبت استخدامها كميزة. |
| الإشعارات والمنبهات والبث عند الإقلاع | `AlarmManager` (5 أصناف) و`LicenseUpdateBootReceiver` | مؤكد. مرتبط بالترخيص والتذكيرات. |

**ملاحظة:** هذه القدرات تفسّر الصلاحيات التي يحتاجها التطبيق الأصلي، ولا تُنقل إلى مشروعنا تلقائيًا. كل قدرة تحتاج قرارًا مستقلًا وموافقة المستخدم.

---

## 8. ملاحظات منهجية وجودة الكود (مؤكدة)

1. **تعمية الأسماء:** 3,417 صنفًا (17.5%) أسماؤها حرف واحد، وتتركز في `abcd` وفي حزم `a.*`.
2. **دوال الضوضاء:** تتكرر أسماء مثل `j6` و`DW` و`zza` في آلاف الاستدعاءات، وهي غالبًا أدوات تعمية أو قياس داخلية من المكتبات والتطبيق. لذلك أُستبعدت من تقدير القدرات، ومنها: 338 توقيعًا من 632 في JSch، و316 من 851 في AdMob، و377 من 1,407 في قياسات Firebase، و468 من 938 في Crashlytics، و1,004 من 1,515 في Baidu.
3. **موارد عابرة:** توجد أسماء `APKTOOL_DUMMY_*` في صنف `AideR` (نحو 16 اسمًا في النصوص)، وهي أثر لأداة فك/إعادة تجميع APK ولا تمثل ميزة.
4. **نصوص الصلاحيات:** 36 نصًا `android.permission.*`. معظمها في `PermissionConstants` (utilcode) بعدد 26 استعمالًا، وفي مكتبات الإعلانات والقياس. لذلك لا تعني أن التطبيق يطلبها.
5. **الإصدار:** لا توجد قيمة إصدار موثوقة في النصوص، والأرقام مثل `16.3.9` و`4.7.2` تعود لمكتبات مختلفة.
6. **التكرار:** المكتبات مكررة في أكثر من حزمة (مثل `androidj.support` و`android.support` و`androidx`)، وهذا أثر لأداة Jetifier.
7. **المفاتيح والقيم الحساسة:** تحوي الموارد أسماء مفاتيح خدمات (مثل `google_api_key`)، ولا تُنقل قيمها.

---

## 9. مقارنة مبدئية مع ShimaProject (مبنية على بحث قرائي في شيفرتنا)

> الحالة مبنية على وجود الأصناف والأوامر في الشيفرة الحالية (1.0.101)، لا على اختبار وظيفي. ويُعدّ الجدول قائمة فجوات تساعد في القرار، وليس تقييمًا نهائيًا.

| الميزة | المرجع (dex.zip) | ShimaProject الآن | الحالة |
|---|---|---|---|
| محرر كود ملوّن وتزايدي | محرر مخصص + TextWarrior | `CodeCanvasView` و`LineStyler` | موجود |
| إكمال الكود | محرك خارجي + قوائم + بيانات API | `CompletionTrie` و`KayStyleCompletionEngine` و`XmlCompletionEngine` | جزئي |
| تشخيص الأخطاء | محرك تحليل خارجي (AIDL) | محلل نحوي جديد (1.0.101) بلا دلالة | جزئي |
| الإصلاح السريع | قائمة مقترحات كاملة | أمر `fix` وقائمة لعضو مفقود (1.0.100) | جزئي |
| الانتقال إلى التعريف | `GotoBrowserActivity` وأوامر كثيرة | أوامر `go_to_definition` و`goto_line` | موجود |
| بحث الاستخدامات والبحث في المشروع | `SearchBrowser` و`find_usages` | `ProjectSearchEngine` | موجود |
| إعادة التسمية والاستخراج والتضمين | موجود | `Renamer` و`Refactor` و`CodeGen` | موجود |
| تنسيق الكود | Google Java Format | مُنسّق خاص (`CodeLanguageTools.format`) و`JavaImportOrganizer` | جزئي |
| اختصارات لوحة المفاتيح | 89 اختصارًا | `Keybinds` وشاشة تفضيلات | جزئي |
| Logcat | متصفح وفلاتر ومشاركة | `LogCatConsole` وأمر `show_logcat` بلا فلاتر منفصلة | جزئي |
| المُصحِّح | وكيل ADRT ونقاط توقف وخطوات | نقاط توقف مرئية فقط | غير موجود |
| Git | خدمة Git كاملة وفروع وفروقات واستنساخ | أوامر `pull` و`push` و`commit` عبر أداة git على الجهاز | جزئي ضعيف |
| SSH/SFTP | JSch | غير موجود | غير موجود |
| Dropbox | مزامنة ومصادقة OAuth | تفضيل تلقائي ومرآة محلية | جزئي |
| بناء APK | aapt وdx وjavac وGradle وتوقيع وProGuard | تشغيل `sh gradlew <task> --no-daemon` من `MainActivity` وتوقيع PKCS12 وإنشاء `proguard-rules.pro` | جزئي |
| تشغيل Java داخل التطبيق | DexClassLoader | غير موجود | غير موجود |
| NDK | تثبيت NDK وإضافة | مفتاح تثبيت NDK (`install_uninstall_ndksupport`) | جزئي |
| مصمم XML بصري | مصمم كامل | `DesignerActivity` (829 سطرًا) | جزئي (يحتاج مقارنة) |
| معاينة Web بخادم محلي | نعم | غير موجود | غير موجود |
| مستعرض موارد Android | نعم | `ResourceResolver` و`XmlResourceIndex` | جزئي |
| معالج المشاريع والقوالب | نعم | `ProjectWizard` وقوالب | موجود |
| شاشات الإعدادات | 8 شاشات و24 فئة | نمط مشابه (1.0.76 إلى 1.0.80) | موجود |
| محرر المانيفست والصلاحيات | نعم | تسجيل تلقائي للمكونات (1.0.30) | جزئي |
| أيقونات | نعم | غير موجود | غير موجود |
| وحدة التدريب Trainer | نعم (1,323 مورد نصي) | غير موجود | غير موجود |
| تحويل النص إلى كلام | نعم | غير موجود | غير موجود |
| الترخيص والاشتراكات والإعلانات والتحليلات | نعم | غير موجود | قرار منتج (لا ننسخه) |

---

## 10. توصيات وخطوات مقترحة (دون تنفيذ في هذه الجولة)

1. **تحديد الأولويات أولًا.** أيّ الميزات تريد أن نعمل عليها؟ أقترح البدء بما يكمّل الفاحص النحوي: المحرك التحليلي المنفصل، ثم الإصلاح السريع الكامل، ثم بحث الاستخدامات الموسّع.
2. **القيود التقنية.** لا تُضاف مكتبات جديدة دون موافقتك (شروط المشروع تمنع تعديل `app/build.gradle` وإضافة مكتبات). معظم الميزات المرجعية تعتمد على مكتبات مضمّنة مثل JSch وjavac وdx وGlide، لذلك قد يحتاج تنفيذها إلى قرار منك.
3. **المُصحِّح (ADRT)** قرار كبير: يتطلب حقن وكيل في التطبيق المُصحَّح، وله آثار أمنية واضحة. أقترح تأجيله حتى تحدد الحاجة.
4. **الترخيص والاشتراكات والإعلانات والتحليلات** لا تُنقل. هي خاصة بالمنتج الأصلي.
5. **الدراسة المتعمقة للمحرك** (`abcd` و`com.aide.engine`) مهمة للفاحص النحوي والإصلاح السريع، وأصبحت ممكنة لأن الأصناف الأساسية موجودة في هذا الأرشيف. تتم وفق البروتوكول، ولكل جزء تقرير مستقل قبل أي تنفيذ.
6. **تحقق من الواقع:** إن أرسلت لي نسخة APK من هذا التطبيق، يمكن التحقق من الصلاحيات والمكونات الفعلية عبر `AndroidManifest.xml` (غير موجود في هذا الأرشيف).

---

## 11. الملاحق

### 11.1 قائمة أوامر المحرر في المرجع (113 أمرًا)
`breakpoint`، `build_variants`، `close`، `close_all`، `close_file`، `close_others`، `close_project`، `code`، `color`، `community`، `configure_code_style`، `copy`، `create_constructor`، `create_setters_and_getters`، `cut`، `debugger`، `design`، `documentation`، `download_docs`، `edit`، `edit_mode`، `errors`، `exit`، `extract_method`، `extract_resources`، `file_list`، `files`، `files_add_library_to_project`، `files_add_new_class`، `files_add_new_xml`، `files_add_to_project`، `files_clone_git_repository`، `files_copy_path`، `files_create_new_file`، `files_create_new_folder`، `files_create_new_project`، `files_create_new_project_item`، `files_delete`، `files_download_dropbox_folder`، `files_git`، `files_open_android_project`، `files_open_java_project`، `files_open_javascript_project`، `files_open_nativeexecutable_project`، `files_open_phonegap_project`، `files_open_website_project`، `files_project_properties`، `files_remove_library_from_project`، `files_rename`، `files_set_as_androidjar`، `files_show_current_file`، `files_show_projects`، `files_sync_dropbox_folder`، `find`، `find_extended_usages`، `find_in_file`، `find_in_project`، `find_textually`، `find_usages`، `fix`، `format`، `format_code`، `forward`، `git_branches`، `git_checkout_branch`، `git_commit`، `git_create_branch`، `git_delete_branch`، `git_merge_branch`، `git_pull`، `git_push`، `go_to`، `goto_line`، `inline_variable`، `introduce_variable`، `learn`، `learn_code_style`، `logcat`، `logcat_clear`، `logcat_clear_filter`، `logcat_filter_by_priority`، `logcat_filter_by_process`، `logcat_filter_by_tag`، `logcat_filter_current_app`، `logcat_pause`، `logcat_resume`، `more`، `navigate_mode`، `organize_imports`، `outcomment_code`، `paste`، `project`، `publish_project`، `redo`، `refactor`، `refresh_build`، `rename`، `replace_textually`، `run`، `save`، `search_results`، `select`، `settings`، `show_errors`، `step_in`، `step_out`، `step_over`، `stop`، `surround_with_trycatch`، `undo`، `unlock_all_features`، `unoutcomment_code`، `view`.

### 11.2 قوائم وتخطيطات مؤكدة من `AideR`
- **القوائم (15):** `commit_options_menu`، `designer_options_menu`، `editor_context_menu`، `editor_small_context_menu`، `filebrowser_context_menu`، `filetab_menu`، `git_context_menu`، `help_options_menu`، `javaconsole_context_menu`، `keybindings_options_menu`، `logcatbrowser_context_menu`، `logcatbrowser_menu`، `main_options_menu`، `main_trainer_options_menu`، `trainer_options_menu`.
- **التخطيطات (84)** تشمل: `about`، `appwizard`، `browser_header`، `colorpicker`، `commitbrowser`، `completion_list`، `createkeystore`، `createproject`، `debugger_view`، `designer`، `dialog_color_picker`، `downloaddropbox`، `editor`، `error_popup`، `errorbrowser`، `errorsview`، `exportapk`، `filebrowser`، `gitclonerepository`، `gitcommitdata`، `gotobrowser`، `helpview`، `keybindings`، `logcatbrowser`، `main`، `main_drawer`، `outputconsole`، `progressdialog`، `promo_dialog`، `propertydialog_entry`، `quickkeysbar`، `replace`، `searchbrowser`، `share_dialog`، `shop_expert_popup`، `shop_learning_popup`، `shop_popup`، `toast_layout`، `trainer` (مع `trainer_course` و`trainer_lesson` و`trainer_dialog`)، `view_noOpenFileView`، `webpreview`.
- **ملفات XML (13):** `aide_backup_rules`، `analytics`، `file_paths`، `preferences_*` (8 ملفات)، `shortcuts`، `util_code_provider_paths`.
- **الموارد الخام (6):** `click`، `fail`، `ouya_key`، `success_lesson`، `success_task`، `task`.
- **أيقونات الاختصارات:** `ic_shortcut_git` و`ic_shortcut_new_project`.

### 11.3 فئات الإعدادات (24)
`apk_sign`، `c_indent`، `completion`، `css_indent`، `dex`، `font`، `git`، `gradle`، `help`، `html_indent`، `java_import`، `java_indent`، `java_indent_options`، `java_nl_options`، `java_space_options`، `java_wrap_options`، `js_indent`، `keyboard`، `native_code`، `run`، `save`، `sdk`، `spaces`، `xml_indent`.

### 11.4 أعداد نصوص الموارد حسب البادئة (من `AideR$string`، بعد استبعاد الحشو)
| البادئة | العدد | ملاحظة |
|---|---:|---|
| `course_` | 1,323 | دورات التدريب |
| `dialog_` | 190 | الحوارات |
| `preference_` | 161 | عناوين الإعدادات |
| `command_` | 113 | أوامر المحرر |
| `keybind_` | 89 | اختصارات لوحة المفاتيح |
| `trainer_` | 51 | واجهة التدريب |
| `shop_` | 36 | المتجر والمميزات |
| `common_` | 32 | نصوص Google Play Services وWear |
| `view_` | 19 | عناوين العرض (تصحيح، سجل، أخطاء) |
| `toast_` | 16 | رسائل قصيرة |
| `menu_` | 14 | عناصر القوائم |
| `activity_` | 7 | عناوين الشاشات |
| الباقي | ≈ 43 | إشعارات وثيمات وإعلانات وغيرها |

**إجمالي أسماء موارد `AideR`:** 3,574 معرّفًا (منها 2,094 نصًا بعد استبعاد الحشو).

### 11.5 الحزم الأكبر (عدد الأصناف)
`com/google/android` (3,023)، و`abcd` (2,793)، و`com/google/common` (1,885)، و`androidj/support/v4` (1,215)، و`com/aide/ui` (729)، و`com/sun/tools` (623)، و`com/s1243808733/android` (605)، و`org/codehaus/groovy` (489)، و`android/support/v4` (455)، و`com/bumptech/glide` (395)، و`com/s1243808733/aide` (377)، و`com/baidu/mobstat` (300)، و`com/blankj/utilcode` (268)، و`com/google/gson` (180)، و`com/crashlytics/android` (176)، و`org/objectweb/asm` (166)، و`com/jcraft/jsch` (147)، و`com/google/googlejavaformat` (141)، و`sun/misc` (139)، و`groovyjarjarantlr` (138)، و`org/apache/commons` (127)، و`com/caverock/androidsvg` (125)، و`com/github/megatronking` (116)، و`com/aide/engine` (122)، و`com/aide/common` (120)، و`com/aide/uidesigner` (106)، و`com/aide/appwizard` (47)، و`com/aide/licensing` (19).

### 11.6 طريقة التحقق من الادعاءات
- **الأصناف والوراثة:** من جدول الأصناف والآباء المُستخرج من بيانات `class_def`.
- **الاستدعاءات:** من فك التعليمات (`invoke-*`) مع تحقق من تطابق الطول. ولتفادي الخلط، تُطابق القدرات على **الصنف المالك والاسم** لا على التوقيع كله (تم تصحيح هذا الخطأ أثناء الدراسة).
- **النصوص:** من جدول `const-string` المستعملة في الدوال، مع أصحابها.
- **أسماء الموارد:** من حقول صنف `AideR`.
- **الحدود المعروفة:** الأرقام تعكس ما في الملف، لا سلوك التطبيق وقت التشغيل.

### 11.7 الإجراءات بعد الدراسة
- حُذف مجلد الدراسة المؤقت `/tmp/dexstudy` بما فيه نسخة `dex.zip` وملفات DEX المفكوكة ومخرجات التحليل الوسيطة.
- لم يُعدَّل أي ملف في مشروع ShimaProject، ولم تُنشأ حزم جديدة في `deliverables/`.
- لم يُنسخ أي كود من الأرشيف إلى المشروع.
