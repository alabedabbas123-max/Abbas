package com.mhd.absher;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Locale;

public class DigitalDocumentsActivity extends AppCompatActivity {
    private DatabaseReference dbRef;
    private ValueEventListener userDataListener;

    public void generateDenseQRCode(String str) {
        int identifier;
        if (str == null || str.trim().isEmpty()) {
            return;
        }
        ImageView imageView = (ImageView) findViewById(R.id.img_citizen_qrcode);
        ImageView imageView2 = (ImageView) findViewById(R.id.imageview_qrcode);
        ImageView imageView3 = (ImageView) findViewById(R.id.img_visitor_qrcode);
        ImageView imageView4 = (imageView3 != null || (identifier = getResources().getIdentifier(a.a("PDkhck48Jy9ZVycLN19bOjAj"), a.a("PDA="), getPackageName())) == 0) ? imageView3 : (ImageView) findViewById(identifier);
        ImageView imageView5 = (ImageView) findViewById(R.id.imageview_license_barcode);
        try {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 150; i++) {
                sb.append(" ");
            }
            String str2 = String.valueOf(str.trim()) + sb.toString();
            Hashtable hashtable = new Hashtable();
            hashtable.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hashtable.put(EncodeHintType.CHARACTER_SET, a.a("AAAAAAA="));
            hashtable.put(EncodeHintType.MARGIN, 1);
            BitMatrix bitMatrixEncode = new QRCodeWriter().encode(str2, BarcodeFormat.QR_CODE, 200, 200, hashtable);
            int width = bitMatrixEncode.getWidth();
            int height = bitMatrixEncode.getHeight();
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            for (int i2 = 0; i2 < width; i2++) {
                for (int i3 = 0; i3 < height; i3++) {
                    bitmapCreateBitmap.setPixel(i2, i3, bitMatrixEncode.get(i2, i3) ? -16777216 : -1);
                }
            }
            if (imageView != null) {
                imageView.setImageBitmap(bitmapCreateBitmap);
            }
            if (imageView2 != null) {
                imageView2.setImageBitmap(bitmapCreateBitmap);
            }
            if (imageView4 != null) {
                imageView4.setImageBitmap(bitmapCreateBitmap);
            }
            if (imageView5 != null) {
                imageView5.setImageBitmap(bitmapCreateBitmap);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getEnglishLicenseType(String str) {
        if (str == null || str.trim().isEmpty()) {
            return a.a("BSYvW1khMQ==");
        }
        String strTrim = str.trim();
        if (strTrim.contains(a.a("jfqemOHdjPP0sg=="))) {
            return a.a("BSYvW1khMQ==");
        }
        if (strTrim.contains(a.a("jNKfr+HRdJ6D4PKM8w=="))) {
            return a.a("BSYvW1khMWZ5SjQ6NV1XJyA=");
        }
        if (strTrim.contains(a.a("je2fqOHdjcP0sg==")) || strTrim.contains(a.a("jNKfr+HRdJ6U4PKNww=="))) {
            return a.a("BSEkQVE2dBJfWTsnNkJKIQ==");
        }
        if (strTrim.contains(a.a("jfuenODyjOr1kQ=="))) {
            return a.a("GDsyQko2LSVBXQ==");
        }
        return (strTrim.contains(a.a("jfeemeDvjOH0vA==")) || strTrim.contains(a.a("jfOemeDvjOH0vA=="))) ? a.a("HTEnW0F1GSdOUDw6I19B") : strTrim;
    }

    public static String getEnglishNationality(String str) {
        if (str == null || str.trim().isEmpty()) {
            return a.a("BhUTaXE=");
        }
        String lowerCase = str.trim().toLowerCase();
        if (lowerCase.contains(a.a("jeeelOHdjOk=")) || lowerCase.contains(a.a("JjUzSVE="))) {
            return a.a("BhUTaXE=");
        }
        if (lowerCase.contains(a.a("jN6fqOHT")) || lowerCase.contains(a.a("LDErSFY="))) {
            return a.a("DBELaHY=");
        }
        if (lowerCase.contains(a.a("jNGemODk")) || lowerCase.contains(a.a("MDM/XUw="))) {
            return a.a("EBMffWw=");
        }
        if (lowerCase.contains(a.a("jeefpeD6jOH0vg==")) || lowerCase.contains(a.a("JiEiTFY="))) {
            return a.a("BgECbHY=");
        }
        if (lowerCase.contains(a.a("jeefpeDkjcz1nw==")) || lowerCase.contains(a.a("jeefpeDkjcw=")) || lowerCase.contains(a.a("Ji00RFk="))) {
            return a.a("Bg0UZHk=");
        }
        if (lowerCase.contains(a.a("jfeenOD6jcA=")) || lowerCase.contains(a.a("jfOenOD6jcA=")) || lowerCase.contains(a.a("Pzs0SVk7"))) {
            return a.a("HxsUaXkb");
        }
        if (lowerCase.contains(a.a("jfyeiuHWjPX1ko3zn6s=")) || lowerCase.contains(a.a("JTUtREshNSg="))) {
            return a.a("BRUNZGsBFQg=");
        }
        if (lowerCase.contains(a.a("jNOfq+D6")) || lowerCase.contains(a.a("PDoiRFk="))) {
            return a.a("HBoCZHk=");
        }
        if (lowerCase.contains(a.a("jfyfq+D5jcL1n437n6fg4Q==")) || lowerCase.contains(a.a("jfyfq+DvjcL1n437n6fg4Q==")) || lowerCase.contains(a.a("jfyfq+HXjcL1n437n6fg4Q==")) || lowerCase.contains(a.a("NzUoSlQ0MCNeUA=="))) {
            return a.a("FxUIanQUEAN+cA==");
        }
        if (lowerCase.contains(a.a("jNWfqeD9jcz0vg==")) || lowerCase.contains(a.a("JTwvQVElJC9DXSY="))) {
            return a.a("BRwPYXEFBA9jfQY=");
        }
        if (lowerCase.contains(a.a("jfOehuHfjc71kIzenoo=")) || lowerCase.contains(a.a("jfeehuHfjc71kIzenoo=")) || lowerCase.contains(a.a("jfGehuHfjc71kIzenoo=")) || lowerCase.contains(a.a("jfmeheDh")) || lowerCase.contains(a.a("MCAuRFclPSc="))) {
            return a.a("EAAOZHcFHQc=");
        }
        if (lowerCase.contains(a.a("jNGeiuHRjcw=")) || lowerCase.contains(a.a("ODUqRA=="))) {
            return a.a("GBUKZA==");
        }
        if (lowerCase.contains(a.a("jfOfq+D6jc70vozenp7h34zh")) || lowerCase.contains(a.a("jfGfq+D6jc70vozenp7h34zh")) || lowerCase.contains(a.a("jfOfq+D6jc70vo3nn6fg8g==")) || lowerCase.contains(a.a("jfGfq+D6jc70vo3nn6fg8g==")) || lowerCase.contains(a.a("PDoiQlYwJy9M"))) {
            return a.a("HBoCYnYQBw9s");
        }
        if (lowerCase.contains(a.a("jNGel+DkjO4=")) || lowerCase.contains(a.a("ODs0Qls2Ow=="))) {
            return a.a("GBsUYnsWGw==");
        }
        if (lowerCase.contains(a.a("jf6fpeHTjPU=")) || lowerCase.contains(a.a("ISEoREs8NQ=="))) {
            return a.a("AQEIZGscFQ==");
        }
        if (lowerCase.contains(a.a("jfien+DyjOD1iQ==")) || lowerCase.contains(a.a("NDghSEo8NQ=="))) {
            return a.a("FBgBaGocFQ==");
        }
        if (lowerCase.contains(a.a("jNCeheHTjOH0vg==")) || lowerCase.contains(a.a("OTEkTFY6Og=="))) {
            return a.a("GREEbHYaGg==");
        }
        if (lowerCase.contains(a.a("jNWfqeDmjPH0sozS")) || lowerCase.contains(a.a("JTUqSEshPShI"))) {
            return a.a("BRUKaGsBHQho");
        }
        if (lowerCase.contains(a.a("je2enODyjcQ=")) || lowerCase.contains(a.a("PCYnXA=="))) {
            return a.a("HAYHfA==");
        }
        if (lowerCase.contains(a.a("jNefpeHfjOw=")) || lowerCase.contains(a.a("PiExTFEh"))) {
            return a.a("HgERbHEB");
        }
        if (lowerCase.contains(a.a("jfOfqODyjPf1n43+")) || lowerCase.contains(a.a("jfGfqODyjPf1n43+")) || lowerCase.contains(a.a("IDUj"))) {
            return a.a("ABUD");
        }
        if (lowerCase.contains(a.a("jNaemuDk")) || lowerCase.contains(a.a("JDUyTEo="))) {
            return a.a("BBUSbGo=");
        }
        if (lowerCase.contains(a.a("jfyegODkjcz0vg==")) || lowerCase.contains(a.a("NzUuX1k8Og=="))) {
            return a.a("FxUOf3kcGg==");
        }
        if (lowerCase.contains(a.a("je2fqODyjcA=")) || lowerCase.contains(a.a("OjknQw=="))) {
            return a.a("GhkHYw==");
        }
        if (lowerCase.contains(a.a("jNKfp+D9jOH0vA==")) || lowerCase.contains(a.a("OzE2TFQ="))) {
            return a.a("GxEWbHQ=");
        }
        if (lowerCase.contains(a.a("jeeenOHfjcL1n4zSn67g8g==")) || lowerCase.contains(a.a("JiYvQVk7Pyc="))) {
            return a.a("BgYPDXQUGg1s");
        }
        if (lowerCase.contains(a.a("jfOfrODvjOH0vo3nnofg8o3A")) || lowerCase.contains(a.a("jfefrODvjOH0vo3nnofg8o3A")) || lowerCase.contains(a.a("NDIhRVk7PTVZWTs="))) {
            return a.a("FBIBZXkbHRV5eRs=");
        }
        if (lowerCase.contains(a.a("jf6enOHWjcz1nw==")) || lowerCase.contains(a.a("ISE0Rl0s"))) {
            return a.a("AQEUZn0M");
        }
        if (lowerCase.contains(a.a("jeGfpeHQjOH0vA==")) || lowerCase.contains(a.a("JjsrTFQ8NQ=="))) {
            return a.a("BhsLbHQcFQ==");
        }
        return (lowerCase.contains(a.a("jf6emeDyjOk=")) || lowerCase.contains(a.a("NjwnSQ=="))) ? a.a("FhwHaQ==") : str.trim().toUpperCase();
    }

    public String getSafeString(DataSnapshot dataSnapshot, String... strArr) {
        for (String str : strArr) {
            if (dataSnapshot.hasChild(str) && dataSnapshot.child(str).getValue() != null) {
                return String.valueOf(dataSnapshot.child(str).getValue());
            }
        }
        return null;
    }

    private void loadDataFromSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        updateCardsVisibility(sharedPreferences.getBoolean(a.a("JjwpWns8IC9XXTsdIg=="), true), sharedPreferences.getBoolean(a.a("JjwpWmowJy9JXTsgD0k="), true), sharedPreferences.getBoolean(a.a("JjwpWm48Jy9ZVycdIg=="), false), sharedPreferences.getBoolean(a.a("JjwpWnQ8NyNDSzA="), true));
        String string = sharedPreferences.getString(a.a("ICcjX3E4NSFI"), "");
        if (!string.isEmpty()) {
            updateUserImageUI(string);
        }
        String string2 = sharedPreferences.getString(a.a("OzUrSHkn"), a.a("je2fqeHfdJ6U4dGNzA3g7I3C9LJ1jcT1n4zenoI="));
        String string3 = sharedPreferences.getString(a.a("OzUrSH07"), a.a("EDohQVEmPGZjWTgxZmVdJzE="));
        String string4 = sharedPreferences.getString(a.a("PDAIWFU3MTQ="), a.a("Z2BxHgtnY3QcAA=="));
        String string5 = sharedPreferences.getString(a.a("Nz00WVARNTJI"), a.a("ZG1/HRdlZWkfDw=="));
        String string6 = sharedPreferences.getString(a.a("OzUyRFc7NSpETCw="), a.a("jfOfqeDmjP/0sI37n6fg/A=="));
        String englishNationality = getEnglishNationality(string6);
        String string7 = sharedPreferences.getString(a.a("JSYpS10mJy9CVg=="), a.a("je2eiuHQjcI="));
        String string8 = sharedPreferences.getString(a.a("MCw2REosECdZXQ=="), a.a("ZG1/HRdlZWkfDw=="));
        String string9 = sharedPreferences.getString(a.a("Njs2VHYgOSRISg=="), a.a("ZA=="));
        String string10 = sharedPreferences.getString(a.a("JzEqRF88Oyg="), a.a("jfOfqeDwjPX0vI3zn6g="));
        String string11 = sharedPreferences.getString(a.a("MDk2QVcsMTRkXA=="), a.a("Z2BxHgtnY3QcAA=="));
        String string12 = sharedPreferences.getString(a.a("PCc1WF0FOCdOXQ=="), a.a("jfOfqeDkjcz1n43i"));
        String string13 = sharedPreferences.getString(a.a("MDk2QVcsMTRjWTgx"), a.a("jNGegOHQjOkN4dCM6/S9jftm9L2N+Z+o4Po="));
        String string14 = sharedPreferences.getString(a.a("Nz00WVAFOCdOXQ=="), a.a("jfOfqeDkjcz1n43i"));
        String string15 = sharedPreferences.getString(a.a("OT0lSFYmMRJUSDA="), a.a("jfqemOHdjPP0sg=="));
        String englishLicenseType = getEnglishLicenseType(string15);
        String string16 = sharedPreferences.getString(a.a("NzgpQlwBLTZI"), a.a("FH8="));
        String string17 = sharedPreferences.getString(a.a("PCc1WF0RNTJI"), a.a("ZGByHRdlZWkdCQ=="));
        String string18 = sharedPreferences.getString(a.a("Iz01REwFITRdVyYx"), a.a("jeafp+DyjPf1kXWM//WfjfKfqeHfjO8="));
        setTextIfNotNull(R.id.tv_citizen_name_ar, string2);
        setTextIfNotNull(R.id.tv_citizen_name_en, string3);
        setTextIfNotNull(R.id.tv_citizen_id_number, toArabicNumbers(string4));
        setTextIfNotNull(R.id.tv_citizen_id_number_en, string4);
        setTextIfNotNull(R.id.tv_citizen_birth_date, toArabicNumbers(string5));
        setTextIfNotNull(R.id.tv_citizen_birth_date_en, string5);
        setTextIfNotNull(R.id.tv_citizen_expiry_date, toArabicNumbers(string8));
        setTextIfNotNull(R.id.tv_citizen_expiry_date_en, string8);
        setTextIfNotNull(R.id.tv_citizen_birth_place, string14);
        setTextIfNotNull(R.id.tv_citizen_copy_number, toArabicNumbers(string9));
        setTextIfNotNull(R.id.tvCardNameHome, string2);
        setTextIfNotNull(R.id.tvCardNameEn, string3);
        setTextIfNotNull(R.id.tvCardIdHome, toArabicNumbers(string4));
        setTextIfNotNull(R.id.tvCardBirthDate, toArabicNumbers(string5));
        setTextIfNotNull(R.id.tvCardNationality, string6);
        setTextIfNotNull(R.id.tvCardProfession, string7);
        setTextIfNotNull(R.id.tvCardExpiryDate, toArabicNumbers(string8));
        setTextIfNotNull(R.id.tvCardCopyNumber, toArabicNumbers(string9));
        setTextIfNotNull(R.id.tvCardReligion, string10);
        setTextIfNotNull(R.id.tvCardEmployerId, toArabicNumbers(string11));
        setTextIfNotNull(R.id.tvCardIssuePlace, string12);
        setTextIfNotNull(R.id.tvCardEmployerName, string13);
        setTextIfNotNull(R.id.tvCardBirthPlace, string14);
        setTextIfNotNull(a.a("ISIZW1EmPTJCSgogL1lUMA=="), a.a("jNOfpeHfjO8N4OeM4fWejeU="));
        setTextIfNotNull(a.a("ISIQREs8IClfbDwgKkg="), a.a("jNOfpeHfjO8N4OeM4fWejeU="));
        setTextIfNotNull(R.id.tv_name_ar, string2);
        setTextIfNotNull(R.id.tv_name_en, string3);
        setTextIfNotNull(R.id.tv_id_number, toArabicNumbers(string4));
        setTextIfNotNull(R.id.tv_issue_place, string12);
        setTextIfNotNull(R.id.tv_issue_date, toArabicNumbers(string17));
        setTextIfNotNull(R.id.tv_expiry_date, toArabicNumbers(string8));
        setTextIfNotNull(R.id.tv_birth_date, toArabicNumbers(string5));
        setTextIfNotNull(R.id.tv_nationality, string6);
        setTextIfNotNull(R.id.tv_visit_purpose, string18);
        setTextIfNotNull(R.id.tv_blood_type, string16.isEmpty() ? a.a("fhs=") : string16);
        setTextIfNotNull(R.id.tv_version_number, toArabicNumbers(string9.isEmpty() ? a.a("ZA==") : string9));
        setTextIfNotNull(R.id.tvLicenseNameAr, string2);
        setTextIfNotNull(a.a("ISIKRFswOjVIdjQ5Iw=="), string2);
        setTextIfNotNull(R.id.tvLicenseNameEn, string3);
        setTextIfNotNull(R.id.tvLicenseIdNumberAr, toArabicNumbers(string4));
        setTextIfNotNull(a.a("ISIKRFswOjVIcTEaM0BaMCY="), toArabicNumbers(string4));
        setTextIfNotNull(R.id.tvLicenseIdNumberEn, string4);
        setTextIfNotNull(R.id.tvLicenseTypeAr, string15);
        setTextIfNotNull(a.a("ISIKRFswOjVIbCwkIw=="), string15);
        setTextIfNotNull(R.id.tvLicenseTypeEn, englishLicenseType);
        setTextIfNotNull(R.id.tvLicenseIssueDateAr, toArabicNumbers(string17));
        setTextIfNotNull(a.a("ISIKRFswOjVIcSYnM0h8NCAj"), toArabicNumbers(string17));
        setTextIfNotNull(R.id.tvLicenseIssueDateEn, string17);
        setTextIfNotNull(R.id.tvLicenseBirthDateAr, toArabicNumbers(string5));
        setTextIfNotNull(a.a("ISIKRFswOjVIejwmMkV8NCAj"), toArabicNumbers(string5));
        setTextIfNotNull(R.id.tvLicenseBirthDateEn, string5);
        setTextIfNotNull(R.id.tvLicenseNationalityAr, string6);
        setTextIfNotNull(a.a("ISIKRFswOjVIdjQgL0JWNDgvWUE="), string6);
        setTextIfNotNull(R.id.tvLicenseNationalityEn, englishNationality);
        setTextIfNotNull(R.id.tvLicenseExpiryDateAr, toArabicNumbers(string8));
        setTextIfNotNull(a.a("ISIKRFswOjVIfS0kL19BETUySA=="), toArabicNumbers(string8));
        setTextIfNotNull(R.id.tvLicenseExpiryDateEn, string8);
        setTextIfNotNull(R.id.tvLicenseBloodTypeAr, string16);
        setTextIfNotNull(a.a("ISIKRFswOjVIejk7KUlsLCQj"), string16);
        setTextIfNotNull(R.id.tvLicenseBloodTypeEn, string16);
        generateDenseQRCode(string4);
    }

    public boolean parseBoolean(DataSnapshot dataSnapshot, String str, boolean z) {
        if (!dataSnapshot.hasChild(str)) {
            return z;
        }
        Object value = dataSnapshot.child(str).getValue();
        if (value instanceof Boolean) {
            return ((Boolean) value).booleanValue();
        }
        return value != null ? a.a("ISYzSA==").equalsIgnoreCase(String.valueOf(value)) : z;
    }

    public void setTextIfNotNull(int i, String str) {
        TextView textView = (TextView) findViewById(i);
        if (textView == null || str == null) {
            return;
        }
        textView.setText(str);
    }

    public void setTextIfNotNull(String str, String str2) {
        int identifier;
        TextView textView;
        if (str == null || str2 == null || (identifier = getResources().getIdentifier(str, a.a("PDA="), getPackageName())) == 0 || (textView = (TextView) findViewById(identifier)) == null) {
            return;
        }
        textView.setText(str2);
    }

    private void syncDataWithFirebase() {
        SharedPreferences sharedPreferences = getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0);
        SharedPreferences sharedPreferences2 = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        SharedPreferences sharedPreferences3 = getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
        String string = sharedPreferences.getString(a.a("ICcjX2swNzRITBww"), "");
        if (string.isEmpty()) {
            string = sharedPreferences3.getString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), "");
        }
        if (string.isEmpty()) {
            string = sharedPreferences2.getString(a.a("JjElX10hHyNU"), "");
        }
        if (string.isEmpty()) {
            string = sharedPreferences2.getString(a.a("ICcjX3MwLQ=="), "");
        }
        if (string.isEmpty()) {
            return;
        }
        try {
            this.dbRef = FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(string);
            this.userDataListener = new ValueEventListener() {
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }

                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        SharedPreferences.Editor editorEdit = DigitalDocumentsActivity.this.getSharedPreferences(a.a("ICcjX3w0ICc="), 0).edit();
                        boolean z = DigitalDocumentsActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWns8IC9XXTsdIg=="), true);
                        boolean z2 = DigitalDocumentsActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWmowJy9JXTsgD0k="), true);
                        boolean z3 = DigitalDocumentsActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWm48Jy9ZVycdIg=="), false);
                        if (!dataSnapshot.hasChild(a.a("JjwpWm48Jy9ZVycdIg==")) && dataSnapshot.hasChild(a.a("JjwpWm48Jy9ZVycXJ19c"))) {
                            z3 = DigitalDocumentsActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWm48Jy9ZVycXJ19c"), false);
                        }
                        boolean z4 = DigitalDocumentsActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWnQ8NyNDSzA="), true);
                        editorEdit.putBoolean(a.a("JjwpWns8IC9XXTsdIg=="), z);
                        editorEdit.putBoolean(a.a("JjwpWmowJy9JXTsgD0k="), z2);
                        editorEdit.putBoolean(a.a("JjwpWm48Jy9ZVycdIg=="), z3);
                        editorEdit.putBoolean(a.a("JjwpWnQ8NyNDSzA="), z4);
                        DigitalDocumentsActivity.this.updateCardsVisibility(z, z2, z3, z4);
                        String safeString = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("ICcjX3E4NSFI"), a.a("ACcjX3E4NSFI"), a.a("ICcjX2c8OSdKXQ=="), a.a("JSYpS1E5MQ9AWTIx"));
                        if (safeString != null && !safeString.trim().isEmpty()) {
                            editorEdit.putString(a.a("ICcjX3E4NSFI"), safeString);
                            DigitalDocumentsActivity.this.updateUserImageUI(safeString);
                        }
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSHkn"), a.a("GzUrSHkn"), R.id.tv_citizen_name_ar, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSH07"), a.a("GzUrSH07"), R.id.tv_citizen_name_en, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Nz00WVAFOCdOXQ=="), a.a("Fz00WVAFOCdOXQ=="), R.id.tv_citizen_birth_place, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Nz00WVARNTJI"), a.a("Fz00WVARNTJI"), R.id.tv_citizen_birth_date, true);
                        String safeString2 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("Nz00WVARNTJI"), a.a("Fz00WVARNTJI"));
                        if (safeString2 != null) {
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tv_citizen_birth_date_en, safeString2);
                        }
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("MCw2REosECdZXQ=="), a.a("ECw2REosECdZXQ=="), R.id.tv_citizen_expiry_date, true);
                        String safeString3 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("MCw2REosECdZXQ=="), a.a("ECw2REosECdZXQ=="));
                        if (safeString3 != null) {
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tv_citizen_expiry_date_en, safeString3);
                        }
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Njs2VHYgOSRISg=="), a.a("Fjs2VHYgOSRISg=="), R.id.tv_citizen_copy_number, true);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSHkn"), a.a("GzUrSHkn"), R.id.tvCardNameHome, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSHkn"), a.a("GzUrSHkn"), R.id.tvLicenseNameAr, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSHkn"), a.a("GzUrSHkn"), a.a("ISIKRFswOjVIdjQ5Iw=="), false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSHkn"), a.a("GzUrSHkn"), R.id.tv_name_ar, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSH07"), a.a("GzUrSH07"), R.id.tvCardNameEn, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSH07"), a.a("GzUrSH07"), R.id.tvLicenseNameEn, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSH07"), a.a("GzUrSH07"), R.id.tv_name_en, false);
                        String safeString4 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("OzUyRFc7NSpETCw="), a.a("GzUyRFc7NSpETCw="));
                        if (safeString4 != null) {
                            editorEdit.putString(a.a("OzUyRFc7NSpETCw="), safeString4);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvCardNationality, safeString4);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseNationalityAr, safeString4);
                            DigitalDocumentsActivity.this.setTextIfNotNull(a.a("ISIKRFswOjVIdjQgL0JWNDgvWUE="), safeString4);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tv_nationality, safeString4);
                            String safeString5 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("OzUyRFc7NSpETCwRKA=="), a.a("GzUyRFc7NSpETCwRKA=="));
                            if (safeString5 == null || safeString5.trim().isEmpty()) {
                                safeString5 = DigitalDocumentsActivity.getEnglishNationality(safeString4);
                            }
                            editorEdit.putString(a.a("OzUyRFc7NSpETCwRKA=="), safeString5);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseNationalityEn, safeString5);
                        }
                        String safeString6 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("OT0lSFYmMRJUSDA="), a.a("GT0lSFYmMRJUSDA="));
                        if (safeString6 != null) {
                            editorEdit.putString(a.a("OT0lSFYmMRJUSDA="), safeString6);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseTypeAr, safeString6);
                            DigitalDocumentsActivity.this.setTextIfNotNull(a.a("ISIKRFswOjVIbCwkIw=="), safeString6);
                            String safeString7 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("OT0lSFYmMRJUSDARKA=="), a.a("GT0lSFYmMRJUSDARKA=="));
                            if (safeString7 == null || safeString7.trim().isEmpty()) {
                                safeString7 = DigitalDocumentsActivity.getEnglishLicenseType(safeString6);
                            }
                            editorEdit.putString(a.a("OT0lSFYmMRJUSDARKA=="), safeString7);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseTypeEn, safeString7);
                        }
                        String safeString8 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("NzgpQlwBLTZI"), a.a("FzgpQlwBLTZI"));
                        if (safeString8 != null) {
                            editorEdit.putString(a.a("NzgpQlwBLTZI"), safeString8);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseBloodTypeAr, safeString8);
                            DigitalDocumentsActivity.this.setTextIfNotNull(a.a("ISIKRFswOjVIejk7KUlsLCQj"), safeString8);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseBloodTypeEn, safeString8);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tv_blood_type, safeString8);
                        }
                        String safeString9 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("PCc1WF0RNTJI"), a.a("HCc1WF0RNTJI"));
                        if (safeString9 != null) {
                            editorEdit.putString(a.a("PCc1WF0RNTJI"), safeString9);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseIssueDateAr, DigitalDocumentsActivity.this.toArabicNumbers(safeString9));
                            DigitalDocumentsActivity.this.setTextIfNotNull(a.a("ISIKRFswOjVIcSYnM0h8NCAj"), DigitalDocumentsActivity.this.toArabicNumbers(safeString9));
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseIssueDateEn, safeString9);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tv_issue_date, DigitalDocumentsActivity.this.toArabicNumbers(safeString9));
                        }
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("JSYpS10mJy9CVg=="), a.a("BSYpS10mJy9CVg=="), R.id.tvCardProfession, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("JzEqRF88Oyg="), a.a("BzEqRF88Oyg="), R.id.tvCardReligion, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("PCc1WF0FOCdOXQ=="), a.a("HCc1WF0FOCdOXQ=="), R.id.tvCardIssuePlace, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("PCc1WF0FOCdOXQ=="), a.a("HCc1WF0FOCdOXQ=="), R.id.tv_issue_place, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("MDk2QVcsMTRjWTgx"), a.a("EDk2QVcsMTRjWTgx"), R.id.tvCardEmployerName, false);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Nz00WVAFOCdOXQ=="), a.a("Fz00WVAFOCdOXQ=="), R.id.tvCardBirthPlace, false);
                        String safeString10 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("Iz01REwFITRdVyYx"), a.a("Az01REwFITRdVyYx"), a.a("Iz01REwKJDNfSDonIw=="));
                        if (safeString10 == null) {
                            safeString10 = a.a("jeafp+DyjPf1kXWM//WfjfKfqeHfjO8=");
                        }
                        editorEdit.putString(a.a("Iz01REwFITRdVyYx"), safeString10);
                        DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tv_visit_purpose, safeString10);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Nz00WVARNTJI"), a.a("Fz00WVARNTJI"), R.id.tvCardBirthDate, true);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Nz00WVARNTJI"), a.a("Fz00WVARNTJI"), R.id.tvLicenseBirthDateAr, true);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Nz00WVARNTJI"), a.a("Fz00WVARNTJI"), a.a("ISIKRFswOjVIejwmMkV8NCAj"), true);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Nz00WVARNTJI"), a.a("Fz00WVARNTJI"), R.id.tv_birth_date, true);
                        String safeString11 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("Nz00WVARNTJI"), a.a("Fz00WVARNTJI"));
                        if (safeString11 != null) {
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseBirthDateEn, safeString11);
                        }
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("MCw2REosECdZXQ=="), a.a("ECw2REosECdZXQ=="), R.id.tvCardExpiryDate, true);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("MCw2REosECdZXQ=="), a.a("ECw2REosECdZXQ=="), R.id.tvLicenseExpiryDateAr, true);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("MCw2REosECdZXQ=="), a.a("ECw2REosECdZXQ=="), a.a("ISIKRFswOjVIfS0kL19BETUySA=="), true);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("MCw2REosECdZXQ=="), a.a("ECw2REosECdZXQ=="), R.id.tv_expiry_date, true);
                        String safeString12 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("MCw2REosECdZXQ=="), a.a("ECw2REosECdZXQ=="));
                        if (safeString12 != null) {
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseExpiryDateEn, safeString12);
                        }
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Njs2VHYgOSRISg=="), a.a("Fjs2VHYgOSRISg=="), R.id.tvCardCopyNumber, true);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Njs2VHYgOSRISg=="), a.a("Fjs2VHYgOSRISg=="), R.id.tv_version_number, true);
                        DigitalDocumentsActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("MDk2QVcsMTRkXA=="), a.a("EDk2QVcsMTRkXA=="), R.id.tvCardEmployerId, true);
                        String safeString13 = DigitalDocumentsActivity.this.getSafeString(dataSnapshot, a.a("PDAIWFU3MTQ="), a.a("HDAIWFU3MTQ="));
                        if (safeString13 != null) {
                            editorEdit.putString(a.a("PDAIWFU3MTQ="), safeString13);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tv_citizen_id_number, DigitalDocumentsActivity.this.toArabicNumbers(safeString13));
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tv_citizen_id_number_en, safeString13);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvCardIdHome, DigitalDocumentsActivity.this.toArabicNumbers(safeString13));
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseIdNumberAr, DigitalDocumentsActivity.this.toArabicNumbers(safeString13));
                            DigitalDocumentsActivity.this.setTextIfNotNull(a.a("ISIKRFswOjVIcTEaM0BaMCY="), DigitalDocumentsActivity.this.toArabicNumbers(safeString13));
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tvLicenseIdNumberEn, safeString13);
                            DigitalDocumentsActivity.this.setTextIfNotNull(R.id.tv_id_number, DigitalDocumentsActivity.this.toArabicNumbers(safeString13));
                            DigitalDocumentsActivity.this.generateDenseQRCode(safeString13);
                        }
                        editorEdit.apply();
                    }
                }
            };
            this.dbRef.addValueEventListener(this.userDataListener);
        } catch (Exception e) {
        }
    }

    public String toArabicNumbers(String str) {
        return str == null ? "" : str.replace(a.a("ZQ=="), a.a("jPQ=")).replace(a.a("ZA=="), a.a("jPU=")).replace(a.a("Zw=="), a.a("jPY=")).replace(a.a("Zg=="), a.a("jPc=")).replace(a.a("YQ=="), a.a("jPA=")).replace(a.a("YA=="), a.a("jPE=")).replace(a.a("Yw=="), a.a("jPI=")).replace(a.a("Yg=="), a.a("jPM=")).replace(a.a("bQ=="), a.a("jPw=")).replace(a.a("bA=="), a.a("jP0="));
    }

    public void updateCardsVisibility(final boolean z, final boolean z2, final boolean z3, final boolean z4) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                View viewFindViewById = DigitalDocumentsActivity.this.findViewById(R.id.documentCardCitizen);
                if (viewFindViewById != null) {
                    viewFindViewById.setVisibility(z ? 0 : 8);
                }
                View viewFindViewById2 = DigitalDocumentsActivity.this.findViewById(R.id.textview_citizen_title);
                if (viewFindViewById2 != null) {
                    viewFindViewById2.setVisibility(z ? 0 : 8);
                }
                View viewFindViewById3 = DigitalDocumentsActivity.this.findViewById(R.id.documentCard1);
                if (viewFindViewById3 != null) {
                    viewFindViewById3.setVisibility(z2 ? 0 : 8);
                }
                View viewFindViewById4 = DigitalDocumentsActivity.this.findViewById(R.id.documentCardVisitor);
                if (viewFindViewById4 != null) {
                    viewFindViewById4.setVisibility(z3 ? 0 : 8);
                }
                TextView textView = (TextView) DigitalDocumentsActivity.this.findViewById(R.id.textview15);
                if (textView != null) {
                    if (z2) {
                        textView.setText(a.a("jNOfpeHfjO8N4dCNxPSyjNE="));
                        textView.setVisibility(0);
                    } else if (z3) {
                        textView.setText(a.a("jNOfpeHfjO8N4OeM4fWejeU="));
                        textView.setVisibility(0);
                    } else {
                        textView.setVisibility(8);
                    }
                }
                DigitalDocumentsActivity.this.setTextIfNotNull(a.a("ISIZW1EmPTJCSgogL1lUMA=="), a.a("jNOfpeHfjO8N4OeM4fWejeU="));
                DigitalDocumentsActivity.this.setTextIfNotNull(a.a("ISIQREs8IClfbDwgKkg="), a.a("jNOfpeHfjO8N4OeM4fWejeU="));
                View viewFindViewById5 = DigitalDocumentsActivity.this.findViewById(R.id.documentCard2);
                if (viewFindViewById5 != null) {
                    viewFindViewById5.setVisibility(z4 ? 0 : 8);
                }
                View viewFindViewById6 = DigitalDocumentsActivity.this.findViewById(R.id.textview16);
                if (viewFindViewById6 != null) {
                    viewFindViewById6.setVisibility(z4 ? 0 : 8);
                }
            }
        });
    }

    public void updateFieldAndUI(DataSnapshot dataSnapshot, SharedPreferences.Editor editor, String str, String str2, int i, boolean z) {
        String safeString = getSafeString(dataSnapshot, str, str2);
        if (safeString != null) {
            editor.putString(str, safeString);
            if (z) {
                safeString = toArabicNumbers(safeString);
            }
            setTextIfNotNull(i, safeString);
        }
    }

    public void updateFieldAndUI(DataSnapshot dataSnapshot, SharedPreferences.Editor editor, String str, String str2, String str3, boolean z) {
        String safeString = getSafeString(dataSnapshot, str, str2);
        if (safeString != null) {
            editor.putString(str, safeString);
            if (z) {
                safeString = toArabicNumbers(safeString);
            }
            setTextIfNotNull(str3, safeString);
        }
    }

    public void updateUserImageUI(final String str) {
        if (str == null || str.trim().isEmpty()) {
            return;
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                int identifier;
                int identifier2;
                int identifier3;
                try {
                    byte[] bArrDecode = Base64.decode(str, 0);
                    Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArrDecode, 0, bArrDecode.length);
                    if (bitmapDecodeByteArray == null) {
                        return;
                    }
                    ImageView imageView = (ImageView) DigitalDocumentsActivity.this.findViewById(R.id.img_citizen_user_photo);
                    if (imageView != null) {
                        imageView.setImageBitmap(bitmapDecodeByteArray);
                    }
                    ImageView imageView2 = (ImageView) DigitalDocumentsActivity.this.findViewById(R.id.imageview_id_photo);
                    if (imageView2 == null && (identifier3 = DigitalDocumentsActivity.this.getResources().getIdentifier(a.a("PDknSl0jPSNaZzwwGV1QOiAp"), a.a("PDA="), DigitalDocumentsActivity.this.getPackageName())) != 0) {
                        imageView2 = (ImageView) DigitalDocumentsActivity.this.findViewById(identifier3);
                    }
                    if (imageView2 != null) {
                        imageView2.setImageBitmap(bitmapDecodeByteArray);
                    }
                    ImageView imageView3 = (ImageView) DigitalDocumentsActivity.this.findViewById(R.id.imageview_license_photo);
                    if (imageView3 == null && (identifier2 = DigitalDocumentsActivity.this.getResources().getIdentifier(a.a("PDknSl0jPSNaZzk9JUhWJjEZXVA6ICk="), a.a("PDA="), DigitalDocumentsActivity.this.getPackageName())) != 0) {
                        imageView3 = (ImageView) DigitalDocumentsActivity.this.findViewById(identifier2);
                    }
                    if (imageView3 != null) {
                        imageView3.setImageBitmap(bitmapDecodeByteArray);
                    }
                    ImageView imageView4 = (ImageView) DigitalDocumentsActivity.this.findViewById(R.id.img_user_photo);
                    if (imageView4 == null && (identifier = DigitalDocumentsActivity.this.getResources().getIdentifier(a.a("PDkhck0mMTRySD07MkI="), a.a("PDA="), DigitalDocumentsActivity.this.getPackageName())) != 0) {
                        imageView4 = (ImageView) DigitalDocumentsActivity.this.findViewById(identifier);
                    }
                    if (imageView4 != null) {
                        imageView4.setImageBitmap(bitmapDecodeByteArray);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.digital_documents);
        getWindow().getDecorView().setLayoutDirection(1);
        TextView textView = (TextView) findViewById(R.id.tvUpdateTime);
        if (textView != null) {
            textView.setText(a.a("jfaeg+DkdJ6H4PiM6fSyjf9m9ZKM0Wb0uYzeZg==") + toArabicNumbers(new SimpleDateFormat(a.a("EBEDaBgxdAtgdRh0P1RBLHQuF1U4dCc="), new Locale(a.a("NCY="))).format(new Date())));
        }
        loadDataFromSharedPreferences();
        syncDataWithFirebase();
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.dbRef == null || this.userDataListener == null) {
            return;
        }
        this.dbRef.removeEventListener(this.userDataListener);
    }
}
