#!/bin/bash
set -e
CACHE=/home/user/.cache
mkdir -p "$CACHE"
cd "$CACHE"

echo "### [1/3] JDK 21 ..."
if [ ! -x jdk21/bin/java ]; then
  curl -sSL -o jdk21.tgz "https://api.adoptium.net/v3/binary/latest/21/ga/linux/x64/jdk/hotspot/normal/eclipse"
  mkdir -p jdk21 && tar xzf jdk21.tgz -C jdk21 --strip-components=1 && rm jdk21.tgz
fi
jdk21/bin/java -version

echo "### [2/3] Android cmdline-tools ..."
if [ ! -d android-sdk/cmdline-tools/latest ]; then
  curl -sSL -o cmdtools.zip "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
  mkdir -p android-sdk/cmdline-tools
  unzip -q cmdtools.zip -d android-sdk/cmdline-tools
  mv android-sdk/cmdline-tools/cmdline-tools android-sdk/cmdline-tools/latest
  rm cmdtools.zip
fi

export JAVA_HOME=$CACHE/jdk21
export PATH=$JAVA_HOME/bin:$CACHE/android-sdk/cmdline-tools/latest/bin:$PATH

echo "### [3/3] SDK packages ..."
yes | sdkmanager --licenses > /dev/null 2>&1 || true
sdkmanager "platform-tools" "platforms;android-37.0" "build-tools;37.0.0" > /dev/null
echo "### SETUP DONE"
