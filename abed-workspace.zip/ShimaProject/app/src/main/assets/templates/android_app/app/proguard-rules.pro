# قواعد ProGuard للمشروع $project_name$
