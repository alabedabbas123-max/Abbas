package com.almlkid.kay.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.*;
import android.text.TextPaint;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;
import android.text.style.UpdateAppearance;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.EditText;
import com.shima.demo.ThemeConfig;
import com.shima.performance.EditorTextSnapshot;
import com.shima.editor.core.PieceTableDocument;
import com.shima.editor.core.UndoRedoManager;
import java.util.*;

/** Code editor backed by a non-overlapping lexer and lightweight syntax checks. */
public class AlmlkEditor extends EditText {
  public interface DiagnosticsListener {
    void onDiagnostics(List<CodeLanguageTools.Diagnostic> items);
  }

  public interface ChangeListener {
    void onChanged(long documentVersion);
  }

  private int keyword,
      string,
      comment,
      number,
      annotation,
      tag,
      identifier,
      function,
      variable,
      operator,
      namespace,
      separator;
  private boolean applying;
  private int generation;
  private int dirtyStart = Integer.MAX_VALUE, dirtyEnd = -1;
  private boolean viewportRefresh = true;
  private boolean analysisPaused;
  private int lastTouchOffset = -1;
  private java.util.concurrent.ExecutorService languageWorker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  private java.util.concurrent.Future<?> languageTask;
  private String fileName = "";
  private int contentVersion;
  private int selectedLineColor;
  private final Paint selectedLinePaint = new Paint();
  private float zoomPreview = 1f, zoomFocusX, zoomFocusY, zoomBaseTextSize;
  private boolean scalingGesture;
  private long lastAnalysisErrorTime;
  private volatile int indexedVersion = -1;
  private volatile String indexedSource = "";
  private final EditorTextSnapshot textSnapshot = new EditorTextSnapshot();
  // The EditText remains the compatibility/UI surface, while this piece table is the authoritative
  // range model for line lookup, incremental edits, and large-document services.
  private PieceTableDocument coreDocument;
  private UndoRedoManager coreHistory;
  private List<CodeLanguageTools.Diagnostic> diagnostics = Collections.emptyList();

  public interface ScrollListener {
    void onEditorScroll(int x, int y);

    void onEditorZoom(float textSizePixels);
  }

  private DiagnosticsListener diagnosticsListener;
  private ChangeListener changeListener;
  private ScrollListener scrollListener;
  private ScaleGestureDetector scaleDetector;
  private final Runnable refreshTask =
      new Runnable() {
        @Override
        public void run() {
          refreshLanguageState();
        }
      };

  private static final class SyntaxSpan extends ForegroundColorSpan {
    SyntaxSpan(int color) {
      super(color);
    }
  }

  private static final class ErrorSpan extends CharacterStyle implements UpdateAppearance {
    @Override
    public void updateDrawState(TextPaint paint) {
      paint.underlineColor = Color.RED;
      paint.underlineThickness = 2.5f;
      paint.setUnderlineText(true);
    }
  }

  public AlmlkEditor(Context c) {
    super(c);
    init();
  }

  public AlmlkEditor(Context c, AttributeSet a) {
    super(c, a);
    init();
  }

  public AlmlkEditor(Context c, AttributeSet a, int s) {
    super(c, a, s);
    init();
  }

  private void init() {
    setLayoutDirection(LAYOUT_DIRECTION_LTR);
    setTextDirection(TEXT_DIRECTION_LTR);
    if (android.os.Build.VERSION.SDK_INT >= 26) {
      setImportantForAutofill(IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
      setAutofillHints((String[]) null);
      setTextClassifier(android.view.textclassifier.TextClassifier.NO_OP);
    }
    setSaveEnabled(false);
    // Compact editor baseline requested by the IDE layout: 10sp keeps more code visible without
    // changing the pinch-zoom limits.
    setTextSize(10);
    setTypeface(Typeface.MONOSPACE);
    setGravity(Gravity.TOP | Gravity.LEFT);
    setPadding(16, 12, 20, 12);
    applyTheme();
    setSingleLine(false);
    setMaxLines(Integer.MAX_VALUE);
    setHorizontallyScrolling(true);
    if (android.os.Build.VERSION.SDK_INT >= 23) {
      // Code has no prose wrapping: simple line breaking is much cheaper during fast flings.
      setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);
      setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE);
    }
    setElegantTextHeight(false);
    configureCodeInputMethod();
    setHorizontallyScrolling(true);
    setHorizontalScrollBarEnabled(true);
    setVerticalScrollBarEnabled(true);
    setScrollBarStyle(SCROLLBARS_INSIDE_OVERLAY);
    setOverScrollMode(OVER_SCROLL_ALWAYS);
    setSingleLine(false);
    scaleDetector =
        new ScaleGestureDetector(
            getContext(),
            new ScaleGestureDetector.SimpleOnScaleGestureListener() {
              @Override
              public boolean onScaleBegin(ScaleGestureDetector detector) {
                scalingGesture = true;
                zoomBaseTextSize = getTextSize();
                zoomPreview = 1f;
                zoomFocusX = detector.getFocusX();
                zoomFocusY = detector.getFocusY();
                return true;
              }

              @Override
              public boolean onScale(ScaleGestureDetector detector) {
                float factor = detector.getScaleFactor();
                if (Float.isNaN(factor) || Float.isInfinite(factor) || factor <= 0f) return true;
                float min = 10f * getResources().getDisplayMetrics().scaledDensity;
                float max = 32f * getResources().getDisplayMetrics().scaledDensity;
                float target =
                    Math.max(
                        min,
                        Math.min(max, zoomBaseTextSize * zoomPreview * factor));
                zoomPreview = target / Math.max(1f, zoomBaseTextSize);
                zoomFocusX = detector.getFocusX();
                zoomFocusY = detector.getFocusY();
                // Do not scale the Canvas while TextView is laying out. Canvas scaling changes the
                // clip and can make a long editor appear empty after a pinch. The final size is
                // committed atomically in onScaleEnd instead.
                postInvalidateOnAnimation();
                return true;
              }

              @Override
              public void onScaleEnd(ScaleGestureDetector detector) {
                float min = 10f * getResources().getDisplayMetrics().scaledDensity;
                float max = 32f * getResources().getDisplayMetrics().scaledDensity;
                float target = zoomBaseTextSize * zoomPreview;
                if (Float.isNaN(target) || Float.isInfinite(target)) target = zoomBaseTextSize;
                target = Math.max(min, Math.min(max, target));
                final float oldSize = Math.max(1f, zoomBaseTextSize);
                final float ratio = target / oldSize;
                final int oldScrollX = getScrollX();
                final int oldScrollY = getScrollY();
                zoomPreview = 1f;
                setTextSize(TypedValue.COMPLEX_UNIT_PX, target);
                if (scrollListener != null) scrollListener.onEditorZoom(target);
                viewportRefresh = true;
                post(
                    () -> {
                      // Keep the area under the fingers visible after re-layout.
                      scrollTo(
                          Math.max(0, Math.round(oldScrollX * ratio)),
                          Math.max(0, Math.round(oldScrollY * ratio)));
                      postInvalidateOnAnimation();
                    });
                scheduleRefresh();
              }
            });
    coreDocument = new PieceTableDocument("", "");
    coreHistory = new UndoRedoManager();
    addTextChangedListener(
        new TextWatcher() {
          public void beforeTextChanged(CharSequence s, int st, int c, int a) {}

          public void onTextChanged(CharSequence s, int start, int before, int count) {
            textSnapshot.applyChange(s, start, before, count);
            if (coreDocument != null) {
              try {
                String removed = coreDocument.readRange(start, start + before).toString();
                String inserted = s.subSequence(start, Math.min(s.length(), start + count)).toString();
                coreDocument.replace(start, start + before, inserted);
                if (!applying && coreHistory != null) coreHistory.record(start, removed, inserted);
              } catch (Throwable mismatch) {
                // A programmatic source load can arrive as a replacement before the UI callback
                // has observed the previous buffer. Re-seed the model rather than blocking input.
                coreDocument = new PieceTableDocument(fileName, s);
                if (coreHistory == null) coreHistory = new UndoRedoManager();
                else coreHistory.clear();
              }
            }
            if (!applying) {
              contentVersion++;
              if (changeListener != null) changeListener.onChanged(contentVersion);
              dirtyStart = Math.min(dirtyStart, Math.max(0, start));
              dirtyEnd = Math.max(dirtyEnd, Math.min(s.length(), start + Math.max(1, count)));
              if (!analysisPaused) scheduleRefresh();
            }
          }

          public void afterTextChanged(Editable e) {}
        });
  }

  /** Configures the editor as a code field, not a prose field. */
  private void configureCodeInputMethod() {
    int codeInputType =
        android.text.InputType.TYPE_CLASS_TEXT
            // Visible-password mode is intentionally used for code: it disables IME autocorrect
            // on keyboards that ignore NO_SUGGESTIONS while preserving normal visible text.
            | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            // The app owns completion; the IME must not provide a second completion layer.
            | android.text.InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE;
    setInputType(codeInputType);
    // Keep the raw value explicit because some IMEs inspect getRawInputType().
    setRawInputType(codeInputType);
    setSingleLine(false);
    setMaxLines(Integer.MAX_VALUE);
    setImeOptions(
        android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI
            | android.view.inputmethod.EditorInfo.IME_FLAG_NO_FULLSCREEN
            | android.view.inputmethod.EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING
            | android.view.inputmethod.EditorInfo.IME_ACTION_NONE);
    setPrivateImeOptions(
        "nm;noMicrophoneKey;noSuggestions;noAutoCorrect;"
            + "com.google.android.inputmethod.latin.noMicrophoneKey");
  }

  public void setScrollListener(ScrollListener listener) {
    scrollListener = listener;
  }

  public void setChangeListener(ChangeListener listener) {
    changeListener = listener;
  }

  public void setAnalysisPaused(boolean paused) {
    analysisPaused = paused;
    if (paused) removeCallbacks(refreshTask);
  }

  /** Returns the current selection, or the identifier surrounding the caret for navigation. */
  public int[] selectionOrIdentifier() {
    Editable editable = getText();
    if (editable == null) return new int[] {0, 0};
    int start = Math.max(0, Math.min(getSelectionStart(), getSelectionEnd()));
    int end = Math.max(start, Math.min(editable.length(), Math.max(getSelectionStart(), getSelectionEnd())));
    if (start != end || editable.length() == 0) return new int[] {start, end};
    int at = Math.max(0, Math.min(start, editable.length() - 1));
    if (!Character.isJavaIdentifierPart(editable.charAt(at)) && at > 0
        && Character.isJavaIdentifierPart(editable.charAt(at - 1))) at--;
    if (!Character.isJavaIdentifierPart(editable.charAt(at))) return new int[] {start, end};
    int left = at;
    int right = at + 1;
    while (left > 0 && Character.isJavaIdentifierPart(editable.charAt(left - 1))) left--;
    while (right < editable.length() && Character.isJavaIdentifierPart(editable.charAt(right))) right++;
    return new int[] {left, right};
  }

  public void normalizeSelectionToTouchedIdentifier() {
    Editable editable = getText();
    if (editable == null || editable.length() == 0 || lastTouchOffset < 0) return;
    int at = Math.max(0, Math.min(lastTouchOffset, editable.length() - 1));
    if (!Character.isJavaIdentifierPart(editable.charAt(at))) {
      if (at > 0 && Character.isJavaIdentifierPart(editable.charAt(at - 1))) at--;
      else return;
    }
    int start = at, end = at + 1;
    while (start > 0 && Character.isJavaIdentifierPart(editable.charAt(start - 1))) start--;
    while (end < editable.length() && Character.isJavaIdentifierPart(editable.charAt(end))) end++;
    if (start < end && (start != getSelectionStart() || end != getSelectionEnd()))
      setSelection(start, end);
  }

  @Override
  protected void onScrollChanged(int horizontal, int vertical, int oldHorizontal, int oldVertical) {
    super.onScrollChanged(horizontal, vertical, oldHorizontal, oldVertical);
    if (scrollListener != null) scrollListener.onEditorScroll(horizontal, vertical);
    if (vertical != oldVertical && getText() != null && getText().length() > 80000) {
      viewportRefresh = true;
      cancelLanguageTask();
      removeCallbacks(refreshTask);
      // Do not analyze while the finger/fling is moving; refresh only after it settles.
      postDelayed(refreshTask, 180);
    }
  }

  @Override
  public boolean onTouchEvent(MotionEvent event) {
    if (event.getActionMasked() == MotionEvent.ACTION_DOWN && event.getPointerCount() == 1) {
      try {
        lastTouchOffset = getOffsetForPosition(event.getX(), event.getY());
      } catch (Throwable ignored) {
        lastTouchOffset = -1;
      }
    }
    boolean wasScaling = scalingGesture;
    if (scaleDetector != null) scaleDetector.onTouchEvent(event);
    if (!wasScaling && scalingGesture) {
      MotionEvent cancel = MotionEvent.obtain(event);
      cancel.setAction(MotionEvent.ACTION_CANCEL);
      super.onTouchEvent(cancel);
      cancel.recycle();
    }
    if (scalingGesture) {
      int action = event.getActionMasked();
      if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL)
        scalingGesture = false;
      return true;
    }
    return super.onTouchEvent(event);
  }

  @Override
  public boolean performClick() {
    try {
      return super.performClick();
    } catch (RuntimeException error) {
      if (isDeadSystem(error)) return false;
      throw error;
    }
  }

  @Override
  public int getAutofillType() {
    return AUTOFILL_TYPE_NONE;
  }

  private boolean isDeadSystem(Throwable error) {
    for (Throwable current = error; current != null; current = current.getCause()) {
      String name = current.getClass().getName();
      if (name.endsWith("DeadSystemException") || name.endsWith("DeadSystemRuntimeException"))
        return true;
    }
    return false;
  }

  public void applyTheme() {
    ThemeConfig theme = new ThemeConfig(getContext());
    setBackgroundColor(theme.color(ThemeConfig.BACKGROUND));
    setTextColor(theme.color(ThemeConfig.PLAIN));
    setHighlightColor(theme.color(ThemeConfig.SELECTED_TEXT));
    keyword = theme.color(ThemeConfig.KEYWORD);
    string = theme.color(ThemeConfig.LITERAL);
    comment = theme.color(ThemeConfig.COMMENT);
    number = theme.color(ThemeConfig.LITERAL);
    annotation = theme.color(ThemeConfig.OPERATOR);
    tag = theme.color(ThemeConfig.TYPE);
    identifier = theme.color(ThemeConfig.IDENTIFIER);
    function = theme.color(ThemeConfig.FUNCTION);
    variable = theme.color(ThemeConfig.VARIABLE);
    operator = theme.color(ThemeConfig.OPERATOR);
    namespace = theme.color(ThemeConfig.NAMESPACE);
    separator = theme.color(ThemeConfig.SEPARATOR);
    selectedLineColor = theme.color(ThemeConfig.SELECTED_LINE);
    if (getText() != null) {
      invalidate();
      scheduleRefresh();
    }
  }

  @Override
  protected void onSelectionChanged(int start, int end) {
    super.onSelectionChanged(start, end);
    postInvalidateOnAnimation();
  }

  @Override
  protected void onDraw(Canvas canvas) {
    // Text size is committed only after a pinch ends. Avoiding a transient canvas scale keeps the
    // TextView clip, line layout, and syntax spans synchronized during zoom.
    drawSelectedLine(canvas);
    super.onDraw(canvas);
  }

  private void drawSelectedLine(Canvas canvas) {
    android.text.Layout layout = getLayout();
    Editable editable = getText();
    if (layout == null
        || editable == null
        || editable.length() == 0
        || Color.alpha(selectedLineColor) == 0) return;
    int cursor = Math.max(0, Math.min(getSelectionStart(), editable.length()));
    int line = layout.getLineForOffset(cursor);
    float top = getTotalPaddingTop() + layout.getLineTop(line) - getScrollY();
    float bottom = getTotalPaddingTop() + layout.getLineBottom(line) - getScrollY();
    selectedLinePaint.setColor(selectedLineColor);
    canvas.drawRect(0, top, getWidth(), bottom, selectedLinePaint);
  }

  public void setFileName(String name) {
    fileName = name == null ? "" : name;
    indexedVersion = -1;
    indexedSource = "";
    viewportRefresh = true;
    dirtyStart = 0;
    dirtyEnd = getText() == null ? 0 : getText().length();
    scheduleRefresh();
  }

  /** Re-seeds the range model when a tab changes without rebuilding the visible EditText. */
  public void resetCoreModel(String uri, CharSequence currentText) {
    fileName = uri == null ? fileName : uri;
    coreDocument = new PieceTableDocument(fileName, currentText == null ? "" : currentText);
    if (coreHistory == null) coreHistory = new UndoRedoManager();
    else coreHistory.clear();
    textSnapshot.reset(currentText == null ? "" : currentText);
  }

  public PieceTableDocument coreDocument() {
    return coreDocument;
  }

  public void setDiagnosticsListener(DiagnosticsListener listener) {
    diagnosticsListener = listener;
    notifyDiagnostics();
  }

  public List<CodeLanguageTools.Diagnostic> getDiagnostics() {
    return new ArrayList<>(diagnostics);
  }

  public List<String> completions() {
    return CodeLanguageTools.complete(fileName, getText().toString(), getSelectionStart());
  }

  public void applyCompletion(String value) {
    String text = getText().toString();
    int cursor = Math.max(0, getSelectionStart()),
        start = CodeLanguageTools.completionStart(text, cursor);
    getText().replace(start, cursor, value);
    int target = start + value.length();
    if (value.endsWith("()")) target--;
    setSelection(target);
    requestFocus();
  }

  public String formatCode() {
    return CodeLanguageTools.format(fileName, getText().toString());
  }

  public void refreshNow() {
    if (analysisPaused) return;
    removeCallbacks(refreshTask);
    refreshLanguageState();
  }

  private void scheduleRefresh() {
    if (analysisPaused) return;
    generation++;
    cancelLanguageTask();
    removeCallbacks(refreshTask);
    postDelayed(refreshTask, 100);
  }

  private void cancelLanguageTask() {
    if (languageTask != null) {
      languageTask.cancel(true);
      languageTask = null;
    }
  }

  private void refreshLanguageState() {
    Editable editable = getText();
    if (editable == null) return;
    final int length = editable.length();
    final String analyzedFile = fileName;
    final int request = ++generation;
    final int version = contentVersion;
    final boolean contentChanged = version != indexedVersion;
    int windowStart = 0, windowEnd = length;
    if (length > 80000) {
      android.text.Layout layout = getLayout();
      int visibleStart = Math.max(0, getSelectionStart());
      int visibleEnd = Math.min(length, visibleStart + 18000);
      if (layout != null && layout.getLineCount() > 0) {
        int firstLine = Math.max(0, layout.getLineForVertical(getScrollY()) - 16);
        int lastLine =
            Math.min(
                layout.getLineCount() - 1,
                layout.getLineForVertical(getScrollY() + getHeight()) + 24);
        visibleStart = layout.getLineStart(firstLine);
        visibleEnd = layout.getLineEnd(lastLine);
      }
      windowStart = Math.max(0, visibleStart - 2500);
      windowEnd = Math.min(length, Math.max(visibleEnd + 4000, windowStart + 12000));
      if (windowEnd - windowStart > 24000) windowEnd = windowStart + 24000;
      while (windowStart > 0 && editable.charAt(windowStart - 1) != '\n') windowStart--;
    } else if (!viewportRefresh && dirtyStart != Integer.MAX_VALUE) {
      windowStart = Math.max(0, Math.min(dirtyStart, length));
      windowEnd = Math.max(windowStart, Math.min(length, dirtyEnd));
      while (windowStart > 0 && editable.charAt(windowStart - 1) != '\n') windowStart--;
      while (windowEnd < length && editable.charAt(windowEnd) != '\n') windowEnd++;
      if (windowEnd < length) windowEnd++;
      int previousLine =
          windowStart > 0 ? TextUtils.lastIndexOf(editable, '\n', windowStart - 2) + 1 : 0;
      windowStart = Math.max(0, previousLine);
    }
    dirtyStart = Integer.MAX_VALUE;
    dirtyEnd = -1;
    viewportRefresh = false;
    final int baseOffset = windowStart;
    final int analyzedEnd = windowEnd;
    final boolean large = length > 80000;
    cancelLanguageTask();
    languageTask =
        languageWorker.submit(
            () -> {
          try {
            String source;
            if (!contentChanged && indexedVersion == version && indexedSource.length() == length) {
              source = indexedSource;
            } else {
              EditorTextSnapshot.Value snapshot = textSnapshot.copy();
              if (snapshot.version != textSnapshot.version() || snapshot.text.length() != length) {
                post(() -> {
                  if (request == generation && !analysisPaused) scheduleRefresh();
                });
                return;
              }
              source = snapshot.text;
            }
            int safeStart = Math.max(0, Math.min(baseOffset, source.length()));
            int safeEnd = Math.max(safeStart, Math.min(analyzedEnd, source.length()));
            String analyzedText = source.substring(safeStart, safeEnd);
            if (contentChanged) {
              ProjectSymbolIndex.registerSource(analyzedFile, source);
              indexedSource = source;
              indexedVersion = version;
            }
            final List<CodeLanguageTools.Range> ranges =
                CodeLanguageTools.highlight(analyzedFile, analyzedText);
            final boolean diagnosticsUpdated = contentChanged;
            final List<CodeLanguageTools.Diagnostic> found =
                diagnosticsUpdated && !large
                    ? CodeLanguageTools.inspect(analyzedFile, source)
                    : Collections.emptyList();
            post(
                () ->
                    applyLanguageState(
                        request,
                        safeStart,
                        safeEnd,
                        large,
                        diagnosticsUpdated,
                        ranges,
                        found));
          } catch (Throwable error) {
            post(() -> showAnalysisError(error));
          }
        });
  }

  private void applyLanguageState(
      int request,
      int baseOffset,
      int analyzedEnd,
      boolean large,
      boolean diagnosticsUpdated,
      List<CodeLanguageTools.Range> ranges,
      List<CodeLanguageTools.Diagnostic> found) {
    if (request != generation || getText() == null) return;
    Editable editable = getText();
    int cursor = Math.max(0, getSelectionStart());
    applying = true;
    clearAnalysisSpans(baseOffset, analyzedEnd, large, diagnosticsUpdated);
    int applied = 0;
    for (CodeLanguageTools.Range range : ranges) {
      if (applied >= 7000) break;
      int start = baseOffset + range.start, end = baseOffset + range.end;
      if (start >= 0 && end <= editable.length() && start < end) {
        editable.setSpan(
            new SyntaxSpan(colorFor(range.type)), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        applied++;
      }
    }
    if (diagnosticsUpdated) {
      diagnostics = found;
      for (CodeLanguageTools.Diagnostic item : diagnostics) {
        if (editable.length() == 0) break;
        int start = Math.max(0, Math.min(item.offset, editable.length() - 1));
        int end = Math.max(start + 1, Math.min(item.end, editable.length()));
        editable.setSpan(new ErrorSpan(), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
      }
    }
    if (cursor <= editable.length()) setSelection(cursor);
    applying = false;
    if (diagnosticsUpdated) notifyDiagnostics();
  }

  private void showAnalysisError(Throwable error) {
    long now = android.os.SystemClock.uptimeMillis();
    if (now - lastAnalysisErrorTime < 3000 || !isAttachedToWindow()) return;
    lastAnalysisErrorTime = now;
    try {
      new android.app.AlertDialog.Builder(getContext())
          .setTitle("خطأ في تحليل الكود")
          .setMessage(
              "تم إيقاف التحليل لحماية التطبيق:\n\n"
                  + error.getClass().getSimpleName()
                  + (error.getMessage() == null ? "" : "\n" + error.getMessage()))
          .setPositiveButton("حسنًا", null)
          .show();
    } catch (Throwable ignored) {
    }
  }

  private void clearAnalysisSpans(int start, int end, boolean clearAllSyntax, boolean clearErrors) {
    Editable editable = getText();
    if (editable == null) return;
    boolean previous = applying;
    applying = true;
    int from = clearAllSyntax ? 0 : Math.max(0, Math.min(start, editable.length()));
    int to = clearAllSyntax ? editable.length() : Math.max(from, Math.min(end, editable.length()));
    for (SyntaxSpan span : editable.getSpans(from, to, SyntaxSpan.class)) editable.removeSpan(span);
    if (clearErrors) {
      for (ErrorSpan span : editable.getSpans(0, editable.length(), ErrorSpan.class))
        editable.removeSpan(span);
    }
    applying = previous;
  }

  private int colorFor(int type) {
    switch (type) {
      case CodeLanguageTools.KEYWORD:
        return keyword;
      case CodeLanguageTools.STRING:
        return string;
      case CodeLanguageTools.COMMENT:
        return comment;
      case CodeLanguageTools.NUMBER:
        return number;
      case CodeLanguageTools.ANNOTATION:
        return annotation;
      case CodeLanguageTools.IDENTIFIER:
        return identifier;
      case CodeLanguageTools.FUNCTION:
        return function;
      case CodeLanguageTools.VARIABLE:
        return variable;
      case CodeLanguageTools.OPERATOR:
        return operator;
      case CodeLanguageTools.NAMESPACE:
        return namespace;
      case CodeLanguageTools.SEPARATOR:
        return separator;
      default:
        return tag;
    }
  }

  @Override
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (languageWorker.isShutdown())
      languageWorker = java.util.concurrent.Executors.newSingleThreadExecutor();
  }

  @Override
  protected void onDetachedFromWindow() {
    generation++;
    removeCallbacks(refreshTask);
    cancelLanguageTask();
    languageWorker.shutdownNow();
    super.onDetachedFromWindow();
  }

  private void notifyDiagnostics() {
    if (diagnosticsListener != null) diagnosticsListener.onDiagnostics(getDiagnostics());
  }
}
