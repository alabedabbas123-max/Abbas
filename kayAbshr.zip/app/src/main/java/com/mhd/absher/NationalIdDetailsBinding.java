package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class NationalIdDetailsBinding {
    public final ImageView btnBack;
    public final LinearLayout detailsLayout;
    public final RelativeLayout headerRow;
    public final ImageView ivIdIcon;
    public final LinearLayout linear51;
    public final LinearLayout linear52;
    public final LinearLayout linear53;
    public final LinearLayout linear54;
    public final LinearLayout linear55;
    public final LinearLayout linear56;
    public final LinearLayout linear57;
    public final RelativeLayout rootView;
    public final ScrollView scrollContent;
    public final Space space58;
    public final TextView textview72;
    public final TextView textview73;
    public final TextView textview74;
    public final TextView textview75;
    public final TextView textview76;
    public final RelativeLayout topBar;
    public final TextView tvCardTitle;
    public final TextView tvExpiryDate;
    public final TextView tvIdNumber;
    public final TextView tvIdVersion;
    public final TextView tvIssueDate;
    public final TextView tvIssuePlace;
    public final TextView tvTitle;
    public final View view8;

    private NationalIdDetailsBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, ScrollView scrollView, LinearLayout linearLayout, LinearLayout linearLayout2, RelativeLayout relativeLayout3, ImageView imageView2, TextView textView2, View view, LinearLayout linearLayout3, LinearLayout linearLayout4, TextView textView3, TextView textView4, LinearLayout linearLayout5, TextView textView5, TextView textView6, LinearLayout linearLayout6, TextView textView7, TextView textView8, LinearLayout linearLayout7, TextView textView9, TextView textView10, LinearLayout linearLayout8, TextView textView11, TextView textView12, Space space) {
        this.rootView = relativeLayout;
        this.topBar = relativeLayout2;
        this.btnBack = imageView;
        this.tvTitle = textView;
        this.scrollContent = scrollView;
        this.linear51 = linearLayout;
        this.linear52 = linearLayout2;
        this.headerRow = relativeLayout3;
        this.ivIdIcon = imageView2;
        this.tvCardTitle = textView2;
        this.view8 = view;
        this.detailsLayout = linearLayout3;
        this.linear53 = linearLayout4;
        this.textview72 = textView3;
        this.tvIdNumber = textView4;
        this.linear54 = linearLayout5;
        this.textview73 = textView5;
        this.tvIssueDate = textView6;
        this.linear55 = linearLayout6;
        this.textview74 = textView7;
        this.tvIssuePlace = textView8;
        this.linear56 = linearLayout7;
        this.textview75 = textView9;
        this.tvExpiryDate = textView10;
        this.linear57 = linearLayout8;
        this.textview76 = textView11;
        this.tvIdVersion = textView12;
        this.space58 = space;
    }

    public static NationalIdDetailsBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBar);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBack);
        TextView textView = (TextView) findChildViewById(view, R.id.tvTitle);
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.scrollContent);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear51);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear52);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.headerRow);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.ivIdIcon);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvCardTitle);
        View viewFindChildViewById = findChildViewById(view, R.id.view8);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.detailsLayout);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.linear53);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview72);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tvIdNumber);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.linear54);
        TextView textView5 = (TextView) findChildViewById(view, R.id.textview73);
        TextView textView6 = (TextView) findChildViewById(view, R.id.tvIssueDate);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.linear55);
        TextView textView7 = (TextView) findChildViewById(view, R.id.textview74);
        TextView textView8 = (TextView) findChildViewById(view, R.id.tvIssuePlace);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.linear56);
        TextView textView9 = (TextView) findChildViewById(view, R.id.textview75);
        TextView textView10 = (TextView) findChildViewById(view, R.id.tvExpiryDate);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.linear57);
        TextView textView11 = (TextView) findChildViewById(view, R.id.textview76);
        TextView textView12 = (TextView) findChildViewById(view, R.id.tvIdVersion);
        Space space = (Space) findChildViewById(view, R.id.space58);
        if (relativeLayout2 == null || imageView == null || textView == null || scrollView == null || linearLayout == null || linearLayout2 == null || relativeLayout3 == null || imageView2 == null || textView2 == null || viewFindChildViewById == null || linearLayout3 == null || linearLayout4 == null || textView3 == null || textView4 == null || linearLayout5 == null || textView5 == null || textView6 == null || linearLayout6 == null || textView7 == null || textView8 == null || linearLayout7 == null || textView9 == null || textView10 == null || linearLayout8 == null || textView11 == null || textView12 == null || space == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new NationalIdDetailsBinding(relativeLayout, relativeLayout2, imageView, textView, scrollView, linearLayout, linearLayout2, relativeLayout3, imageView2, textView2, viewFindChildViewById, linearLayout3, linearLayout4, textView3, textView4, linearLayout5, textView5, textView6, linearLayout6, textView7, textView8, linearLayout7, textView9, textView10, linearLayout8, textView11, textView12, space);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static NationalIdDetailsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static NationalIdDetailsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.national_id_details, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
