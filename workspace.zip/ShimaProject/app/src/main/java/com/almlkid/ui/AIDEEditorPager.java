package com.almlkid.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.*;
import android.widget.*;
import com.almlkid.kay.ui.AlmlkEditor;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.EditorSearchEngine;
import com.almlkid.kay.ui.KayStyleCompletionEngine;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.ui.SmaliDefinitionResolver;
import com.shima.demo.R;
import com.shima.demo.ThemeConfig;
import com.shima.performance.EditorTextSnapshot;
import com.shima.performance.EncodingManager;
import com.shima.performance.FileSystemRepository;
import com.shima.performance.InstantSessionStore;
import com.shima.editor.core.AtomicSaveManager;
import com.shima.editor.core.SavePolicy;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Multi-tab editor with file header, line numbers and a keyboard-only quick-key bar. */
public class AIDEEditorPager extends LinearLayout {
  public interface QuickFixListener {
    void createMissingMember(ProjectSymbolIndex.MissingMember member);
  }

  public interface SessionListener {
    void restored(boolean success);
  }

  public interface DefinitionListener {
    void requested(ProjectSymbolIndex.DefinitionTarget target);
  }

  public interface UsageListener {
    void requested(String fileName, String source, int selectionStart, int selectionEnd);
  }

  public interface ReplaceListener {
    void completed(int replacements);
  }

  public interface DefinitionRequestListener {
    void requested(String fileName, String source, int selectionStart, int selectionEnd);
  }

  private final LinkedHashMap<String, LinearLayout> tabs = new LinkedHashMap<>();
  private final LinkedHashMap<String, String> fileContents = new LinkedHashMap<>();
  // The legacy map is kept only so old sessions can be ignored safely; new sessions never write
  // source content to disk.
  private final LinkedHashMap<String, java.io.File> lazySessionFiles = new LinkedHashMap<>();
  private final LinkedHashMap<String, String> lazySessionReferences = new LinkedHashMap<>();
  private final LinkedHashMap<String, String> sessionReferences = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionCursors = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionScrollX = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionScrollY = new LinkedHashMap<>();
  private LinearLayout tabStrip, quickBar;
  private View fileHeader;
  private View editorRow;
  private TextView headerName, headerPath;
  private ImageView headerIcon;
  private AlmlkEditor code;
  private String activeFile;
  private String loadingFile;
  // بند الإحلال: التراجع/الإعادة مدمجان في موديل almlk (UndoRedoStack) — لا تاريخ خارجي.
  private boolean historyLocked;
  private boolean keyboardVisible, dismissedForCurrentKeyboard;
  private QuickFixListener quickFixListener;
  private DefinitionListener definitionListener;
  private DefinitionRequestListener definitionRequestListener;
  private UsageListener usageListener;
  private int quickFixGeneration, definitionGeneration;
  private PopupWindow completionWindow;
  private ListView completionList;
  private EditorCompletionAdapter completionAdapter;
  private java.util.concurrent.ExecutorService completionWorker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  // Session restore/file reads use a separate lane so they never delay typing or completion.
  private java.util.concurrent.ExecutorService sessionWorker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  // Completion lookups must not queue behind session restore, file I/O, or definition requests.
  private java.util.concurrent.ExecutorService completionLookupWorker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  private FileSystemRepository fileRepository;
  private AtomicSaveManager autoSaveManager;
  private InstantSessionStore sessionStore;
  private java.util.concurrent.Future<?> autoSaveTask;
  private final Runnable autoSaveRunnable = this::queueAutoSave;
  private int completionGeneration;
  // The snapshot is updated by changed ranges on the UI thread and copied only on the worker.
  private final EditorTextSnapshot completionSnapshot = new EditorTextSnapshot();
  private final CompletionLookupCache completionCache = new CompletionLookupCache();
  private java.util.concurrent.Future<?> completionLookupFuture;
  private long lastEditorErrorTime;
  private final Runnable completionTask = this::showLiveCompletions;
  private int largestVisibleHeight;

  public AIDEEditorPager(Context c) {
    super(c);
    init();
  }

  public AIDEEditorPager(Context c, AttributeSet a) {
    super(c, a);
    init();
  }

  public AIDEEditorPager(Context c, AttributeSet a, int s) {
    super(c, a, s);
    init();
  }

  private void init() {
    fileRepository = new FileSystemRepository(getContext());
    autoSaveManager = new AtomicSaveManager(getContext());
    // Constructed from the worker below: SharedPreferences may initialize from disk once.
    setLayoutDirection(LAYOUT_DIRECTION_LTR);
    setOrientation(VERTICAL);
    setBackgroundColor(Color.BLACK);
    addTabs();
    addFileHeader();
    addEditor();
    addQuickKeys();
    applyTheme();
    watchKeyboard();
    setVisibility(GONE);
  }

  private void addTabs() {
    HorizontalScrollView scroll = new HorizontalScrollView(getContext());
    scroll.setHorizontalScrollBarEnabled(false);
    scroll.setFillViewport(true);
    scroll.setBackgroundColor(Color.rgb(34, 34, 34));
    tabStrip = new LinearLayout(getContext());
    tabStrip.setOrientation(HORIZONTAL);
    tabStrip.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    scroll.addView(tabStrip, new HorizontalScrollView.LayoutParams(-2, -1));
    addView(scroll, new LayoutParams(-1, dp(46)));
  }

  private void addFileHeader() {
    LinearLayout header = new LinearLayout(getContext());
    header.setOrientation(HORIZONTAL);
    header.setGravity(Gravity.CENTER_VERTICAL);
    header.setPadding(dp(12), dp(5), dp(12), dp(5));
    header.setBackgroundColor(Color.BLACK);
    header.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    headerIcon = new ImageView(getContext());
    headerIcon.setImageResource(R.drawable.file_type_java);
    headerIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
    header.addView(headerIcon, new LinearLayout.LayoutParams(dp(48), dp(48)));
    LinearLayout labels = new LinearLayout(getContext());
    labels.setOrientation(VERTICAL);
    labels.setPadding(dp(8), 0, 0, 0);
    headerName = text("MainActivity.java", 17, Color.WHITE);
    headerName.setTypeface(null, Typeface.BOLD);
    headerName.setSingleLine(false);
    headerName.setMaxLines(2);
    headerName.setEllipsize(android.text.TextUtils.TruncateAt.END);
    headerPath = text("/storage/emulated/0/AppProjects", 12, Color.LTGRAY);
    headerPath.setSingleLine(true);
    headerPath.setEllipsize(android.text.TextUtils.TruncateAt.START);
    labels.addView(headerName, new LinearLayout.LayoutParams(-1, 0, 1));
    labels.addView(headerPath, new LinearLayout.LayoutParams(-1, 0, 1));
    header.addView(labels, new LinearLayout.LayoutParams(0, -1, 1));
    fileHeader = header;
    addView(header, new LayoutParams(-1, dp(61)));
    View line = new View(getContext());
    line.setBackgroundColor(Color.rgb(41, 182, 246));
    addView(line, new LayoutParams(-1, dp(2)));
  }

  private void addEditor() {
    LinearLayout row = new LinearLayout(getContext());
    row.setOrientation(HORIZONTAL);
    row.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    row.setBackgroundColor(Color.BLACK);
    editorRow = row;
    // بند الإحلال: أرقام الأسطر داخلية في لوحة الرسم (الجالتر) — لا View خارجية.
    code = new AlmlkEditor(getContext());
    code.setLineSpacing(dp(3), 1);
    code.setChangeListener(version -> {
      if (!historyLocked && loadingFile == null) {
        removeCallbacks(autoSaveRunnable);
        postDelayed(autoSaveRunnable, 850L);
      }
    });
    code.setCustomSelectionActionModeCallback(
        new ActionMode.Callback() {
          private static final int CREATE_MISSING_MEMBER = 0x53484D41;
          private static final int EXPAND_SELECTION = 0x53484D42;
          private static final int GO_TO_DEFINITION = 0x53484D43;
          private static final int FIND_USAGES = 0x53484D44;

          @Override
          public boolean onCreateActionMode(ActionMode mode, android.view.Menu menu) {
            code.normalizeSelectionToTouchedIdentifier();
            // بند 3 — فتح قائمة التحديد يجب ألا يهزّ لوحة المفاتيح: إن كانت ظاهرة قبل القائمة
            // تُعاد إلى وضعها فور بدء وضع الإجراء حتى لا تختفي ثم تعود.
            android.graphics.Rect imeFrame = new android.graphics.Rect();
            code.getWindowVisibleDisplayFrame(imeFrame);
            int imeHeightDiff = code.getRootView().getHeight() - imeFrame.bottom;
            boolean imeWasVisible =
                imeHeightDiff > getResources().getDisplayMetrics().density * 100;
            if (imeWasVisible) {
              final android.view.inputmethod.InputMethodManager imm =
                  (android.view.inputmethod.InputMethodManager)
                      getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
              code.postDelayed(() -> imm.showSoftInput(code, 0), 80);
            }
            android.view.MenuItem item =
                menu.add(0, CREATE_MISSING_MEMBER, 0, "إنشاء الدالة في الكلاس");
            android.graphics.drawable.Drawable icon =
                getResources().getDrawable(android.R.drawable.ic_input_add).mutate();
            icon.setColorFilter(0xFF43A047, android.graphics.PorterDuff.Mode.SRC_IN);
            item.setIcon(icon);
            item.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_NEVER);
            android.view.MenuItem expand = menu.add(0, EXPAND_SELECTION, 1, "توسيع التحديد");
            expand.setIcon(android.R.drawable.ic_menu_crop);
            expand.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);
            android.view.MenuItem definition =
                menu.add(0, GO_TO_DEFINITION, 2, "الانتقال إلى العنصر المحدد");
            definition.setIcon(android.R.drawable.ic_menu_directions);
            definition.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_NEVER);
            android.view.MenuItem usages = menu.add(0, FIND_USAGES, 3, "استعراض الاستخدامات");
            usages.setIcon(android.R.drawable.ic_menu_search);
            usages.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_NEVER);
            return true;
          }

          @Override
          public boolean onPrepareActionMode(ActionMode mode, android.view.Menu menu) {
            return false;
          }

          private void analyzeQuickFixOnDemand(ActionMode mode) {
            final int selectionStart = code.getSelectionStart();
            final int selectionEnd = code.getSelectionEnd();
            final String source = code.getText().toString();
            mode.finish();
            final int request = ++quickFixGeneration;
            completionWorker.execute(
                () -> {
                  try {
                    final ProjectSymbolIndex.MissingMember result =
                        ProjectSymbolIndex.analyzeSelection(source, selectionStart, selectionEnd);
                    post(
                        () -> {
                          if (request != quickFixGeneration) return;
                          if (result != null && quickFixListener != null)
                            quickFixListener.createMissingMember(result);
                          else
                            Toast.makeText(
                                    getContext(),
                                    "لا توجد دالة مفقودة للعنصر المحدد",
                                    Toast.LENGTH_SHORT)
                                .show();
                        });
                  } catch (Throwable error) {
                    post(
                        () -> {
                          if (request == quickFixGeneration) showEditorError(error);
                        });
                  }
                });
          }

          private void resolveDefinitionOnDemand(ActionMode mode) {
            final int selectionStart = code.getSelectionStart();
            final int selectionEnd = code.getSelectionEnd();
            final String source = code.getText().toString();
            final String sourceFile = activeFile;
            mode.finish();
            final int request = ++definitionGeneration;
            completionWorker.execute(
                () -> {
                  try {
                    final ProjectSymbolIndex.DefinitionTarget target =
                        sourceFile.toLowerCase(java.util.Locale.US).endsWith(".smali")
                            ? SmaliDefinitionResolver.resolve(
                                sourceFile, source, selectionStart, selectionEnd)
                            : ProjectSymbolIndex.resolveDefinition(
                                sourceFile, source, selectionStart, selectionEnd);
                    post(
                        () -> {
                          if (request != definitionGeneration) return;
                          if (target != null && definitionListener != null) {
                            definitionListener.requested(target);
                          } else if (target == null && definitionRequestListener != null) {
                            definitionRequestListener.requested(
                                sourceFile, source, selectionStart, selectionEnd);
                          } else {
                            Toast.makeText(
                                    getContext(),
                                    "تعذر العثور على تعريف العنصر المحدد",
                                    Toast.LENGTH_SHORT)
                                .show();
                          }
                        });
                  } catch (Throwable error) {
                    post(
                        () -> {
                          if (request == definitionGeneration) showEditorError(error);
                        });
                  }
                });
          }

          private void resolveUsagesOnDemand(ActionMode mode) {
            final int selectionStart = code.getSelectionStart();
            final int selectionEnd = code.getSelectionEnd();
            final String source = code.getText().toString();
            final String sourceFile = activeFile;
            mode.finish();
            final int request = ++definitionGeneration;
            completionWorker.execute(
                () ->
                    post(
                        () -> {
                          if (request != definitionGeneration) return;
                          if (usageListener != null)
                            usageListener.requested(sourceFile, source, selectionStart, selectionEnd);
                        }));
          }

          @Override
          public boolean onActionItemClicked(ActionMode mode, android.view.MenuItem item) {
            int id = item.getItemId();
            if (id == android.R.id.selectAll
                || id == android.R.id.cut
                || id == android.R.id.copy
                || id == android.R.id.paste) {
              boolean handled = code.onTextContextMenuItem(id);
              if (handled && id != android.R.id.selectAll) mode.finish();
              return handled;
            }
            if (id == EXPAND_SELECTION) {
              expandCodeSelection();
              return true;
            }
            if (id == CREATE_MISSING_MEMBER) {
              analyzeQuickFixOnDemand(mode);
              return true;
            }
            if (id == GO_TO_DEFINITION) {
              resolveDefinitionOnDemand(mode);
              return true;
            }
            if (id == FIND_USAGES) {
              resolveUsagesOnDemand(mode);
              return true;
            }
            return false;
          }

          @Override
          public void onDestroyActionMode(ActionMode mode) {
            quickFixGeneration++;
            definitionGeneration++;
          }
        });
    code.addTextChangedListener(
        new android.text.TextWatcher() {
          public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // التراجع/الإعادة مدمجان بموديل المحرك (بند الإحلال) — لا تتبع خارجي.
          }

          public void onTextChanged(CharSequence s, int start, int before, int count) {
            completionSnapshot.applyChange(s, start, before, count);
            cancelCompletionLookup();
            if (!historyLocked
                && isXmlFile()
                && count == 1
                && start > 0
                && start < s.length()
                && s.charAt(start - 1) == '<'
                && s.charAt(start) == '/') {
              final int marker = start + 1;
              post(() -> completeXmlClosingTag(marker));
            }
            removeCallbacks(completionTask);
            completionGeneration++;
            if (!historyLocked) {
              boolean refreshCompletions = false;
              if (count > 0 && start + count <= s.length()) {
                char last = s.charAt(start + count - 1);
                refreshCompletions =
                    Character.isJavaIdentifierPart(last)
                        || last == '.'
                        || last == '<'
                        || last == ':'
                        || last == '@';
              } else if (count == 0 && before > 0 && start > 0 && start <= s.length()) {
                char previous = s.charAt(start - 1);
                refreshCompletions = Character.isJavaIdentifierPart(previous) || previous == '.';
              }
              if (refreshCompletions) postDelayed(completionTask, 24);
              else dismissCompletions();
            } else dismissCompletions();
          }

          public void afterTextChanged(android.text.Editable e) {}
        });
    row.addView(code, new LinearLayout.LayoutParams(0, -1, 1));
    addView(row, new LayoutParams(-1, 0, 1));
  }

  private void expandCodeSelection() {
    String text = code.getText().toString();
    int start = Math.max(0, Math.min(code.getSelectionStart(), code.getSelectionEnd()));
    int end = Math.min(text.length(), Math.max(code.getSelectionStart(), code.getSelectionEnd()));
    int left = start, right = end;
    while (left > 0 && Character.isJavaIdentifierPart(text.charAt(left - 1))) left--;
    while (right < text.length() && Character.isJavaIdentifierPart(text.charAt(right))) right++;
    int dotBefore = left - 1;
    while (dotBefore >= 0 && Character.isWhitespace(text.charAt(dotBefore))) dotBefore--;
    if (dotBefore >= 0 && text.charAt(dotBefore) == '.') {
      left = dotBefore;
      while (left > 0 && Character.isJavaIdentifierPart(text.charAt(left - 1))) left--;
    }
    int cursor = right;
    while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
    if (cursor < text.length() && text.charAt(cursor) == '.') {
      cursor++;
      while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
      while (cursor < text.length() && Character.isJavaIdentifierPart(text.charAt(cursor)))
        cursor++;
    }
    while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
    if (cursor < text.length() && text.charAt(cursor) == '(') {
      int depth = 0;
      char quote = 0;
      boolean escape = false;
      for (int i = cursor; i < text.length(); i++) {
        char value = text.charAt(i);
        if (quote != 0) {
          if (escape) escape = false;
          else if (value == '\\') escape = true;
          else if (value == quote) quote = 0;
        } else if (value == '"' || value == '\'') quote = value;
        else if (value == '(') depth++;
        else if (value == ')' && --depth == 0) {
          right = i + 1;
          break;
        }
      }
    } else right = Math.max(right, cursor);
    if (left == start && right == end) {
      left = text.lastIndexOf('\n', start - 1) + 1;
      int lineEnd = text.indexOf('\n', end);
      right = lineEnd < 0 ? text.length() : lineEnd;
    }
    if (left < right) code.setSelection(left, right);
  }

  private void addQuickKeys() {
    quickBar = new LinearLayout(getContext());
    quickBar.setOrientation(HORIZONTAL);
    quickBar.setGravity(Gravity.CENTER_VERTICAL);
    quickBar.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    quickBar.setBackgroundColor(Color.rgb(31, 31, 31));
    quickBar.setElevation(dp(6));
    quickBar.setContentDescription("شريط رموز البرمجة");
    HorizontalScrollView scroll = new HorizontalScrollView(getContext());
    scroll.setHorizontalScrollBarEnabled(false);
    scroll.setFillViewport(false);
    LinearLayout keys = new LinearLayout(getContext());
    keys.setOrientation(HORIZONTAL);
    keys.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    String[] values = {
      "→", "{", "}", "(", ")", ";", "=", ",", ".", "\"", "'", "|", "&", "[", "]",
      "<", ">", "/", "\\", "+", "-", "*", "%", "!", "?", "#", "@", ":", "_"
    };
    for (String value : values) {
      TextView key = text(value, 18, Color.WHITE);
      key.setGravity(Gravity.CENTER);
      key.setPadding(0, 0, 0, 0);
      key.setBackground(selectable());
      key.setOnClickListener(v -> smartInsert(((TextView) v).getText().toString()));
      keys.addView(key, new LinearLayout.LayoutParams(dp(38), dp(40)));
    }
    scroll.addView(keys, new HorizontalScrollView.LayoutParams(-2, -1));
    quickBar.addView(scroll, new LinearLayout.LayoutParams(0, dp(42), 1));
    TextView close = text("×", 28, Color.WHITE);
    close.setGravity(Gravity.CENTER);
    close.setBackgroundColor(Color.rgb(31, 31, 31));
    close.setOnClickListener(
        v -> {
          dismissedForCurrentKeyboard = true;
          quickBar.setVisibility(GONE);
        });
    quickBar.addView(close, new LinearLayout.LayoutParams(dp(46), dp(42)));
    addView(quickBar, new LayoutParams(-1, dp(42)));
    quickBar.setVisibility(GONE);
  }

  private void watchKeyboard() {
    getViewTreeObserver()
        .addOnGlobalLayoutListener(
            () -> {
              Rect area = new Rect();
              getWindowVisibleDisplayFrame(area);
              int current = area.height();
              if (current > largestVisibleHeight) largestVisibleHeight = current;
              int total = getRootView().getHeight();
              boolean visible =
                  (largestVisibleHeight - current) > Math.max(dp(170), largestVisibleHeight / 6)
                      || (total - area.bottom) > Math.max(dp(170), total / 6);
              if (visible != keyboardVisible) {
                keyboardVisible = visible;
                if (!visible) {
                  dismissedForCurrentKeyboard = false;
                  dismissCompletions();
                  quickBar.setVisibility(GONE);
                  fileHeader.setVisibility(VISIBLE);
                } else {
                  fileHeader.setVisibility(GONE);
                  if (!dismissedForCurrentKeyboard) quickBar.setVisibility(VISIBLE);
                }
              }
            });
  }

  private static final class SessionData {
    String selected;
    final LinkedHashMap<String, String> files = new LinkedHashMap<>();
  }

  public void restoreSessionAsync(SessionListener listener) {
    // Only metadata is read here. The selected file is loaded later, on demand.
    sessionWorker.execute(
        () -> {
          if (sessionStore == null) sessionStore = new InstantSessionStore(getContext());
          InstantSessionStore.Snapshot snapshot = sessionStore.load();
          if (snapshot.tabs.isEmpty()) {
            restoreSessionInBackground(listener); // one-time compatibility with old builds
            return;
          }
          post(() -> applyInstantSession(snapshot, listener));
        });
  }

  private void applyInstantSession(InstantSessionStore.Snapshot snapshot, SessionListener listener) {
    lazySessionReferences.clear();
    sessionReferences.clear();
    sessionCursors.clear();
    sessionScrollX.clear();
    sessionScrollY.clear();
    // تقرير فتح الملفات — مُطهّر الجلسة (checkOpenFile على طريقة AIDE): تُسقط التبويبات التي
    // مرجعها ملف محذوف — لكن فقط عندما يكون التحقق ممكنًا فعليًا (وصول مباشر للتخزين)،
    // وإلا بقيت المراجع محفوظة ليُعاد تحميلها بعد منح الإذن (لا ضياع للجلسة).
    final boolean canVerifyFiles = canVerifyFileExistence();
    int restored = 0;
    for (InstantSessionStore.Tab tab : snapshot.tabs) {
      if (canVerifyFiles
          && tab.reference != null
          && tab.reference.startsWith("/")
          && !new java.io.File(tab.reference).isFile()) {
        continue; // مرجع ميّت — لا تبويبات وهمية تتعطل لاحقًا.
      }
      if (!tabs.containsKey(tab.name)) addTab(tab.name);
      sessionReferences.put(tab.name, tab.reference);
      if (!tab.reference.isEmpty()) lazySessionReferences.put(tab.name, tab.reference);
      sessionCursors.put(tab.name, tab.cursor);
      sessionScrollX.put(tab.name, tab.scrollX);
      sessionScrollY.put(tab.name, tab.scrollY);
      restored++;
    }
    if (restored == 0) {
      if (listener != null) listener.restored(false);
      return;
    }
    String first =
        snapshot.selected != null && tabs.containsKey(snapshot.selected)
            ? snapshot.selected
            : tabs.keySet().iterator().next();
    setVisibility(VISIBLE);
    if (listener != null) listener.restored(true);
    postOnAnimation(() -> selectFile(first));
  }

  /** التحقق من الوجود ممكن فقط مع وصول مباشر للتخزين (وإلا false-سلبي يقتل تبويبات سليمة). */
  private boolean canVerifyFileExistence() {
    if (android.os.Build.VERSION.SDK_INT < 30) return true;
    try {
      return android.os.Environment.isExternalStorageManager();
    } catch (Throwable ignored) {
      return false;
    }
  }

  private void restoreSessionInBackground(SessionListener listener) {
    java.io.File session = new java.io.File(getContext().getFilesDir(), "editor-session.bin");
    if (!session.isFile()) {
      if (listener != null) post(() -> listener.restored(false));
      return;
    }
    try (java.io.DataInputStream input =
        new java.io.DataInputStream(
            new java.io.BufferedInputStream(new java.io.FileInputStream(session)))) {
      int version = input.readInt();
      String selected = input.readUTF();
      int count = Math.min(12, Math.max(0, input.readInt()));
      if (version == 4 || version == 3) {
        LinkedHashMap<String, java.io.File> lazyFiles = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> cursors = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> scrollXs = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> scrollYs = new LinkedHashMap<>();
        java.io.File directory = new java.io.File(getContext().getFilesDir(), "session-tabs");
        for (int i = 0; i < count; i++) {
          String name = input.readUTF();
          String storedName = input.readUTF();
          lazyFiles.put(name, new java.io.File(directory, storedName));
          if (version == 4) {
            cursors.put(name, Math.max(0, input.readInt()));
            scrollXs.put(name, Math.max(0, input.readInt()));
            scrollYs.put(name, Math.max(0, input.readInt()));
          }
        }
        post(() -> applyLazySession(selected, lazyFiles, cursors, scrollXs, scrollYs, listener));
        return;
      }
      if (version == 2 && count > 0) {
        String firstName = input.readUTF();
        String firstContent = readSessionContent(input);
        post(
            () -> {
              applyFirstSessionFile(firstName, firstContent);
              if (listener != null) listener.restored(true);
            });
        SessionData remaining = new SessionData();
        remaining.selected = selected;
        for (int i = 1; i < count; i++) {
          String name = input.readUTF();
          remaining.files.put(name, readSessionContent(input));
        }
        if (!remaining.files.isEmpty()) post(() -> appendSessionFiles(remaining));
        return;
      }
      if (version != 1) throw new java.io.IOException("Unsupported session version");
      SessionData legacy = new SessionData();
      legacy.selected = selected;
      for (int i = 0; i < count; i++) {
        String name = input.readUTF();
        legacy.files.put(name, readSessionContent(input));
      }
      post(
          () -> {
            boolean success = applyLegacySession(legacy);
            if (listener != null) listener.restored(success);
          });
    } catch (Exception error) {
      session.delete();
      post(
          () -> {
            if (listener != null) listener.restored(false);
          });
    }
  }

  private String readSessionContent(java.io.DataInputStream input) throws java.io.IOException {
    int length = input.readInt();
    if (length < 0 || length > 1200000) throw new java.io.IOException("Invalid session file");
    byte[] bytes = new byte[length];
    input.readFully(bytes);
    return EncodingManager.decodeUtf8(bytes);
  }

  private void applyLazySession(
      String selected,
      LinkedHashMap<String, java.io.File> files,
      LinkedHashMap<String, Integer> cursors,
      LinkedHashMap<String, Integer> scrollXs,
      LinkedHashMap<String, Integer> scrollYs,
      SessionListener listener) {
    if (files.isEmpty()) {
      if (listener != null) listener.restored(false);
      return;
    }
    lazySessionFiles.clear();
    lazySessionFiles.putAll(files);
    sessionCursors.clear();
    sessionCursors.putAll(cursors);
    sessionScrollX.clear();
    sessionScrollX.putAll(scrollXs);
    sessionScrollY.clear();
    sessionScrollY.putAll(scrollYs);
    for (String name : files.keySet()) if (!tabs.containsKey(name)) addTab(name);
    String first = files.containsKey(selected) ? selected : files.keySet().iterator().next();
    setVisibility(VISIBLE);
    if (listener != null) listener.restored(true);
    postOnAnimation(() -> selectFile(first));
  }

  private void applyFirstSessionFile(String name, String content) {
    if (!tabs.containsKey(name)) addTab(name);
    fileContents.put(name, content);
    selectFile(name);
    setVisibility(VISIBLE);
  }

  private void appendSessionFiles(SessionData data) {
    for (Map.Entry<String, String> entry : data.files.entrySet()) {
      if (!tabs.containsKey(entry.getKey())) addTab(entry.getKey());
      fileContents.put(entry.getKey(), entry.getValue());
    }
  }

  private boolean applyLegacySession(SessionData data) {
    if (data == null || data.files.isEmpty()) return false;
    for (Map.Entry<String, String> entry : data.files.entrySet()) {
      if (!tabs.containsKey(entry.getKey())) addTab(entry.getKey());
      fileContents.put(entry.getKey(), entry.getValue());
    }
    selectFile(tabs.containsKey(data.selected) ? data.selected : tabs.keySet().iterator().next());
    setVisibility(VISIBLE);
    return true;
  }

  private void queueAutoSave() {
    if (autoSaveManager == null || activeFile == null || code == null || loadingFile != null) return;
    String reference = sessionReferences.get(activeFile);
    if (reference == null || reference.isEmpty()) return;
    // The copy is delayed until the debounce has elapsed, so typing itself never copies the full
    // document or touches disk on the UI thread.
    String snapshot = code.getText().toString();
    autoSaveManager.requestSave(activeFile, reference, snapshot, SavePolicy.editorDefault(), null);
  }

  public void saveSession() {
    removeCallbacks(autoSaveRunnable);
    rememberActiveViewport();
    // تقرير فتح الملفات — لا نعيد كتابة نص الـ placeholder فوق محتوى الفتح المؤجل.
    if (activeFile != null
        && code != null
        && !activeFile.equals(loadingFile)
        && !openingFiles.contains(activeFile))
      fileContents.put(activeFile, code.getText().toString());
    final String selected = activeFile == null ? "" : activeFile;
    final ArrayList<InstantSessionStore.Tab> metadata = new ArrayList<>();
    for (String name : tabs.keySet()) {
      if (metadata.size() >= InstantSessionStore.MAX_TABS) break;
      metadata.add(
          new InstantSessionStore.Tab(
              name,
              sessionReferences.containsKey(name) ? sessionReferences.get(name) : "",
              sessionCursors.containsKey(name) ? sessionCursors.get(name) : 0,
              sessionScrollX.containsKey(name) ? sessionScrollX.get(name) : 0,
              sessionScrollY.containsKey(name) ? sessionScrollY.get(name) : 0));
    }
    final InstantSessionStore.Snapshot snapshot =
        new InstantSessionStore.Snapshot(selected, metadata);
    sessionWorker.execute(
        () -> {
          if (sessionStore == null) sessionStore = new InstantSessionStore(getContext());
          sessionStore.save(snapshot);
          // Remove content snapshots produced by pre-architecture versions.
          deleteQuietly(new java.io.File(getContext().getFilesDir(), "editor-session.bin"));
          deleteTree(new java.io.File(getContext().getFilesDir(), "session-tabs"));
        });
  }

  private void deleteQuietly(java.io.File file) {
    if (file != null) file.delete();
  }

  private void deleteTree(java.io.File file) {
    if (file == null || !file.exists()) return;
    if (file.isDirectory()) {
      java.io.File[] children = file.listFiles();
      if (children != null) for (java.io.File child : children) deleteTree(child);
    }
    file.delete();
  }

  // Legacy v1-v4 reader/writer retained only for one-time migration; saveSession() never calls it.
  private void writeSession(
      String selected,
      LinkedHashMap<String, String> snapshot,
      LinkedHashMap<String, Integer> cursors,
      LinkedHashMap<String, Integer> scrollXs,
      LinkedHashMap<String, Integer> scrollYs,
      LinkedHashMap<String, java.io.File> lazyFiles) {
    java.io.File target = new java.io.File(getContext().getFilesDir(), "editor-session.bin");
    java.io.File temporary = new java.io.File(getContext().getFilesDir(), "editor-session.tmp");
    java.io.File directory = new java.io.File(getContext().getFilesDir(), "session-tabs");
    if (snapshot.isEmpty()) {
      target.delete();
      temporary.delete();
      return;
    }
    directory.mkdirs();
    try (java.io.DataOutputStream output =
        new java.io.DataOutputStream(
            new java.io.BufferedOutputStream(new java.io.FileOutputStream(temporary)))) {
      output.writeInt(4);
      output.writeUTF(selected);
      output.writeInt(snapshot.size());
      for (Map.Entry<String, String> entry : snapshot.entrySet()) {
        String storedName = sessionFileName(entry.getKey());
        java.io.File storedFile = new java.io.File(directory, storedName);
        String content = entry.getValue();
        if (content != null) writeSessionTab(storedFile, content);
        else {
          java.io.File previous = lazyFiles.get(entry.getKey());
          if (!storedFile.isFile() && previous != null && previous.isFile())
            copyFile(previous, storedFile);
          if (!storedFile.isFile()) writeSessionTab(storedFile, "");
        }
        output.writeUTF(entry.getKey());
        output.writeUTF(storedName);
        output.writeInt(cursors.containsKey(entry.getKey()) ? cursors.get(entry.getKey()) : 0);
        output.writeInt(scrollXs.containsKey(entry.getKey()) ? scrollXs.get(entry.getKey()) : 0);
        output.writeInt(scrollYs.containsKey(entry.getKey()) ? scrollYs.get(entry.getKey()) : 0);
      }
    } catch (Exception error) {
      temporary.delete();
      return;
    }
    if (target.exists()) target.delete();
    temporary.renameTo(target);
  }

  private String sessionFileName(String name) {
    int forward = name.hashCode();
    int reverse = new StringBuilder(name).reverse().toString().hashCode();
    return Integer.toHexString(forward) + "-" + Integer.toHexString(reverse) + ".txt";
  }

  private void writeSessionTab(java.io.File target, String content) throws java.io.IOException {
    byte[] bytes = EncodingManager.encodeUtf8(content);
    if (bytes.length > 1200000) bytes = new byte[0];
    java.io.File temporary = new java.io.File(target.getParentFile(), target.getName() + ".tmp");
    try (java.io.FileOutputStream output = new java.io.FileOutputStream(temporary)) {
      output.write(bytes);
      output.flush();
    }
    if (target.exists()) target.delete();
    if (!temporary.renameTo(target)) throw new java.io.IOException("Session tab rename failed");
  }

  private void copyFile(java.io.File source, java.io.File target) throws java.io.IOException {
    try (java.io.FileInputStream input = new java.io.FileInputStream(source);
        java.io.FileOutputStream output = new java.io.FileOutputStream(target)) {
      byte[] buffer = new byte[8192];
      int read;
      while ((read = input.read(buffer)) >= 0) output.write(buffer, 0, read);
    }
  }

  public void openFile(String name) {
    openFile(name, null, "");
  }

  public void openFile(String name, String content) {
    openFile(name, content, "");
  }

  /** Opens a tab and associates it with a stable file path/SAF URI for metadata-only restore. */
  public void openFile(String name, String content, String reference) {
    if (name == null || name.trim().isEmpty()) return;
    if (!tabs.containsKey(name)) addTab(name);
    String safeReference = reference == null ? "" : reference;
    if (!safeReference.isEmpty()) sessionReferences.put(name, safeReference);
    lazySessionFiles.remove(name);
    lazySessionReferences.remove(name);
    openingFiles.remove(name);
    if (content != null) fileContents.put(name, content);
    else if (!fileContents.containsKey(name) && safeReference.isEmpty())
      fileContents.put(name, sample(name));
    selectFile(name);
    setVisibility(VISIBLE);
  }

  /**
   * تقرير فتح الملفات — «فتح فوري» على طريقة AIDE: التبويب يُنشأ ويُنتقل إليه لحظة النقرة
   * بمحتوى مؤقت «جارٍ فتح الملف…»، ثم تقرأ almlk.FileContentService (خدمة مستقرة لا تموت مع
   * إغلاق الدرج أو تبديل اللوحات) وتحقن المحتوى دون إعادة بناء التبويب.
   */
  public void openFilePending(String name, String reference) {
    if (name == null || name.trim().isEmpty()) return;
    if (!tabs.containsKey(name)) addTab(name);
    final String safeReference = reference == null ? "" : reference;
    if (!safeReference.isEmpty()) sessionReferences.put(name, safeReference);
    lazySessionFiles.remove(name);
    lazySessionReferences.remove(name);
    // ملف مفتوح من قبل ومحتواه حي → انتقال فوري بلا أي قراءة (أسرع مسار في AIDE).
    // لكن placeholder عتيق (من جولة غير مكتملة) لا يعدّ محتوى — يعاد فتحه.
    String existing = fileContents.get(name);
    if (existing != null && !PendingOpen.TEXT.equals(existing)) {
      selectFile(name);
      setVisibility(VISIBLE);
      return;
    }
    openingFiles.add(name);
    fileContents.put(name, PendingOpen.TEXT);
    selectFile(name);
    setVisibility(VISIBLE);
    almlk.FileContentService.get()
        .open(
            getContext(),
            name,
            safeReference,
            (fileName, success, content) -> {
              if (!name.equals(fileName)) return;
              openingFiles.remove(name);
              // النجاح فقط يُخزَّن محتوى؛ الفشل نصّ مرئي عابر حتى تبقى إعادة النقر
              // محاولة قراءة جديدة لا مشاهدة عطل قديم.
              if (success) fileContents.put(name, content);
              else fileContents.remove(name);
              if (!name.equals(activeFile) || code == null) return;
              historyLocked = true;
              code.setHint(null);
              code.setText(content);
              historyLocked = false;
              restoreViewport(name);
              code.setAnalysisPaused(false);
              code.post(code::refreshNow);
            });
  }

  private static final class PendingOpen {
    static final String TEXT = "…جارٍ فتح الملف…";
  }

  /** أسماء التبويبات في حالة فتح مؤجل — تقرّر عوضًا عنها الوصول الحقيقي للمحتوى. */
  private final java.util.HashSet<String> openingFiles = new java.util.HashSet<>();

  private void addTab(String name) {
    LinearLayout holder = new LinearLayout(getContext());
    holder.setOrientation(VERTICAL);
    TextView label = text(name, 14, Color.LTGRAY);
    label.setGravity(Gravity.CENTER);
    label.setSingleLine(false);
    label.setMaxLines(2);
    label.setEllipsize(android.text.TextUtils.TruncateAt.END);
    label.setPadding(dp(10), 0, dp(10), 0);
    holder.addView(label, new LinearLayout.LayoutParams(dp(175), 0, 1));
    View line = new View(getContext());
    holder.addView(line, new LinearLayout.LayoutParams(-1, dp(3)));
    holder.setOnClickListener(v -> selectFile(name));
    tabs.put(name, holder);
    tabStrip.addView(holder, new LinearLayout.LayoutParams(dp(175), -1));
  }

  private void rememberActiveViewport() {
    if (activeFile == null || code == null) return;
    sessionCursors.put(activeFile, Math.max(0, code.getSelectionStart()));
    sessionScrollX.put(activeFile, Math.max(0, code.getScrollX()));
    sessionScrollY.put(activeFile, Math.max(0, code.getScrollY()));
  }

  private void restoreViewport(String name) {
    int cursor = sessionCursors.containsKey(name) ? sessionCursors.get(name) : 0;
    int x = sessionScrollX.containsKey(name) ? sessionScrollX.get(name) : 0;
    int y = sessionScrollY.containsKey(name) ? sessionScrollY.get(name) : 0;
    code.post(
        () -> {
          if (!name.equals(activeFile)) return;
          code.setSelection(Math.min(Math.max(0, cursor), code.length()));
          code.scrollTo(x, y);
        });
  }

  private void selectFile(String name) {
    dismissCompletions();
    cancelCompletionLookup();
    completionCache.clear();
    rememberActiveViewport();
    if (name != null && !name.equals(activeFile)) pushNavigationPoint();
    // تقرير فتح الملفات — لا نعيد كتابة نص الـ placeholder فوق محتوى الفتح المؤجل.
    if (activeFile != null
        && code != null
        && !activeFile.equals(loadingFile)
        && !openingFiles.contains(activeFile))
      fileContents.put(activeFile, code.getText().toString());
    activeFile = name;
    for (String key : tabs.keySet()) {
      LinearLayout h = tabs.get(key);
      TextView label = (TextView) h.getChildAt(0);
      boolean active = key.equals(name);
      label.setTextColor(active ? Color.WHITE : Color.LTGRAY);
      label.setTypeface(null, active ? Typeface.BOLD : Typeface.NORMAL);
      h.getChildAt(1).setBackgroundColor(active ? Color.rgb(41, 182, 246) : Color.TRANSPARENT);
    }
    headerName.setText(name);
    headerIcon.setImageResource(iconForFile(name));
    headerPath.setText("/storage/emulated/0/AppProjects/المشروع/" + name);
    historyLocked = true;
    String lazyReference = lazySessionReferences.get(name);
    java.io.File legacyLazyFile = lazySessionFiles.get(name);
    boolean lazyRestore =
        !fileContents.containsKey(name)
            && ((lazyReference != null && !lazyReference.isEmpty()) || legacyLazyFile != null);
    code.setAnalysisPaused(lazyRestore);
    code.setFileName(name);
    // Keep the core range model aligned with the currently visible tab before the next setText
    // callback applies the replacement incrementally.
    code.resetCoreModel(name, code.getText());
    if (lazyRestore) {
      loadingFile = name;
      code.setHint(R.string.session_restoring_file);
      code.setText("");
      loadLazySessionReference(
          name, lazyReference != null && !lazyReference.isEmpty()
              ? lazyReference
              : legacyLazyFile.getAbsolutePath());
    } else {
      loadingFile = null;
      code.setHint(null);
      code.setText(fileContents.containsKey(name) ? fileContents.get(name) : sample(name));
      restoreViewport(name);
    }
    historyLocked = false;
    code.clearHistory();
    if (!lazyRestore) code.refreshNow();
    scheduleIdleSessionSave();
    lastFileSelectTime = System.currentTimeMillis();
  }

  // تقرير 03 — حفظ الجلسة عند الخمول: metadata فقط بعد 800ms من آخر تنقل بين التبويبات.
  private final Runnable idleSessionSave = this::saveSession;

  private void scheduleIdleSessionSave() {
    removeCallbacks(idleSessionSave);
    postDelayed(idleSessionSave, 800);
  }

  /** تقرير 01/03 — تحرير كاشات الذاكرة المؤقتة عند طلب النظام onTrimMemory. */
  public void trimMemoryCaches() {
    completionCache.clear();
    dismissCompletions();
  }

  /** بند 3 — إعادة لوحة المفاتيح إلى وضعها الظاهر بعد الانتقال أو القوائم دون اهتزاز. */
  public void ensureKeyboardVisible() {
    if (code == null) return;
    code.requestFocus();
    android.view.inputmethod.InputMethodManager imm =
        (android.view.inputmethod.InputMethodManager)
            getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.showSoftInput(code, 0);
  }

  // ===== سجل التنقل: «العودة» تعيد الكلاس والموضع السابق بعد الانتقال لعنصر أو تبديل ملف =====
  private static final class NavPoint {
    String file;
    int offset;
    int scrollY;
  }
  private final ArrayDeque<NavPoint> navigationBackStack = new ArrayDeque<>();
  private boolean navRestore;
  private long lastFileSelectTime;

  private void pushNavigationPoint() {
    if (navRestore || activeFile == null || code == null) return;
    int offset = Math.max(0, code.getSelectionStart());
    NavPoint top = navigationBackStack.peek();
    // لا تكرار لنفس الموضع تقريبًا حتى لا يضغط المستخدم «عودة» بلا أثر ظاهر.
    if (top != null
        && top.file != null
        && top.file.equals(activeFile)
        && Math.abs(top.offset - offset) < 40) return;
    NavPoint point = new NavPoint();
    point.file = activeFile;
    point.offset = offset;
    point.scrollY = code.getScrollY();
    navigationBackStack.push(point);
    while (navigationBackStack.size() > 50) navigationBackStack.removeLast();
  }

  /** يعيد آخر كلاس/موضع قبل الانتقال. true إن وُجدت نقطة رجوع. */
  public boolean navigateBack() {
    while (!navigationBackStack.isEmpty()) {
      final NavPoint point = navigationBackStack.pop();
      if (point == null || point.file == null || !tabs.containsKey(point.file)) continue;
      navRestore = true;
      try {
        if (!point.file.equals(activeFile)) selectFile(point.file);
        code.post(
            () -> {
              if (code == null) return;
              code.setSelection(Math.max(0, Math.min(point.offset, code.length())));
              code.scrollTo(code.getScrollX(), Math.max(0, point.scrollY));
            });
      } finally {
        code.post(() -> navRestore = false);
      }
      return true;
    }
    return false;
  }

  /** الانتقال الفوري: إن كان الملف مفتوحًا في تبويب يُفعَّل مباشرة — بلا قراءة ولا عمال. */
  public boolean activateTabIfOpen(String name) {
    if (name == null || !tabs.containsKey(name)) return false;
    selectFile(name);
    return true;
  }

  private void loadLazySessionReference(String name, String reference) {
    sessionWorker.execute(
        () -> {
          String restored = "";
          Throwable error = null;
          try {
            restored = fileRepository.readTextBlocking(reference, name, 8 * 1024 * 1024);
          } catch (Throwable failure) {
            error = failure;
          }
          final String value = restored;
          final Throwable failure = error;
          post(
              () -> {
                if (failure == null) {
                  lazySessionReferences.remove(name);
                  lazySessionFiles.remove(name);
                  fileContents.put(name, value);
                }
                // تقرير AIDE — بروتوكول CurrentFiles_: فشل القراءة (مثلًا غياب صلاحية التخزين)
                // لا يحذف مراجع الجلسة؛ تبقى قابلة للاسترجاع عبر retryLazySessionReferences().
                if (!name.equals(activeFile)) return;
                if (name.equals(loadingFile) && code.length() == 0) {
                  historyLocked = true;
                  code.setHint(failure == null ? null : "تعذر فتح الملف بترميز UTF-8");
                  code.setText(failure == null ? value : "تعذر فتح الملف:\n" + failure.getMessage());
                  historyLocked = false;
                  loadingFile = null;
                  restoreViewport(name);
                  code.setAnalysisPaused(false);
                  // بند 1 — التلوين يطبق فور اكتمال الفتح، بلا تأخير.
                  code.post(code::refreshNow);
                } else if (name.equals(loadingFile)) {
                  loadingFile = null;
                  code.setHint(null);
                  code.setAnalysisPaused(false);
                  code.post(code::refreshNow);
                }
              });
        });
  }

  /**
   * تقرير AIDE — استعادة ما تعذّر فتحه (غياب إذن التخزين مثلًا): نعيد تحميل كل تبويب ما
   * تزال مراجعه محفوظة ولم يُملأ محتواه. آمنة التكرار وتستدعى بعد منح الصلاحية/عند العودة.
   */
  public void retryLazySessionReferences() {
    if (lazySessionReferences.isEmpty()) return;
    final ArrayList<String> pending = new ArrayList<>();
    final ArrayList<String> refs = new ArrayList<>();
    for (Map.Entry<String, String> pendingRef : lazySessionReferences.entrySet()) {
      if (fileContents.containsKey(pendingRef.getKey())) continue;
      pending.add(pendingRef.getKey());
      refs.add(pendingRef.getValue());
    }
    for (int i = 0; i < pending.size(); i++) {
      loadLazySessionReference(pending.get(i), refs.get(i));
    }
  }

  private void smartInsert(String value) {
    String text = code.getText().toString();
    int start = Math.max(0, Math.min(code.getSelectionStart(), code.getSelectionEnd()));
    int end = Math.max(start, Math.max(code.getSelectionStart(), code.getSelectionEnd()));
    if ("→".equals(value)) {
      code.setSelection(Math.min(text.length(), end + 1));
      code.requestFocus();
      return;
    }
    String close = null;
    if ("{".equals(value)) close = "}";
    else if ("(".equals(value)) close = ")";
    else if ("[".equals(value)) close = "]";
    else if ("<".equals(value) && isXmlFile()) close = ">";
    else if ("\"".equals(value)) close = "\"";
    if (close != null) {
      if ("\"".equals(value) && start == end && isEscaped(text, start)) {
        // الإدراج الذكي عبر استبدال المحرك الموحّد — يُسجَّل تراجعًا (بند الإحلال).
        code.replaceRange(start, start, value);
        code.setSelection(start + 1);
      } else if ("\"".equals(value) && start == end && isInsideDoubleQuote(text, start)) {
        if (start < text.length() && text.charAt(start) == '"')
          code.setSelection(start + 1);
        else {
          code.replaceRange(start, start, value);
          code.setSelection(start + 1);
        }
      } else {
        String selected = text.substring(start, end);
        code.replaceRange(start, end, value + selected + close);
        code.setSelection(start + value.length(), start + value.length() + selected.length());
      }
    } else if (start == end
        && value.length() == 1
        && "})]>\"".indexOf(value.charAt(0)) >= 0
        && start < text.length()
        && text.charAt(start) == value.charAt(0)) {
      code.setSelection(start + 1);
    } else {
      code.replaceRange(start, end, value);
      code.setSelection(start + value.length());
    }
    code.requestFocus();
  }

  private boolean isXmlFile() {
    String name = activeFile == null ? "" : activeFile.toLowerCase(java.util.Locale.US);
    return name.endsWith(".xml");
  }

  private boolean isEscaped(CharSequence text, int offset) {
    int slashes = 0;
    for (int i = offset - 1; i >= 0 && text.charAt(i) == '\\'; i--) slashes++;
    return (slashes & 1) != 0;
  }

  private boolean isInsideDoubleQuote(CharSequence text, int offset) {
    boolean quoted = false, escaped = false;
    int lineStart = offset;
    while (lineStart > 0 && text.charAt(lineStart - 1) != '\n') lineStart--;
    for (int i = lineStart; i < offset; i++) {
      char value = text.charAt(i);
      if (escaped) escaped = false;
      else if (value == '\\') escaped = true;
      else if (value == '"') quoted = !quoted;
    }
    return quoted;
  }

  private void completeXmlClosingTag(int marker) {
    String text = code.getText().toString();
    if (text.isEmpty() || marker < 2 || marker > text.length()) return;
    if (text.charAt(marker - 2) != '<' || text.charAt(marker - 1) != '/') return;
    String tag = findUnclosedXmlTag(text, marker - 2);
    if (tag == null || tag.isEmpty()) return;
    historyLocked = true;
    if (marker < text.length() && text.charAt(marker) == '>') {
      code.replaceRange(marker, marker, tag);
      code.setSelection(marker + tag.length() + 1);
    } else {
      code.replaceRange(marker, marker, tag + ">");
      code.setSelection(marker + tag.length() + 1);
    }
    historyLocked = false;
  }

  private String findUnclosedXmlTag(CharSequence text, int limit) {
    ArrayDeque<String> stack = new ArrayDeque<>();
    int i = 0;
    while (i < limit) {
      int open = indexOf(text, '<', i, limit);
      if (open < 0 || open + 1 >= limit) break;
      if (startsWith(text, open, "<!--")) {
        int close = indexOf(text, "-->", open + 4, limit);
        i = close < 0 ? limit : close + 3;
        continue;
      }
      int close = xmlTagEnd(text, open + 1, limit);
      if (close < 0) {
        int nameStart = open + 1;
        while (nameStart < limit && Character.isWhitespace(text.charAt(nameStart))) nameStart++;
        int nameEnd = nameStart;
        while (nameEnd < limit && isXmlNameCharacter(text.charAt(nameEnd))) nameEnd++;
        if (nameEnd > nameStart) stack.push(text.subSequence(nameStart, nameEnd).toString());
        break;
      }
      char kind = text.charAt(open + 1);
      if (kind != '!' && kind != '?') {
        boolean closing = kind == '/';
        int nameStart = open + (closing ? 2 : 1);
        while (nameStart < close && Character.isWhitespace(text.charAt(nameStart))) nameStart++;
        int nameEnd = nameStart;
        while (nameEnd < close && isXmlNameCharacter(text.charAt(nameEnd))) nameEnd++;
        if (nameEnd > nameStart) {
          String name = text.subSequence(nameStart, nameEnd).toString();
          if (closing) {
            while (!stack.isEmpty()) {
              String current = stack.pop();
              if (current.equals(name)) break;
            }
          } else {
            int tail = close - 1;
            while (tail > nameEnd && Character.isWhitespace(text.charAt(tail))) tail--;
            if (text.charAt(tail) != '/') stack.push(name);
          }
        }
      }
      i = close + 1;
    }
    return stack.isEmpty() ? null : stack.peek();
  }

  private int xmlTagEnd(CharSequence text, int from, int limit) {
    char quote = 0;
    for (int i = from; i < limit; i++) {
      char value = text.charAt(i);
      if (quote != 0) {
        if (value == quote) quote = 0;
      } else if (value == '"' || value == '\'') quote = value;
      else if (value == '>') return i;
    }
    return -1;
  }

  private boolean isXmlNameCharacter(char value) {
    return Character.isLetterOrDigit(value)
        || value == '_'
        || value == '-'
        || value == ':'
        || value == '.';
  }

  private int indexOf(CharSequence text, char needle, int from, int limit) {
    for (int i = Math.max(0, from); i < Math.min(limit, text.length()); i++)
      if (text.charAt(i) == needle) return i;
    return -1;
  }

  private int indexOf(CharSequence text, String needle, int from, int limit) {
    int last = Math.min(limit, text.length()) - needle.length();
    for (int i = Math.max(0, from); i <= last; i++) {
      if (startsWith(text, i, needle)) return i;
    }
    return -1;
  }

  private boolean startsWith(CharSequence text, int offset, String value) {
    if (offset < 0 || offset + value.length() > text.length()) return false;
    for (int i = 0; i < value.length(); i++)
      if (text.charAt(offset + i) != value.charAt(i)) return false;
    return true;
  }

  public void applyTheme() {
    ThemeConfig theme = new ThemeConfig(getContext());
    int background = theme.color(ThemeConfig.BACKGROUND);
    int plain = theme.color(ThemeConfig.PLAIN);
    int chrome = theme.isDark() ? Color.rgb(34, 34, 34) : Color.rgb(238, 238, 238);
    setBackgroundColor(background);
    if (editorRow != null) editorRow.setBackgroundColor(background);
    if (fileHeader != null) fileHeader.setBackgroundColor(background);
    if (tabStrip != null) {
      tabStrip.setBackgroundColor(chrome);
      if (tabStrip.getParent() instanceof View)
        ((View) tabStrip.getParent()).setBackgroundColor(chrome);
    }
    if (quickBar != null) quickBar.setBackgroundColor(chrome);
    if (headerName != null) headerName.setTextColor(plain);
    if (headerPath != null) headerPath.setTextColor(theme.isDark() ? Color.LTGRAY : Color.DKGRAY);
    if (code != null) code.applyTheme();
    for (LinearLayout holder : tabs.values()) {
      TextView label = (TextView) holder.getChildAt(0);
      label.setTextColor(
          holder == tabs.get(activeFile) ? plain : (theme.isDark() ? Color.LTGRAY : Color.DKGRAY));
    }
  }

  public boolean hasOpenFile() {
    return activeFile != null;
  }

  public String getActiveFile() {
    return activeFile;
  }

  public String getTextContent() {
    return code == null ? "" : code.getText().toString();
  }

  public void undoEdit() {
    if (code.undo()) code.requestFocus();
  }

  public void redoEdit() {
    if (code.redo()) code.requestFocus();
  }

  public boolean findText(String query) {
    return findText(query, false, false, false, true);
  }

  /** Finds the next local-document match without scanning the rest of the project. */
  public boolean findText(
      String query, boolean caseSensitive, boolean wholeWord, boolean regularExpression,
      boolean forward) {
    if (query == null || query.isEmpty() || code == null) return false;
    String text = code.getText().toString();
    EditorSearchEngine.Query search =
        new EditorSearchEngine.Query(query, caseSensitive, wholeWord, regularExpression);
    int at;
    int end;
    if (regularExpression) {
      List<EditorSearchEngine.Match> matches = EditorSearchEngine.findAll(text, search, 50000);
      EditorSearchEngine.Match selected = null;
      if (forward) {
        int from = Math.max(0, code.getSelectionEnd());
        for (EditorSearchEngine.Match match : matches) {
          if (match.start >= from) { selected = match; break; }
        }
        if (selected == null && !matches.isEmpty()) selected = matches.get(0);
      } else {
        int before = Math.max(0, code.getSelectionStart());
        for (EditorSearchEngine.Match match : matches) {
          if (match.start < before) selected = match;
          else break;
        }
        if (selected == null && !matches.isEmpty()) selected = matches.get(matches.size() - 1);
      }
      if (selected == null) return false;
      at = selected.start;
      end = selected.end;
    } else {
      at = forward
          ? EditorSearchEngine.findNext(text, search, Math.max(0, code.getSelectionEnd()), true)
          : EditorSearchEngine.findPrevious(text, search, Math.max(0, code.getSelectionStart()), true);
      if (at < 0) return false;
      end = Math.min(text.length(), at + query.length());
    }
    if (at < 0) return false;
    code.requestFocus();
    code.setSelection(at, end);
    final int destination = at;
    code.post(() -> code.bringPointIntoView(destination));
    return true;
  }

  public int replaceAll(String from, String to) {
    return replaceAll(from, to, false, false, false);
  }

  /** Replaces matches in the active document and keeps the cursor near its previous location. */
  public int replaceAll(
      String from, String to, boolean caseSensitive, boolean wholeWord, boolean regularExpression) {
    if (from == null || from.isEmpty() || code == null) return 0;
    String before = code.getText().toString();
    EditorSearchEngine.Query search =
        new EditorSearchEngine.Query(from, caseSensitive, wholeWord, regularExpression);
    List<EditorSearchEngine.Match> matches = EditorSearchEngine.findAll(before, search, 50000);
    if (matches.isEmpty()) return 0;
    int cursor = Math.max(0, code.getSelectionStart());
    String updated = EditorSearchEngine.replaceAll(before, search, to);
    historyLocked = true;
    code.setText(updated);
    historyLocked = false;
    code.setSelection(Math.min(cursor, code.length()));
    code.refreshNow();
    return matches.size();
  }

  /** Runs the expensive match/build phase away from the UI thread, then applies one edit. */
  public void replaceAllAsync(
      String from,
      String to,
      boolean caseSensitive,
      boolean wholeWord,
      boolean regularExpression,
      ReplaceListener listener) {
    if (code == null || from == null || from.isEmpty()) {
      if (listener != null) post(() -> listener.completed(0));
      return;
    }
    final String before = code.getText().toString();
    final int cursor = Math.max(0, code.getSelectionStart());
    final EditorSearchEngine.Query search =
        new EditorSearchEngine.Query(from, caseSensitive, wholeWord, regularExpression);
    completionLookupWorker.execute(
        () -> {
          List<EditorSearchEngine.Match> matches =
              EditorSearchEngine.findAll(before, search, 50000);
          if (matches.isEmpty()) {
            post(() -> { if (listener != null) listener.completed(0); });
            return;
          }
          final String updated = EditorSearchEngine.replaceAll(before, search, to);
          post(() -> {
            if (code == null || !before.equals(code.getText().toString())) {
              if (listener != null) listener.completed(0);
              return;
            }
            historyLocked = true;
            code.setText(updated);
            historyLocked = false;
            code.setSelection(Math.min(cursor, code.length()));
            code.refreshNow();
            if (listener != null) listener.completed(matches.size());
          });
        });
  }

  public boolean goToOffset(int offset) {
    if (code == null) return false;
    // سجّل الموضع الحالي قبل القفز لكن ليس مباشرة بعد تبديل ملف (قيد الاستعادة أو انتقال متسلسل).
    if (System.currentTimeMillis() - lastFileSelectTime > 400) pushNavigationPoint();
    int target = Math.max(0, Math.min(offset, code.length()));
    code.requestFocus();
    code.setSelection(target);
    code.post(() -> code.bringPointIntoView(target));
    return true;
  }

  public boolean goToLine(int line) {
    if (line < 1) return false;
    String text = code.getText().toString();
    int at = 0;
    for (int n = 1; n < line; n++) {
      at = text.indexOf('\n', at);
      if (at < 0) return false;
      at++;
    }
    code.requestFocus();
    code.setSelection(Math.min(at, code.length()));
    return true;
  }

  public void formatSource() {
    String original = code.getText().toString();
    String formatted = code.formatCode();
    if (original.equals(formatted)) return;
    int semanticCursor = semanticPosition(original, Math.max(0, code.getSelectionStart()));
    historyLocked = true;
    // التنسيق استبدال واحد قابل للتراجع داخل موديل المحرك (بند الإحلال).
    code.replaceRange(0, original.length(), formatted);
    code.setSelection(offsetForSemanticPosition(formatted, semanticCursor));
    historyLocked = false;
    code.refreshNow();
  }

  private int semanticPosition(String text, int offset) {
    int count = 0;
    for (int i = 0; i < Math.min(offset, text.length()); i++)
      if (!Character.isWhitespace(text.charAt(i))) count++;
    return count;
  }

  private int offsetForSemanticPosition(String text, int semanticPosition) {
    int count = 0;
    for (int i = 0; i < text.length(); i++) {
      if (!Character.isWhitespace(text.charAt(i)) && count++ >= semanticPosition) return i;
    }
    return text.length();
  }

  public void setQuickFixListener(QuickFixListener listener) {
    quickFixListener = listener;
  }

  public void setDefinitionListener(DefinitionListener listener) {
    definitionListener = listener;
  }

  public void setDefinitionRequestListener(DefinitionRequestListener listener) {
    definitionRequestListener = listener;
  }

  public void setUsageListener(UsageListener listener) {
    usageListener = listener;
  }

  public void requestUsageForCurrentSelection() {
    if (code == null || usageListener == null || activeFile == null) return;
    usageListener.requested(
        activeFile, code.getText().toString(), code.getSelectionStart(), code.getSelectionEnd());
  }

  /** Entry point for the toolbar/menu Go To action, independent of ActionMode. */
  public void requestDefinitionForCurrentSelection() {
    if (code == null || activeFile == null) return;
    final String source = code.getText().toString();
    final int[] selection = code.selectionOrIdentifier();
    final int selectionStart = selection[0];
    final int selectionEnd = selection[1];
    final int request = ++definitionGeneration;
    final String requestedFile = activeFile;
    completionWorker.execute(
        () -> {
          try {
            final ProjectSymbolIndex.DefinitionTarget target =
                requestedFile.toLowerCase(java.util.Locale.US).endsWith(".smali")
                    ? SmaliDefinitionResolver.resolve(
                        requestedFile, source, selectionStart, selectionEnd)
                    : ProjectSymbolIndex.resolveDefinition(
                        requestedFile, source, selectionStart, selectionEnd);
            post(
                () -> {
                  if (request != definitionGeneration) return;
                  if (target != null && definitionListener != null) {
                    definitionListener.requested(target);
                  } else if (definitionRequestListener != null) {
                    definitionRequestListener.requested(
                        requestedFile, source, selectionStart, selectionEnd);
                  } else {
                    Toast.makeText(
                            getContext(),
                            "تعذر العثور على تعريف العنصر المحدد",
                            Toast.LENGTH_SHORT)
                        .show();
                  }
                });
          } catch (Throwable error) {
            post(() -> {
              if (request == definitionGeneration) showEditorError(error);
            });
          }
        });
  }

  public void refreshSemanticDiagnostics() {
    if (code != null && activeFile != null) code.refreshNow();
  }

  public java.util.List<com.almlkid.kay.ui.CodeLanguageTools.Diagnostic> diagnostics() {
    code.refreshNow();
    return code.getDiagnostics();
  }

  private void showLiveCompletions() {
    if (code == null || !code.hasFocus() || code.getSelectionStart() != code.getSelectionEnd())
      return;
    final String requestedFile = activeFile;
    final int cursor = code.getSelectionStart();
    final int request = ++completionGeneration;
    completionLookupFuture =
        completionLookupWorker.submit(
            () -> {
              try {
                // Copy the document on the worker, never from the key event/UI callback.
                EditorTextSnapshot.Value snapshot = completionSnapshot.copy();
                if (request != completionGeneration) return;
                final java.util.List<ProjectSymbolIndex.CompletionItem> items =
                    cachedOrComputeCompletions(requestedFile, snapshot.text, cursor);
                post(
                    () -> {
                      if (request != completionGeneration
                          || code.getSelectionStart() != cursor
                          || !java.util.Objects.equals(requestedFile, activeFile)) return;
                      displayLiveCompletions(items);
                    });
              } catch (Throwable error) {
                post(() -> showEditorError(error));
              }
            });
  }

  private List<ProjectSymbolIndex.CompletionItem> cachedOrComputeCompletions(
      String file, String source, int cursor) {
    int safeCursor = Math.max(0, Math.min(cursor, source.length()));
    int tokenStart = CodeLanguageTools.completionStart(source, safeCursor);
    String prefix = source.substring(tokenStart, safeCursor);
    String context = source.substring(Math.max(0, tokenStart - 256), tokenStart);
    String after = source.substring(safeCursor);
    // Exclude the active prefix so typing the next character can reuse the same base result.
    int sourceHash = 31 * source.substring(0, tokenStart).hashCode() + after.hashCode();
    List<ProjectSymbolIndex.CompletionItem> cached =
        completionCache.lookup(file, prefix, context, after, sourceHash);
    if (cached != null) return cached;

    List<ProjectSymbolIndex.CompletionItem> computed =
        KayStyleCompletionEngine.complete(file, source, safeCursor);
    completionCache.store(file, prefix, context, after, sourceHash, computed);
    return computed == null ? Collections.emptyList() : computed;
  }

  private void cancelCompletionLookup() {
    if (completionLookupFuture != null) {
      completionLookupFuture.cancel(true);
      completionLookupFuture = null;
    }
  }

  private void displayLiveCompletions(
      final java.util.List<ProjectSymbolIndex.CompletionItem> items) {
    if (items == null || items.isEmpty()) {
      dismissCompletions();
      return;
    }
    if (completionAdapter == null) completionAdapter = new EditorCompletionAdapter(getContext());
    completionAdapter.setItems(items);
    if (completionList == null) {
      completionList = (ListView)
          LayoutInflater.from(getContext()).inflate(R.layout.code_completion_popup, null, false);
      completionList.setAdapter(completionAdapter);
      completionList.setOnItemClickListener((parent, view, position, id) -> {
        if (completionAdapter == null || position >= completionAdapter.getCount()) return;
        applyCompletion(completionAdapter.getItem(position).insertText);
        dismissCompletions();
      });
    }
    int width = Math.min(dp(310), getResources().getDisplayMetrics().widthPixels - dp(24));
    int height = Math.min(dp(190), dp(8 + Math.min(4, items.size()) * 44));
    if (completionWindow == null) {
      completionWindow = new PopupWindow(completionList, width, height, false);
      completionWindow.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFF292929));
      completionWindow.setOutsideTouchable(true);
      completionWindow.setTouchable(true);
      completionWindow.setElevation(dp(10));
    } else {
      completionWindow.setWidth(width);
      completionWindow.setHeight(height);
    }
    int[] location = new int[2];
    code.getLocationOnScreen(location);
    int cursor = Math.max(0, code.getSelectionStart());
    int x = location[0] + dp(8);
    int y = location[1] + dp(38);
    // بند الإحلال: موضع المؤشر يؤخذ من مقاسات اللوحة مباشرة (بديل android.text.Layout).
    if (cursor <= code.length()) {
      int[] position = code.offsetToViewPosition(cursor);
      x = location[0] + position[0];
      y = location[1] + position[1];
    }
    x = Math.max(dp(8), Math.min(x,
        getResources().getDisplayMetrics().widthPixels - width - dp(8)));
    Rect visibleFrame = new Rect();
    getWindowVisibleDisplayFrame(visibleFrame);
    int bottomLimit = visibleFrame.bottom - dp(6);
    if (quickBar != null && quickBar.getVisibility() == VISIBLE) {
      int[] quickLocation = new int[2];
      quickBar.getLocationOnScreen(quickLocation);
      bottomLimit = Math.min(bottomLimit, quickLocation[1] - dp(4));
    }
    y = Math.max(dp(70), Math.min(y, bottomLimit - height));
    if (completionWindow.isShowing()) completionWindow.update(x, y, width, height);
    else completionWindow.showAtLocation(this, Gravity.NO_GRAVITY, x, y);
  }

  private void showEditorError(Throwable error) {
    long now = android.os.SystemClock.uptimeMillis();
    if (now - lastEditorErrorTime < 3000 || !isAttachedToWindow()) return;
    lastEditorErrorTime = now;
    dismissCompletions();
    new android.app.AlertDialog.Builder(getContext())
        .setTitle("خطأ في المحرر")
        .setMessage(
            "تعذر إكمال العملية دون إغلاق التطبيق:\n\n"
                + error.getClass().getSimpleName()
                + (error.getMessage() == null ? "" : "\n" + error.getMessage()))
        .setPositiveButton("حسنًا", null)
        .show();
  }

  private void dismissCompletions() {
    completionGeneration++;
    cancelCompletionLookup();
    if (completionWindow != null) {
      completionWindow.dismiss();
      completionWindow = null;
    }
  }

  public java.util.List<String> completions() {
    java.util.List<ProjectSymbolIndex.CompletionItem> detailed =
        KayStyleCompletionEngine.complete(
            activeFile, code.getText().toString(), code.getSelectionStart());
    java.util.ArrayList<String> values = new java.util.ArrayList<>();
    for (ProjectSymbolIndex.CompletionItem item : detailed) values.add(item.insertText);
    return values;
  }

  public void applyCompletion(String value) {
    code.applyCompletion(value);
  }

  public void closeCurrent() {
    if (activeFile == null) return;
    LinearLayout tab = tabs.remove(activeFile);
    if (tab != null) tabStrip.removeView(tab);
    fileContents.remove(activeFile);
    lazySessionFiles.remove(activeFile);
    lazySessionReferences.remove(activeFile);
    sessionReferences.remove(activeFile);
    sessionCursors.remove(activeFile);
    sessionScrollX.remove(activeFile);
    sessionScrollY.remove(activeFile);
    activeFile = null;
    if (tabs.isEmpty()) {
      setVisibility(GONE);
      code.setText("");
    } else selectFile(tabs.keySet().iterator().next());
  }

  public void closeAll() {
    tabs.clear();
    fileContents.clear();
    lazySessionFiles.clear();
    lazySessionReferences.clear();
    sessionReferences.clear();
    sessionCursors.clear();
    sessionScrollX.clear();
    sessionScrollY.clear();
    loadingFile = null;
    tabStrip.removeAllViews();
    activeFile = null;
    code.setText("");
    setVisibility(GONE);
  }

  private int iconForFile(String name) {
    String n = name == null ? "" : name.toLowerCase(java.util.Locale.US);
    if (n.endsWith(".java") || n.endsWith(".kt")) return R.drawable.file_type_java;
    if (n.endsWith(".xml")) return R.drawable.file_type_xml;
    if (n.endsWith(".gradle") || n.endsWith(".gradle.kts")) {
      return R.drawable.project_properties;
    }
    if (n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".aar") || n.endsWith(".apk") || n.endsWith(".dex")) {
      return R.drawable.file_type_zip;
    }
    if (n.endsWith(".txt") || n.endsWith(".md") || n.endsWith(".properties") || n.endsWith(".json") || n.endsWith(".csv") || n.endsWith(".smali"))
      return R.drawable.file_type_txt;
    return R.drawable.file_type_unknown;
  }

  private android.graphics.drawable.Drawable selectable() {
    android.util.TypedValue out = new android.util.TypedValue();
    getContext().getTheme().resolveAttribute(android.R.attr.selectableItemBackground, out, true);
    return getResources().getDrawable(out.resourceId);
  }

  private TextView text(String value, int size, int color) {
    TextView t = new TextView(getContext());
    t.setText(value);
    t.setTextSize(size);
    t.setTextColor(color);
    return t;
  }

  @Override
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (completionWorker.isShutdown())
      completionWorker = java.util.concurrent.Executors.newSingleThreadExecutor();
    if (sessionWorker.isShutdown())
      sessionWorker = java.util.concurrent.Executors.newSingleThreadExecutor();
    if (completionLookupWorker.isShutdown())
      completionLookupWorker = java.util.concurrent.Executors.newSingleThreadExecutor();
    if (fileRepository == null) fileRepository = new FileSystemRepository(getContext());
    if (autoSaveManager == null) autoSaveManager = new AtomicSaveManager(getContext());
  }

  @Override
  protected void onDetachedFromWindow() {
    removeCallbacks(completionTask);
    dismissCompletions();
    completionWorker.shutdownNow();
    sessionWorker.shutdownNow();
    completionLookupWorker.shutdownNow();
    if (fileRepository != null) {
      fileRepository.close();
      fileRepository = null;
    }
    if (autoSaveManager != null) {
      autoSaveManager.close();
      autoSaveManager = null;
    }
    super.onDetachedFromWindow();
  }

  private int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }

  private String sample(String name) {
    if (name.endsWith(".xml"))
      return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
          + "<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
          + "    android:layout_width=\"match_parent\"\n"
          + "    android:layout_height=\"match_parent\" />";
    return "package com.example.myapp;\n\n"
        + "import android.app.Activity;\n"
        + "import android.os.Bundle;\n\n"
        + "public class "
        + name.replace(".java", "")
        + " extends Activity {\n"
        + "    @Override\n"
        + "    protected void onCreate(Bundle state) {\n"
        + "        super.onCreate(state);\n"
        + "    }\n"
        + "}";
  }
}
