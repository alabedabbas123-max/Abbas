package almlk;

import com.almlkid.kay.ui.CodeLanguageTools;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicReferenceArray;

/**
 * بند almlk ← الملوّن التزايدي «C0032va» بروحه الحرفية:
 *
 * <ul>
 *   <li>حالة معجمية لكل سطر: عادي/تعليق، ولـXML وسم وCDATA واقتباس مفرد/مزدوج عبر الأسطر؛
 *       تعيد الإعراب من أول سطر متّسخ وتتوقف عند التقارب.
 *   <li>يعمل على خيط خلفي واحد بعيدًا عن الواجهة؛ أول تنفيذ يكسو الشاشة فورًا دون انتظار أي
 *       معالجة أخرى (الملفات الضخمة تُلوَّن نافذةً نافذةً بصمت).
 *   <li>إلغاء المهام الباهتة: أي تغيّر جديد يلغي الجولة السابقة (جيل متقدّم).
 *   <li>أنماط النص وفهرس {@link XmlColorLiteral} ينشران ذريًا من المرور نفسه؛ لا تحليل في الرسم.
 *   <li>أنماط الإخراج تعيد استعمال ثوابت {@link CodeLanguageTools} — نفس لوحة ألوان التطبيق.
 * </ul>
 */
public final class LineStyler {

  /** يُستدعى على خيط الواجهة بعد كل جولة لإعادة رسم النطاق المتأثر. */
  public interface StylesListener {
    void onStylesUpdated(int fromLine, int toLine);
  }

  private static final int MODE_PLAIN = 0;
  private static final int MODE_JAVA = 1;
  private static final int MODE_XML = 2;
  private static final int MODE_SMALI = 3;
  private static final int MODE_CONF = 4; // properties/pro/ini/yml… — تعليق # وقيم فقط

  private static final int STATE_NORMAL = 0;
  private static final int STATE_BLOCK_COMMENT = 1; // /* ... */ أو <!-- ... -->
  private static final int STATE_XML_TAG = 2; // داخل وسم، واسم العنصر قُرئ
  private static final int STATE_XML_CDATA = 3; // <![CDATA[ ... ]]> عبر الأسطر
  private static final int STATE_XML_DOUBLE_QUOTE = 4; // قيمة سمة "..." عبر الأسطر
  private static final int STATE_XML_SINGLE_QUOTE = 5; // قيمة سمة '...' عبر الأسطر
  private static final int STATE_XML_TAG_EXPECT_NAME = 6; // سطر انتهى بعد < أو </ قبل الاسم

  /** نتيجة سطر واحدة تُنشر ذريًا: لا يرى الرسم نمطًا جديدًا مع فهرس لون قديم. */
  private static final class LineResult {
    final int[] styles;
    final XmlColorLiteral[] colorLiterals;
    final int endState;

    LineResult(int[] styles, XmlColorLiteral[] colorLiterals, int endState) {
      this.styles = styles;
      this.colorLiterals = colorLiterals;
      this.endState = endState;
    }
  }

  private final LineDocument document;
  private final ExecutorService worker = Executors.newSingleThreadExecutor();
  private StylesListener listener;

  private volatile AtomicReferenceArray<LineResult> lineResults = new AtomicReferenceArray<>(0);
  private volatile int generation;
  private Future<?> running;
  private int mode = MODE_PLAIN;
  /** ملف Gradle: لوحة جافا مع إبقاء أسماء الأوامر بيضاء (مطابقة مظهر المرجع). */
  private volatile boolean gradleFile = false;
  private String fileName = "";
  private volatile boolean paused;

  public LineStyler(LineDocument document) {
    this.document = document;
    document.addChangeListener(
        (from, to) -> {
          // النص يتغير فورًا على خيط الواجهة؛ أبطل نتائج الأسطر المتأثرة قبل طلب الجولة كي لا
          // يرسم إطار واحد زخرفة/نمطًا بائتًا فوق النص الجديد.
          invalidateResults(from, to);
          request(from, to);
        });
  }

  private void invalidateResults(int fromLine, int toLine) {
    AtomicReferenceArray<LineResult> snapshot = lineResults;
    int from = Math.max(0, fromLine);
    int to = Math.min(toLine, snapshot.length() - 1);
    for (int line = from; line <= to; line++) snapshot.set(line, null);
  }

  public void setListener(StylesListener listener) {
    this.listener = listener;
  }

  public void setPaused(boolean paused) {
    this.paused = paused;
  }

  /** تغيّر الملف/المحتوى كاملًا: تصفير كامل وجولة جديدة. */
  public void setFileName(String name) {
    fileName = name == null ? "" : name;
    String lower = fileName.toLowerCase(java.util.Locale.US);
    // ملفات البناء: لوحة جافا نفسها (بما فيها تلوين الدوال) لكن أسماء أوامر Gradle تبقى بيضاء.
    gradleFile = lower.endsWith(".gradle") || lower.endsWith(".gradle.kts");
    // ‎.class: العرض للقراءة مصدرُ جافا مولّد — يُلوَّن بلوحة جافا كاملة كما في المرجع.
    if (lower.endsWith(".java") || lower.endsWith(".class") || lower.endsWith(".kt") || lower.endsWith(".c")
        || lower.endsWith(".cpp") || lower.endsWith(".h") || lower.endsWith(".cs")
        || lower.endsWith(".gradle") || lower.endsWith(".kts") || lower.endsWith(".groovy")
        || lower.endsWith(".js") || lower.endsWith(".ts") || lower.endsWith(".json")
        || lower.endsWith(".css")) {
      mode = MODE_JAVA;
    } else if (XmlCodeFormatter.isXmlName(fileName) || lower.endsWith(".html")
        || lower.endsWith(".htm") || lower.endsWith(".svg")) {
      mode = MODE_XML;
    } else if (lower.endsWith(".smali")) {
      mode = MODE_SMALI;
    } else if (lower.endsWith(".properties") || lower.endsWith(".pro") || lower.endsWith(".ini")
        || lower.endsWith(".cfg") || lower.endsWith(".toml") || lower.endsWith(".yml")
        || lower.endsWith(".yaml") || lower.endsWith(".gitignore")) {
      mode = MODE_CONF;
    } else {
      mode = MODE_PLAIN;
    }
    synchronized (this) {
      // تغيير نوع الملف يلغي الجيل السابق قبل نشر أي سطر، ثم يبدأ بنتائج فارغة تمامًا.
      generation++;
      if (running != null) running.cancel(false);
      lineResults = new AtomicReferenceArray<>(Math.max(0, document.lineCount()));
    }
    request(0, Integer.MAX_VALUE);
  }

  /** طلب إكساء من سطر إلى سطر (تغيّر تزايدي أو تحديث شامل). */
  public void request(int fromLine, int toLine) {
    if (paused) return;
    final int generationAtRequest;
    synchronized (this) {
      generationAtRequest = ++generation;
      if (running != null) running.cancel(false);
    }
    final int from = Math.max(0, fromLine);
    running =
        worker.submit(
            () -> runStylingPass(generationAtRequest, from, toLine));
  }

  /** جولة واحدة: من السطر الأول المتّسخ حتى التقارب. */
  private void runStylingPass(int generationAtRun, int from, int to) {
    int lineCount = document.lineCount();
    if (lineCount == 0) return;
    ensureResultCapacity(lineCount);
    int firstLine = Math.min(from, lineCount - 1);
    int lastTouched = firstLine - 1;
    int batchFrom = firstLine;

    // حالة الدخول عند أول سطر = نتيجة نهاية السطر السابق المنشورة ذريًا.
    AtomicReferenceArray<LineResult> initial = lineResults;
    LineResult previous = firstLine > 0 && firstLine - 1 < initial.length()
        ? initial.get(firstLine - 1)
        : null;
    int state = previous == null ? STATE_NORMAL : previous.endState;

    for (int line = firstLine; line < lineCount; line++) {
      if (generationAtRun != generation || paused) return; // مهمة باهتة — تُلغى فورًا.
      AtomicReferenceArray<LineResult> snapshot = lineResults;
      LineResult old = line < snapshot.length() ? snapshot.get(line) : null;
      if (line > to && old != null && old.endState == state) {
        break; // تقارب مبكر: ما بعد النطاق المتّسخ ما زال يدخل بالحالة نفسها.
      }

      char[] chars;
      synchronized (document) {
        chars = document.lineChars(line);
      }
      int[] styles = lexLine(chars, state, line);
      int endState = lexLineEndState;
      XmlColorLiteral[] literals = lexLineColorLiterals;

      // لا يُسمح لجولة أُلغيت أثناء تحليل السطر أن تنشر نصف نتيجة بائتة.
      if (generationAtRun != generation || paused) return;
      LineResult fresh = new LineResult(styles, literals, endState);
      AtomicReferenceArray<LineResult> target = lineResults;
      if (line >= target.length()) {
        ensureResultCapacity(lineCount);
        target = lineResults;
      }
      target.set(line, fresh); // styles + colors + endState مرئية كوحدة واحدة.
      state = endState;
      lastTouched = line;

      // دفعات 512 سطرًا: النتيجة تظهر تدريجيًا بلا انتظار الملف كله.
      if (line - firstLine > 0 && (line - firstLine) % 512 == 0) {
        postStylesUpdated(generationAtRun, batchFrom, line);
        batchFrom = line + 1;
      }
    }
    postStylesUpdated(generationAtRun, batchFrom, lastTouched);
  }

  private void postStylesUpdated(int generationAtRun, int from, int to) {
    if (to < from || listener == null) return;
    new android.os.Handler(android.os.Looper.getMainLooper())
        .post(
            () -> {
              StylesListener target = listener;
              if (target != null && generationAtRun == generation)
                target.onStylesUpdated(from, to);
            });
  }

  private int lexLineEndState = STATE_NORMAL;
  private XmlColorLiteral[] lexLineColorLiterals = XmlColorLiteral.EMPTY_ARRAY;

  /** تكبير مخزن النتائج مع الحفاظ على الأسطر المنشورة؛ AtomicReferenceArray يعطي رؤية O(1). */
  private synchronized void ensureResultCapacity(int lineCount) {
    AtomicReferenceArray<LineResult> current = lineResults;
    if (current.length() >= lineCount) return;
    AtomicReferenceArray<LineResult> bigger = new AtomicReferenceArray<>(lineCount + 64);
    for (int i = 0; i < current.length(); i++) bigger.set(i, current.get(i));
    lineResults = bigger;
  }

  /** أنماط سطر (كما طوله) أو null إن لم يُكسَ بعد — قراءة الواجهة بلا حجب. */
  public int[] stylesForLine(int line) {
    AtomicReferenceArray<LineResult> snapshot = lineResults;
    if (line < 0 || line >= snapshot.length()) return null;
    LineResult result = snapshot.get(line);
    return result == null ? null : result.styles;
  }

  /** قيم ألوان XML في السطر؛ مصفوفة ثابتة منشورة مع أنماط السطر نفسها. */
  public XmlColorLiteral[] colorLiteralsForLine(int line) {
    AtomicReferenceArray<LineResult> snapshot = lineResults;
    if (line < 0 || line >= snapshot.length()) return XmlColorLiteral.EMPTY_ARRAY;
    LineResult result = snapshot.get(line);
    return result == null ? XmlColorLiteral.EMPTY_ARRAY : result.colorLiterals;
  }

  public void shutdown() {
    worker.shutdownNow();
  }

  // ---------------- اللكسير السطري (حالات: عادي/كتلي) ----------------

  private int[] lexLine(char[] chars, int entryState, int lineNumber) {
    // كل لغة غير XML تنشر مصفوفة ألوان فارغة؛ فرع Java أدناه لم تتغير قواعده أو نواتجه.
    lexLineColorLiterals = XmlColorLiteral.EMPTY_ARRAY;
    // عزل كامل لمسار XML: آلة حالاته لا تدخل إطلاقًا إلى مسار Java/Smali/الإعدادات.
    if (mode == MODE_XML) return lexXmlLine(chars, entryState, lineNumber);
    int length = chars.length;
    int[] styles = new int[length];
    lexLineEndState = STATE_NORMAL;
    // سياق التصنيف داخل السطر (إثراء 1.0.16 + مطابقة لوحة المرجع 1.0.19):
    // qualifiedName: داخل اسم مؤهل بعد import/package حتى «;» → مقاطع الحزم NAMESPACE.
    // expectType: بعد class/extends/new... → المعرف التالي نوع TAG.
    // prevIdentLike: الرمز السابق معرف/نوع — يميّز «تعريف دالة» (أبيض Plain) عن «استدعاء»
    // (أزرق FUNCTION) كما يظهر سلوك التطبيق المصدر (تقرير دراسة التلوين 1.0.19).
    boolean qualifiedName = false;
    boolean expectType = false;
    boolean prevIdentLike = false;
    int i = 0;
    if (entryState == STATE_BLOCK_COMMENT) {
      i = consumeBlockComment(chars, 0, styles);
      // consumeBlockComment يضبط نهاية الحالة بنفسه عند عدم الإنهاء فقط — لا فرض هنا.
      if (i >= length) return styles;
    }
    while (i < length) {
      char c = chars[i];
      if (c == ';') qualifiedName = false;
      if (c == ' ' || c == '\t') {
        i++;
        continue;
      }
      if (c == '/' && i + 1 < length && chars[i + 1] == '/' && mode == MODE_JAVA) {
        fill(styles, i, length, CodeLanguageTools.COMMENT);
        i = length;
      } else if (c == '/' && i + 1 < length && chars[i + 1] == '*' && mode == MODE_JAVA) {
        i = consumeBlockComment(chars, i, styles);
      } else if (c == '#' && (mode == MODE_SMALI || mode == MODE_CONF)) {
        fill(styles, i, length, CodeLanguageTools.COMMENT);
        i = length;
      } else if (c == '"') {
        i = consumeQuoted(chars, i, styles, '"');
        prevIdentLike = false;
      } else if (c == '\'') {
        i = consumeQuoted(chars, i, styles, '\'');
        prevIdentLike = false;
      } else if (c == '@' && mode != MODE_XML && i + 1 < length
          && Character.isJavaIdentifierStart(chars[i + 1])) {
        int end = i + 1;
        while (end < length && Character.isJavaIdentifierPart(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.ANNOTATION);
        prevIdentLike = false;
        i = end;
      } else if (Character.isDigit(c)) {
        int end = i + 1;
        while (end < length
            && (Character.isLetterOrDigit(chars[end]) || chars[end] == '.' || chars[end] == '_'))
          end++;
        fill(styles, i, end, CodeLanguageTools.NUMBER);
        prevIdentLike = false;
        i = end;
      } else if (c == '.' && mode == MODE_SMALI && i + 1 < length
          && Character.isJavaIdentifierStart(chars[i + 1])) {
        // تعليمة smali (.method .field .registers ...) — كلمات مفتاحية.
        int end = i + 1;
        while (end < length && Character.isJavaIdentifierPart(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.KEYWORD);
        i = end;
      } else if ((c == 'L' || c == '[') && mode == MODE_SMALI
          && i + 1 < length && isSmaliTypeStart(chars, i)) {
        int end = i;
        while (end < length && chars[end] != ';') end++;
        fill(styles, i, Math.min(end + 1, length), CodeLanguageTools.FUNCTION);
        i = Math.min(end + 1, length);
      } else if (c == 'v' && mode == MODE_SMALI && i + 1 < length
          && Character.isDigit(chars[i + 1])) {
        int end = i + 1;
        while (end < length && Character.isDigit(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.NUMBER);
        i = end;
      } else if (Character.isJavaIdentifierStart(c)) {
        int end = i + 1;
        while (end < length && Character.isJavaIdentifierPart(chars[end])) end++;
        String word = new String(chars, i, end - i);
        if (mode == MODE_JAVA && PRIMITIVE_TYPES.contains(word)) {
          // قاعدة المصدر: الأنواع البدائية (void/float/int...) زرقاء كنوع لا حمراء ككلمة.
          fill(styles, i, end, CodeLanguageTools.TAG);
          expectType = false;
          prevIdentLike = true;
        } else if (isKeyword(word)) {
          fill(styles, i, end, CodeLanguageTools.KEYWORD);
          prevIdentLike = false;
          if (mode == MODE_JAVA) {
            if ("import".equals(word) || "package".equals(word)) qualifiedName = true;
            expectType = "class".equals(word) || "interface".equals(word) || "enum".equals(word)
                || "extends".equals(word) || "implements".equals(word) || "new".equals(word)
                || "instanceof".equals(word) || "throws".equals(word) || "record".equals(word);
          }
        } else if (mode == MODE_JAVA) {
          // تصنيف مطابق للتطبيق المصدر (تقرير 1.0.19):
          // حزم/متغيرات/ثوابت عنبرية، أنواع واستدعاءات زرقاء، أسماء التعريفات بيضاء.
          int next = end;
          while (next < length && (chars[next] == ' ' || chars[next] == '\t')) next++;
          boolean function = next < length && chars[next] == '(';
          if (qualifiedName && !Character.isUpperCase(word.charAt(0))) {
            fill(styles, i, end, CodeLanguageTools.NAMESPACE);
          } else if (isAllCapsConstant(word)) {
            // الثوابت ALL_CAPS (VISIBLE/MIN_...) معرفات عنبرية لا أنواعًا رغم بدايتها الكبيرة.
            fill(styles, i, end, CodeLanguageTools.IDENTIFIER);
          } else if (expectType || Character.isUpperCase(word.charAt(0))) {
            fill(styles, i, end, CodeLanguageTools.TAG);
          } else if (function) {
            // مسبوق بنوع/معرف ⇒ تعريف دالة يبقى Plain أبيض؛ غير ذلك ⇒ استدعاء أزرق.
            if (!prevIdentLike) fill(styles, i, end, CodeLanguageTools.FUNCTION);
          } else if (!gradleFile) {
            fill(styles, i, end, CodeLanguageTools.IDENTIFIER); // المتغيرات/الحقول/البراميترات
          }
          // في gradle: أسماء الأوامر (implementation/android/...) تبقى بيضاء كما في المرجع.
          expectType = false;
          prevIdentLike = true;
        }
        i = end;
      } else if ("(){}[];,.".indexOf(c) >= 0) {
        // فواصل وترقيم (أقواس/فواصل/نقاط) — فئة مستقلة زرقاء كما في المصدر.
        styles[i] = CodeLanguageTools.SEPARATOR;
        prevIdentLike = false;
        i++;
      } else if ("=+-*/%&|!<>~^?:".indexOf(c) >= 0) {
        styles[i] = CodeLanguageTools.OPERATOR;
        prevIdentLike = false;
        i++;
      } else {
        prevIdentLike = false;
        i++;
      }
    }
    return styles;
  }

  /**
   * مُكْسي XML وفهرس اللون في مرور واحد معزول كليًا عن Java. يحفظ عبر السطور حالات الوسم
   * والتعليق وCDATA ونوعي الاقتباس، فلا يُفسَّر &gt; داخل قيمة متعددة الأسطر كنهاية وسم.
   */
  private int[] lexXmlLine(char[] chars, int entryState, int lineNumber) {
    int length = chars.length;
    int[] styles = new int[length];
    ArrayList<XmlColorLiteral> colors = null;
    int i = 0;
    boolean inTag = entryState == STATE_XML_TAG
        || entryState == STATE_XML_TAG_EXPECT_NAME
        || entryState == STATE_XML_DOUBLE_QUOTE
        || entryState == STATE_XML_SINGLE_QUOTE;
    boolean expectElementName = entryState == STATE_XML_TAG_EXPECT_NAME;

    // استمرار تعليق من السطر السابق: لا تُفهرس أي قيم داخله.
    if (entryState == STATE_BLOCK_COMMENT) {
      int end = findToken(chars, 0, "-->");
      if (end < 0) {
        fill(styles, 0, length, CodeLanguageTools.COMMENT);
        return finishXmlLine(styles, colors, STATE_BLOCK_COMMENT);
      }
      i = end + 3;
      fill(styles, 0, i, CodeLanguageTools.COMMENT);
      inTag = false;
    } else if (entryState == STATE_XML_CDATA) {
      // CDATA محتوى خام: يُلوّن Literal ولا يُفسر ما بداخله كألوان أو وسوم.
      int end = findToken(chars, 0, "]]>");
      if (end < 0) {
        fill(styles, 0, length, CodeLanguageTools.STRING);
        return finishXmlLine(styles, colors, STATE_XML_CDATA);
      }
      i = end + 3;
      fill(styles, 0, i, CodeLanguageTools.STRING);
      inTag = false;
    } else if (entryState == STATE_XML_DOUBLE_QUOTE
        || entryState == STATE_XML_SINGLE_QUOTE) {
      char quote = entryState == STATE_XML_DOUBLE_QUOTE ? '"' : '\'';
      int close = findChar(chars, 0, quote);
      int contentEnd = close < 0 ? length : close;
      colors = collectXmlColors(chars, 0, contentEnd, lineNumber, colors);
      if (close < 0) {
        fill(styles, 0, length, CodeLanguageTools.STRING);
        return finishXmlLine(styles, colors, entryState);
      }
      i = close + 1;
      fill(styles, 0, i, CodeLanguageTools.STRING);
      inTag = true;
      expectElementName = false;
    }

    while (i < length) {
      char c = chars[i];
      if (!inTag) {
        if (c == '<' && matches(chars, i, "<!--")) {
          int end = findToken(chars, i + 4, "-->");
          if (end < 0) {
            fill(styles, i, length, CodeLanguageTools.COMMENT);
            return finishXmlLine(styles, colors, STATE_BLOCK_COMMENT);
          }
          int after = end + 3;
          fill(styles, i, after, CodeLanguageTools.COMMENT);
          i = after;
          continue;
        }
        if (c == '<' && matches(chars, i, "<![CDATA[")) {
          int end = findToken(chars, i + 9, "]]>");
          if (end < 0) {
            fill(styles, i, length, CodeLanguageTools.STRING);
            return finishXmlLine(styles, colors, STATE_XML_CDATA);
          }
          int after = end + 3;
          fill(styles, i, after, CodeLanguageTools.STRING);
          i = after;
          continue;
        }
        if (c == '<') {
          styles[i] = CodeLanguageTools.KEYWORD;
          inTag = true;
          expectElementName = true;
          i++;
          continue;
        }
        if (c == '#') {
          XmlColorLiteral literal = XmlColorLiteral.parseAt(chars, i, length, lineNumber);
          if (literal != null) {
            if (colors == null) colors = new ArrayList<>();
            colors.add(literal);
            i = literal.endColumn;
            continue;
          }
        }
        if (c == '&') {
          // كيان &amp; / &#160; — قيمة حرفية خضراء كما يرسمها المرجع.
          int end = i + 1;
          while (end < length && end - i < 10
              && (Character.isLetterOrDigit(chars[end]) || chars[end] == '#')) end++;
          if (end < length && chars[end] == ';') {
            fill(styles, i, end + 1, CodeLanguageTools.STRING);
            i = end + 1;
            continue;
          }
        }
        i++; // نص حر بين الوسوم — أبيض Plain.
        continue;
      }

      // داخل وسم (ولو عبر أسطر متعددة):
      if (c == '>') {
        styles[i] = CodeLanguageTools.KEYWORD;
        inTag = false;
        expectElementName = false;
        i++;
        continue;
      }
      if (c == '/' || c == '?' || c == '!') {
        styles[i] = CodeLanguageTools.KEYWORD;
        i++;
        continue;
      }
      if (c == '"' || c == '\'') {
        char quote = c;
        int close = findChar(chars, i + 1, quote);
        int contentEnd = close < 0 ? length : close;
        colors = collectXmlColors(chars, i + 1, contentEnd, lineNumber, colors);
        if (close < 0) {
          fill(styles, i, length, CodeLanguageTools.STRING);
          return finishXmlLine(
              styles,
              colors,
              quote == '"' ? STATE_XML_DOUBLE_QUOTE : STATE_XML_SINGLE_QUOTE);
        }
        int after = close + 1;
        fill(styles, i, after, CodeLanguageTools.STRING);
        i = after;
        continue;
      }
      if (c == '=') {
        styles[i] = CodeLanguageTools.OPERATOR;
        i++;
        continue;
      }
      if (Character.isJavaIdentifierStart(c) || c == ':') {
        int end = i + 1;
        while (end < length
            && (Character.isJavaIdentifierPart(chars[end])
                || chars[end] == '-' || chars[end] == ':' || chars[end] == '.')) end++;
        fill(
            styles,
            i,
            end,
            expectElementName ? CodeLanguageTools.KEYWORD : CodeLanguageTools.VARIABLE);
        expectElementName = false;
        i = end;
        continue;
      }
      i++;
    }

    int endState = inTag
        ? (expectElementName ? STATE_XML_TAG_EXPECT_NAME : STATE_XML_TAG)
        : STATE_NORMAL;
    return finishXmlLine(styles, colors, endState);
  }

  private int[] finishXmlLine(
      int[] styles, ArrayList<XmlColorLiteral> colors, int endState) {
    lexLineEndState = endState;
    lexLineColorLiterals = colors == null || colors.isEmpty()
        ? XmlColorLiteral.EMPTY_ARRAY
        : colors.toArray(new XmlColorLiteral[colors.size()]);
    return styles;
  }

  /** يفهرس الألوان داخل جزء مسموح (نص XML أو قيمة مقتبسة) دون تخصيص إن لم يجد شيئًا. */
  private ArrayList<XmlColorLiteral> collectXmlColors(
      char[] chars,
      int from,
      int to,
      int lineNumber,
      ArrayList<XmlColorLiteral> colors) {
    int i = Math.max(0, from);
    int limit = Math.min(chars.length, to);
    while (i < limit) {
      if (chars[i] != '#') {
        i++;
        continue;
      }
      XmlColorLiteral literal = XmlColorLiteral.parseAt(chars, i, limit, lineNumber);
      if (literal == null) {
        i++;
        continue;
      }
      if (colors == null) colors = new ArrayList<>();
      colors.add(literal);
      i = literal.endColumn;
    }
    return colors;
  }

  private int findToken(char[] chars, int from, String token) {
    int last = chars.length - token.length();
    for (int i = Math.max(0, from); i <= last; i++) if (matches(chars, i, token)) return i;
    return -1;
  }

  private int findChar(char[] chars, int from, char target) {
    for (int i = Math.max(0, from); i < chars.length; i++) if (chars[i] == target) return i;
    return -1;
  }

  private boolean matches(char[] chars, int at, String token) {
    if (at + token.length() > chars.length) return false;
    for (int i = 0; i < token.length(); i++)
      if (chars[at + i] != token.charAt(i)) return false;
    return true;
  }

  private boolean isSmaliTypeStart(char[] chars, int at) {
    if (chars[at] == '[') return true;
    if (at + 1 >= chars.length) return false;
    char next = chars[at + 1];
    return Character.isUpperCase(next) || next == 'a' || next == 'b' || next == 'c';
  }

  private int consumeQuoted(char[] chars, int start, int[] styles, char quote) {
    int i = start + 1;
    boolean escaped = false;
    while (i < chars.length) {
      char c = chars[i];
      if (escaped) escaped = false;
      else if (c == '\\') escaped = true;
      else if (c == quote) {
        i++;
        break;
      }
      i++;
    }
    fill(styles, start, Math.min(i, chars.length), CodeLanguageTools.STRING);
    return Math.min(i, chars.length);
  }

  private int consumeBlockComment(char[] chars, int start, int[] styles) {
    String terminator = mode == MODE_XML ? "-->" : "*/";
    int i = start;
    int from = start;
    while (i < chars.length) {
      if (matches(chars, i, terminator)) {
        i += terminator.length();
        fill(styles, from, Math.min(i, chars.length), CodeLanguageTools.COMMENT);
        return i;
      }
      i++;
    }

    fill(styles, from, chars.length, CodeLanguageTools.COMMENT);
    lexLineEndState = STATE_BLOCK_COMMENT;
    return chars.length;
  }

  private static void fill(int[] styles, int from, int to, int id) {
    for (int i = Math.max(0, from); i < Math.min(to, styles.length); i++) styles[i] = id;
  }

  /** الأنواع البدائية — تُلوَّن كأنواع (زرقاء) لا ككلمات مفتاحية، مطابقة للتطبيق المصدر. */
  private static final HashSet<String> PRIMITIVE_TYPES = new HashSet<>();

  static {
    String[] primitives = {
      "void", "boolean", "byte", "char", "short", "int", "long", "float", "double"
    };
    for (String word : primitives) PRIMITIVE_TYPES.add(word);
  }

  /** ثابت ALL_CAPS (حرفان فأكثر، كبائر/أرقام/شرطات سفلية فقط وفيه حرف واحد على الأقل). */
  private static boolean isAllCapsConstant(String word) {
    if (word.length() < 2) return false;
    boolean hasLetter = false;
    for (int i = 0; i < word.length(); i++) {
      char c = word.charAt(i);
      if (c >= 'A' && c <= 'Z') hasLetter = true;
      else if (!(c >= '0' && c <= '9') && c != '_' && c != '$') return false;
    }
    return hasLetter;
  }

  /** كلمات Java الشائعة (تغطي أيضًا C/C++/smali بشكل معقول كما في المصدر). */
  private static final HashSet<String> JAVA_KEYWORDS = new HashSet<>();

  static {
    String[] words = {
      "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class",
      "const", "continue", "default", "do", "double", "else", "enum", "extends", "final",
      "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int",
      "interface", "long", "native", "new", "package", "private", "protected", "public",
      "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
      "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false",
      "null", "record", "sealed", "permits", "var", "yield", "synchronized",
      "int32_t", "int64_t", "struct", "typedef", "union", "unsigned", "register", "sizeof",
      "override", "virtual", "template", "namespace", "using", "inline", "explicit"
    };
    for (String word : words) JAVA_KEYWORDS.add(word);
  }

  private boolean isKeyword(String word) {
    if (mode == MODE_JAVA) return JAVA_KEYWORDS.contains(word);
    if (mode == MODE_SMALI)
      return "move".equals(word) || "invoke-virtual".equals(word) || "invoke-static".equals(word)
          || "invoke-direct".equals(word) || "return-void".equals(word);
    return false;
  }
}
