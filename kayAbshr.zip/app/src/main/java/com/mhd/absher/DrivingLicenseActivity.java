package com.mhd.absher;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;

public class DrivingLicenseActivity extends AppCompatActivity {
    private String toArabicNumbers(String str) {
        return str == null ? "" : str.replace(a.a("ZQ=="), a.a("jPQ=")).replace(a.a("ZA=="), a.a("jPU=")).replace(a.a("Zw=="), a.a("jPY=")).replace(a.a("Zg=="), a.a("jPc=")).replace(a.a("YQ=="), a.a("jPA=")).replace(a.a("YA=="), a.a("jPE=")).replace(a.a("Yw=="), a.a("jPI=")).replace(a.a("Yg=="), a.a("jPM=")).replace(a.a("bQ=="), a.a("jPw=")).replace(a.a("bA=="), a.a("jP0="));
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.driving_license);
        getWindow().getDecorView().setLayoutDirection(1);
        SharedPreferences sharedPreferences = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        String string = sharedPreferences.getString(a.a("OzUrSHkn"), a.a("je2fqeHfdJ6U4dGNzA3g7I3C9LJ1jP/0vIze"));
        String string2 = sharedPreferences.getString(a.a("PDAIWFU3MTQ="), a.a("jPWfj+H2jeL0nYzyn4rh/Y3v9Jg="));
        String string3 = sharedPreferences.getString(a.a("Nz00WVARNTJI"), a.a("jPWfhOH8jeUC4fSN5ALh9I3i"));
        String string4 = sharedPreferences.getString(a.a("OzUyRFc7NSpETCw="), a.a("jfOfqeHfjcP0vg=="));
        String string5 = sharedPreferences.getString(a.a("OT0lSFYmMRJUSDA="), a.a("jfqemOHdjPP0sg=="));
        String string6 = sharedPreferences.getString(a.a("PCc1WF0RNTJI"), a.a("jPWfieHxjeYC4fWN5wLh9Y3n"));
        String string7 = sharedPreferences.getString(a.a("MCw2REosECdZXQ=="), a.a("jPWfieHwjeYC4fWN5wLh9Y3n"));
        String string8 = sharedPreferences.getString(a.a("OT0lSFYmMRVZWSEhNQ=="), a.a("jeeeiuDkjcz1kQ=="));
        TextView textView = (TextView) findViewById(R.id.tvLicenseType);
        TextView textView2 = (TextView) findViewById(R.id.tvLicenseIssueDate);
        TextView textView3 = (TextView) findViewById(R.id.tvLicenseExpiryDate);
        TextView textView4 = (TextView) findViewById(R.id.tvLicenseStatus);
        TextView textView5 = (TextView) findViewById(R.id.tvLicenseName);
        TextView textView6 = (TextView) findViewById(R.id.tvLicenseNationality);
        TextView textView7 = (TextView) findViewById(R.id.tvLicenseId);
        TextView textView8 = (TextView) findViewById(R.id.tvLicenseDob);
        TextView textView9 = (TextView) findViewById(R.id.textview21);
        if (textView != null) {
            textView.setText(string5);
        }
        if (textView9 != null) {
            textView9.setText(string5);
        }
        if (textView2 != null) {
            textView2.setText(toArabicNumbers(string6));
        }
        if (textView3 != null) {
            textView3.setText(toArabicNumbers(string7));
        }
        if (textView4 != null) {
            textView4.setText(string8);
        }
        if (textView5 != null) {
            textView5.setText(string);
        }
        if (textView6 != null) {
            textView6.setText(string4);
        }
        if (textView7 != null) {
            textView7.setText(toArabicNumbers(string2));
        }
        if (textView8 != null) {
            textView8.setText(toArabicNumbers(string3));
        }
        ImageView imageView = (ImageView) findViewById(R.id.btnBackDrivingLicense);
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DrivingLicenseActivity.this.finish();
                }
            });
        }
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linear38);
        if (linearLayout != null) {
            linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent((Context) DrivingLicenseActivity.this, (Class<?>) ActivityHomeActivity.class);
                    intent.addFlags(67108864);
                    DrivingLicenseActivity.this.startActivity(intent);
                }
            });
        }
    }
}
