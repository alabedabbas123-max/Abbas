#!/usr/bin/env bash
# القبول الشامل للحزمة — المرحلة التاسعة.
#
# يفحص **الناتج النهائي** لا نجاح الترجمة: المانيفست، الموارد، الـdex، التوقيع،
# أرقام النسخة، وسلامة الاستبعادات في zip المصدر.
#
#   ./qa/acceptance.sh <apk> <zip>
#
# يخرج 0 عند اجتياز كل بنود القبول، و1 عند سقوط أي بند.

set -uo pipefail

APK="${1:-}"
ZIP="${2:-}"
# مساران مطلَقان: الفحوص تنفّذ cd مؤقتة (لفكّ الـdex) فلا يجوز الاعتماد على نسبي.
case "$APK" in /*) ;; *) APK="$PWD/$APK" ;; esac
case "$ZIP" in /*) ;; *) ZIP="$PWD/$ZIP" ;; esac
if [ -z "$APK" ] || [ -z "$ZIP" ]; then
  echo "الاستخدام: ./qa/acceptance.sh <apk> <zip>" >&2; exit 2
fi
cd "$(dirname "$0")/.."

# ── إيجاد build-tools ────────────────────────────────────────────────────
BT=""
for cand in "${ANDROID_HOME:-}/build-tools"/* /home/user/.cache/android-sdk/build-tools/*; do
  [ -x "$cand/aapt2" ] && BT="$cand"
done
if [ -z "$BT" ]; then echo "✘ لم يُعثر على aapt2 (ANDROID_HOME؟)" >&2; exit 2; fi

PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✔ $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  ✘ $1 — $2"; }
note() { echo "  · $1"; }

echo
echo "═══ القبول الشامل ═══"
VERSION=$(cat VERSION 2>/dev/null || echo "?")
UNDER=$(echo "$VERSION" | tr '.' '_')

echo
echo "[1] تطابق النسخة والتسمية"
[ "$VERSION" != "?" ] && ok "VERSION = $VERSION" || bad "VERSION" "غير مقروء"
case "$(basename "$APK")" in
  shima_${UNDER}.apk) ok "اسم الـAPK يطابق النسخة" ;;
  *) bad "اسم الـAPK" "$(basename "$APK") ≠ shima_${UNDER}.apk" ;;
esac
case "$(basename "$ZIP")" in
  shima_${UNDER}.zip) ok "اسم الـzip يطابق النسخة" ;;
  *) bad "اسم الـzip" "$(basename "$ZIP") ≠ shima_${UNDER}.zip" ;;
esac
ZIPVER=$(unzip -p "$ZIP" VERSION 2>/dev/null || echo "?")
[ "$ZIPVER" = "$VERSION" ] && ok "VERSION داخل الـzip = $VERSION" \
  || bad "VERSION داخل الـzip" "$ZIPVER ≠ $VERSION"

echo
echo "[2] التوقيع — يجب أن تبقى الشهادة نفسها عبر النسخ (وإلا تعذّر التحديث)"
CERT=$("$BT/apksigner" verify --print-certs "$APK" 2>/dev/null \
       | grep -o 'certificate SHA-256 digest: [0-9a-f]*' | head -1 | awk '{print $NF}')
EXPECTED=40655b0b0a05c83a3ae0322df1a8fd4410fda71480005ebb6032f4c9592dc4a6
[ "$CERT" = "$EXPECTED" ] && ok "شهادة التوقيع مطابقة لـ1.0.60+" \
  || bad "شهادة التوقيع" "${CERT:-لم تُقرأ} ≠ $EXPECTED"
"$BT/apksigner" verify "$APK" >/dev/null 2>&1 && ok "التوقيع صالح" || bad "التوقيع" "غير صالح"

echo
echo "[3] هوية الحزمة"
BADGING=$("$BT/aapt2" dump badging "$APK" 2>/dev/null | head -1)
echo "$BADGING" | grep -q "name='com.shima.demo'" && ok "اسم الحزمة com.shima.demo" \
  || bad "اسم الحزمة" "$BADGING"
note "$BADGING" | sed 's/^  · //'

echo
echo "[4] الأنشطة مُسجَّلة في المانيفست (لا صنف يُستدعى بلا تسجيل)"
TREE=$("$BT/aapt2" dump xmltree --file AndroidManifest.xml "$APK" 2>/dev/null)
for act in MainActivity AboutActivity ThemeActivity CodeStyleActivity DesignerActivity; do
  if [[ "$TREE" == *"com.shima.demo.$act"* ]]; then ok "النشاط $act مُسجَّل"
  else bad "النشاط $act" "غير موجود في المانيفست"; fi
done
if [[ "$TREE" == *"com.almlkid.ui.preferences.AlmlkPreferencesActivity"* ]]; then ok "النشاط AlmlkPreferencesActivity مُسجَّل"
else bad "النشاط AlmlkPreferencesActivity" "غير موجود في المانيفست"; fi
EXPORTED=$(echo "$TREE" | grep -c 'android:exported.*=true' || true)
note "أنشطة exported=true: $EXPORTED"

echo
echo "[5] كل صنف com.shima.demo موجود في الـdex فعلًا"
TMP=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP" 2>/dev/null
DEXN=$(ls "$TMP"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
[ "$DEXN" -gt 0 ] && ok "استُخرجت $DEXN ملفات dex" || bad "استخراج الـdex" "صفر ملفات"
MISSING=0
for cls in MainActivity AboutActivity CodeStyleActivity CommandCenter LocaleAwareActivity LocaleAwarePreferenceActivity; do
  # grep -l بلا -q: الأخير يخرج مبكرًا فيقتل grep بـSIGPIPE ومع pipefail يسقط الأنبوب كاذبًا.
  HITS=$(grep -l "Lcom/shima/demo/$cls;" "$TMP"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "الصنف $cls" "غير موجود في أي dex"; MISSING=$((MISSING+1)); fi
done
[ $MISSING -eq 0 ] && ok "أصناف com.shima.demo الأساسية في الـdex"
rm -rf "$TMP"

echo
echo "[6] الموارد: لا مرجع مكسور (الترجمة وحدها لا تكشف هذا)"
RES=$("$BT/aapt2" dump resources "$APK" 2>/dev/null)
for r in layout/activity_code_style layout/activity_settings string/code_style_title id/settingsCodeStyle menu/main_options_menu; do
  # مطابقة بـ[[ ]] لا بأنبوب: RES ضخم (آلاف الموارد) وgrep -q كان يقتله بـSIGPIPE.
  if [[ "$RES" == *"$r"* ]]; then ok "المورد $r موجود"; else bad "المورد $r" "غير موجود"; fi
done
if [[ "$RES" == *'() "Application"'* && "$RES" == *'(ar) "التطبيق"'* ]]; then
  ok "موارد عنوان الإعدادات موجودة بالإنجليزية والعربية"
else
  bad "موارد عنوان الإعدادات" "الإنجليزية أو العربية غير معبأة في APK"
fi

echo
echo "[7] zip المصدر: لا تسريب"
# -Z1 يُدرج الأسماء وحدها: ترويسة `unzip -l` تحمل المسار المطلق للـzip نفسه،
# ومساره يحوي /deliverables/ فيُطابق نمط الاستبعاد كذبًا.
ZLIST=$(unzip -Z1 "$ZIP" 2>/dev/null)
LEAK=$(printf '%s\n' "$ZLIST" | grep -Ec 'local\.properties|/build/|/\.gradle/|/deliverables/|/qa/\.out/' || true)
[ "$LEAK" = "0" ] && ok "لا local.properties ولا build ولا .gradle ولا deliverables" \
  || bad "تسريب في الـzip" "$LEAK مدخلًا مستبعدًا موجودًا"
if [[ "$ZLIST" == *"app/src/main/java/almlk/CodeStyle.java"* ]]; then
  ok "المصادر موجودة في الـzip"
else bad "المصادر" "almlk/CodeStyle.java غائب"; fi
if [[ "$ZLIST" == *"qa.sh"* ]]; then
  ok "مجموعة الانحدار داخل الـzip (تنتقل مع المشروع)"
else bad "qa.sh" "غير موجود في الـzip"; fi
if [[ "$ZLIST" == *"qa/acceptance.sh"* ]]; then
  ok "سكربت القبول داخل الـzip"
else bad "qa/acceptance.sh" "غير موجود في الـzip"; fi

echo
echo "══════════════════════════════════════════════════════"
echo "Acceptance: passed=$PASS failed=$FAIL"
echo "══════════════════════════════════════════════════════"
[ $FAIL -eq 0 ] || exit 1
