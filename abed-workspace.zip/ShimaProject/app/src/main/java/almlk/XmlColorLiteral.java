package almlk;

/**
 * قيمة لون Hex مكتشفة من XML، بمدى سطري ثابت وقيمة ARGB جاهزة للاستهلاك.
 *
 * <p>هذا النموذج لا يعتمد Android، كي يبقى الكشف قابلاً للاختبار خارج الواجهة. إنشاء القيم يتم
 * أثناء المرور المعجمي نفسه في {@link LineStyler}؛ الرسم والتحديد يقرآن المدى ذاته، وسيقرأه
 * الاستبدال في مرحلته بدل إعادة تحليل النص بثلاث آليات منفصلة.
 */
public final class XmlColorLiteral {

  /** شكل القيمة الأصلي وعدد خاناتها. */
  public enum Format {
    RGB3(3, false),
    ARGB4(4, true),
    RGB6(6, false),
    ARGB8(8, true);

    public final int digits;
    public final boolean hasAlpha;

    Format(int digits, boolean hasAlpha) {
      this.digits = digits;
      this.hasAlpha = hasAlpha;
    }
  }

  static final XmlColorLiteral[] EMPTY_ARRAY = new XmlColorLiteral[0];

  public final int line;
  public final int startColumn;
  public final int endColumn;
  public final int argb;
  public final Format format;

  XmlColorLiteral(int line, int startColumn, int endColumn, int argb, Format format) {
    this.line = line;
    this.startColumn = startColumn;
    this.endColumn = endColumn;
    this.argb = argb;
    this.format = format;
  }

  public int length() {
    return endColumn - startColumn;
  }

  /**
   * يصوغ ناتج المنتقي وفق العقد: RGB كامل إذا كان الأصل بلا ألفا والناتج معتم، وإلا ARGB
   * كامل. الصيغ القصيرة تُفتح بقيمتها الصحيحة ثم تخرج 6/8 خانات كبيرة.
   */
  public String formatReplacement(int color) {
    boolean includeAlpha = format.hasAlpha || ((color >>> 24) & 0xFF) != 0xFF;
    int digits = includeAlpha ? 8 : 6;
    char[] out = new char[digits + 1];
    out[0] = '#';
    long packed = includeAlpha ? color & 0xFFFFFFFFL : color & 0xFFFFFFL;
    for (int i = digits; i >= 1; i--) {
      int nibble = (int) (packed & 0xF);
      out[i] = (char) (nibble < 10 ? '0' + nibble : 'A' + nibble - 10);
      packed >>>= 4;
    }
    return new String(out);
  }

  /** هل العمود داخل القيمة، مع نهاية حصرية كمديات Java المعتادة. */
  public boolean containsColumn(int column) {
    return column >= startColumn && column < endColumn;
  }

  /** هل المدى المحدد كله داخل هذه القيمة. */
  public boolean containsRange(int start, int end) {
    int from = Math.min(start, end);
    int to = Math.max(start, end);
    return from >= startColumn && to <= endColumn;
  }

  /** بحث موحّد للمؤشر/اللمس داخل مصفوفة السطر المنشورة؛ النهاية حصرية فلا يلتقط الجوار. */
  public static XmlColorLiteral atColumn(XmlColorLiteral[] literals, int column) {
    if (literals == null) return null;
    for (int i = 0; i < literals.length; i++) {
      XmlColorLiteral literal = literals[i];
      if (literal != null && literal.containsColumn(column)) return literal;
    }
    return null;
  }

  /**
   * يعيد القيمة الوحيدة التي تحتوي التحديد كله. التحديد الذي يعبر اقتباسًا أو قيمة ثانية
   * مرفوض؛ أما التحديد الجزئي داخل الخانات فيُطبّع لاحقًا إلى مدى القيمة الكامل.
   */
  public static XmlColorLiteral containingRange(
      XmlColorLiteral[] literals, int startColumn, int endColumn) {
    if (literals == null || startColumn == endColumn) return null;
    for (int i = 0; i < literals.length; i++) {
      XmlColorLiteral literal = literals[i];
      if (literal != null && literal.containsRange(startColumn, endColumn)) return literal;
    }
    return null;
  }

  /**
   * يحاول قراءة لون يبدأ عند {@code hashColumn} داخل الجزء [hashColumn, limit).
   *
   * <p>تُرفض الخانات الزائدة والالتصاق بمعرف من الجانبين، فلا يتحول جزء من نص أطول إلى لون.
   * لا تُقرر هذه الدالة سياق XML (تعليق/CDATA/قيمة)؛ يقرر {@link LineStyler} السياق أولاً ثم
   * يستدعيها فقط في النصوص والقيم المسموح بها.
   */
  static XmlColorLiteral parseAt(char[] chars, int hashColumn, int limit, int line) {
    if (chars == null || hashColumn < 0 || hashColumn >= limit || limit > chars.length
        || chars[hashColumn] != '#') return null;

    if (hashColumn > 0 && isAttachedIdentifier(chars[hashColumn - 1])) return null;

    int end = hashColumn + 1;
    while (end < limit && hex(chars[end]) >= 0) end++;
    int digits = end - hashColumn - 1;
    Format format;
    switch (digits) {
      case 3:
        format = Format.RGB3;
        break;
      case 4:
        format = Format.ARGB4;
        break;
      case 6:
        format = Format.RGB6;
        break;
      case 8:
        format = Format.ARGB8;
        break;
      default:
        return null;
    }

    // لا نقبل تطابقًا جزئيًا قطعته نهاية الجزء المنطقي، ولا لونًا ملتصقًا بكلمة لاحقة.
    if (end < chars.length && (hex(chars[end]) >= 0 || isAttachedIdentifier(chars[end])))
      return null;

    int argb;
    if (digits == 3) {
      int r = duplicateNibble(hex(chars[hashColumn + 1]));
      int g = duplicateNibble(hex(chars[hashColumn + 2]));
      int b = duplicateNibble(hex(chars[hashColumn + 3]));
      argb = 0xFF000000 | (r << 16) | (g << 8) | b;
    } else if (digits == 4) {
      int a = duplicateNibble(hex(chars[hashColumn + 1]));
      int r = duplicateNibble(hex(chars[hashColumn + 2]));
      int g = duplicateNibble(hex(chars[hashColumn + 3]));
      int b = duplicateNibble(hex(chars[hashColumn + 4]));
      argb = (a << 24) | (r << 16) | (g << 8) | b;
    } else {
      long packed = 0;
      for (int i = hashColumn + 1; i < end; i++) packed = (packed << 4) | hex(chars[i]);
      argb = digits == 6 ? (int) (0xFF000000L | packed) : (int) packed;
    }
    return new XmlColorLiteral(line, hashColumn, end, argb, format);
  }

  private static int duplicateNibble(int value) {
    return (value << 4) | value;
  }

  private static int hex(char value) {
    if (value >= '0' && value <= '9') return value - '0';
    if (value >= 'a' && value <= 'f') return value - 'a' + 10;
    if (value >= 'A' && value <= 'F') return value - 'A' + 10;
    return -1;
  }

  private static boolean isAttachedIdentifier(char value) {
    return Character.isJavaIdentifierPart(value) || value == '#';
  }

  @Override
  public String toString() {
    return "XmlColorLiteral{" + line + ":" + startColumn + "-" + endColumn
        + ", " + format + ", 0x" + Integer.toHexString(argb) + "}";
  }
}
