package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.a.a.a.a.a;

public final class NationalBarcodeCardBinding {
    public final FrameLayout frameLayout2;
    public final ImageView imageview12;
    public final ImageView imageviewQrLogo;
    public final RelativeLayout relativelayout12;
    public final RelativeLayout rootView;

    private NationalBarcodeCardBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, FrameLayout frameLayout, ImageView imageView, ImageView imageView2) {
        this.rootView = relativeLayout;
        this.relativelayout12 = relativeLayout2;
        this.frameLayout2 = frameLayout;
        this.imageview12 = imageView;
        this.imageviewQrLogo = imageView2;
    }

    public static NationalBarcodeCardBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.relativelayout12);
        FrameLayout frameLayout = (FrameLayout) findChildViewById(view, R.id.frame_layout2);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.imageview12);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview_qr_logo);
        if (relativeLayout2 == null || frameLayout == null || imageView == null || imageView2 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new NationalBarcodeCardBinding(relativeLayout, relativeLayout2, frameLayout, imageView, imageView2);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static NationalBarcodeCardBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static NationalBarcodeCardBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.national_barcode_card, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
