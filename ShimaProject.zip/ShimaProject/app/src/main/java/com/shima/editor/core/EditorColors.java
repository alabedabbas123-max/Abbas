package com.shima.editor.core;

/** Theme-owned colors; tokenization never contains UI color values. */
public final class EditorColors {
  public final int background;
  public final int foreground;
  public final int keyword;
  public final int opcode;
  public final int comment;
  public final int string;
  public final int register;
  public final int label;
  public final int typeDescriptor;
  public final int number;
  public final int annotation;
  public final int error;

  public EditorColors(
      int background,
      int foreground,
      int keyword,
      int opcode,
      int comment,
      int string,
      int register,
      int label,
      int typeDescriptor,
      int number,
      int annotation,
      int error) {
    this.background = background;
    this.foreground = foreground;
    this.keyword = keyword;
    this.opcode = opcode;
    this.comment = comment;
    this.string = string;
    this.register = register;
    this.label = label;
    this.typeDescriptor = typeDescriptor;
    this.number = number;
    this.annotation = annotation;
    this.error = error;
  }

  public static EditorColors dark() {
    return new EditorColors(
        0xFF191919, 0xFFE8E8E8, 0xFF80CBC4, 0xFF64B5F6, 0xFF7E8A97, 0xFFFFCC80,
        0xFFCE93D8, 0xFFFFB74D, 0xFF4DD0E1, 0xFFB0BEC5, 0xFFBA68C8, 0xFFFF6B6B);
  }
}
