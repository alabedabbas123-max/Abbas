package com.mhd.absher;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class OtherServicesActivity extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.other_services);
        View viewFindViewById = findViewById(R.id.navHome);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    OtherServicesActivity.this.startActivity(new Intent((Context) OtherServicesActivity.this, (Class<?>) ActivityHomeActivity.class));
                    OtherServicesActivity.this.finish();
                }
            });
        }
        View viewFindViewById2 = findViewById(R.id.navFamily);
        if (viewFindViewById2 != null) {
            viewFindViewById2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    OtherServicesActivity.this.startActivity(new Intent((Context) OtherServicesActivity.this, (Class<?>) FamilyActivity.class));
                    OtherServicesActivity.this.finish();
                }
            });
        }
        View viewFindViewById3 = findViewById(R.id.navWorkers);
        if (viewFindViewById3 != null) {
            viewFindViewById3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    OtherServicesActivity.this.startActivity(new Intent((Context) OtherServicesActivity.this, (Class<?>) WorkersActivity.class));
                    OtherServicesActivity.this.finish();
                }
            });
        }
        View viewFindViewById4 = findViewById(R.id.navMyServices);
        if (viewFindViewById4 != null) {
            viewFindViewById4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    OtherServicesActivity.this.startActivity(new Intent((Context) OtherServicesActivity.this, (Class<?>) MyServicesActivity.class));
                    OtherServicesActivity.this.finish();
                }
            });
        }
    }
}
