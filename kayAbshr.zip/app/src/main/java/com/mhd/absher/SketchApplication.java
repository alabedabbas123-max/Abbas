package com.mhd.absher;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Process;
import android.util.Log;
import com.a.a.a.a.a;
import com.google.android.material.color.DynamicColors;

public class SketchApplication extends Application {
    private static Context mApplicationContext;

    public static Context getContext() {
        return mApplicationContext;
    }

    @Override
    public void onCreate() {
        mApplicationContext = getApplicationContext();
        DynamicColors.applyToActivitiesIfAvailable(this);
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable th) {
                Intent intent = new Intent(SketchApplication.this.getApplicationContext(), (Class<?>) DebugActivity.class);
                intent.setFlags(268468224);
                intent.putExtra(a.a("MCY0Qko="), Log.getStackTraceString(th));
                SketchApplication.this.startActivity(intent);
                SketchLogger.broadcastLog(Log.getStackTraceString(th));
                Process.killProcess(Process.myPid());
                System.exit(1);
            }
        });
        SketchLogger.startLogging();
        super.onCreate();
    }
}
