package com.almlkid.ui.preferences;

/** المرحلة 2: جسر أوامر Build & Run بين شظية الإعدادات والمضيف (MainActivity). */
public final class BuildActions {

  public interface Delegate {
    void refreshMaven();

    void ndkToggle();

    void applyEditorVisual();

    void writeProguardConfig();

    void configureGradle();
  }

  public static volatile Delegate delegate;

  private BuildActions() {}
}
