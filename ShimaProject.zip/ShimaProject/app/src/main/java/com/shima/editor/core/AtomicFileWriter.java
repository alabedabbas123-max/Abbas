package com.shima.editor.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;

/** Atomic local-file writer used by both explicit save and autosave. */
public final class AtomicFileWriter {
  private AtomicFileWriter() {}

  public static void write(File target, byte[] bytes) throws IOException {
    if (target == null) throw new IOException("مسار الملف فارغ");
    File parent = target.getParentFile();
    if (parent != null && !parent.exists() && !parent.mkdirs() && !parent.isDirectory())
      throw new IOException("تعذر إنشاء مجلد الملف");
    File temporary = new File(parent == null ? new File(".") : parent, target.getName() + ".shima.tmp");
    try (FileOutputStream output = new FileOutputStream(temporary, false)) {
      output.write(bytes == null ? new byte[0] : bytes);
      output.flush();
      try {
        output.getFD().sync();
      } catch (IOException ignored) {
        // Some providers/filesystems do not expose fsync; rename is still safer than direct write.
      }
    }
    if (target.exists() && !target.delete()) {
      temporary.delete();
      throw new IOException("تعذر استبدال الملف القديم");
    }
    if (!temporary.renameTo(target)) {
      try (FileInputStream input = new FileInputStream(temporary);
          FileOutputStream output = new FileOutputStream(target, false)) {
        byte[] buffer = new byte[8192];
        int count;
        while ((count = input.read(buffer)) >= 0) {
          if (count > 0) output.write(buffer, 0, count);
        }
        output.flush();
      } finally {
        temporary.delete();
      }
    }
  }

  public static void write(File target, String text, Charset charset) throws IOException {
    write(target, (text == null ? "" : text).getBytes(charset));
  }
}
