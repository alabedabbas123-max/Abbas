# تقرير دراسة: قوائم محرر XML الثلاث في المرجع (AIDE Pro)

## 1. مصادر الدراسة
- `res/menu/editor_context_menu.xml` — قائمة وضع التحديد (الحالتان: لون / غير لون).
- `res/menu/main_options_menu.xml` — قائمة ⋮ الرئيسية (حالة بلا تحديد).
- `res/menu/editor_small_context_menu.xml` — قائمة النقر المصغرة (Edit / Fix… / Design).
- سلاسل `values-en/strings.xml` + أيقونات السمات `?icon_*` في styles.xml.
- لقطات المستخدم الست (مطابقة حرفية مع الـXML المفكوك).

## 2. الحالة أ — بلا تحديد (⋮ الرئيسية، اللقطتان 5-6)
البنود بالترتيب: **Edit Mode** (أو Navigate Mode عند ظهور الكيبورد — زر واحد يتبدل)، **View…▸** {الملفات، الأخطاء، نتائج البحث، المصحح، LogCat، قائمة الملفات المفتوحة}، **GoTo**، **Save** (باهت عند عدم وجود تغييرات غير محفوظة)، **More…▸** {Find…▸ {Find usages، بحث في الملف، بحث في المشروع، الذهاب لسطر، Documentation}، Refactor…▸ {Rename، Inline variable، Introduce variable، Extract method}، Code…▸ {Organize imports، Surround try-catch، تعليق، إلغاء تعليق، Setters/Getters، Constructor، Extract resources، استبدال نصي}، Format…▸ {تنسيق الشيفرة، Learn style، Configure style}، Project▸ {إعادة بناء، Build variants، نشر، إغلاق المشروع}، Tools (ديناميكية)، الإعدادات، خروج}.

## 3. الحالة ب — تحديد نص غير لون (اللقطتان 3-4)
شريط التحديد: عنوان + Select(⛶ توسيع التحديد) + قص + نسخ + لصق كأزرار. قائمة ⋮:
**Fix…▸** (يظهر فقط عند توفر إصلاحات، حتى 6 بنود ديناميكية) → **Tools..▸** (فرعية ديناميكية) → **GoTo** → **Documentation** → **Breakpoint** (معطل/باهت في XML) → **Refactor…▸** → **Code…▸** → **Format…▸** → **Find…▸** {Find usages، Find extended usages، بحث نصي} → **Close File**.

## 4. الحالة ج — تحديد قيمة لون (اللقطتان 1-2)
نفس قائمة (ب) يتصدرها بند **Color…** (أيقونة ?icon_manage): يفتح منتقي الألوان (net.margaritov نفسه) بقيمة اللون المحدد، والتأكيد **يستبدل النص المحدد** بالقيمة الجديدة. يظهر فقط إذا كان التحديد صيغة لون ‎#RGB/#RRGGBB/#AARRGGBB.

## 5. دلالات التنفيذ في سياق XML
- GoTo/تعليق/إلغاء تعليق/تنسيق/بحث/استبدال/Find usages/إغلاق الملف/Save: تعمل (قنواتنا موجودة).
- Documentation: فتح وثائق المطورين للرمز المحدد.
- Breakpoint وبنود جافا الصرفة (Rename/Inline/Introduce/Extract/Imports/TryCatch/Setters/Constructor/ExtractResources/Learn style): معطلة باهتة في XML كما بالمرجع.
- Save: أهلية حية حسب وجود تعديلات غير محفوظة.
- Edit Mode/Navigate Mode: تبديل ظهور الكيبورد (زر واحد يعكس الوضع الآخر).

## 6. خطة التنفيذ — ثلاث مراحل (كل مرحلة دورة تسليم كاملة)
- **المرحلة 1**: إحلال قائمة ⋮ الرئيسية (حالة بلا تحديد) بنمط المرجع حرفيًا: Edit/Navigate Mode المتبدل، View…، GoTo، Save بالأهلية الحية، More… بشجرته الكاملة — كل بند موصول بقناة الأوامر، وأهلية/تعطيل حسب نوع الملف.
- **المرحلة 2**: قائمة وضع التحديد (غير لون): البنود العشرة بالترتيب الحرفي مع تنفيذ كل القابل للتنفيذ في XML وتعطيل بنود جافا، وإخفاء Fix… عند غياب الإصلاحات.
- **المرحلة 3**: حالة اللون: كاشف صيغة اللون في التحديد + بند Color… يتصدر القائمة ويحرر القيمة عبر منتقي الألوان ويستبدل التحديد بالناتج.
