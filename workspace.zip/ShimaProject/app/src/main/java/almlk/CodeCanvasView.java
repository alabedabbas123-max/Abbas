package almlk;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.widget.OverScroller;

/**
 * بند almlk ← مكافئ محرك الرسم/التمرير «OConsole»: لوحة رسم كود مخصصة بالكامل.
 *
 * <p>الأساليب المنقولة (بكودنا الخاص، بدون أي رموز حماية):
 *
 * <ul>
 *   <li>اقتصاص النطاق المرئي: لا يُرسم إلا السطور الظاهرة (بكسل←سطر عبر MonospaceMetrics).
 *   <li>مقاطع السطر السبعة بترتيب OConsole: أعلام ← تحديد ← نص مُدفَّع ← قوس-تطابق ← رقم
 *       سطر ← طي ← تنفيذ ← مؤشر.
 *   <li>دُفعات الألوان عبر StyleRunBatcher ودهانات StylePaintCache — صفر تخصيص داخل onDraw.
 *   <li>تحديد عمودي الدقة بمقبضي سحب (بداية/نهاية) كما في CodeEditTextScrollView.
 *   <li>تمرير/قذف بفيزياء إطار العمل (OverScroller + VelocityTracker) — بلا مضاعفات اصطكاك.
 *   <li>تكبير قرصي ذرّي يحفظ البؤرة تحت الإصبع (إعادة بناء مقاسات لحظية واحدة).
 *   <li>نبض المؤشر عبر CaretBlinker وتثبيته تلقائيًا داخل المرئي.
 * </ul>
 */
public class CodeCanvasView extends View {

  /** أنماط السطر أحرفًا + لون كل نمط — واجهة الملوّن التزايدي («C0032va» المُجرد). */
  public interface StyleProvider {
    int[] lineStyles(LineDocument document, int line);

    int colorFor(int styleId);
  }

  /** أعلام السطر (بتات) — أخطاء/توقف/علامات/تنفيذ. */
  public interface LineFlagProvider {
    int flagsForLine(int line);
  }

  /** قناة تفاعلات اللوحة نحو طبقة الإدخال (OEditor) والواجهة. */
  public interface InteractionListener {
    void onSelectionModeChanged(boolean active);

    void onContentScrolled(int x, int y);

    void onTextSizeChanged(float textSizePixels);

    void onShowKeyboardRequested();

    void onCaretRepositioned();
  }

  public static final int FLAG_ERROR = 1;
  public static final int FLAG_WARNING = 2;
  public static final int FLAG_BREAKPOINT = 4;
  public static final int FLAG_BOOKMARK = 8;
  public static final int FLAG_EXECUTION = 16;

  protected LineDocument document;
  private StyleProvider styleProvider;
  private LineFlagProvider flagProvider;
  private InteractionListener interactions;

  private StylePaintCache paints;
  private MonospaceMetrics metrics;
  private final CaretBlinker caretBlinker;
  private final OverScroller scroller;
  private float textSizePx;

  private float gutterWidth;
  private float contentWidth;
  private float contentHeight;
  private float lineSpacingExtra;

  protected int caretLine, caretColumn;
  private int anchorLine = -1, anchorColumn; // طرف التحديد الثابت
  private boolean selectionMode; // دخلنا وضع تحديد (ضغط مطوّل/مزدوج/مقابض)
  /** تحديد نشأ من لمسة المستخدم (ضغط مطوّل/مزدوج/مقابض) — وحدها تفتح قائمة القص/النسخ
   *  (التحديدات البرمجية كالبحث والانتقال لا تُخرج القائمة — مثل TextView). */
  protected boolean selectionFromTouch;

  private int matchingBracketLine = -1;

  private int textColor = 0xFFECEFF1;
  private int gutterColor = 0xFF90A4AE;
  private int backgroundColor = 0xFF121417;
  private int gutterBackgroundColor = 0xFF1B1E22;
  private int currentLineColor = 0x221BB6F6;
  private int selectionColor = 0x3355AAFF;
  private int caretColor = 0xFF29B6F6;
  private int bracketColor = 0xFF26A69A;
  private int handleColor = 0xFF29B6F6;
  private CharSequence hint; // نص توضيحي عند فراغ المستند (مكافئ TextView hint)
  private int errorFlagColor = 0xFFEF5350;
  private int warningFlagColor = 0xFFFFA726;
  private int breakpointColor = 0xFFEC407A;
  private int bookmarkColor = 0xFF42A5F5;
  private int executionColor = 0xFF66BB6A;
  private int foldDotColor = 0xFF78909C;

  // ------ حالة اللمس ------
  private static final int TOUCH_IDLE = 0;
  private static final int TOUCH_SCROLL = 1;
  private static final int TOUCH_SELECTING = 2;
  private static final int TOUCH_HANDLE_START = 3;
  private static final int TOUCH_HANDLE_END = 4;
  private static final int TOUCH_PINCH = 5;

  private int touchState = TOUCH_IDLE;
  private float downX, downY, lastMoveX, lastMoveY;
  private boolean moved;
  private long downTime;
  private long lastTapTime;
  private float lastTapX, lastTapY;
  private float pinchStartDistance;
  private float pinchStartTextSize;
  private float pinchFocusX, pinchFocusY;
  private VelocityTracker velocity;

  private char[] textBuffer = new char[256];
  private int textBufferLength;
  private final char[] gutterDigitsBuffer = new char[10];

  /** مستمع إعادة القياس/الرسم — يُسجَّل عند المستند الحالي ويُنقل مع أي تبديل. */
  private final LineDocument.ChangeListener redrawListener = (from, to) -> onContentChanged();

  private char[] lineInto(int line) {
    LineBuffer buffer;
    synchronized (document) {
      buffer = document.line(line);
      if (buffer.length() > textBuffer.length) textBuffer = new char[buffer.length() * 2];
      buffer.getChars(0, buffer.length(), textBuffer, 0);
      textBufferLength = buffer.length();
    }
    return textBuffer;
  }

  public CodeCanvasView(Context context) {
    super(context);
    textSizePx = getResources().getDisplayMetrics().scaledDensity * 12;
    rebuildTypography();
    caretBlinker = new CaretBlinker(this);
    scroller = new OverScroller(context);
    document = new LineDocument();
    document.addChangeListener(redrawListener);
    setFocusable(true);
    setFocusableInTouchMode(true);
    setWillNotDraw(false);
    setVerticalScrollBarEnabled(true);
    setHorizontalScrollBarEnabled(true);
  }

  private void rebuildTypography() {
    android.graphics.Paint probe =
        new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
    probe.setTypeface(Typeface.MONOSPACE);
    probe.setTextSize(textSizePx);
    metrics = MonospaceMetrics.measure(probe);
    paints = new StylePaintCache(Typeface.MONOSPACE, textSizePx);
  }

  // ---------------- ربط النموذج والمزودات ----------------

  public void setInteractionListener(InteractionListener listener) {
    interactions = listener;
  }

  public void setDocument(LineDocument newDocument) {
    LineDocument fresh = newDocument == null ? new LineDocument() : newDocument;
    document.removeChangeListener(redrawListener);
    document = fresh;
    document.addChangeListener(redrawListener);
    matchingBracketLine = -1;
    caretLine = 0;
    caretColumn = 0;
    anchorLine = -1;
    onContentChanged();
  }

  public LineDocument getDocument() {
    return document;
  }

  public void setStyleProvider(StyleProvider provider) {
    styleProvider = provider;
    invalidate();
  }

  public void setLineFlagProvider(LineFlagProvider provider) {
    flagProvider = provider;
    invalidate();
  }

  public MonospaceMetrics metrics() {
    return metrics;
  }

  /** عرض جالتر أرقام الأسطر الحالي (لمواضع النوافذ المنبثقة). */
  public float gutterWidth() {
    return gutterWidth;
  }

  public float getTextSizePx() {
    return textSizePx;
  }

  /** تكبير ذرّي: مقاسات جديدة لمرة واحدة (منهج المرجع — لا تحجيم متدرج). */
  public void setTextSizePx(float newSize) {
    float min = dp(7), max = dp(48);
    float size = Math.max(min, Math.min(newSize, max));
    if (Math.abs(size - textSizePx) < 0.5f) return;
    textSizePx = size;
    rebuildTypography();
    recomputeContentSize(false);
    caretBlinker.holdVisible();
    invalidate();
    if (interactions != null) interactions.onTextSizeChanged(textSizePx);
  }

  public void setLineSpacingExtra(float extraPx) {
    lineSpacingExtra = Math.max(0, extraPx);
    recomputeContentSize(false);
    invalidate();
  }

  public float lineStride() {
    return metrics.lineHeight + lineSpacingExtra;
  }

  private void onContentChanged() {
    recomputeContentSize(false);
    clampCaret();
    recomputeBracketLine();
    invalidate();
  }

  // ---------------- الألوان (واجهة الثيم) ----------------

  public void setEditorColors(
      int text, int gutter, int background, int gutterBg, int currentLine, int selection,
      int caret, int bracket) {
    textColor = text;
    gutterColor = gutter;
    backgroundColor = background;
    gutterBackgroundColor = gutterBg;
    currentLineColor = currentLine;
    selectionColor = selection;
    caretColor = caret;
    bracketColor = bracket;
    invalidate();
  }

  public void setFlagColors(int error, int warning, int breakpoint, int bookmark) {
    errorFlagColor = error;
    warningFlagColor = warning;
    breakpointColor = breakpoint;
    bookmarkColor = bookmark;
  }

  /** نص توضيحي يظهر فوق المستند الفارغ (مكافئ hint في TextView). */
  public void setHint(CharSequence hintText) {
    hint = hintText;
    invalidate();
  }

  // ---------------- القياس والتمرير ----------------

  private void recomputeContentSize(boolean keepScroll) {
    int longest = 0;
    int count;
    synchronized (document) {
      count = document.lineCount();
      for (int i = 0; i < count; i++) longest = Math.max(longest, document.lineLength(i));
    }
    gutterWidth = (Math.max(3, digits(count)) + 1) * metrics.mWidth + dp(12);
    contentWidth = gutterWidth + (longest + 2) * metrics.mWidth + dp(24);
    contentHeight = count * lineStride() + dp(12);
    if (!keepScroll) clampScroll();
  }

  private static int digits(int value) {
    int count = 1;
    while (value >= 10) {
      value /= 10;
      count++;
    }
    return count;
  }

  private int maxScrollX() {
    return (int) Math.max(0, contentWidth - getWidth() + gutterWidth);
  }

  private int maxScrollY() {
    return (int) Math.max(0, contentHeight - getHeight());
  }

  private void clampScroll() {
    scrollTo(
        Math.max(0, Math.min(getScrollX(), maxScrollX())),
        Math.max(0, Math.min(getScrollY(), maxScrollY())));
  }

  public void scrollByPixels(float dx, float dy) {
    scrollTo(
        Math.max(0, Math.min((int) (getScrollX() + dx), maxScrollX())),
        Math.max(0, Math.min((int) (getScrollY() + dy), maxScrollY())));
  }

  @Override
  protected void onScrollChanged(int l, int t, int oldl, int oldt) {
    super.onScrollChanged(l, t, oldl, oldt);
    if (interactions != null) interactions.onContentScrolled(l, t);
    awakenScrollBars();
  }

  // أشرطة التمرير الإطارية (أسلوب الحاوي المرجعي).
  @Override
  protected int computeVerticalScrollRange() {
    return (int) contentHeight;
  }

  @Override
  protected int computeVerticalScrollExtent() {
    return getHeight();
  }

  @Override
  protected int computeVerticalScrollOffset() {
    return getScrollY();
  }

  // ---------------- حالة المؤشر/التحديد/المطابقة ----------------

  private void clampCaret() {
    int count = document.lineCount();
    caretLine = Math.max(0, Math.min(caretLine, count - 1));
    caretColumn = Math.max(0, Math.min(caretColumn, document.lineLength(caretLine)));
  }

  public void setCaret(int line, int column) {
    caretLine = Math.max(0, Math.min(line, document.lineCount() - 1));
    caretColumn = Math.max(0, Math.min(column, document.lineLength(caretLine)));
    anchorLine = -1;
    if (selectionMode) {
      selectionMode = false;
      if (interactions != null) interactions.onSelectionModeChanged(false);
    }
    recomputeBracketLine();
    caretBlinker.holdVisible();
    ensureCaretVisible();
    invalidate();
    if (interactions != null) interactions.onCaretRepositioned();
  }

  /** تحريك المؤشر مع الإبقاء على التحديد (Shift أو سحب المقبض). */
  public void setCaretExtendingSelection(int line, int column) {
    if (anchorLine < 0) {
      anchorLine = caretLine;
      anchorColumn = caretColumn;
    }
    caretLine = Math.max(0, Math.min(line, document.lineCount() - 1));
    caretColumn = Math.max(0, Math.min(column, document.lineLength(caretLine)));
    recomputeBracketLine();
    caretBlinker.holdVisible();
    ensureCaretVisible();
    invalidate();
    if (interactions != null) interactions.onCaretRepositioned();
  }

  public int caretLine() {
    return caretLine;
  }

  public int caretColumn() {
    return caretColumn;
  }

  public boolean hasSelection() {
    return anchorLine >= 0 && (anchorLine != caretLine || anchorColumn != caretColumn);
  }

  public boolean inSelectionMode() {
    return selectionMode;
  }

  /** المواضع المرتبة: [سطر البداية، عمودها، سطر النهاية، عمودها] — أو المؤشر طرفًا واحدًا. */
  public int[] orderedSelection() {
    if (anchorLine < 0) return new int[] {caretLine, caretColumn, caretLine, caretColumn};
    if (anchorLine < caretLine || (anchorLine == caretLine && anchorColumn <= caretColumn))
      return new int[] {anchorLine, anchorColumn, caretLine, caretColumn};
    return new int[] {caretLine, caretColumn, anchorLine, anchorColumn};
  }

  public void setSelectionRange(int startLine, int startColumn, int endLine, int endColumn) {
    anchorLine = Math.max(0, Math.min(startLine, document.lineCount() - 1));
    anchorColumn = Math.max(0, Math.min(startColumn, document.lineLength(anchorLine)));
    caretLine = Math.max(0, Math.min(endLine, document.lineCount() - 1));
    caretColumn = Math.max(0, Math.min(endColumn, document.lineLength(caretLine)));
    selectionMode = hasSelection();
    selectionFromTouch = false; // تحديد برمجي — بلا قائمة سياق
    recomputeBracketLine();
    invalidate();
    if (interactions != null) interactions.onSelectionModeChanged(selectionMode);
  }

  public void enterSelectionMode() {
    if (!selectionMode) {
      selectionMode = true;
      if (interactions != null) interactions.onSelectionModeChanged(true);
    }
  }

  public void exitSelectionMode() {
    anchorLine = -1;
    if (selectionMode) {
      selectionMode = false;
      if (interactions != null) interactions.onSelectionModeChanged(false);
    }
    invalidate();
  }

  public void clearSelection() {
    exitSelectionMode();
  }

  /** انتقاء المعرف تحت موضع معيّن (ضغط مزدوج/مطوّل) بقواعد Java. */
  public void selectWordAt(int line, int column) {
    int clampedLine = Math.max(0, Math.min(line, document.lineCount() - 1));
    char[] chars;
    synchronized (document) {
      chars = document.lineChars(clampedLine);
    }
    if (chars.length == 0) return;
    int at = Math.max(0, Math.min(column, chars.length - 1));
    int start = almlk.IdentifierBounds.start(new String(chars), at);
    int end = almlk.IdentifierBounds.end(new String(chars), at);
    if (end <= start) return;
    anchorLine = clampedLine;
    anchorColumn = start;
    caretLine = clampedLine;
    caretColumn = end;
    selectionMode = true;
    selectionFromTouch = true; // نشأ من لمسة — يفتح قائمة القص/النسخ
    recomputeBracketLine();
    caretBlinker.holdVisible();
    ensureCaretVisible();
    invalidate();
    if (interactions != null) interactions.onSelectionModeChanged(true);
  }

  public void selectAll() {
    anchorLine = 0;
    anchorColumn = 0;
    caretLine = document.lineCount() - 1;
    caretColumn = document.lineLength(caretLine);
    selectionMode = caretLine > 0 || caretColumn > 0;
    invalidate();
    if (interactions != null) interactions.onSelectionModeChanged(selectionMode);
  }

  private void recomputeBracketLine() {
    matchingBracketLine = BracketMatcher.matchingLine(document, caretLine, caretColumn);
  }

  /** يضمن ظهور المؤشر داخل المرئي بهامش سطر أعلى/أسفل (أسلوب OEditor.ensureCaretVisible). */
  public void ensureCaretVisible() {
    float lineTop = caretLine * lineStride();
    float lineBottom = lineTop + lineStride();
    int newX = getScrollX(), newY = getScrollY();
    float margin = lineStride();
    if (lineTop < getScrollY() + margin) newY = (int) Math.max(0, lineTop - margin);
    else if (lineBottom > getScrollY() + getHeight() - margin)
      newY = (int) Math.min(maxScrollY(), lineBottom - getHeight() + margin);
    float caretX = gutterWidth + metrics.columnToX(caretColumn) - getScrollX();
    if (caretX < gutterWidth + dp(8))
      newX = (int) Math.max(0, gutterWidth + metrics.columnToX(caretColumn) - gutterWidth - dp(8));
    else if (caretX > getWidth() - dp(16))
      newX = (int) Math.min(maxScrollX(),
          gutterWidth + metrics.columnToX(caretColumn) - getWidth() + dp(32));
    if (newX != getScrollX() || newY != getScrollY()) scrollTo(newX, newY);
  }

  // ---------------- اللمس ----------------

  private int[] positionFromPoint(float x, float y) {
    int line = Math.max(0, metrics.yToLine(y + getScrollY()));
    line = Math.min(line, document.lineCount() - 1);
    int column = metrics.xToColumn(x + getScrollX() - gutterWidth);
    column = Math.max(0, Math.min(column, document.lineLength(line)));
    return new int[] {line, column};
  }

  private float handleX(int line, int column) {
    return gutterWidth + metrics.columnToX(column) - getScrollX();
  }

  private float handleY(int line) {
    return (line + 1) * lineStride() - getScrollY();
  }

  private boolean nearHandle(float x, float y, int line, int column) {
    float hx = handleX(line, column), hy = handleY(line);
    float radius = dp(24);
    return Math.abs(x - hx) < radius && Math.abs(y - hy) < radius;
  }

  @Override
  public boolean onTouchEvent(MotionEvent event) {
    switch (event.getActionMasked()) {
      case MotionEvent.ACTION_DOWN:
        touchState = TOUCH_IDLE;
        downX = lastMoveX = event.getX();
        downY = lastMoveY = event.getY();
        moved = false;
        downTime = event.getEventTime();
        scroller.forceFinished(true);
        obtainVelocity();
        velocity.addMovement(event);
        removeCallbacks(longPressTrigger);
        postDelayed(longPressTrigger, 500);
        // نقرة على مقبض تحديد؟
        if (selectionMode && hasSelection()) {
          int[] ordered = orderedSelection();
          if (nearHandle(event.getX(), event.getY(), ordered[0], ordered[1])) {
            touchState = TOUCH_HANDLE_START;
            selectionFromTouch = true; // سحب مقبض = تحديد لمسي
          } else if (nearHandle(event.getX(), event.getY(), ordered[2], ordered[3])) {
            touchState = TOUCH_HANDLE_END;
            selectionFromTouch = true;
          }
        }
        if (touchState == TOUCH_IDLE) requestFocus();
        return true;
      case MotionEvent.ACTION_POINTER_DOWN:
        if (event.getPointerCount() == 2 && touchState != TOUCH_HANDLE_START
            && touchState != TOUCH_HANDLE_END) {
          touchState = TOUCH_PINCH;
          pinchStartDistance = pointerDistance(event);
          pinchStartTextSize = textSizePx;
          pinchFocusX = (event.getX(0) + event.getX(1)) / 2f;
          pinchFocusY = (event.getY(0) + event.getY(1)) / 2f;
          // بؤرة التكبير: موضع النص تحت نقطة المنتصف قبل إعادة البناء.
          int[] anchorPos = positionFromPoint(pinchFocusX, pinchFocusY);
          pinchAnchorLine = anchorPos[0];
          pinchAnchorColumn = anchorPos[1];
          pinchAnchorFracY =
              (pinchFocusY + getScrollY() - pinchAnchorLine * lineStride()) / lineStride();
        }
        return true;
      case MotionEvent.ACTION_MOVE:
        if (velocity != null) velocity.addMovement(event);
        if (touchState == TOUCH_PINCH && event.getPointerCount() >= 2) {
          float distance = pointerDistance(event);
          if (pinchStartDistance > 0) {
            // نقرة ذرّية لكل خطوة: نص جديد + إبقاء البؤرة تحت الإصبع (منهجنا المؤرشف 1.0.12).
            float target = pinchStartTextSize * (distance / pinchStartDistance);
            float beforeX = gutterWidth + metrics.columnToX(pinchAnchorColumn) - getScrollX();
            float beforeY = pinchAnchorLine * lineStride() + pinchAnchorFracY * lineStride()
                - getScrollY();
            setTextSizePx(target);
            int newScrollX =
                (int) (gutterWidth + metrics.columnToX(pinchAnchorColumn) - beforeX + 0);
            int newScrollY = (int) (pinchAnchorLine * lineStride()
                + pinchAnchorFracY * lineStride() - beforeY);
            scrollTo(
                Math.max(0, Math.min(newScrollX, maxScrollX())),
                Math.max(0, Math.min(newScrollY, maxScrollY())));
          }
          return true;
        }
        float dx = event.getX() - lastMoveX;
        float dy = event.getY() - lastMoveY;
        float totalDx = event.getX() - downX;
        float totalDy = event.getY() - downY;
        if (!moved && Math.hypot(totalDx, totalDy) > dp(8)) {
          moved = true;
          removeCallbacks(longPressTrigger);
          if (touchState == TOUCH_IDLE) touchState = TOUCH_SCROLL;
        }
        if (touchState == TOUCH_SCROLL) {
          scrollByPixels(-dx, -dy);
        } else if (touchState == TOUCH_SELECTING || touchState == TOUCH_HANDLE_START
            || touchState == TOUCH_HANDLE_END) {
          int[] pos = positionFromPoint(event.getX(), event.getY());
          if (touchState == TOUCH_HANDLE_START) {
            int[] ordered = orderedSelection();
            if (pos[0] < ordered[2] || (pos[0] == ordered[2] && pos[1] <= ordered[3])) {
              anchorLine = ordered[2];
              anchorColumn = ordered[3];
              caretLine = pos[0];
              caretColumn = pos[1];
            } else {
              anchorLine = ordered[0];
              anchorColumn = ordered[1];
              caretLine = pos[0];
              caretColumn = pos[1];
            }
            recomputeBracketLine();
            caretBlinker.holdVisible();
            invalidate();
          } else {
            setCaretExtendingSelection(pos[0], pos[1]);
          }
          moved = true;
        } else if (moved && touchState == TOUCH_IDLE) {
          touchState = TOUCH_SCROLL;
        }
        lastMoveX = event.getX();
        lastMoveY = event.getY();
        return true;
      case MotionEvent.ACTION_POINTER_UP:
        if (touchState == TOUCH_PINCH && event.getPointerCount() <= 2) {
          touchState = TOUCH_IDLE;
        }
        return true;
      case MotionEvent.ACTION_UP:
        if (velocity != null) velocity.addMovement(event);
        removeCallbacks(longPressTrigger);
        boolean wasTap = !moved && event.getEventTime() - downTime < 600;
        if (touchState == TOUCH_PINCH) {
          touchState = TOUCH_IDLE;
          releaseVelocity();
          return true;
        }
        if (touchState == TOUCH_HANDLE_START || touchState == TOUCH_HANDLE_END) {
          touchState = TOUCH_IDLE;
          releaseVelocity();
          return true;
        }
        if (touchState == TOUCH_SELECTING) {
          touchState = TOUCH_IDLE;
          releaseVelocity();
          return true;
        }
        if (wasTap && touchState == TOUCH_IDLE) {
          int[] pos = positionFromPoint(event.getX(), event.getY());
          long now = event.getEventTime();
          boolean doubleTap =
              now - lastTapTime < 350 && Math.hypot(event.getX() - lastTapX, event.getY() - lastTapY)
                  < dp(24);
          if (doubleTap) {
            selectWordAt(pos[0], pos[1]);
            lastTapTime = 0;
          } else {
            setCaret(pos[0], pos[1]);
            lastTapTime = now;
            lastTapX = event.getX();
            lastTapY = event.getY();
            if (interactions != null) interactions.onShowKeyboardRequested();
          }
          releaseVelocity();
          return true;
        }
        if (moved && touchState == TOUCH_SCROLL) {
          flingFromTracker();
        }
        touchState = TOUCH_IDLE;
        releaseVelocity();
        return true;
      case MotionEvent.ACTION_CANCEL:
        touchState = TOUCH_IDLE;
        releaseVelocity();
        return true;
      default:
        return true;
    }
  }

  private int pinchAnchorLine;
  private int pinchAnchorColumn;
  private float pinchAnchorFracY;

  /** مؤقت الضغط المطوّل (500ms): انتقاء المعرف ودخول وضع التحديد إن لم يتحرك الإصبع. */
  private final Runnable longPressTrigger =
      () -> {
        if (!moved && touchState == TOUCH_IDLE && hasWindowFocus()) {
          int[] pos = positionFromPoint(downX, downY);
          selectWordAt(pos[0], pos[1]);
          touchState = TOUCH_SELECTING;
        }
      };

  private void obtainVelocity() {
    if (velocity == null) velocity = VelocityTracker.obtain();
  }

  private void releaseVelocity() {
    if (velocity != null) {
      velocity.recycle();
      velocity = null;
    }
  }

  private void flingFromTracker() {
    if (velocity == null) return;
    velocity.computeCurrentVelocity(1000);
    scroller.fling(
        getScrollX(), getScrollY(),
        (int) -velocity.getXVelocity(), (int) -velocity.getYVelocity(),
        0, maxScrollX(), 0, maxScrollY());
    postInvalidateOnAnimation();
  }

  private float pointerDistance(MotionEvent event) {
    if (event.getPointerCount() < 2) return 0f;
    float dx = event.getX(0) - event.getX(1);
    float dy = event.getY(0) - event.getY(1);
    return (float) Math.hypot(dx, dy);
  }

  @Override
  public void computeScroll() {
    if (scroller.computeScrollOffset()) {
      scrollTo(scroller.getCurrX(), scroller.getCurrY());
      postInvalidateOnAnimation();
    }
  }

  // ---------------- الرسم: مقاطع السطر السبعة بترتيب OConsole ----------------

  @Override
  protected void onDraw(Canvas canvas) {
    canvas.drawColor(backgroundColor);
    if (document == null) return;
    float originX = gutterWidth - getScrollX();
    float originY = -getScrollY();

    // hint: مستند فارغ تمامًا وثمة نص توضيحي → يُرسم باهتًا فوق أول سطر.
    boolean emptyDocument =
        document.lineCount() == 1 && document.lineLength(0) == 0;
    if (emptyDocument && hint != null && hint.length() > 0) {
      canvas.drawText(
          hint.toString(),
          originX + dp(8),
          metrics.ascent + lineSpacingExtra / 2f + dp(4),
          paints.text(withAlpha(textColor, 110), false));
    }

    int firstLine = Math.max(0, (int) (getScrollY() / lineStride()));
    int lastLine = Math.min(
        document.lineCount() - 1, (int) ((getScrollY() + getHeight()) / lineStride()) + 1);
    if (firstLine > lastLine) return;

    canvas.save();
    canvas.clipRect(gutterWidth, 0, getWidth(), getHeight());

    int[] sel = orderedSelection();
    boolean selecting = hasSelection();

    for (int line = firstLine; line <= lastLine; line++) {
      float lineTop = originY + line * lineStride();
      float lineBottom = lineTop + lineStride();

      drawFlagRibbons(canvas, line, lineTop, lineBottom);
      if (line == caretLine)
        canvas.drawRect(0, lineTop, contentWidth, lineBottom, paints.currentLine(currentLineColor));
      if (selecting) drawSelectionSegment(canvas, line, originX, lineTop, lineBottom, sel);
      drawLineText(canvas, line, originX, lineTop);
      drawBracketUnderline(canvas, line, originX, lineBottom);
      drawFoldMarker(canvas, line, lineTop, lineBottom);
      drawExecutionArrow(canvas, line, originX, lineTop);
    }
    drawCaret(canvas, originX, originY);
    if (selecting && selectionMode) drawSelectionHandles(canvas, sel);
    canvas.restore();

    drawGutterColumn(canvas, firstLine, lastLine);
  }

  /** مقطع 1: أشرطة أعلام السطر بعرض المحتوى كاملًا. */
  private void drawFlagRibbons(Canvas canvas, int line, float top, float bottom) {
    if (flagProvider == null) return;
    int flags = flagProvider.flagsForLine(line);
    if (flags == 0) return;
    if ((flags & FLAG_ERROR) != 0)
      canvas.drawRect(0, top, contentWidth, bottom, paints.fill(withAlpha(errorFlagColor, 40)));
    if ((flags & FLAG_WARNING) != 0)
      canvas.drawRect(0, top, contentWidth, bottom, paints.fill(withAlpha(warningFlagColor, 32)));
    if ((flags & FLAG_BREAKPOINT) != 0)
      canvas.drawRect(0, top, contentWidth, bottom, paints.fill(withAlpha(breakpointColor, 36)));
    if ((flags & FLAG_BOOKMARK) != 0)
      canvas.drawRect(0, top, contentWidth, bottom, paints.fill(withAlpha(bookmarkColor, 28)));
  }

  /** مقطع 2: التحديد عمودي الدقة — من عمود البداية إلى عمود النهاية (امتداد للعرض بينهما). */
  private void drawSelectionSegment(
      Canvas canvas, int line, float originX, float top, float bottom, int[] sel) {
    if (line < sel[0] || line > sel[2]) return;
    int startColumn = line == sel[0] ? sel[1] : 0;
    float from = originX + metrics.columnToX(startColumn);
    float to = (line == sel[2])
        ? originX + metrics.columnToX(sel[3])
        : Math.max(originX + document.lineLength(line) * metrics.mWidth, getWidth() - originX);
    if (to <= from) to = from + metrics.mWidth / 2;
    canvas.drawRect(from, top, to, bottom, paints.selection(selectionColor));
  }

  /** مقبضا السحب عند طرفي التحديد (دائرة + ذيل عمودي) — أسلوب مقابض الحاوي المرجعي. */
  private void drawSelectionHandles(Canvas canvas, int[] sel) {
    float startX = handleX(sel[0], sel[1]);
    float startY = handleY(sel[0]);
    float endX = handleX(sel[2], sel[3]);
    float endY = handleY(sel[2]);
    float r = dp(6);
    android.graphics.Paint paint = paints.fill(handleColor);
    canvas.drawRect(startX - dp(1.5f), startY - lineStride(), startX + dp(1.5f), startY, paint);
    canvas.drawCircle(startX, startY + r * 0.6f, r, paint);
    canvas.drawRect(endX - dp(1.5f), endY - lineStride(), endX + dp(1.5f), endY, paint);
    canvas.drawCircle(endX, endY + r * 0.6f, r, paint);
  }

  /** مقطع 3: نص السطر runs مدفعة عبر StyleRunBatcher — صفر قياس وتخصيص أثناء الرسم. */
  private void drawLineText(Canvas canvas, int line, float originX, float lineTop) {
    char[] chars = lineInto(line);
    if (textBufferLength == 0) return;
    float baseline = lineTop + metrics.ascent + lineSpacingExtra / 2f;
    int[] styles = styleProvider == null ? null : styleProvider.lineStyles(document, line);
    if (styles == null || styles.length == 0) {
      canvas.drawText(
          chars, 0, textBufferLength, originX, baseline,
          paints.text(styleProvider == null ? textColor : styleProvider.colorFor(0), false));
      return;
    }
    StyleRunBatcher.batch(
        styles,
        0,
        Math.min(styles.length, textBufferLength),
        (styleId, start, end) ->
            canvas.drawText(
                chars,
                start,
                end - start,
                originX + metrics.columnToX(start),
                baseline,
                paints.text(styleProvider.colorFor(styleId), false)));
  }

  /** مقطع 4: خط تطابق الأقواس. */
  private void drawBracketUnderline(Canvas canvas, int line, float originX, float lineBottom) {
    if (line != matchingBracketLine || line == caretLine) return;
    canvas.drawRect(originX, lineBottom - dp(1.5f), contentWidth - dp(4), lineBottom,
        paints.bracketLine(bracketColor));
  }

  /** مقطع 5: نقطة قابلية الطي بجوار الجالتر (سطر منتهٍ بـ '{'). */
  private void drawFoldMarker(Canvas canvas, int line, float lineTop, float lineBottom) {
    char[] chars = lineInto(line);
    int last = textBufferLength - 1;
    while (last >= 0 && (chars[last] == ' ' || chars[last] == '\t')) last--;
    if (last < 0 || chars[last] != '{') return;
    float dotSize = Math.min(dp(3), lineStride() / 6);
    canvas.drawCircle(
        gutterWidth - dp(7), lineTop + lineStride() / 2, dotSize, paints.foldDot(foldDotColor));
  }

  /** مقطع 6: سهم نقطة التنفيذ (المصحّح). */
  private void drawExecutionArrow(Canvas canvas, int line, float originX, float lineTop) {
    if (flagProvider == null) return;
    int flags = flagProvider.flagsForLine(line);
    if ((flags & FLAG_EXECUTION) == 0) return;
    float x = originX + document.lineLength(line) * metrics.mWidth + dp(6);
    canvas.drawRect(x, lineTop, x + dp(2), lineTop + lineStride(), paints.fill(executionColor));
    canvas.drawRect(x, lineTop + lineStride() - dp(2), x + dp(8), lineTop + lineStride(),
        paints.fill(executionColor));
  }

  /** مقطع 7: المؤشر النابض. */
  private void drawCaret(Canvas canvas, float originX, float originY) {
    if (!caretBlinker.visible() || caretLine >= document.lineCount()) return;
    float x = originX + metrics.columnToX(caretColumn);
    float top = originY + caretLine * lineStride() + lineSpacingExtra / 2f;
    if (top > getHeight() || top + metrics.lineHeight < 0) return;
    canvas.drawRect(x, top, x + dp(2), top + metrics.lineHeight, paints.caret(caretColor));
  }

  /** جالتر الأرقام: كتابة يدوية بلا تخصيص. */
  private void drawGutterColumn(Canvas canvas, int firstLine, int lastLine) {
    canvas.drawRect(0, 0, gutterWidth, getHeight(), paints.fill(gutterBackgroundColor));
    for (int line = firstLine; line <= lastLine; line++) {
      float baseline = -getScrollY() + line * lineStride() + metrics.ascent + lineSpacingExtra / 2f;
      int length = writeInt(gutterDigitsBuffer, line + 1);
      canvas.drawText(
          gutterDigitsBuffer, 0, length,
          gutterWidth - dp(8) - length * metrics.digitWidth,
          baseline,
          paints.gutter(gutterColor));
    }
  }

  private static int writeInt(char[] dest, int value) {
    int position = dest.length;
    int number = value;
    do {
      dest[--position] = (char) ('0' + (number % 10));
      number /= 10;
    } while (number > 0);
    int length = dest.length - position;
    System.arraycopy(dest, position, dest, 0, length);
    return length;
  }

  private static int withAlpha(int color, int alpha) {
    return (color & 0xFFFFFF) | (alpha << 24);
  }

  protected float dp(float value) {
    return value * getResources().getDisplayMetrics().density;
  }

  // ---------------- دورة الحياة ----------------

  /** يبدأ نبض المؤشر عند اكتساب التركيز — عادة الأداة المرجعية. */
  @Override
  protected void onFocusChanged(boolean gainFocus, int direction, android.graphics.Rect previouslyFocusedRect) {
    super.onFocusChanged(gainFocus, direction, previouslyFocusedRect);
    if (gainFocus) caretBlinker.holdVisible();
    caretBlinker.stop();
    if (gainFocus) caretBlinker.start();
    invalidate();
  }

  @Override
  protected void onDetachedFromWindow() {
    caretBlinker.stop();
    super.onDetachedFromWindow();
  }
}
