package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class RecruitmentRequestsBinding {
    public final ImageView btnBackRecruitment;
    public final ImageView imgEmptyRecruitment;
    public final LinearLayout linear14;
    public final RelativeLayout rootView;
    public final RelativeLayout topBarRecruitment;
    public final TextView tvNoRecruitmentSub;
    public final TextView tvNoRecruitmentTitle;
    public final TextView tvRecruitmentTitle;

    private RecruitmentRequestsBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, LinearLayout linearLayout, ImageView imageView2, TextView textView2, TextView textView3) {
        this.rootView = relativeLayout;
        this.topBarRecruitment = relativeLayout2;
        this.btnBackRecruitment = imageView;
        this.tvRecruitmentTitle = textView;
        this.linear14 = linearLayout;
        this.imgEmptyRecruitment = imageView2;
        this.tvNoRecruitmentTitle = textView2;
        this.tvNoRecruitmentSub = textView3;
    }

    public static RecruitmentRequestsBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBarRecruitment);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBackRecruitment);
        TextView textView = (TextView) findChildViewById(view, R.id.tvRecruitmentTitle);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear14);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imgEmptyRecruitment);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvNoRecruitmentTitle);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tvNoRecruitmentSub);
        if (relativeLayout2 == null || imageView == null || textView == null || linearLayout == null || imageView2 == null || textView2 == null || textView3 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new RecruitmentRequestsBinding(relativeLayout, relativeLayout2, imageView, textView, linearLayout, imageView2, textView2, textView3);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static RecruitmentRequestsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static RecruitmentRequestsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.recruitment_requests, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
