#!/bin/bash
set -e
CACHE=/home/user/.cache
export JAVA_HOME=$CACHE/jdk21
export ANDROID_HOME=$CACHE/android-sdk
export GRADLE_USER_HOME=$CACHE/gradle
export PATH=$JAVA_HOME/bin:$PATH
cd /home/user/ShimaProject
sh gradlew --no-daemon --console=plain :app:assembleDebug 2>&1 | tail -60
echo "### BUILD SCRIPT DONE"
ls -la app/build/outputs/apk/debug/ 2>/dev/null || true
