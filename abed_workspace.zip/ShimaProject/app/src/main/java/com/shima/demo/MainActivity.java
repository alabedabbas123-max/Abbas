package com.shima.demo;

import android.app.*;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import androidx.drawerlayout.widget.DrawerLayout;
import android.view.*;
import android.widget.*;
import com.almlkid.kay.ui.ProjectSearchEngine;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.ui.UsageSearchEngine;
import com.almlkid.kay.view.VPDrawerLayout;
import com.almlkid.ui.SequentialPanelHost;
import com.almlkid.ui.AIDEEditorPager;
import com.almlkid.ui.browsers.BrowserPager;
import com.shima.projects.ProjectWizard;
import java.io.File;
import java.util.*;

/** Java controller for the original res/layout/main_drawer.xml screen. */
public class MainActivity extends Activity
    implements BrowserPager.ActionListener, CommandCenter.Host {
  VPDrawerLayout drawer;
  AIDEEditorPager editor;
  BrowserPager browser;
  ImageButton masterButton;
  View moreActionView;
  PopupWindow ideMenuWindow;
  View empty;
  boolean projectOpen = false;
  final CommandCenter commands = new CommandCenter();
  final ShellCommandRunner shell = new ShellCommandRunner();
  ProjectSession session;
  // شريط وضع التحرير (دلالة المرجع): يتحول مع ظهور كيبورد المحرر ويعود مع إخفائه.
  boolean editingToolbar;
  boolean lastCanUndo, lastCanRedo;
  AlertDialog requiredStorageDialog;
  FrameLayout sequentialPanelsDrawer;
  View sequentialPanelsScrim;
  SequentialPanelHost sequentialPanels;

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
    getWindow().setStatusBarColor(Color.BLACK);
    getWindow().setNavigationBarColor(Color.rgb(35, 35, 35));
    if (getIntent().getBooleanExtra("safe_mode", false)) {
      showSafeMode();
      return;
    }
    try {
      session = new ProjectSession(this);
      setContentView(R.layout.main_drawer);
      configureActionBar();
      drawer = findViewById(R.id.mainDrawerLayout);
      editor = findViewById(R.id.mainCodePageView);
      // Fix: create the panel host in code instead of inflating <com.almlkid.ui.SequentialPanelHost>
      // from XML. LayoutInflater resolves custom views via reflection, and any build pipeline that
      // strips "unreferenced" constructors makes inflation crash with NoSuchMethodException.
      FrameLayout panelSlot = findViewById(R.id.mainSequentialPanelHost);
      sequentialPanels = panelSlot == null ? null : new SequentialPanelHost(this);
      if (panelSlot != null) {
        panelSlot.addView(
            sequentialPanels,
            new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
      }
      browser = sequentialPanels == null ? findViewById(R.id.mainBrowserPager) : sequentialPanels.browser();
      empty = findViewById(R.id.mainCodeEmptyView);
      if (drawer == null || editor == null || browser == null || sequentialPanels == null || empty == null)
        throw new IllegalStateException("main_drawer.xml is missing a required view");
      browser.setOnFileSelectedListener(
          (name, content) -> {
            // Keep only the stable path/SAF URI in the session; the text is still loaded lazily.
            openFile(name, content, browser.fileReference(name));
          });
      // تقرير فتح الملفات — الفتح الفوري: التبويب يظهر لحظة النقرة («جارٍ فتح الملف…»)،
      // وحوار تبديل المشروع يُطلق هنا عند النقرة وليس عند وصول المحتوى.
      browser.setOnFileOpeningListener(
          name -> {
            drawer.closeDrawers();
            String reference = browser.fileReference(name);
            maybeSwitchProjectForFile(reference);
            projectOpen = true;
            empty.setVisibility(View.GONE);
            editor.openFilePending(name, reference);
            if (masterButton != null) masterButton.setVisibility(View.VISIBLE);
            getActionBar().setTitle(name);
            getActionBar().setSubtitle("المشروع المفتوح");
          });
      browser.setActionListener(this);
      sequentialPanels.setErrors(
          editor.diagnostics(), editor.getTextContent());
      sequentialPanels.setErrorClickListener(
          diagnostic -> {
            if (editor != null && diagnostic != null) {
              editor.goToOffset(diagnostic.offset);
              // لا إغلاق تلقائي: اللوحة تبقى حتى يغادرها المستخدم بنفسه.
            }
          });
      sequentialPanels.setBuildOutput("لم يبدأ البناء أو التشغيل بعد.");
      sequentialPanels.setUsageClickListener(
          usage -> {
            if (usage == null || editor == null) return;
            // كالمرجع: الانتقال بالسطر/العمود على النص الحي وقت النقر — لا إزاحات بائتة،
            // والقفزة تُؤجل تلقائيًا داخل المحرر إن كان محتوى التبويب قيد التحميل الكسول.
            // التفعيل بالمرجع الثابت يحترم أسماء التبويبات المفردة ولا يفتح تبويبًا مكررًا.
            String openTab = editor.selectIfOpenLive(usage.reference, usage.fileName);
            if (openTab == null && editor.activateTabIfOpen(usage.fileName))
              openTab = usage.fileName;
            if (openTab != null) {
              editor.goToMatch(openTab, usage.line, usage.column);
              // الدخول المباشر كما في المرجع: اللوحة تُغلق فورًا ويظهر المحرر على الموقع.
              closeSequentialPanels();
              return;
            }
            browser.openUsageAsync(
                usage,
                (success, fileName, content, offset, message) -> {
                  if (!success || fileName == null || content == null) {
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                    return;
                  }
                  // ترتيب المرجع: الفتح (حقن متزامن) يسبق القفزة دائمًا — والقفزة تستهدف
                  // اسم التبويب الفعلي بعد الفتح (قد يكون مفردًا).
                  openFile(fileName, content, browser.fileReference(fileName));
                  editor.goToMatch(editor.getActiveFile(), usage.line, usage.column);
                  closeSequentialPanels();
                });
          });
      sequentialPanels.setCloseListener(this::closeSequentialPanels);
      editor.setHostCommandListener(this::dispatch);
      // قائمة التبويب: عند إغلاق كل التبويبات منها تُعرض الواجهة الفارغة كما في بقية المسارات.
      editor.setTabsClosedListener(
          () -> {
            empty.setVisibility(View.VISIBLE);
            editor.setVisibility(View.GONE);
            if (masterButton != null) masterButton.setVisibility(View.GONE);
          });
      editor.setQuickFixListener(this::confirmCreateMissingMember);
      editor.setDefinitionListener(this::openDefinition);
      editor.setDefinitionRequestListener(this::findDefinitionForSelection);
      editor.setUsageListener(this::findUsagesForSelection);
      editor.setHistoryStateListener(this::refreshEditingToolbarState);
      masterButton = findViewById(R.id.mainMasterButton);
      if (masterButton != null) {
        masterButton.setOnClickListener(v -> showCommands());
        hideMasterButtonWithKeyboard(masterButton);
      }
      ProgressBar progress = findViewById(R.id.mainErrorProgress);
      if (progress != null) progress.setVisibility(View.GONE);
      configureDrawer();
      applySelectedTheme();
      showNoProject();
      editor.restoreSessionAsync(
          restored -> {
            if (!restored) return;
            projectOpen = true;
            empty.setVisibility(View.GONE);
            editor.setVisibility(View.VISIBLE);
            if (masterButton != null) masterButton.setVisibility(View.VISIBLE);
            browser.indexProjectSymbols(editor::refreshSemanticDiagnostics);
          });
      // حفظ المشروع المفتوح عبر إعادة التشغيل: استرجاع عنوانه وفتح جذره مباشرة.
      if (session != null && session.isOpen()) {
        projectOpen = true;
        getActionBar().setTitle(session.name());
        getActionBar().setSubtitle("مشروع Android");
        if (browser != null) {
          // تقرير AIDE — بروتوكول الاستعادة = إعادة تنفيذ بروتوكول الفتح ذاته (جذر + فهرسة + إعلام).
          browser.openProjectRoot(session.path());
          Toast.makeText(this, "فتح المشروع: " + session.name(), Toast.LENGTH_SHORT).show();
        }
      }
      browser.postDelayed(this::showPermissionsCenterOnFirstRun, 500);
    } catch (Throwable error) {
      CrashStore.save(this, error);
      showStartupError(error);
    }
  }

  void configureActionBar() {
    ActionBar b = getActionBar();
    if (b == null) return;
    b.setTitle("المشروع الحالي");
    b.setSubtitle("بيئة البرمجة العربية");
    b.setBackgroundDrawable(new ColorDrawable(Color.rgb(34, 34, 34)));
    b.setDisplayHomeAsUpEnabled(true);
    b.setHomeButtonEnabled(true);
    b.setHomeAsUpIndicator(R.drawable.ic_navigation_menu);
  }

  void applySelectedTheme() {
    ThemeConfig theme = new ThemeConfig(this);
    int background = theme.color(ThemeConfig.BACKGROUND);
    int chrome = Color.rgb(34, 34, 34);
    getWindow().setStatusBarColor(theme.isDark() ? Color.BLACK : Color.rgb(224, 224, 224));
    getWindow()
        .setNavigationBarColor(theme.isDark() ? Color.rgb(35, 35, 35) : Color.rgb(224, 224, 224));
    ActionBar bar = getActionBar();
    if (bar != null) bar.setBackgroundDrawable(new ColorDrawable(chrome));
    if (empty != null) empty.setBackgroundColor(background);
    if (editor != null) editor.applyTheme();
    if (browser != null) browser.applyTheme();
  }

  void configureDrawer() {
    drawer.setScrimColor(Color.BLACK);
    drawer.setHorizontalSwipeListener(
        new VPDrawerLayout.HorizontalSwipeListener() {
          @Override
          public void onDrawerSwipeLeft() {
            // The file browser and tool panes are one continuous pager.
            if (sequentialPanels != null) sequentialPanels.nextPage();
          }

          @Override
          public boolean onDrawerSwipeRight() {
            // At the file page return false so DrawerLayout can close normally.
            return sequentialPanels != null && sequentialPanels.previousPageIfPossible();
          }
        });
    drawer.addDrawerListener(
        new DrawerLayout.SimpleDrawerListener() {
          @Override
          public void onDrawerOpened(View v) {
            getActionBar().setHomeAsUpIndicator(R.drawable.ic_navigation_back);
            invalidateOptionsMenu();
          }

          @Override
          public void onDrawerClosed(View v) {
            getActionBar().setHomeAsUpIndicator(R.drawable.ic_navigation_menu);
            invalidateOptionsMenu();
          }
        });
  }

  void showNoProject() {
    projectOpen = false;
    empty.setVisibility(View.VISIBLE);
    editor.setVisibility(View.GONE);
    if (masterButton != null) masterButton.setVisibility(View.GONE);
    getActionBar().setTitle("المشروع الحالي");
    getActionBar().setSubtitle("بيئة البرمجة العربية");
  }

  void openFile(String file) {
    openFile(file, null);
  }

  void openFile(String file, String content) {
    openFile(file, content, "");
  }

  void openFile(String file, String content, String reference) {
    // تقرير فتح الملفات — تقرير التبديل بين المشاريع يسبق القراءة الآن (setOnFileOpeningListener)
    // أي وصول openFile هنا يعني أن المحتوى جاهز للحقن فقط.
    projectOpen = true;
    empty.setVisibility(View.GONE);
    editor.openFile(file, content, reference);
    if (browser != null)
      browser.setActiveEditorSnapshot(editor.getActiveFile(), editor.getTextContent(), reference);
    if (masterButton != null) masterButton.setVisibility(View.VISIBLE);
    getActionBar().setTitle(file);
    getActionBar().setSubtitle("المشروع المفتوح");
  }

  @Override
  public void onProjectOpened(String name, String path) {
    // فتح مشروع مختلف عمّا هو مفتوح: تأكيد أولًا مع إيقاف تخزين المشروع السابق بسرعة.
    if (projectOpen
        && session != null
        && session.isOpen()
        && path != null
        && !path.isEmpty()
        && !session.path().equals(path)) {
      confirmProjectSwitch(name, path);
      return;
    }
    applyProjectOpen(name, path);
  }

  /** حوار تأكيد أنيق قبل استبدال المشروع الحالي بآخر جديد. */
  private void confirmProjectSwitch(final String name, final String path) {
    final String previousName = session.name();
    final String previousPath = session.path();
    new AlertDialog.Builder(this)
        .setTitle("فتح مشروع جديد")
        .setMessage(
            "سيتم فتح «" + name + "» وإيقاف التخزين المؤقت للمشروع السابق «"
                + previousName + "» فورًا وبشكل كامل. المتابعة؟")
        .setPositiveButton(
            "فتح",
            (dialog, which) -> {
              suspendProjectCaches(previousPath);
              applyProjectOpen(name, path);
            })
        .setNegativeButton(
            "إلغاء",
            (dialog, which) -> {
              // تراجع أنيق: إبقاء المشروع السابق مفتوحًا وإعادة المتصفح إلى جذره.
              if (browser != null) browser.openProjectRoot(previousPath);
            })
        .show();
  }

  /** التخزين المؤقت للمشروع الحالي فقط: إسقاط فهرس/كاش المشروع السابق فورًا. */
  private void suspendProjectCaches(String previousPath) {
    ProjectSymbolIndex.clear();
    if (editor != null) editor.closeAll();
    if (browser != null) browser.suspendProjectCacheFor(previousPath);
  }

  /** إن كان الملف المفتوح داخل مشروع آخر غير المفتوح: طلب فتح مشروع جديد (نفس حوار التأكيد). */
  /** مسار مشروعٍ طلبنا تبديله لملفٍ منه — يمنع ظهور الحوار مرتين لنفس المشروع. */
  private String pendingFileSwitchPath;

  private void maybeSwitchProjectForFile(String reference) {
    if (reference == null || !reference.startsWith("/")) return;
    final String base = "/storage/emulated/0/AppProjects/";
    if (!reference.startsWith(base)) return;
    int slash = reference.indexOf('/', base.length());
    if (slash < 0) return;
    String projectPath = reference.substring(0, slash);
    String projectName = projectPath.substring(projectPath.lastIndexOf('/') + 1);
    if (projectName.isEmpty()
        || session == null
        || !session.isOpen()
        || session.path().equals(projectPath)) return;
    // تقرير فتح الملفات — الحوار مرة واحدة لكل مشروع مقترن حتى لو نقر المستخدم عدة ملفات.
    if (projectPath.equals(pendingFileSwitchPath)) return;
    pendingFileSwitchPath = projectPath;
    getWindow()
        .getDecorView()
        .postDelayed(
            () -> {
              if (projectPath.equals(pendingFileSwitchPath)) pendingFileSwitchPath = null;
            },
            4000);
    onProjectOpened(projectName, projectPath);
  }

  private void applyProjectOpen(String name, String path) {
    projectOpen = true;
    session.open(name, path);
    boolean hasOpenFile = editor.hasOpenFile();
    empty.setVisibility(hasOpenFile ? View.GONE : View.VISIBLE);
    editor.setVisibility(hasOpenFile ? View.VISIBLE : View.GONE);
    if (masterButton != null) masterButton.setVisibility(hasOpenFile ? View.VISIBLE : View.GONE);
    getActionBar().setTitle(name);
    getActionBar().setSubtitle("مشروع Android");
    browser.indexProjectSymbols(editor::refreshSemanticDiagnostics);
    // تقرير 04 — فحص dependencies في الخلفية وعرض الخطة في لوحة Build دون تعطيل المحرر.
    com.shima.dependencies.GradleDependencyScanner.scanAsync(
        new File(path),
        lines -> {
          if (sequentialPanels != null)
            for (String line : lines) sequentialPanels.appendBuildOutput(line);
        });
  }

  private void openDefinition(ProjectSymbolIndex.DefinitionTarget definition) {
    if (definition == null) return;
    // بند 3 — وضع لوحة المفاتيح لا يتغير بسبب الانتقال أو القوائم.
    final boolean imeWasVisible = isImeVisible();
    // المقارنة بالاسم القصير + مرجع الجلسة الدقيق — أسماء التبويبات قد تكون مفردة (app/X.java).
    String activeName = editor == null ? null : editor.getActiveFile();
    String activeShort =
        activeName == null ? "" : activeName.substring(activeName.lastIndexOf('/') + 1);
    String activeReference = editor == null ? "" : editor.activeFileReference();
    boolean sameOpenFile = definition.fileName != null
        && (definition.fileName.equals(activeName) || definition.fileName.equals(activeShort))
        && (definition.reference == null || definition.reference.isEmpty()
            || activeReference.isEmpty() || definition.reference.equals(activeReference));
    // الكلاس = انتقال صامت كما في المرجع؛ لوحة «أماكن التواجد» للعناصر (دوال/حقول) فقط.
    boolean classTarget =
        definition.kind == ProjectSymbolIndex.DefinitionTarget.KIND_CLASS
            || (definition.symbol != null && definition.symbol.equals(definition.className));
    if (definition.source == null && sameOpenFile) {
      // القفزة تُحل على نص المحرر الحي وقت النقر — الإزاحة المفهرسة قد تكون بائتة بعد التحرير.
      int landed = editor.goToSymbol(definition.symbol, definition.offset);
      if (landed >= 0 && !classTarget)
        showNavigationUsages(
            definition.fileName, editor.getTextContent(), landed, definition.symbol);
      restoreKeyboardIfVisible(imeWasVisible);
      return;
    }
    // تبويب مفتوح آخر محتواه حي: تفعيل مباشر وقفزة على نصه — لا إعادة حقن من القرص
    // تدمّر تعديلات غير محفوظة.
    if (definition.source == null && editor != null) {
      String openTab = editor.selectIfOpenLive(definition.reference, definition.fileName);
      if (openTab != null) {
        int landed = editor.goToSymbol(definition.symbol, definition.offset);
        if (landed >= 0 && !classTarget)
          showNavigationUsages(
              definition.fileName, editor.getTextContent(), landed, definition.symbol);
        restoreKeyboardIfVisible(imeWasVisible);
        return;
      }
    }
    final String targetReference = definition.reference;
    browser.openDefinition(
        definition,
        (success, fileName, content, offset, message) -> {
          if (!success || fileName == null || content == null) {
            // المرجع يتنقل بصمت — التنبيه عند الفشل فقط.
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            return;
          }
          String reference = targetReference == null || targetReference.isEmpty()
              ? browser.fileReference(fileName) : targetReference;
          openFile(fileName, content, reference);
          // القفزة تُحل على المحتوى المحقون للتو — لا اعتماد أعمى على إزاحة الفهرس.
          editor.goToSymbol(definition.symbol, offset);
          // الانتقال من كلاس آخر = مباشر إلى موقع العنصر في كلاسه — بلا لوحة إضافية.
          restoreKeyboardIfVisible(imeWasVisible);
        });
  }

  /** يملأ لوحة «نتائج البحث» الجانبية بكل مواضع العنصر الذي انتقلنا إليه. */
  private void showNavigationUsages(
      String fileName, String source, int offset, String symbol) {
    if (symbol == null || symbol.isEmpty() || source == null || browser == null) return;
    int start = Math.max(0, Math.min(offset, source.length()));
    int end = Math.min(source.length(), start + symbol.length());
    showSequentialPanels(SequentialPanelHost.Panel.SEARCH);
    sequentialPanels.setSearchStatus("أماكن تواجد " + symbol + "…");
    sequentialPanels.setSearchResults(Collections.emptyList(), symbol);
    browser.findUsagesAsync(
        fileName,
        source,
        start,
        end,
        (usages, done) -> {
          if (sequentialPanels == null) return;
          sequentialPanels.setSearchResults(usages, symbol);
          int count = usages == null ? 0 : usages.size();
          // البث التدريجي: عدّاد حي أثناء المسح ثم الحصيلة النهائية — لا تعليق على حالة وسيطة.
          sequentialPanels.setSearchStatus(
              !done
                  ? "أماكن تواجد " + symbol + "… (" + count + ")"
                  : count == 0
                      ? "لا توجد استخدامات لـ " + symbol
                      : "أماكن تواجد " + symbol + ": " + count);
        });
  }

  private boolean isImeVisible() {
    android.graphics.Rect frame = new android.graphics.Rect();
    android.view.View decor = getWindow().getDecorView();
    decor.getWindowVisibleDisplayFrame(frame);
    int heightDiff = decor.getRootView().getHeight() - frame.bottom;
    return heightDiff > getResources().getDisplayMetrics().density * 100;
  }

  private void restoreKeyboardIfVisible(boolean wasVisible) {
    if (wasVisible && editor != null) editor.postDelayed(editor::ensureKeyboardVisible, 150);
  }

  private void findDefinitionForSelection(
      String fileName, String source, int selectionStart, int selectionEnd) {
    browser.findDefinitionAsync(
        fileName,
        source,
        selectionStart,
        selectionEnd,
        target -> {
          if (target == null) {
            Toast.makeText(this, "تعذر العثور على تعريف العنصر المحدد", Toast.LENGTH_SHORT).show();
          } else {
            openDefinition(target);
          }
        });
  }

  private void findUsagesForSelection(
      String fileName, String source, int selectionStart, int selectionEnd) {
    final String symbol = UsageSearchEngine.identifierAt(source, selectionStart, selectionEnd);
    if (symbol.isEmpty()) {
      Toast.makeText(this, "حدد اسم دالة أو متغير أو كلاس أولًا", Toast.LENGTH_SHORT).show();
      return;
    }
    showSequentialPanels(SequentialPanelHost.Panel.SEARCH);
    sequentialPanels.setSearchStatus("جار البحث عن استخدامات " + symbol + "…");
    sequentialPanels.setSearchResults(Collections.emptyList(), symbol);
    browser.findUsagesAsync(
        fileName,
        source,
        selectionStart,
        selectionEnd,
        (usages, done) -> {
          if (sequentialPanels != null) {
            sequentialPanels.setSearchResults(usages, symbol);
            int count = usages == null ? 0 : usages.size();
            sequentialPanels.setSearchStatus(
                !done
                    ? "جار البحث عن استخدامات " + symbol + "… (" + count + ")"
                    : count == 0
                        ? "لا توجد استخدامات لـ " + symbol
                        : "تم العثور على " + count + " استخدام");
          }
        });
  }

  private void showSequentialPanels(SequentialPanelHost.Panel initial) {
    if (sequentialPanels == null) return;
    if (initial == SequentialPanelHost.Panel.ERRORS && editor != null)
      sequentialPanels.setErrors(editor.diagnostics(), editor.getTextContent());
    sequentialPanels.showPage(initial == null ? SequentialPanelHost.Panel.ERRORS : initial);
    if (drawer != null && !drawer.isDrawerOpen(Gravity.LEFT)) drawer.openDrawer(Gravity.LEFT);
  }

  private void closeSequentialPanels() {
    if (drawer != null && drawer.isDrawerOpen(Gravity.LEFT)) drawer.closeDrawer(Gravity.LEFT);
  }

  private void showPanel(SequentialPanelHost.Panel panel) {
    showSequentialPanels(panel);
  }

  private void confirmCreateMissingMember(ProjectSymbolIndex.MissingMember member) {
    StringBuilder signature = new StringBuilder();
    signature.append(member.returnType).append(' ').append(member.methodName).append('(');
    for (int i = 0; i < member.parameters.size(); i++) {
      if (i > 0) signature.append(", ");
      ProjectSymbolIndex.Parameter parameter = member.parameters.get(i);
      signature.append(parameter.type).append(' ').append(parameter.name);
    }
    signature.append(')');
    new AlertDialog.Builder(this)
        .setTitle("تعديل الملفات")
        .setMessage(
            "هل تريد إنشاء الدالة التالية؟\n\n" + member.className + ".java\n\n" + signature)
        .setNegativeButton("لا", null)
        .setPositiveButton(
            "نعم",
            (dialog, which) ->
                browser.createMissingMember(
                    member,
                    (success, fileName, content, message) -> {
                      Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                      if (success) {
                        openFile(fileName, content);
                        editor.refreshSemanticDiagnostics();
                      }
                    }))
        .show();
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    menu.clear();
    menu.add(0, 1, 0, getString(R.string.command_run))
        .setIcon(R.drawable.ic_vectoric_run)
        .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    // دلالة المرجع: أثناء الكتابة يحل زوج التراجع/الإعادة محل القلم، بأهلية حية
    // (المتاح أبيض والمعطل باهت) — وخارج التحرير يعود القلم كما كان.
    boolean editingNow =
        editingToolbar && (drawer == null || !drawer.isDrawerOpen(Gravity.LEFT));
    if (editingNow && editor != null) {
      lastCanUndo = editor.canUndoEdit();
      lastCanRedo = editor.canRedoEdit();
      MenuItem undoItem =
          menu.add(0, 4, 1, "تراجع").setIcon(R.drawable.ic_vectoric_undo);
      undoItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
      undoItem.setEnabled(lastCanUndo);
      if (undoItem.getIcon() != null)
        undoItem.getIcon().mutate().setAlpha(lastCanUndo ? 255 : 95);
      MenuItem redoItem =
          menu.add(0, 5, 2, "إعادة").setIcon(R.drawable.ic_vectoric_redo);
      redoItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
      redoItem.setEnabled(lastCanRedo);
      if (redoItem.getIcon() != null)
        redoItem.getIcon().mutate().setAlpha(lastCanRedo ? 255 : 95);
    } else if (activeLayoutXml()) {
      // دلالة المرجع: ملف تخطيط XML بلا كيبورد → أيقونة معاينة التصميم محل القلم.
      menu.add(0, 6, 1, "معاينة التصميم")
          .setIcon(R.drawable.ic_vectoric_design)
          .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    } else
      menu.add(0, 2, 1, getString(R.string.command_edit))
          .setIcon(R.drawable.ic_vectoric_edit)
          .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    MenuItem more = menu.add(0, 3, 3, getString(R.string.menu_more));
    ImageButton button = new ImageButton(this);
    button.setImageResource(R.drawable.ic_vectoric_more);
    button.setContentDescription(getString(R.string.menu_more));
    button.setBackgroundColor(Color.TRANSPARENT);
    button.setPadding(dp(12), dp(12), dp(12), dp(12));
    button.setOnClickListener(v -> showIdeRootMenu(v));
    moreActionView = button;
    more.setActionView(button);
    more.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    return true;
  }

  /** اختصارات العتاد على مستوى الـIDE — ترسل معرفات الأوامر للفهرس كما كل نقاط الواجهة. */
  @Override
  public boolean onKeyShortcut(int keyCode, android.view.KeyEvent event) {
    if (event.isCtrlPressed()) {
      switch (keyCode) {
        case android.view.KeyEvent.KEYCODE_S:
          dispatch("save");
          return true;
        case android.view.KeyEvent.KEYCODE_F:
          dispatch(event.isShiftPressed() ? "replace" : "find");
          return true;
        case android.view.KeyEvent.KEYCODE_H:
          dispatch("replace");
          return true;
        case android.view.KeyEvent.KEYCODE_G:
          dispatch("goto_line");
          return true;
        case android.view.KeyEvent.KEYCODE_SLASH:
          dispatch("comment");
          return true;
        case android.view.KeyEvent.KEYCODE_L:
          dispatch("format");
          return true;
        case android.view.KeyEvent.KEYCODE_SPACE:
          dispatch("complete");
          return true;
        default:
          break;
      }
    }
    return super.onKeyShortcut(keyCode, event);
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      if (drawer.isDrawerOpen(Gravity.LEFT)) drawer.closeDrawers();
      else openBrowser();
      return true;
    }
    if (item.getItemId() == 1) {
      // نمط المرجع: الأيقونة ترسل معرف الأمر للفهرس فيفحص الأهلية ثم ينفذ.
      dispatch("run");
      return true;
    }
    if (item.getItemId() == 2) {
      // أيقونة القلم كما في المرجع: دخول التحرير مباشرة، وإن لا ملف مفتوحًا نفتح المتصفح.
      if (editor == null || !editor.beginEditingSession()) openFilesBrowser();
      return true;
    }
    if (item.getItemId() == 6) {
      openDesigner();
      return true;
    }
    if (item.getItemId() == 4) {
      dispatch("undo");
      return true;
    }
    if (item.getItemId() == 5) {
      dispatch("redo");
      return true;
    }
    if (item.getItemId() == 3) {
      showIdeRootMenu(moreActionView != null ? moreActionView : masterButton);
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  @Override
  public void onCreateProject() {
    drawer.closeDrawers();
    // بنية المرجع: معالج قوالب حقيقي — فئات من JSON، اسم/حزمة بتحقق حي، نسخ واستبدالات،
    // ثم فتح المشروع وملفات البداية. لا ستب ولا وهم (بند الإحلال الكامل).
    ProjectWizard.show(
        this,
        browser != null ? browser.projectsTargetDirectory() : null,
        new ProjectWizard.Host() {
          @Override
          public void onProjectCreated(
              File projectRoot, File mainModule, java.util.List<File> starterFiles) {
            if (browser != null) browser.openCreatedProject(projectRoot);
            openStarterFiles(starterFiles);
          }

          @Override
          public void onProjectImported(File targetDirectory) {
            if (browser != null) browser.refreshListing();
          }
        });
  }

  /** فتح ملفات بداية المشروع في التبويبات بالترتيب — القراءة خلفية والحقن على الواجهة. */
  private void openStarterFiles(java.util.List<File> starters) {
    if (starters == null || starters.isEmpty()) return;
    new Thread(
            () -> {
              for (File starter : starters) {
                String content;
                try (java.io.FileInputStream in = new java.io.FileInputStream(starter)) {
                  java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                  byte[] buffer = new byte[8192];
                  int read;
                  while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
                  content = out.toString("UTF-8");
                } catch (Exception unreadable) {
                  continue;
                }
                final String name = starter.getName();
                final String text = content;
                final String reference = starter.getAbsolutePath();
                runOnUiThread(() -> openFile(name, text, reference));
              }
            })
        .start();
  }

  @Override
  public void onCloneGit() {
    drawer.closeDrawers();
    View v = getLayoutInflater().inflate(R.layout.gitclonerepository, null);
    ((TextView) v.findViewById(R.id.gitclonerepositoryLocation))
        .setText("/storage/emulated/0/AppProjects");
    ((EditText) v.findViewById(R.id.gitclonerepositoryUrl)).setText("");
    ((EditText) v.findViewById(R.id.gitclonerepositoryDirectoryName)).setText("");
    new AlertDialog.Builder(this)
        .setTitle("استنساخ مستودع Git")
        .setView(v)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "استنساخ",
            (d, w) -> Toast.makeText(this, "جارِ استنساخ المستودع…", Toast.LENGTH_SHORT).show())
        .show();
  }

  /** فتح الدرج على القسم المثبت — زر القائمة لا يُسقط المستخدم من الأخطاء/البحث للملفات. */
  void openBrowser() {
    if (drawer != null) drawer.openDrawer(Gravity.LEFT);
  }

  /** فتح الدرج على صفحة الملفات تحديدًا — للأوامر التي تقصد الملفات صراحة. */
  void openFilesBrowser() {
    if (sequentialPanels != null) sequentialPanels.showFilesPage();
    if (drawer != null) drawer.openDrawer(Gravity.LEFT);
  }

  @Override
  public void onStoragePermissionRequested() {
    showPermissionsCenter();
  }

  private void showPermissionsCenterOnFirstRun() {
    ensureRequiredStorageAccess();
  }

  private void ensureRequiredStorageAccess() {
    if (browser == null || !browser.needsProjectFolderSelection()) {
      if (requiredStorageDialog != null && requiredStorageDialog.isShowing()) {
        requiredStorageDialog.dismiss();
      }
      return;
    }
    if (isFinishing() || (requiredStorageDialog != null && requiredStorageDialog.isShowing()))
      return;

    requiredStorageDialog =
        new AlertDialog.Builder(this)
            .setTitle("السماح بالوصول إلى ملفات المشاريع")
            .setMessage(
                "يحتاج Shima إلى صلاحية قراءة مجلد المشاريع حتى تظهر الملفات داخل المجلدات."
                    + " اختر مجلد AppProjects من منتقي النظام، أو امنح الوصول لجميع الملفات.")
            .setPositiveButton("اختيار مجلد المشاريع", (dialog, which) -> onSelectProjectFolder())
            .setNeutralButton("الوصول لجميع الملفات", (dialog, which) -> openAllFilesSettings())
            .create();
    requiredStorageDialog.setCancelable(false);
    requiredStorageDialog.setCanceledOnTouchOutside(false);
    requiredStorageDialog.show();
  }

  private void showPermissionsCenter() {
    String files =
        android.os.Build.VERSION.SDK_INT < 30 || android.os.Environment.isExternalStorageManager()
            ? "✓ الوصول لجميع الملفات"
            : "الوصول لجميع الملفات";
    String installs =
        android.os.Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls()
            ? "✓ تثبيت ملفات APK"
            : "تثبيت ملفات APK";
    String overlay =
        android.os.Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this)
            ? "✓ الظهور فوق التطبيقات"
            : "الظهور فوق التطبيقات";
    android.os.PowerManager power =
        (android.os.PowerManager) getSystemService(android.content.Context.POWER_SERVICE);
    String battery =
        android.os.Build.VERSION.SDK_INT < 23
                || (power != null && power.isIgnoringBatteryOptimizations(getPackageName()))
            ? "✓ استثناء تحسين البطارية"
            : "استثناء تحسين البطارية";
    String[] options = {
      "اختيار مجلد المشروع — موصى به",
      files,
      installs,
      overlay,
      battery,
      "صلاحيات التخزين القديمة",
      "معلومات الصلاحيات المتقدمة"
    };
    new AlertDialog.Builder(this)
        .setTitle("صلاحيات التطبيق")
        .setItems(
            options,
            (dialog, which) -> {
              switch (which) {
                case 0:
                  onSelectProjectFolder();
                  break;
                case 1:
                  openAllFilesSettings();
                  break;
                case 2:
                  openInstallPackagesSettings();
                  break;
                case 3:
                  openOverlaySettings();
                  break;
                case 4:
                  requestBatteryExemption();
                  break;
                case 5:
                  requestLegacyStoragePermissions();
                  break;
                default:
                  showMessage(
                      "الصلاحيات المتقدمة",
                      "INTERNET وACCESS_NETWORK_STATE وACCESS_WIFI_STATE وWAKE_LOCK تُمنح تلقائيًا"
                          + " عند التثبيت.\n\n"
                          + "READ_LOGS لا يُمنح لتطبيق عادي إلا عبر ADB أو كتطبيق نظام."
                          + " ACCESS_SUPERUSER لا يمنح صلاحية root؛ يتطلب جهازًا مروّتًا ومدير"
                          + " root. صلاحية C2DM تحتاج خدمة إشعارات مهيأة وليست نافذة إذن مستقلة.");
              }
            })
        .setNegativeButton("إغلاق", null)
        .show();
  }

  private void openAllFilesSettings() {
    if (android.os.Build.VERSION.SDK_INT < 30) {
      requestLegacyStoragePermissions();
      return;
    }
    try {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
              android.net.Uri.parse("package:" + getPackageName())));
    } catch (Exception error) {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
    }
  }

  private void openInstallPackagesSettings() {
    if (android.os.Build.VERSION.SDK_INT < 26) return;
    startActivity(
        new android.content.Intent(
            android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            android.net.Uri.parse("package:" + getPackageName())));
  }

  private void openOverlaySettings() {
    if (android.os.Build.VERSION.SDK_INT < 23) return;
    startActivity(
        new android.content.Intent(
            android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            android.net.Uri.parse("package:" + getPackageName())));
  }

  private void requestBatteryExemption() {
    if (android.os.Build.VERSION.SDK_INT < 23) return;
    try {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
              android.net.Uri.parse("package:" + getPackageName())));
    } catch (Exception error) {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
    }
  }

  private void requestLegacyStoragePermissions() {
    if (android.os.Build.VERSION.SDK_INT < 23) return;
    if (android.os.Build.VERSION.SDK_INT >= 33) {
      showMessage(
          "صلاحية التخزين",
          "في Android 13 وما بعده استخدم اختيار مجلد المشروع أو صلاحية الوصول لجميع الملفات.");
      return;
    }
    String[] permissions =
        android.os.Build.VERSION.SDK_INT <= 29
            ? new String[] {
              android.Manifest.permission.READ_EXTERNAL_STORAGE,
              android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            }
            : new String[] {android.Manifest.permission.READ_EXTERNAL_STORAGE};
    requestPermissions(permissions, 40);
  }

  @Override
  public void onSelectProjectFolder() {
    android.content.Intent intent =
        new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT_TREE);
    intent.addFlags(
        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
    startActivityForResult(intent, 77);
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == 88) {
      applySelectedTheme();
      return;
    }
    if (requestCode == 7801) {
      if (resultCode != RESULT_OK || data == null || editor == null) return;
      // تعديلات المصمم تعود نصًا كاملًا — تُحقن عبر موديل المحرك (قابلة للتراجع + حفظ تلقائي).
      String updated = data.getStringExtra("xml");
      if (updated != null) editor.replaceActiveContent(updated);
      int designerOffset = data.getIntExtra("goto", -1);
      if (designerOffset >= 0) editor.goToOffset(designerOffset);
      return;
    }
    if (requestCode == 77) {
      if (resultCode == RESULT_OK && data != null && data.getData() != null) {
        android.net.Uri uri = data.getData();
        int flags =
            data.getFlags()
                & (android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
          getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) {
        }
        if (browser != null) browser.openTree(uri);
      }
      getWindow().getDecorView().postDelayed(this::ensureRequiredStorageAccess, 350);
    }
  }

  @Override
  protected void onPause() {
    if (editor != null) editor.saveSession();
    super.onPause();
  }

  @Override
  protected void onStop() {
    // تقرير 03 — حفظ الجلسة والملفات المتسخة عند مغادرة الواجهة، وليس فقط عند الإغلاق.
    if (editor != null) editor.saveSession();
    super.onStop();
  }

  @Override
  public void onTrimMemory(int level) {
    super.onTrimMemory(level);
    // تقارير 01/03 — تحرير كاشات التوكنز/النتائج عند ضغط الذاكرة بدل الانتظار حتى OOM.
    if (editor != null) editor.trimMemoryCaches();
  }

  @Override
  protected void onResume() {
    super.onResume();
    applySelectedTheme();
    if (browser != null) browser.refresh();
    getWindow()
        .getDecorView()
        .postDelayed(
            () -> {
              ensureRequiredStorageAccess();
              // تقرير AIDE — بعد منح صلاحية التخزين نسترد التبويبات التي فشل فتحها عند الإقلاع.
              if (browser != null && !browser.needsProjectFolderSelection() && editor != null) {
                editor.retryLazySessionReferences();
              }
            },
            450);
  }

  private interface MenuAction {
    void run(View anchor);
  }

  private static final class IdeMenuEntry {
    final String title;
    final boolean submenu, highlighted;
    final String command;
    final MenuAction action;

    IdeMenuEntry(
        String title, boolean submenu, boolean highlighted, String command, MenuAction action) {
      this.title = title;
      this.submenu = submenu;
      this.highlighted = highlighted;
      this.command = command;
      this.action = action;
    }
  }

  private IdeMenuEntry menu(int title, boolean submenu, String command, MenuAction action) {
    return new IdeMenuEntry(getString(title), submenu, false, command, action);
  }

  private IdeMenuEntry highlightedMenu(
      int title, boolean submenu, String command, MenuAction action) {
    return new IdeMenuEntry(getString(title), submenu, true, command, action);
  }

  /** عنصر قائمة يُبنى من كائن الأمر نفسه: العنوان الديناميكي والأهلية من الفهرس مباشرة. */
  private IdeMenuEntry commandEntry(String id) {
    CommandCenter.Command c = commands.get(id);
    return new IdeMenuEntry(c == null ? id : c.titleFor(this), false, false, id, null);
  }

  /** بند معطل دائمًا (بنود جافا الصرفة في سياق XML) — أهلية كاذبة عبر أمر غير موجود. */
  private IdeMenuEntry disabledEntry(String title) {
    return new IdeMenuEntry(title, false, false, "__disabled__", null);
  }

  /** القائمة الجذرية بنمط المرجع الحرفي (حالة بلا تحديد):
   *  Edit/Navigate Mode المتبدل، View…، GoTo، Save، More…. */
  void showIdeRootMenu(View anchor) {
    if (anchor == null) return;
    boolean keyboardShown = editingToolbar;
    showIdeMenu(
        anchor,
        Arrays.asList(
            new IdeMenuEntry(
                keyboardShown ? "وضع التنقل" : "وضع التحرير",
                false,
                false,
                null,
                a -> toggleEditNavigateMode()),
            menu(R.string.menu_view, true, null, this::showIdeViewMenu),
            commandEntry("goto_element"),
            commandEntry("save"),
            menu(R.string.menu_more, true, null, this::showIdeMoreMenu)));
  }

  /** عرض… بنمط المرجع: الأقسام الخمسة + قائمة الملفات المفتوحة. */
  private void showIdeViewMenu(View anchor) {
    showIdeMenu(
        anchor,
        Arrays.asList(
            highlightedMenu(R.string.menu_back, false, null, this::showIdeRootMenu),
            commandEntry("files"),
            commandEntry("show_errors"),
            commandEntry("show_search_results"),
            commandEntry("show_debugger"),
            commandEntry("show_logcat"),
            new IdeMenuEntry("قائمة الملفات المفتوحة", false, false, null,
                a -> showOpenFilesDialog())));
  }

  private void showIdeMoreMenu(View anchor) {
    showIdeMenu(
        anchor,
        Arrays.asList(
            highlightedMenu(R.string.menu_back, false, null, this::showIdeRootMenu),
            menu(R.string.menu_find, true, null, this::showIdeFindMenu),
            new IdeMenuEntry("إعادة التشكيل…", true, false, null, this::showIdeRefactorMenu),
            menu(R.string.menu_code, true, null, this::showIdeCodeMenu),
            new IdeMenuEntry("التنسيق…", true, false, null, this::showIdeFormatMenu),
            menu(R.string.menu_project, true, null, this::showIdeProjectMenu),
            menu(R.string.menu_tools, true, null, this::showIdeToolsMenu),
            menu(R.string.menu_settings, false, "settings", null),
            menu(R.string.menu_exit, false, null, a -> confirmExit())));
  }

  /** بحث… بنمط المرجع: استخدامات/ملف/مشروع/سطر/توثيق. */
  private void showIdeFindMenu(View anchor) {
    showIdeMenu(
        anchor,
        Arrays.asList(
            highlightedMenu(R.string.menu_back, false, null, this::showIdeMoreMenu),
            commandEntry("find_usages"),
            commandEntry("find"),
            commandEntry("replace"),
            commandEntry("show_search_results"),
            commandEntry("goto_line"),
            new IdeMenuEntry("التوثيق Documentation", false, false, null,
                a -> openDocumentation())));
  }

  /** إعادة التشكيل… — بنود جافا الصرفة معطلة في XML كما في المرجع. */
  private void showIdeRefactorMenu(View anchor) {
    showIdeMenu(
        anchor,
        Arrays.asList(
            highlightedMenu(R.string.menu_back, false, null, this::showIdeMoreMenu),
            disabledEntry("إعادة تسمية Rename"),
            disabledEntry("تضمين المتغير Inline"),
            disabledEntry("استخلاص متغير Introduce"),
            disabledEntry("استخلاص دالة Extract")));
  }

  /** التنسيق… بنمط المرجع: التنفيذ الفعلي للتنسيق وبندا النمط معطلان. */
  private void showIdeFormatMenu(View anchor) {
    showIdeMenu(
        anchor,
        Arrays.asList(
            highlightedMenu(R.string.menu_back, false, null, this::showIdeMoreMenu),
            commandEntry("format"),
            disabledEntry("تعلّم نمط الشيفرة"),
            disabledEntry("إعداد نمط الشيفرة")));
  }

  // كل القوائم الفرعية تُبنى من سياقات الفهرس نفسه — مصدر واحد للأوامر كما في سجل المرجع.
  /** الشيفرة… بنود المرجع الثمانية — بنود جافا الصرفة معطلة في XML. */
  private void showIdeCodeMenu(View anchor) {
    showIdeMenu(
        anchor,
        Arrays.asList(
            highlightedMenu(R.string.menu_back, false, null, this::showIdeMoreMenu),
            disabledEntry("تنظيم الاستيرادات"),
            disabledEntry("إحاطة بـ try-catch"),
            new IdeMenuEntry("تعليق الشيفرة", false, false, null,
                a -> { if (editor != null) editor.commentLines(); }),
            new IdeMenuEntry("إلغاء تعليق الشيفرة", false, false, null,
                a -> { if (editor != null) editor.uncommentLines(); }),
            disabledEntry("إنشاء Setters/Getters"),
            disabledEntry("إنشاء Constructor"),
            disabledEntry("استخراج الموارد"),
            commandEntry("replace")));
  }

  /** المشروع بنود المرجع: إعادة بناء/متغيرات البناء/نشر/إغلاق المشروع. */
  private void showIdeProjectMenu(View anchor) {
    showIdeMenu(
        anchor,
        Arrays.asList(
            highlightedMenu(R.string.menu_back, false, null, this::showIdeMoreMenu),
            commandEntry("build_debug"),
            disabledEntry("متغيرات البناء"),
            commandEntry("build_release"),
            new IdeMenuEntry("إغلاق المشروع", false, false, null,
                a -> closeCurrentProject())));
  }

  private void showIdeGitMenu(View anchor) {
    showCatalogueMenu(anchor, "git");
  }

  private void showIdeToolsMenu(View anchor) {
    ArrayList<IdeMenuEntry> items = new ArrayList<>();
    items.add(highlightedMenu(R.string.menu_back, false, null, this::showIdeMoreMenu));
    for (CommandCenter.Command c : commands.inMenu("tools")) items.add(commandEntry(c.id));
    items.add(new IdeMenuEntry("Git", true, false, null, this::showIdeGitMenu));
    showIdeMenu(anchor, items);
  }

  private void showCatalogueMenu(View anchor, String menuId) {
    ArrayList<IdeMenuEntry> items = new ArrayList<>();
    items.add(highlightedMenu(R.string.menu_back, false, null, this::showIdeMoreMenu));
    for (CommandCenter.Command c : commands.inMenu(menuId)) items.add(commandEntry(c.id));
    showIdeMenu(anchor, items);
  }

  private void showIdeMenu(View anchor, List<IdeMenuEntry> items) {
    if (anchor == null) return;
    if (ideMenuWindow != null) ideMenuWindow.dismiss();
    LinearLayout container =
        (LinearLayout) getLayoutInflater().inflate(R.layout.ide_overflow_menu, null, false);
    for (IdeMenuEntry entry : items) {
      View row = getLayoutInflater().inflate(R.layout.ide_overflow_entry, container, false);
      TextView title = row.findViewById(R.id.ideOverflowEntryTitle);
      TextView arrow = row.findViewById(R.id.ideOverflowEntryArrow);
      title.setText(entry.title);
      if (entry.highlighted) title.setTextColor(Color.rgb(41, 182, 246));
      arrow.setVisibility(entry.submenu ? View.VISIBLE : View.GONE);
      boolean enabled = true;
      if (entry.command != null) {
        CommandCenter.Command command = commands.get(entry.command);
        enabled = command != null && command.enabled(this);
      }
      row.setEnabled(enabled);
      row.setAlpha(enabled ? 1f : 0.38f);
      row.setOnClickListener(
          v -> {
            if (!v.isEnabled()) return;
            ideMenuWindow.dismiss();
            if (entry.command != null) dispatch(entry.command);
            else if (entry.action != null) anchor.post(() -> entry.action.run(anchor));
          });
      container.addView(row);
    }
    // عرض يلائم المحتوى كما في المرجع — لا يشغل نصف الشاشة (طلب المستخدم مع لقطات القائمة).
    ideMenuWindow = new PopupWindow(container, dp(280), ViewGroup.LayoutParams.WRAP_CONTENT, true);
    ideMenuWindow.setBackgroundDrawable(new ColorDrawable(Color.rgb(48, 48, 48)));
    ideMenuWindow.setOutsideTouchable(true);
    ideMenuWindow.setElevation(dp(10));
    ideMenuWindow.setAnimationStyle(android.R.style.Animation_Dialog);
    int x = -dp(280) + anchor.getWidth();
    ideMenuWindow.showAsDropDown(anchor, x, -dp(4));
  }

  /** بند المرجع المتبدل: وضع التحرير يفتح كيبورد المحرر، ووضع التنقل يخفيه. */
  private void toggleEditNavigateMode() {
    if (editor == null) return;
    if (editingToolbar) {
      View focused = getCurrentFocus();
      android.view.inputmethod.InputMethodManager imm =
          (android.view.inputmethod.InputMethodManager)
              getSystemService(INPUT_METHOD_SERVICE);
      if (imm != null && focused != null)
        imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
    } else if (!editor.beginEditingSession()) {
      openFilesBrowser();
    }
  }

  /** «قائمة الملفات المفتوحة» المرجعية: اختيار تبويب يفعّله مباشرة. */
  private void showOpenFilesDialog() {
    if (editor == null) return;
    final List<String> names = editor.openFileNames();
    if (names.isEmpty()) {
      Toast.makeText(this, "لا ملفات مفتوحة", Toast.LENGTH_SHORT).show();
      return;
    }
    new AlertDialog.Builder(this)
        .setTitle("الملفات المفتوحة")
        .setItems(names.toArray(new String[0]), (d, w) -> editor.showOpenFile(names.get(w)))
        .setNegativeButton("إغلاق", null)
        .show();
  }

  /** التوثيق: فتح وثائق أندرويد للرمز تحت المؤشر (أو الصفحة المرجعية عامة). */
  private void openDocumentation() {
    String symbol = editor == null ? "" : editor.selectedOrCursorWord();
    String url =
        symbol == null || symbol.isEmpty()
            ? "https://developer.android.com/reference"
            : "https://developer.android.com/s/results?q=" + android.net.Uri.encode(symbol);
    try {
      startActivity(
          new android.content.Intent(
              android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)));
    } catch (Exception noBrowser) {
      Toast.makeText(this, "لا يوجد متصفح لفتح التوثيق", Toast.LENGTH_SHORT).show();
    }
  }

  /** إغلاق المشروع كما في المرجع: إغلاق التبويبات ومسح الجلسة والعودة لمجلد المشاريع. */
  private void closeCurrentProject() {
    if (editor != null) editor.closeAll();
    if (session != null) session.clear();
    showNoProject();
    if (browser != null) browser.showProjectsHome();
    if (drawer != null) drawer.openDrawer(Gravity.LEFT);
  }

  private void confirmExit() {
    new AlertDialog.Builder(this)
        .setTitle(R.string.menu_exit_title)
        .setMessage(R.string.menu_exit_message)
        .setNegativeButton(R.string.action_no, null)
        .setPositiveButton(R.string.action_yes, (dialog, which) -> finish())
        .show();
  }

  void showCommands() {
    final List<String> groups = commands.groups();
    new AlertDialog.Builder(this)
        .setTitle("الأوامر")
        .setItems(groups.toArray(new String[0]), (d, w) -> showCommandGroup(groups.get(w)))
        .show();
  }

  void showCommandGroup(String group) {
    final List<CommandCenter.Command> list = commands.inGroup(group);
    String[] labels = new String[list.size()];
    for (int i = 0; i < list.size(); i++) {
      CommandCenter.Command c = list.get(i);
      labels[i] = (c.enabled(this) ? "" : "🔒  ") + c.titleFor(this);
    }
    new AlertDialog.Builder(this)
        .setTitle(group)
        .setItems(labels, (d, w) -> dispatch(list.get(w).id))
        .setNegativeButton("رجوع", (d, w) -> showCommands())
        .show();
  }

  void dispatch(String id) {
    CommandCenter.Command c = commands.get(id);
    if (!commands.dispatch(id, this)) {
      String reason;
      if (c == null) reason = "أمر غير معروف";
      else if (c.needsProject && !hasProject()) reason = "افتح مشروعًا أولًا";
      else if (c.needsEditor && !hasEditor()) reason = "افتح ملفًا في المحرر أولًا";
      else reason = "الأمر غير متاح الآن";
      Toast.makeText(this, reason, Toast.LENGTH_SHORT).show();
    }
  }

  /** Opens a bounded, debounced project-symbol search without doing source I/O on the UI thread. */
  /** آخر استعلام GoTo — يُحفظ بين الفتحات ويُستعاد محددًا بالكامل كما في المرجع. */
  private static String lastGotoQuery = "";

  /** حد عرض نتائج GoTo كما في المرجع: فوق الحد تُعرض رسالة «اكتب المزيد» بدل القائمة. */
  private static final int GOTO_RESULT_LIMIT = 50;

  void promptGotoElement() {
    View view = getLayoutInflater().inflate(R.layout.gotobrowser, null);
    EditText queryBox = view.findViewById(R.id.gotobrowserSearchBox);
    Switch includeSystem = view.findViewById(R.id.gotobrowserSwitch);
    ListView resultList = view.findViewById(R.id.gotobrowserSymbolList);
    TextView message = view.findViewById(R.id.gotobrowserMessage);
    ProgressBar progress = view.findViewById(R.id.gotobrowserProgress);
    if (queryBox == null || resultList == null || message == null || progress == null) return;
    if (browser != null && editor != null && editor.hasOpenFile())
      browser.setActiveEditorSnapshot(
          editor.getActiveFile(), editor.getTextContent(), editor.activeFileReference());
    includeSystem.setTextOn("كل العناصر");
    includeSystem.setTextOff("المشروع");
    includeSystem.setChecked(false);
    final ArrayList<ProjectSymbolIndex.DefinitionTarget> targets = new ArrayList<>();
    // صف النتيجة كما في المرجع: أيقونة النوع + الاسم (مع «()» للدوال) + الحاوية كسطر ثانٍ.
    ArrayAdapter<ProjectSymbolIndex.DefinitionTarget> adapter =
        new ArrayAdapter<ProjectSymbolIndex.DefinitionTarget>(this, 0, targets) {
          @Override
          public View getView(int position, View convertView, android.view.ViewGroup parent) {
            View row = convertView != null
                ? convertView
                : getLayoutInflater().inflate(R.layout.gotobrowser_entry, parent, false);
            ProjectSymbolIndex.DefinitionTarget target =
                position < targets.size() ? targets.get(position) : null;
            android.widget.ImageView icon = row.findViewById(R.id.gotobrowserEntryImage);
            TextView name = row.findViewById(R.id.gotobrowserEntryName);
            TextView container = row.findViewById(R.id.gotobrowserEntryContainerName);
            View help = row.findViewById(R.id.gotobrowserHelpButton);
            if (help != null) help.setVisibility(View.GONE);
            if (target == null) return row;
            if (icon != null) icon.setImageResource(gotoEntryIcon(target));
            if (name != null)
              name.setText(
                  target.kind == ProjectSymbolIndex.DefinitionTarget.KIND_METHOD
                      ? target.symbol + "()"
                      : target.symbol);
            if (container != null) container.setText(resultLocation(target));
            return row;
          }
        };
    resultList.setAdapter(adapter);
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle("الانتقال إلى عنصر")
            .setView(view)
            .setNegativeButton("إغلاق", null)
            .create();
    final int[] generation = {0};
    final Runnable[] pending = {null};
    android.text.TextWatcher watcher = new android.text.TextWatcher() {
      @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
      @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
        final int request = ++generation[0];
        if (pending[0] != null) queryBox.removeCallbacks(pending[0]);
        targets.clear();
        adapter.notifyDataSetChanged();
        String text = s == null ? "" : s.toString().trim();
        message.setText(text.isEmpty() ? "اكتب اسم كلاس أو دالة أو حقل" : "جار البحث…");
        progress.setVisibility(text.isEmpty() ? View.GONE : View.VISIBLE);
        if (text.isEmpty()) return;
        final boolean showSystem = includeSystem.isChecked();
        pending[0] = () -> browser.searchSymbolsAsync(text, showSystem, (found, cancelled) -> {
          if (request != generation[0] || !dialog.isShowing()) return;
          progress.setVisibility(View.GONE);
          targets.clear();
          if (found != null && found.size() > GOTO_RESULT_LIMIT) {
            // سلوك المرجع عند تجاوز الحد: رسالة «أكثر من N مطابقة» بلا قائمة.
            message.setText(
                "أكثر من " + GOTO_RESULT_LIMIT + " عنصر مطابق — اكتب حروفًا أكثر للتضييق");
          } else {
            if (found != null) targets.addAll(found);
            message.setText(targets.isEmpty() ? "لا توجد عناصر مطابقة" : "اختر عنصرًا للفتح");
          }
          adapter.notifyDataSetChanged();
        });
        // Keep only a tiny frame budget: the search worker is cancellable and the in-memory
        // snapshot makes results appear while the user is still typing.
        queryBox.postDelayed(pending[0], 35);
      }
      @Override public void afterTextChanged(android.text.Editable s) {}
    };
    queryBox.addTextChangedListener(watcher);
    includeSystem.setOnCheckedChangeListener((button, checked) -> {
      if (queryBox.getText().length() > 0) queryBox.setText(queryBox.getText());
    });
    resultList.setOnItemClickListener((parent, row, position, id) -> {
      if (position < 0 || position >= targets.size()) return;
      ProjectSymbolIndex.DefinitionTarget target = targets.get(position);
      dialog.dismiss();
      openDefinition(target);
    });
    dialog.setOnDismissListener(d -> {
      // حفظ الاستعلام بين الفتحات — نفس حقل المرجع الساكن المحفوظ عند الإغلاق.
      lastGotoQuery = queryBox.getText() == null ? "" : queryBox.getText().toString();
      generation[0]++;
      if (pending[0] != null) queryBox.removeCallbacks(pending[0]);
      browser.cancelProjectSearch();
    });
    dialog.setOnShowListener(d -> {
      queryBox.requestFocus();
      dialog.getWindow().setSoftInputMode(
          android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    });
    // استعادة آخر استعلام + تحديد كامل + بحث فوري عند الفتح — كما يفعل المرجع في onCreate.
    if (!lastGotoQuery.isEmpty()) queryBox.setText(lastGotoQuery);
    queryBox.selectAll();
    dialog.show();
  }

  /** أيقونة صف GoTo حسب نوع الرمز — كتمييز المرجع بين كلاس/دالة/حقل. */
  private int gotoEntryIcon(ProjectSymbolIndex.DefinitionTarget target) {
    if (target == null) return R.drawable.completion_variable;
    switch (target.kind) {
      case ProjectSymbolIndex.DefinitionTarget.KIND_CLASS:
        return R.drawable.completion_class;
      case ProjectSymbolIndex.DefinitionTarget.KIND_METHOD:
        return R.drawable.completion_method;
      case ProjectSymbolIndex.DefinitionTarget.KIND_FIELD:
        return R.drawable.completion_variable;
      default:
        return target.symbol != null && target.symbol.equals(target.className)
            ? R.drawable.completion_class
            : R.drawable.completion_variable;
    }
  }

  /** السطر الثاني لصف GoTo: الحاوية (الكلاس) ثم الملف — كما يعرض المرجع اسم الحاوية. */
  private String resultLocation(ProjectSymbolIndex.DefinitionTarget target) {
    if (target == null) return "";
    String file = target.fileName == null ? "" : target.fileName;
    boolean ownClass = target.className == null
        || target.className.isEmpty()
        || target.className.equals(target.symbol);
    return ownClass ? file : target.className + " — " + file;
  }

  void showDesigner() {
    View v = getLayoutInflater().inflate(R.layout.designer, null);
    new AlertDialog.Builder(this)
        .setTitle("المصمم المرئي")
        .setView(v)
        .setNegativeButton("إغلاق", null)
        .show();
  }

  void runProject() {
    runBuild("assembleDebug", "تشغيل المشروع");
  }

  void runBuild(String task, String title) {
    File root = session == null ? null : session.directory();
    if (root == null || !root.isDirectory()) {
      showMessage(
          "البناء",
          "هذا المشروع مفتوح عبر مزود مستندات لا يكشف مسارًا تنفيذيًا. التصفح والتحرير متاحان، لكن"
              + " تشغيل Gradle يحتاج مجلدًا محليًا مباشرًا.");
      return;
    }
    File wrapper = new File(root, "gradlew");
    if (!wrapper.isFile()) {
      showMessage("البناء", "لم يتم العثور على gradlew في:\n" + root.getAbsolutePath());
      return;
    }
    showPanel(SequentialPanelHost.Panel.BUILD);
    if (sequentialPanels != null)
      sequentialPanels.setBuildOutput("$ sh gradlew " + task + " --no-daemon\n");
    View view = getLayoutInflater().inflate(R.layout.outputconsole, null);
    TextView output = view.findViewById(R.id.outputConsole);
    output.setTextColor(Color.LTGRAY);
    output.setTextSize(13);
    output.setPadding(dp(12), dp(10), dp(12), dp(10));
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton("إيقاف", null)
            .create();
    dialog.setOnShowListener(
        x -> {
          dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> shell.cancel());
          Map<String, String> env = new HashMap<>();
          env.put("SHIMA_CURRENT_PROJECT", root.getAbsolutePath());
          shell.run(
              root,
              Arrays.asList("sh", "gradlew", task, "--no-daemon"),
              env,
              new ShellCommandRunner.Listener() {
                public void onStart(String c) {
                  output.setText("$ " + c + "\n\n");
                }

                public void onLine(String line) {
                  output.append(line + "\n");
                  if (sequentialPanels != null) sequentialPanels.appendBuildOutput(line);
                }

                public void onFinish(int code, boolean cancelled) {
                  String summary = cancelled ? "تم إيقاف العملية." : "انتهت العملية برمز " + code;
                  output.append("\n" + summary);
                  if (sequentialPanels != null) sequentialPanels.appendBuildOutput(summary);
                  dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setText("إغلاق");
                  dialog
                      .getButton(AlertDialog.BUTTON_NEGATIVE)
                      .setOnClickListener(v -> dialog.dismiss());
                }
              });
        });
    dialog.setOnDismissListener(x -> shell.cancel());
    dialog.show();
  }

  void runShell(String command, String title) {
    File root = session == null ? null : session.directory();
    if (root == null) {
      showMessage(title, "الأمر يحتاج مشروعًا ذا مسار محلي مباشر.");
      return;
    }
    View view = getLayoutInflater().inflate(R.layout.outputconsole, null);
    TextView output = view.findViewById(R.id.outputConsole);
    output.setTextColor(Color.LTGRAY);
    output.setTextSize(13);
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton("إيقاف", null)
            .create();
    dialog.setOnShowListener(
        x -> {
          dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> shell.cancel());
          Map<String, String> env = new HashMap<>();
          env.put("SHIMA_CURRENT_PROJECT", root.getAbsolutePath());
          shell.run(
              root,
              Arrays.asList("sh", "-c", command),
              env,
              new ShellCommandRunner.Listener() {
                public void onStart(String c) {
                  output.setText("$ " + command + "\n\n");
                }

                public void onLine(String line) {
                  output.append(line + "\n");
                }

                public void onFinish(int code, boolean stopped) {
                  output.append(stopped ? "\nتم الإيقاف." : "\nرمز الخروج: " + code);
                  dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setText("إغلاق");
                  dialog
                      .getButton(AlertDialog.BUTTON_NEGATIVE)
                      .setOnClickListener(v -> dialog.dismiss());
                }
              });
        });
    dialog.setOnDismissListener(x -> shell.cancel());
    dialog.show();
  }

  void promptTerminal() {
    final EditText input = new EditText(this);
    input.setHint("مثال: ./gradlew tasks");
    input.setSingleLine(true);
    new AlertDialog.Builder(this)
        .setTitle("طرفية المشروع")
        .setView(input)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "تشغيل",
            (d, w) -> {
              String c = input.getText().toString().trim();
              if (!c.isEmpty()) runShell(c, "الطرفية");
            })
        .show();
  }

  void promptCommit() {
    final EditText input = new EditText(this);
    input.setHint("رسالة الالتزام");
    input.setSingleLine(true);
    new AlertDialog.Builder(this)
        .setTitle("Git: إنشاء التزام")
        .setView(input)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "التزام",
            (d, w) -> {
              String m = input.getText().toString().trim();
              if (!m.isEmpty()) runShell("git commit -m " + shellQuote(m), "Git");
            })
        .show();
  }

  String shellQuote(String value) {
    return "'" + value.replace("'", "'\\''") + "'";
  }

  void showMessage(String title, String text) {
    new AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(text)
        .setPositiveButton("حسنًا", null)
        .show();
  }

  @Override
  public boolean hasProject() {
    return projectOpen && session != null && session.isOpen();
  }

  @Override
  public boolean hasEditor() {
    return editor != null && editor.hasOpenFile();
  }

  @Override
  public boolean canUndo() {
    return hasEditor() && editor.canUndoEdit();
  }

  @Override
  public boolean canRedo() {
    return hasEditor() && editor.canRedoEdit();
  }

  @Override
  public boolean panelsShowing() {
    return drawer != null && drawer.isDrawerOpen(Gravity.LEFT);
  }

  @Override
  public void execute(String id) {
    switch (id) {
      case "run":
      case "build_debug":
        runBuild("assembleDebug", id.equals("run") ? "تشغيل المشروع" : "بناء نسخة التصحيح");
        break;
      case "build_release":
        runBuild("assembleRelease", "بناء نسخة الإصدار");
        break;
      case "clean":
        runBuild("clean", "تنظيف المشروع");
        break;
      case "terminal":
        promptTerminal();
        break;
      case "save":
        browser.saveOpenedFileAsync(
            editor.getActiveFile(),
            editor.getTextContent(),
            (saved, message) -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show());
        break;
      case "undo":
        editor.undoEdit();
        break;
      case "redo":
        editor.redoEdit();
        break;
      case "find":
        promptFind();
        break;
      case "replace":
        promptReplace();
        break;
      case "goto_line":
        promptGotoLine();
        break;
      case "goto_element":
        // GoTo كما في المصدر (GotoBrowserActivity): متصفح عناصر فوري مؤجل الإدخال ومقيد
        // النتائج — سريع وسلس. القفز من رمز محدد يبقى لأمر goto_definition وقائمة التحديد.
        promptGotoElement();
        break;
      case "format":
        editor.formatSource();
        Toast.makeText(this, "تم تنسيق المصدر", Toast.LENGTH_SHORT).show();
        break;
      case "comment":
        editor.toggleLineComment();
        break;
      case "select_all":
        editor.selectAllText();
        break;
      case "analyze":
        showDiagnostics();
        break;
      case "complete":
        showCompletions();
        break;
      case "find_usages":
        editor.requestUsageForCurrentSelection();
        break;
      case "goto_definition":
        editor.requestDefinitionForCurrentSelection();
        break;
      case "panels":
        // سلوك المرجع: عنصر اللوحات يتبدّل بين الإظهار والإخفاء حسب الحالة الراهنة.
        if (panelsShowing()) closeSequentialPanels();
        else showPanel(SequentialPanelHost.Panel.ERRORS);
        break;
      case "show_errors":
        showPanel(SequentialPanelHost.Panel.ERRORS);
        break;
      case "show_search_results":
        showPanel(SequentialPanelHost.Panel.SEARCH);
        break;
      case "show_build_output":
        showPanel(SequentialPanelHost.Panel.BUILD);
        break;
      case "show_debugger":
        showPanel(SequentialPanelHost.Panel.DEBUGGER);
        break;
      case "show_logcat":
        showPanel(SequentialPanelHost.Panel.LOGCAT);
        break;
      case "close_file":
        editor.closeCurrent();
        if (!editor.hasOpenFile()) {
          empty.setVisibility(View.VISIBLE);
          editor.setVisibility(View.GONE);
          if (masterButton != null) masterButton.setVisibility(View.GONE);
        }
        break;
      case "close_all":
        editor.closeAll();
        empty.setVisibility(View.VISIBLE);
        editor.setVisibility(View.GONE);
        if (masterButton != null) masterButton.setVisibility(View.GONE);
        break;
      case "files":
        openFilesBrowser();
        break;
      case "new_file":
        openFilesBrowser();
        browser.createFile();
        break;
      case "new_folder":
        openFilesBrowser();
        browser.createFolder();
        break;
      case "refresh":
        browser.refresh();
        break;
      case "git_status":
        runShell("git status --short --branch", "Git: الحالة");
        break;
      case "git_log":
        runShell("git log --oneline -n 20", "Git: السجل");
        break;
      case "git_add":
        runShell("git add -A && git status --short", "Git: إضافة التغييرات");
        break;
      case "git_commit":
        promptCommit();
        break;
      case "git_pull":
        runShell("git pull --ff-only", "Git: سحب");
        break;
      case "git_push":
        runShell("git push", "Git: رفع");
        break;
      case "theme":
        startActivityForResult(new android.content.Intent(this, ThemeActivity.class), 88);
        break;
      case "permissions":
        showPermissionsCenter();
        break;
      case "documentation":
        openDocumentation();
        break;
      case "settings":
        startActivity(new Intent(this, SettingsActivity.class));
        break;
      case "about":
        showMessage(
            "حول Shima IDE",
            "بيئة برمجة Android عربية. نظام الأوامر والبناء وGit مستقل وخفيف، ولا يحتوي على ملفات"
                + " المصدر المرجعية الخارجية.");
        break;
    }
  }

  void showDiagnostics() {
    showSequentialPanels(SequentialPanelHost.Panel.ERRORS);
    if (sequentialPanels != null)
      sequentialPanels.setErrors(
          editor == null ? Collections.emptyList() : editor.diagnostics(),
          editor == null ? "" : editor.getTextContent());
  }

  void showCompletions() {
    java.util.List<String> values = editor.completions();
    if (values.isEmpty()) {
      Toast.makeText(this, "لا توجد اقتراحات للكلمة الحالية", Toast.LENGTH_SHORT).show();
      return;
    }
    new AlertDialog.Builder(this)
        .setTitle("الإكمال التلقائي")
        .setItems(values.toArray(new String[0]), (d, w) -> editor.applyCompletion(values.get(w)))
        .setNegativeButton("إلغاء", null)
        .show();
  }

  void promptFind() {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    final EditText input = new EditText(this);
    input.setHint("النص المطلوب أو تعبير Regex");
    input.setSingleLine(true);
    final CheckBox project = new CheckBox(this);
    final CheckBox caseSensitive = new CheckBox(this);
    final CheckBox wholeWord = new CheckBox(this);
    final CheckBox regex = new CheckBox(this);
    project.setText("البحث في المشروع كاملًا");
    caseSensitive.setText("مطابقة حالة الأحرف");
    wholeWord.setText("كلمة كاملة فقط");
    regex.setText("تعبير منتظم Regex");
    box.addView(input);
    box.addView(project);
    box.addView(caseSensitive);
    box.addView(wholeWord);
    box.addView(regex);
    regex.setOnCheckedChangeListener((button, checked) -> {
      wholeWord.setEnabled(!checked);
      if (checked) wholeWord.setChecked(false);
    });
    new AlertDialog.Builder(this)
        .setTitle("بحث سريع واحترافي")
        .setMessage("يستخدم البحث الحرفي فهرسة مباشرة، ويمكن إيقاف البحث السابق تلقائيًا.")
        .setView(box)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "بحث",
            (d, w) -> {
              String text = input.getText().toString().trim();
              if (text.isEmpty()) {
                Toast.makeText(this, "أدخل نص البحث أولًا", Toast.LENGTH_SHORT).show();
                return;
              }
              ProjectSearchEngine.Query query =
                  new ProjectSearchEngine.Query(
                      text,
                      caseSensitive.isChecked(),
                      wholeWord.isChecked(),
                      regex.isChecked(),
                      ProjectSearchEngine.DEFAULT_MAX_RESULTS);
              if (project.isChecked()) {
                showSequentialPanels(SequentialPanelHost.Panel.SEARCH);
                sequentialPanels.setSearchStatus("جار البحث في ملفات المشروع…");
                sequentialPanels.setSearchResults(Collections.emptyList(), text);
                browser.searchProjectAsync(
                    query,
                    (results, filesScanned, cancelled) -> {
                      if (sequentialPanels == null) return;
                      sequentialPanels.setSearchResults(results, text);
                      sequentialPanels.setSearchStatus(
                          cancelled
                              ? "تم إيقاف البحث بعد فحص " + filesScanned + " ملفًا"
                              : "تم فحص " + filesScanned + " ملفًا — " + results.size() + " نتيجة");
                    });
              } else {
                boolean found = editor.findText(
                    text,
                    caseSensitive.isChecked(),
                    wholeWord.isChecked(),
                    regex.isChecked(),
                    true);
                Toast.makeText(
                        this,
                        found ? "تم الانتقال إلى النتيجة التالية" : "لم يتم العثور على النص",
                        Toast.LENGTH_SHORT)
                    .show();
              }
            })
        .show();
  }

  void promptReplace() {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    final EditText from = new EditText(this), to = new EditText(this);
    from.setHint("البحث عن");
    to.setHint("الاستبدال بـ");
    final CheckBox caseSensitive = new CheckBox(this);
    final CheckBox wholeWord = new CheckBox(this);
    final CheckBox regex = new CheckBox(this);
    caseSensitive.setText("مطابقة حالة الأحرف");
    wholeWord.setText("كلمة كاملة فقط");
    regex.setText("تعبير منتظم Regex");
    regex.setOnCheckedChangeListener((button, checked) -> {
      wholeWord.setEnabled(!checked);
      if (checked) wholeWord.setChecked(false);
    });
    box.addView(from);
    box.addView(to);
    box.addView(caseSensitive);
    box.addView(wholeWord);
    box.addView(regex);
    new AlertDialog.Builder(this)
        .setTitle("بحث واستبدال")
        .setView(box)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "استبدال الكل",
            (d, w) -> editor.replaceAllAsync(
                from.getText().toString(),
                to.getText().toString(),
                caseSensitive.isChecked(),
                wholeWord.isChecked(),
                regex.isChecked(),
                count -> Toast.makeText(
                    this, "تم استبدال " + count + " موضع", Toast.LENGTH_SHORT).show()))
        .show();
  }

  void promptGotoLine() {
    final EditText input = new EditText(this);
    input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
    input.setHint("رقم السطر");
    new AlertDialog.Builder(this)
        .setTitle("انتقال إلى سطر")
        .setView(input)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "انتقال",
            (d, w) -> {
              try {
                if (!editor.goToLine(Integer.parseInt(input.getText().toString())))
                  Toast.makeText(this, "رقم السطر خارج الملف", Toast.LENGTH_SHORT).show();
              } catch (Exception e) {
                Toast.makeText(this, "أدخل رقمًا صحيحًا", Toast.LENGTH_SHORT).show();
              }
            })
        .show();
  }

  /** ملف التبويب النشط تخطيط XML (داخل res/layout*) — شرط ظهور زر معاينة التصميم. */
  boolean activeLayoutXml() {
    if (editor == null || !projectOpen) return false;
    // اسم التبويب قصير — الموقع الحقيقي في المرجع المستقر (مسار كامل أو SAF URI مرمّز).
    String candidate = editor.getActiveFileReference();
    if (candidate == null || candidate.isEmpty()) candidate = editor.getActiveFile();
    if (candidate == null) return false;
    if (candidate.startsWith("content:")) candidate = android.net.Uri.decode(candidate);
    String normalized = candidate.replace('\\', '/').toLowerCase(java.util.Locale.US);
    if (!normalized.endsWith(".xml")) return false;
    int slash = normalized.lastIndexOf('/');
    if (slash <= 0) return false;
    int parentSlash = normalized.lastIndexOf('/', slash - 1);
    String parent = normalized.substring(parentSlash + 1, slash);
    return parent.startsWith("layout");
  }

  /** فتح المصمم على النص الحي للتبويب النشط — المعاينة تعكس آخر ما كتبته ولو غير محفوظ. */
  void openDesigner() {
    if (editor == null) return;
    android.content.Intent intent = new android.content.Intent(this, DesignerActivity.class);
    intent.putExtra("xml", editor.getTextContent());
    String reference = editor.getActiveFileReference();
    intent.putExtra("file", reference.isEmpty() ? editor.getActiveFile() : reference);
    startActivityForResult(intent, 7801);
  }


  /** إعادة بناء الشريط فقط عند انقلاب أهلية التراجع/الإعادة فعلًا — لا عمل زائدًا بكل حرف. */
  void refreshEditingToolbarState() {
    if (editor == null) return;
    if (!editingToolbar) {
      // خارج وضع الكتابة: تبديل التبويب قد يبدّل زر القلم/معاينة التصميم.
      invalidateOptionsMenu();
      return;
    }
    boolean canUndo = editor.canUndoEdit();
    boolean canRedo = editor.canRedoEdit();
    if (canUndo != lastCanUndo || canRedo != lastCanRedo) invalidateOptionsMenu();
  }

  void hideMasterButtonWithKeyboard(final View masterButton) {
    final View root = getWindow().getDecorView();
    final int[] largestVisibleHeight = {0};
    root.getViewTreeObserver()
        .addOnGlobalLayoutListener(
            () -> {
              android.graphics.Rect frame = new android.graphics.Rect();
              root.getWindowVisibleDisplayFrame(frame);
              int currentHeight = frame.height();
              if (currentHeight > largestVisibleHeight[0]) largestVisibleHeight[0] = currentHeight;
              int difference = largestVisibleHeight[0] - currentHeight;
              boolean keyboardShown = difference > Math.max(dp(170), largestVisibleHeight[0] / 6);
              boolean editorActive =
                  editor != null && editor.hasOpenFile() && editor.getVisibility() == View.VISIBLE;
              int expected = keyboardShown || !editorActive ? View.GONE : View.VISIBLE;
              if (masterButton.getVisibility() != expected) masterButton.setVisibility(expected);
              // شريط وضع التحرير (دلالة المرجع): يتبدل مع ظهور كيبورد المحرر وإخفائه.
              boolean editingNow = keyboardShown && editorActive;
              if (editingNow != editingToolbar) {
                editingToolbar = editingNow;
                invalidateOptionsMenu();
              }
            });
  }

  void showStartupError(Throwable error) {
    ActionBar bar = getActionBar();
    if (bar != null) bar.hide();
    LinearLayout page = new LinearLayout(this);
    page.setOrientation(LinearLayout.VERTICAL);
    page.setPadding(dp(20), dp(24), dp(20), dp(16));
    page.setBackgroundColor(Color.rgb(25, 25, 25));
    TextView title = new TextView(this);
    title.setText("خطأ في تحميل واجهة البرمجة");
    title.setTextColor(Color.WHITE);
    title.setTextSize(22);
    page.addView(title);
    TextView message = new TextView(this);
    message.setText(
        "تم احتواء الخطأ ولن يتم إغلاق التطبيق. يمكنك عرض التفاصيل أو متابعة العمل بالوضع الآمن.");
    message.setTextColor(Color.LTGRAY);
    message.setPadding(0, dp(10), 0, dp(12));
    page.addView(message);
    TextView log = new TextView(this);
    log.setText(CrashStore.read(this));
    log.setTextColor(Color.rgb(255, 180, 180));
    log.setTextSize(11);
    log.setTypeface(android.graphics.Typeface.MONOSPACE);
    log.setTextIsSelectable(true);
    ScrollView scroll = new ScrollView(this);
    scroll.addView(log);
    page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    Button safe = new Button(this);
    safe.setText("فتح الوضع الآمن");
    safe.setOnClickListener(v -> showSafeMode());
    page.addView(safe);
    Button retry = new Button(this);
    retry.setText("إعادة المحاولة");
    retry.setOnClickListener(v -> recreate());
    page.addView(retry);
    setContentView(page);
  }

  void showSafeMode() {
    ActionBar bar = getActionBar();
    if (bar != null) bar.hide();
    LinearLayout page = new LinearLayout(this);
    page.setOrientation(LinearLayout.VERTICAL);
    page.setGravity(Gravity.CENTER_HORIZONTAL);
    page.setPadding(dp(24), dp(42), dp(24), dp(20));
    page.setBackgroundColor(Color.rgb(25, 25, 25));
    ImageView logo = new ImageView(this);
    logo.setImageResource(R.drawable.ic_launcher);
    page.addView(logo, new LinearLayout.LayoutParams(dp(80), dp(80)));
    TextView title = new TextView(this);
    title.setText("Almk AIDE — الوضع الآمن");
    title.setTextColor(Color.WHITE);
    title.setTextSize(22);
    title.setGravity(Gravity.CENTER);
    title.setPadding(0, dp(18), 0, dp(8));
    page.addView(title);
    TextView note = new TextView(this);
    note.setText(
        "تم تعطيل الواجهات المخصصة مؤقتًا. ملفات المشروع لم تُحذف ويمكن إعادة محاولة فتح الواجهة"
            + " الكاملة.");
    note.setTextColor(Color.LTGRAY);
    note.setTextSize(15);
    note.setGravity(Gravity.CENTER);
    page.addView(note, new LinearLayout.LayoutParams(-1, 0, 1));
    Button retry = new Button(this);
    retry.setText("فتح الواجهة الكاملة");
    retry.setOnClickListener(
        v -> {
          getIntent().removeExtra("safe_mode");
          recreate();
        });
    page.addView(retry, new LinearLayout.LayoutParams(-1, dp(52)));
    Button report = new Button(this);
    report.setText("عرض آخر خطأ");
    report.setOnClickListener(
        v -> startActivity(new android.content.Intent(this, RecoveryActivity.class)));
    page.addView(report, new LinearLayout.LayoutParams(-1, dp(52)));
    setContentView(page);
  }

  int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }

  @Override
  public void onBackPressed() {
    if (drawer != null && drawer.isDrawerOpen(Gravity.LEFT)) {
      drawer.closeDrawers();
      return;
    }
    // الانتقال لعنصر ثم «عودة» يعيد للكلاس/الموضع السابق عبر سجل التنقل.
    if (editor != null && editor.navigateBack()) return;
    // مع مشروع مفتوح: «عودة» تعرض قائمة الملفات/الكلاسات ولا تُخرج المشروع لشاشة الفراغ.
    if (projectOpen) {
      if (drawer != null) drawer.openDrawer(Gravity.LEFT);
      return;
    }
    super.onBackPressed();
  }
}
