package com.shima.performance;

/**
 * Incremental, thread-safe mirror of the editor text.
 *
 * <p>The UI thread applies only the changed range. Worker threads can then copy a stable immutable
 * String without calling EditText.getText().toString() during keyboard input. This keeps the main
 * thread focused on drawing and input while language services analyze the same document version.
 */
public final class EditorTextSnapshot {
  private final StringBuilder buffer = new StringBuilder();
  private boolean initialized;
  private int version;

  /** Applies a TextWatcher change using the current text and the old range. */
  public synchronized void applyChange(
      CharSequence current, int start, int before, int count) {
    if (current == null
        || start < 0
        || before < 0
        || count < 0
        || !initialized
        || start > buffer.length()
        || start + before > buffer.length()) {
      resetLocked(current);
      return;
    }
    String inserted = current.subSequence(start, Math.min(current.length(), start + count)).toString();
    buffer.replace(start, start + before, inserted);
    if (buffer.length() != current.length()) {
      resetLocked(current);
      return;
    }
    version++;
  }

  /** Replaces the mirror after a non-TextWatcher source load. */
  public synchronized void reset(CharSequence current) {
    resetLocked(current);
  }

  public synchronized int version() {
    return version;
  }

  /** Creates a stable copy. Call this only from a worker thread for large documents. */
  public synchronized Value copy() {
    return new Value(buffer.toString(), version);
  }

  /**
   * Windowed copy (منهج AIDE: المُلوّن يقرأ ما يراه فقط): نسخة مستقرة لمقطع واحد من
   * المستند دون نسخه كله — أمان الخيط نفسه مع O(مقطع) بدل O(مستند) لكل دورة تحليل.
   */
  public synchronized Value copyRange(int start, int end) {
    int from = Math.max(0, Math.min(start, buffer.length()));
    int to = Math.max(from, Math.min(end, buffer.length()));
    return new Value(buffer.substring(from, to), version);
  }

  private void resetLocked(CharSequence current) {
    buffer.setLength(0);
    if (current != null) buffer.append(current);
    initialized = true;
    version++;
  }

  public static final class Value {
    public final String text;
    public final int version;

    private Value(String text, int version) {
      this.text = text;
      this.version = version;
    }
  }
}
