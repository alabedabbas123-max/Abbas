package com.google.zxing.common.detector;

import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitMatrix;

public final class WhiteRectangleDetector {
    private static final int CORR = 1;
    private static final int INIT_SIZE = 10;
    private final int downInit;
    private final int height;
    private final BitMatrix image;
    private final int leftInit;
    private final int rightInit;
    private final int upInit;
    private final int width;

    public WhiteRectangleDetector(BitMatrix bitMatrix) {
        this(bitMatrix, 10, bitMatrix.getWidth() / 2, bitMatrix.getHeight() / 2);
    }

    public WhiteRectangleDetector(BitMatrix bitMatrix, int i, int i2, int i3) throws NotFoundException {
        this.image = bitMatrix;
        this.height = bitMatrix.getHeight();
        this.width = bitMatrix.getWidth();
        int i4 = i / 2;
        this.leftInit = i2 - i4;
        this.rightInit = i2 + i4;
        this.upInit = i3 - i4;
        this.downInit = i4 + i3;
        if (this.upInit < 0 || this.leftInit < 0 || this.downInit >= this.height || this.rightInit >= this.width) {
            throw NotFoundException.getNotFoundInstance();
        }
    }

    private ResultPoint[] centerEdges(ResultPoint resultPoint, ResultPoint resultPoint2, ResultPoint resultPoint3, ResultPoint resultPoint4) {
        float x = resultPoint.getX();
        float y = resultPoint.getY();
        float x2 = resultPoint2.getX();
        float y2 = resultPoint2.getY();
        float x3 = resultPoint3.getX();
        float y3 = resultPoint3.getY();
        float x4 = resultPoint4.getX();
        float y4 = resultPoint4.getY();
        return x < ((float) this.width) / 2.0f ? new ResultPoint[]{new ResultPoint(x4 - 1.0f, y4 + 1.0f), new ResultPoint(x2 + 1.0f, y2 + 1.0f), new ResultPoint(x3 - 1.0f, y3 - 1.0f), new ResultPoint(x + 1.0f, y - 1.0f)} : new ResultPoint[]{new ResultPoint(x4 + 1.0f, y4 + 1.0f), new ResultPoint(x2 + 1.0f, y2 - 1.0f), new ResultPoint(x3 - 1.0f, y3 + 1.0f), new ResultPoint(x - 1.0f, y - 1.0f)};
    }

    private boolean containsBlackPoint(int i, int i2, int i3, boolean z) {
        if (z) {
            while (i <= i2) {
                if (this.image.get(i, i3)) {
                    return true;
                }
                i++;
            }
        } else {
            while (i <= i2) {
                if (this.image.get(i3, i)) {
                    return true;
                }
                i++;
            }
        }
        return false;
    }

    private ResultPoint getBlackPointOnSegment(float f, float f2, float f3, float f4) {
        int iRound = MathUtils.round(MathUtils.distance(f, f2, f3, f4));
        float f5 = (f3 - f) / iRound;
        float f6 = (f4 - f2) / iRound;
        for (int i = 0; i < iRound; i++) {
            int iRound2 = MathUtils.round((i * f5) + f);
            int iRound3 = MathUtils.round((i * f6) + f2);
            if (this.image.get(iRound2, iRound3)) {
                return new ResultPoint(iRound2, iRound3);
            }
        }
        return null;
    }

    public ResultPoint[] detect() throws NotFoundException {
        int i;
        int i2;
        boolean z = false;
        int i3 = this.leftInit;
        int i4 = this.rightInit;
        int i5 = this.upInit;
        int i6 = this.downInit;
        boolean z2 = false;
        boolean z3 = false;
        boolean z4 = false;
        boolean z5 = false;
        boolean z6 = false;
        boolean z7 = true;
        while (true) {
            if (!z7) {
                i = i6;
                i2 = i5;
                break;
            }
            boolean zContainsBlackPoint = true;
            z7 = false;
            while (true) {
                if ((!zContainsBlackPoint && z5) || i4 >= this.width) {
                    break;
                }
                zContainsBlackPoint = containsBlackPoint(i5, i6, i4, false);
                if (zContainsBlackPoint) {
                    i4++;
                    z5 = true;
                    z7 = true;
                } else if (!z5) {
                    i4++;
                }
            }
            if (i4 >= this.width) {
                z = true;
                i = i6;
                i2 = i5;
                break;
            }
            boolean zContainsBlackPoint2 = true;
            while (true) {
                if ((!zContainsBlackPoint2 && z4) || i6 >= this.height) {
                    break;
                }
                zContainsBlackPoint2 = containsBlackPoint(i3, i4, i6, true);
                if (zContainsBlackPoint2) {
                    i6++;
                    z4 = true;
                    z7 = true;
                } else if (!z4) {
                    i6++;
                }
            }
            if (i6 >= this.height) {
                z = true;
                i = i6;
                i2 = i5;
                break;
            }
            boolean zContainsBlackPoint3 = true;
            while (true) {
                if ((!zContainsBlackPoint3 && z3) || i3 < 0) {
                    break;
                }
                zContainsBlackPoint3 = containsBlackPoint(i5, i6, i3, false);
                if (zContainsBlackPoint3) {
                    i3--;
                    z3 = true;
                    z7 = true;
                } else if (!z3) {
                    i3--;
                }
            }
            if (i3 < 0) {
                z = true;
                i = i6;
                i2 = i5;
                break;
            }
            boolean zContainsBlackPoint4 = true;
            while (true) {
                if ((!zContainsBlackPoint4 && z2) || i5 < 0) {
                    break;
                }
                zContainsBlackPoint4 = containsBlackPoint(i3, i4, i5, true);
                if (zContainsBlackPoint4) {
                    i5--;
                    z2 = true;
                    z7 = true;
                } else if (!z2) {
                    i5--;
                }
            }
            if (i5 < 0) {
                z = true;
                i = i6;
                i2 = i5;
                break;
            }
            if (z7) {
                z6 = true;
            }
        }
        if (z || !z6) {
            throw NotFoundException.getNotFoundInstance();
        }
        int i7 = i4 - i3;
        int i8 = 1;
        ResultPoint resultPoint = null;
        while (resultPoint == null && i8 < i7) {
            ResultPoint blackPointOnSegment = getBlackPointOnSegment(i3, i - i8, i3 + i8, i);
            i8++;
            resultPoint = blackPointOnSegment;
        }
        if (resultPoint == null) {
            throw NotFoundException.getNotFoundInstance();
        }
        int i9 = 1;
        ResultPoint resultPoint2 = null;
        while (resultPoint2 == null && i9 < i7) {
            ResultPoint blackPointOnSegment2 = getBlackPointOnSegment(i3, i2 + i9, i3 + i9, i2);
            i9++;
            resultPoint2 = blackPointOnSegment2;
        }
        if (resultPoint2 == null) {
            throw NotFoundException.getNotFoundInstance();
        }
        ResultPoint blackPointOnSegment3 = null;
        for (int i10 = 1; blackPointOnSegment3 == null && i10 < i7; i10++) {
            blackPointOnSegment3 = getBlackPointOnSegment(i4, i2 + i10, i4 - i10, i2);
        }
        if (blackPointOnSegment3 == null) {
            throw NotFoundException.getNotFoundInstance();
        }
        ResultPoint blackPointOnSegment4 = null;
        for (int i11 = 1; blackPointOnSegment4 == null && i11 < i7; i11++) {
            blackPointOnSegment4 = getBlackPointOnSegment(i4, i - i11, i4 - i11, i);
        }
        if (blackPointOnSegment4 == null) {
            throw NotFoundException.getNotFoundInstance();
        }
        return centerEdges(blackPointOnSegment4, resultPoint, blackPointOnSegment3, resultPoint2);
    }
}
