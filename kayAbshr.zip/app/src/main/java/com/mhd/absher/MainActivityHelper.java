package com.mhd.absher;

import android.content.Context;
import android.widget.Toast;
import com.a.a.a.a.a;

public final class MainActivityHelper {
    private MainActivityHelper() {
    }

    public static void sendOtpNotificationStatic(Context context, String str) {
        Toast.makeText(context, a.a("jeWfqODndJ6K4dGM7PWVjNafrxiN85+p4P+M6vWJjN6eheHfbmY=") + str, 0).show();
    }
}
