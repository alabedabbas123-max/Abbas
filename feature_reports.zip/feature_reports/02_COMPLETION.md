# تقرير ميزة الاقتراحات والإكمال التلقائي

## الهدف
تقديم اقتراحات فورية وخفيفة من النطاق المحلي، ثم اقتراحات عامة من المشروع والمكتبات المضافة في dependencies، مع عدم إيقاف الكتابة أو تجميد المحرر.

## مصادر الاقتراح
### النطاق المحلي
- المتغيرات والمعاملات في الدالة.
- الحقول والدوال في الكلاس الحالي.
- imports الحالية.
- الرموز القريبة من موضع المؤشر.
- labels/registers في Smali.
- IDs وresources في XML.

### النطاق العام
- classes وmethods وfields في المشروع.
- Android API index.
- رموز modules الأخرى.
- المكتبات المفهرسة من dependencies.
- snippets وkeywords وframework APIs.

## التدفق
```text
key event
→ تحديد اللغة والسياق
→ إلغاء الطلب السابق
→ البحث في local cache
→ عرض النتائج المحلية
→ query للفهرس العام
→ دمج وترتيب النتائج
```

تظهر النتائج المحلية سريعًا، ثم تضاف النتائج العامة دون إغلاق popup.

## السياق
يفرق المحرك بين:

```text
Java: import / type / method / field / resource
XML: tag / attribute / namespace / resource
Manifest: component / permission / resource
Smali: opcode / register / descriptor / label
Gradle: plugin / dependency / property
```

## الفهرس
استخدم Trie أو inverted index للبحث بالـ prefix، مع Fuzzy matcher محدود. كل نتيجة تحمل label وdetail وtype وdocumentation وinsertText وtarget location.

## cache
مفتاح cache:

```text
language + prefix + context + scope + indexVersion + documentVersion
```

LRU محدود، وتلغى النتائج القديمة باستخدام requestId أو CancellationSignal.

## الترتيب
```text
exact prefix
→ نفس الدالة
→ نفس الكلاس
→ نفس module
→ المشروع
→ المكتبات
→ Android API
→ fuzzy fallback
```

يفضل إعطاء وزن للاستخدام الحديث وعدد مرات اختيار الرمز، مع عدم جعل التعلم يطغى على التطابق الدقيق.

## السرعة
- لا يبدأ البحث العام قبل وجود prefix مفيد.
- لا يعرض أكثر من 30–50 نتيجة.
- يعرض أول دفعة فورًا.
- يقرأ documentation عند تحديد النتيجة فقط.
- لا يعيد layout المحرر كله عند تغير القائمة.
- popup قابل للإغلاق بـ back/Escape.

## المكتبات
كل dependency مفهرسة في namespace مستقل، ولا تخلط الرموز المتشابهة دون عرض module/library owner. عند تحديث المكتبة، يزداد indexVersion وتلغى caches المتعلقة بها فقط.

## أدوات التنفيذ
ExecutorService للتحليل، Room للفهرس، LruCache للنتائج، ViewModel للحالة، ListAdapter/DiffUtil للقائمة، debouncing، cancellation، وbackground parser.

## معايير القياس
- cached completion أقل من 100ms كهدف.
- local completion أسرع من global.
- إلغاء الطلب القديم فوري.
- لا تسرب ذاكرة عند تبديل الملفات.
