package com.mhd.absher;

import android.content.Context;
import android.content.SharedPreferences;
import com.a.a.a.a.a;

public class SessionManager {
    private final SharedPreferences prefs;
    private static final String PREFS_NAME = a.a("ICcjX2cmMTVeUTo6");
    private static final String KEY_IS_LOGGED_IN = a.a("PCcZQVcyMyNJZzw6");

    public SessionManager(Context context) {
        this.prefs = context.getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
    }

    public boolean isLoggedIn() {
        return this.prefs.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public void logout() {
        this.prefs.edit().clear().apply();
    }

    public void setLoggedIn(boolean z) {
        this.prefs.edit().putBoolean(KEY_IS_LOGGED_IN, z).apply();
    }
}
