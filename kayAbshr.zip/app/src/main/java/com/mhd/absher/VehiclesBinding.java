package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class VehiclesBinding {
    public final ImageView btnBack;
    public final HorizontalScrollView hscroll2;
    public final ImageView imageview100;
    public final ImageView imageview95;
    public final ImageView imageview96;
    public final ImageView imageview97;
    public final ImageView imageview98;
    public final ImageView imageview99;
    public final LinearLayout linear109;
    public final LinearLayout linear110;
    public final LinearLayout linear111;
    public final LinearLayout linear112;
    public final LinearLayout linear113;
    public final LinearLayout linear114;
    public final LinearLayout linear115;
    public final LinearLayout linear116;
    public final LinearLayout linear117;
    public final RelativeLayout rootVehicles;
    public final Space space118;
    public final TextView textview184;
    public final TextView textview185;
    public final TextView textview186;
    public final TextView textview187;
    public final TextView textview188;
    public final TextView textview189;
    public final TextView textview190;
    public final TextView textview191;
    public final TextView textview192;
    public final RelativeLayout topBar;
    public final ScrollView vscroll6;

    private VehiclesBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, ScrollView scrollView, LinearLayout linearLayout, LinearLayout linearLayout2, TextView textView2, ImageView imageView2, LinearLayout linearLayout3, ImageView imageView3, TextView textView3, TextView textView4, LinearLayout linearLayout4, TextView textView5, HorizontalScrollView horizontalScrollView, LinearLayout linearLayout5, LinearLayout linearLayout6, ImageView imageView4, TextView textView6, LinearLayout linearLayout7, ImageView imageView5, TextView textView7, LinearLayout linearLayout8, ImageView imageView6, TextView textView8, LinearLayout linearLayout9, ImageView imageView7, TextView textView9, Space space) {
        this.rootVehicles = relativeLayout;
        this.topBar = relativeLayout2;
        this.btnBack = imageView;
        this.textview184 = textView;
        this.vscroll6 = scrollView;
        this.linear109 = linearLayout;
        this.linear110 = linearLayout2;
        this.textview185 = textView2;
        this.imageview95 = imageView2;
        this.linear111 = linearLayout3;
        this.imageview96 = imageView3;
        this.textview186 = textView3;
        this.textview187 = textView4;
        this.linear112 = linearLayout4;
        this.textview188 = textView5;
        this.hscroll2 = horizontalScrollView;
        this.linear113 = linearLayout5;
        this.linear114 = linearLayout6;
        this.imageview97 = imageView4;
        this.textview189 = textView6;
        this.linear115 = linearLayout7;
        this.imageview98 = imageView5;
        this.textview190 = textView7;
        this.linear116 = linearLayout8;
        this.imageview99 = imageView6;
        this.textview191 = textView8;
        this.linear117 = linearLayout9;
        this.imageview100 = imageView7;
        this.textview192 = textView9;
        this.space118 = space;
    }

    public static VehiclesBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBar);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBack);
        TextView textView = (TextView) findChildViewById(view, R.id.textview184);
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.vscroll6);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear109);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear110);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview185);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview95);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear111);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.imageview96);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview186);
        TextView textView4 = (TextView) findChildViewById(view, R.id.textview187);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.linear112);
        TextView textView5 = (TextView) findChildViewById(view, R.id.textview188);
        HorizontalScrollView horizontalScrollView = (HorizontalScrollView) findChildViewById(view, R.id.hscroll2);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.linear113);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.linear114);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.imageview97);
        TextView textView6 = (TextView) findChildViewById(view, R.id.textview189);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.linear115);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.imageview98);
        TextView textView7 = (TextView) findChildViewById(view, R.id.textview190);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.linear116);
        ImageView imageView6 = (ImageView) findChildViewById(view, R.id.imageview99);
        TextView textView8 = (TextView) findChildViewById(view, R.id.textview191);
        LinearLayout linearLayout9 = (LinearLayout) findChildViewById(view, R.id.linear117);
        ImageView imageView7 = (ImageView) findChildViewById(view, R.id.imageview100);
        TextView textView9 = (TextView) findChildViewById(view, R.id.textview192);
        Space space = (Space) findChildViewById(view, R.id.space118);
        if (relativeLayout2 == null || imageView == null || textView == null || scrollView == null || linearLayout == null || linearLayout2 == null || textView2 == null || imageView2 == null || linearLayout3 == null || imageView3 == null || textView3 == null || textView4 == null || linearLayout4 == null || textView5 == null || horizontalScrollView == null || linearLayout5 == null || linearLayout6 == null || imageView4 == null || textView6 == null || linearLayout7 == null || imageView5 == null || textView7 == null || linearLayout8 == null || imageView6 == null || textView8 == null || linearLayout9 == null || imageView7 == null || textView9 == null || space == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new VehiclesBinding(relativeLayout, relativeLayout2, imageView, textView, scrollView, linearLayout, linearLayout2, textView2, imageView2, linearLayout3, imageView3, textView3, textView4, linearLayout4, textView5, horizontalScrollView, linearLayout5, linearLayout6, imageView4, textView6, linearLayout7, imageView5, textView7, linearLayout8, imageView6, textView8, linearLayout9, imageView7, textView9, space);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static VehiclesBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static VehiclesBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.vehicles, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootVehicles;
    }
}
