package almlk;

import android.content.Context;

/**
 * المرحلة 3: خريطة اختصارات المفاتيح — تحليل ومطابقة نقيان، والمصدر الواحد
 * للافتراضات (تقرأها شظية Keybindings ويستدعيها المضيف عند الإدخال).
 */
public final class Keybinds {
  public static final int META_CTRL = 1;
  public static final int META_ALT = 2;
  public static final int META_SHIFT = 4;

  private static final String[][] DEFAULTS = {
    {"save", "CTRL+S"},
    {"undo", "CTRL+Z"},
    {"redo", "CTRL+Y"},
    {"find", "CTRL+F"},
    {"format", "CTRL+SHIFT+F"},
    {"run", "F5"},
  };

  private Keybinds() {}

  public static String defaultLabel(String id) {
    for (String[] d : DEFAULTS) if (d[0].equals(id)) return d[1];
    return "";
  }

  public static String[] ids() {
    String[] out = new String[DEFAULTS.length];
    for (int i = 0; i < DEFAULTS.length; i++) out[i] = DEFAULTS[i][0];
    return out;
  }

  /** bitmask من لصيقة مثل CTRL+SHIFT+F — نقي. */
  public static int parseMeta(String label) {
    if (label == null) return 0;
    String upper = label.toUpperCase();
    int meta = 0;
    if (upper.contains("CTRL")) meta |= META_CTRL;
    if (upper.contains("ALT")) meta |= META_ALT;
    if (upper.contains("SHIFT")) meta |= META_SHIFT;
    return meta;
  }

  /** رمز المفتاح بعد آخر + — نقي. */
  public static String keyToken(String label) {
    if (label == null) return "";
    int at = label.lastIndexOf('+');
    return (at < 0 ? label : label.substring(at + 1)).trim().toUpperCase();
  }

  /** رمز مفتاح أندرويد ← لصيقة موحّدة (A-Z/0-9/F1-12/SPACE/ENTER/TAB). */
  public static String tokenForAndroidKeyCode(int keyCode) {
    if (keyCode >= android.view.KeyEvent.KEYCODE_A && keyCode <= android.view.KeyEvent.KEYCODE_Z)
      return String.valueOf((char) ('A' + (keyCode - android.view.KeyEvent.KEYCODE_A)));
    if (keyCode >= android.view.KeyEvent.KEYCODE_0 && keyCode <= android.view.KeyEvent.KEYCODE_9)
      return String.valueOf((char) ('0' + (keyCode - android.view.KeyEvent.KEYCODE_0)));
    if (keyCode >= android.view.KeyEvent.KEYCODE_F1 && keyCode <= android.view.KeyEvent.KEYCODE_F12)
      return "F" + (1 + (keyCode - android.view.KeyEvent.KEYCODE_F1));
    if (keyCode == android.view.KeyEvent.KEYCODE_SPACE) return "SPACE";
    if (keyCode == android.view.KeyEvent.KEYCODE_ENTER) return "ENTER";
    if (keyCode == android.view.KeyEvent.KEYCODE_TAB) return "TAB";
    return "";
  }

  /** الأمر المطابق للضغطة إن وُجد ربط (مخزَّن أو افتراضي)، وإلا null. */
  public static String commandFor(
      Context context, boolean ctrl, boolean alt, boolean shift, int keyCode) {
    String token = tokenForAndroidKeyCode(keyCode);
    if (token.isEmpty()) return null;
    for (String[] d : DEFAULTS) {
      String label =
          AppSettings.prefs(context).getString("keybind_" + d[0], d[1]);
      int want = parseMeta(label);
      boolean metaOk =
          ((want & META_CTRL) != 0) == ctrl
              && ((want & META_ALT) != 0) == alt
              && ((want & META_SHIFT) != 0) == shift;
      if (metaOk && keyToken(label).equals(token)) return d[0];
    }
    return null;
  }
}
