package almlk;

/**
 * المنسّق البنيوي لـXML — المرحلة السادسة.
 *
 * <p>يعيد **الإزاحة فقط**: لا يلمس محتوى عقدة نصية، ولا CDATA، ولا تعليقًا، ولا قيمة سمة.
 * هذا يعطي ثابتًا قابلًا للاختبار — بعد إزالة المسافة البادئة من كل سطر يبقى النص مطابقًا
 * للأصل — فلا يمكن للتنسيق أن يُتلف ملفًا.
 *
 * <p>مصدر الحقيقة البنيوي هو {@link XmlStructureScanner} (مسار واحد، بلا Regex ولا محلل ثانٍ).
 *
 * <p>حجم الإزاحة تفضيل مستقل {@code xml_indentation_size} افتراضيه 4 بارتداد آمن إلى 4 عند
 * أي قيمة فاسدة — مطابقة لدلالة {@code C0065aa.m520sG()} في المرجع.
 */
public final class XmlCodeFormatter {

  // الثوابت مُعارَة من almlk.CodeStyle — مصدر حقيقة واحد، لا تكرار (بند الإحلال).
  public static final String INDENT_KEY = CodeStyle.XML_INDENT_KEY;
  public static final int DEFAULT_INDENT = CodeStyle.DEFAULT_INDENT;
  public static final int MAX_INDENT = CodeStyle.MAX_INDENT;

  private XmlCodeFormatter() {}

  /** هل الاسم ملف XML بحسب الامتداد — بوابة اللغة قبل أي تنفيذ. */
  public static boolean isXmlName(String fileName) {
    return fileName != null && fileName.toLowerCase(java.util.Locale.US).endsWith(".xml");
  }

  /**
   * قراءة تفضيل إزاحة XML بارتداد آمن.
   *
   * <p>التفويض إلى {@link CodeStyle} — فالقراءة والحدود والارتداد معرَّفة مرة واحدة هناك،
   * وتبقى هذه الواجهة العامة كما هي لمن يستدعيها (بند 4: بلا كسر عقود).
   */
  public static int resolveIndentSize(android.content.Context context) {
    return CodeStyle.indentSize(context, INDENT_KEY);
  }

  /**
   * تنسيق بنيوي: إعادة إزاحة الأسطر دون أي تغيير في المحتوى.
   *
   * @param text النص الكامل للمستند.
   * @param indentSize عدد المسافات لكل مستوى.
   * @return النص المنسّق؛ يطابق {@code text} إن لم يكن هناك ما يُضبط.
   */
  public static String format(String text, int indentSize) {
    if (text == null || text.isEmpty()) return text;
    int step = indentSize < 0 ? 0 : Math.min(indentSize, MAX_INDENT);
    XmlStructureScanner.Layout layout = XmlStructureScanner.scan(text);
    StringBuilder out = new StringBuilder(text.length() + layout.lineCount * step);

    for (int line = 0; line < layout.lineCount; line++) {
      int from = layout.lineStart[line];
      int to = layout.lineEnd[line];
      int state = layout.startState[line];

      if (XmlStructureScanner.isVerbatimState(state)) {
        // داخل تعليق أو CDATA: المحتوى حرفي ولا يُعاد إزاحته.
        out.append(text, from, to);
      } else {
        int content = from;
        while (content < to && XmlStructureScanner.isSpace(text.charAt(content))) content++;
        if (content < to) {
          int level = layout.depthBefore[line];
          // استمرار وسم ممتد عبر الأسطر يبقى على عمق الوسم بعد فتحه.
          if (!XmlStructureScanner.isTagContinuation(state) && layout.startsWithClose[line]) level--;
          if (level < 0) level = 0;
          for (int i = level * step; i > 0; i--) out.append(' ');
          out.append(text, content, to);
        }
        // السطر الفارغ يبقى فارغًا بلا مسافات زائدة.
      }

      if (line < layout.lineCount - 1) out.append('\n');
    }
    return out.toString();
  }
}
