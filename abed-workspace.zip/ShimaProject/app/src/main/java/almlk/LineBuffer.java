package almlk;

/**
 * بند almlk ← دور كلاس abcd «C0079A» (تخزين السطر الواحد): مصفوفة char قابلة للتوسّع
 * بتمكّننا من تعديل سطر دون إنشاء سلاسل جديدة لكل ضغطة مفتاح.
 *
 * <p>سعة مبدئية 8 تتضاعف عند الامتلاء — خفيف كالسطر في محرر AIDE، بلا أي غلاف Spannable.
 */
public final class LineBuffer {

  private char[] chars;
  private int length;

  public LineBuffer() {
    this(8);
  }

  public LineBuffer(int capacity) {
    chars = new char[Math.max(8, capacity)];
  }

  public LineBuffer(char[] content) {
    this(content == null ? 8 : Math.max(8, content.length * 2));
    if (content != null) {
      System.arraycopy(content, 0, chars, 0, content.length);
      length = content.length;
    }
  }

  public int length() {
    return length;
  }

  public char charAt(int index) {
    return chars[index];
  }

  /** نسخ مقطع إلى وجهة خارجية (أسلوب getChars في مهام الرسم/التحليل — بلا تخصيص داخلي). */
  public void getChars(int start, int count, char[] dest, int destOffset) {
    System.arraycopy(chars, start, dest, destOffset, count);
  }

  public void insert(int at, char c) {
    ensure(length + 1);
    System.arraycopy(chars, at, chars, at + 1, length - at);
    chars[at] = c;
    length++;
  }

  public void insert(int at, char[] data, int offset, int count) {
    ensure(length + count);
    System.arraycopy(chars, at, chars, at + count, length - at);
    System.arraycopy(data, offset, chars, at, count);
    length += count;
  }

  public void append(char c) {
    insert(length, c);
  }

  public void delete(int start, int count) {
    System.arraycopy(chars, start + count, chars, start, length - start - count);
    length -= count;
  }

  public void replace(char[] content) {
    ensure(content.length);
    System.arraycopy(content, 0, chars, 0, content.length);
    length = content.length;
  }

  private void ensure(int capacity) {
    if (capacity <= chars.length) return;
    int grown = chars.length;
    while (grown < capacity) grown *= 2;
    char[] next = new char[grown];
    System.arraycopy(chars, 0, next, 0, length);
    chars = next;
  }

  @Override
  public String toString() {
    return new String(chars, 0, length);
  }
}
