package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import com.a.a.a.a.a;

public final class VisitorIdBinding {
    public final CardView documentCardVisitor;
    public final FrameLayout frameVisitorQrcode;
    public final ImageView imgCardBg;
    public final ImageView imgUserPhoto;
    public final ImageView imgVisitorQrLogo;
    public final ImageView imgVisitorQrcode;
    public final RelativeLayout relativelayout3;
    public final RelativeLayout rootView;
    public final TextView tvBirthDate;
    public final TextView tvBloodType;
    public final TextView tvExpiryDate;
    public final TextView tvIdNumber;
    public final TextView tvIssueDate;
    public final TextView tvIssuePlace;
    public final TextView tvNameAr;
    public final TextView tvNameEn;
    public final TextView tvNationality;
    public final TextView tvVersionNumber;
    public final TextView tvVisitPurpose;

    private VisitorIdBinding(RelativeLayout relativeLayout, CardView cardView, RelativeLayout relativeLayout2, ImageView imageView, ImageView imageView2, FrameLayout frameLayout, ImageView imageView3, ImageView imageView4, TextView textView, TextView textView2, TextView textView3, TextView textView4, TextView textView5, TextView textView6, TextView textView7, TextView textView8, TextView textView9, TextView textView10, TextView textView11) {
        this.rootView = relativeLayout;
        this.documentCardVisitor = cardView;
        this.relativelayout3 = relativeLayout2;
        this.imgCardBg = imageView;
        this.imgUserPhoto = imageView2;
        this.frameVisitorQrcode = frameLayout;
        this.imgVisitorQrcode = imageView3;
        this.imgVisitorQrLogo = imageView4;
        this.tvVersionNumber = textView;
        this.tvNameAr = textView2;
        this.tvNameEn = textView3;
        this.tvIdNumber = textView4;
        this.tvIssuePlace = textView5;
        this.tvIssueDate = textView6;
        this.tvExpiryDate = textView7;
        this.tvBirthDate = textView8;
        this.tvNationality = textView9;
        this.tvVisitPurpose = textView10;
        this.tvBloodType = textView11;
    }

    public static VisitorIdBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        CardView cardViewFindChildViewById = findChildViewById(view, R.id.documentCardVisitor);
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.relativelayout3);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.img_card_bg);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.img_user_photo);
        FrameLayout frameLayout = (FrameLayout) findChildViewById(view, R.id.frame_visitor_qrcode);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.img_visitor_qrcode);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.img_visitor_qr_logo);
        TextView textView = (TextView) findChildViewById(view, R.id.tv_version_number);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tv_name_ar);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tv_name_en);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tv_id_number);
        TextView textView5 = (TextView) findChildViewById(view, R.id.tv_issue_place);
        TextView textView6 = (TextView) findChildViewById(view, R.id.tv_issue_date);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tv_expiry_date);
        TextView textView8 = (TextView) findChildViewById(view, R.id.tv_birth_date);
        TextView textView9 = (TextView) findChildViewById(view, R.id.tv_nationality);
        TextView textView10 = (TextView) findChildViewById(view, R.id.tv_visit_purpose);
        TextView textView11 = (TextView) findChildViewById(view, R.id.tv_blood_type);
        if (cardViewFindChildViewById == null || relativeLayout2 == null || imageView == null || imageView2 == null || frameLayout == null || imageView3 == null || imageView4 == null || textView == null || textView2 == null || textView3 == null || textView4 == null || textView5 == null || textView6 == null || textView7 == null || textView8 == null || textView9 == null || textView10 == null || textView11 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new VisitorIdBinding(relativeLayout, cardViewFindChildViewById, relativeLayout2, imageView, imageView2, frameLayout, imageView3, imageView4, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static VisitorIdBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static VisitorIdBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.visitor_id, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
