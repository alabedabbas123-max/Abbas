package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class AccidentRegistrationBinding {
    public final LinearLayout bottomNavAccident;
    public final ImageView btnCloseAccident;
    public final Button btnRegisterAccidentAction;
    public final ImageView imageview10;
    public final ImageView imageview11;
    public final ImageView imageview12;
    public final ImageView imageview7;
    public final ImageView imageview8;
    public final ImageView imageview9;
    public final LinearLayout linear12;
    public final LinearLayout linear14;
    public final LinearLayout linear15;
    public final LinearLayout linear16;
    public final LinearLayout linear17;
    public final LinearLayout linear18;
    public final LinearLayout linear19;
    public final LinearLayout linear20;
    public final RelativeLayout rootView;
    public final LinearLayout tabsLayout;
    public final TextView textview10;
    public final TextView textview11;
    public final TextView textview12;
    public final TextView textview13;
    public final TextView textview14;
    public final TextView textview15;
    public final TextView textview16;
    public final TextView textview17;
    public final TextView textview18;
    public final RelativeLayout topBarAccident;
    public final TextView tvAccidentTitle;
    public final View view13;

    private AccidentRegistrationBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, LinearLayout linearLayout, LinearLayout linearLayout2, TextView textView2, View view, LinearLayout linearLayout3, TextView textView3, LinearLayout linearLayout4, LinearLayout linearLayout5, ImageView imageView2, TextView textView4, LinearLayout linearLayout6, ImageView imageView3, TextView textView5, LinearLayout linearLayout7, ImageView imageView4, TextView textView6, LinearLayout linearLayout8, ImageView imageView5, TextView textView7, LinearLayout linearLayout9, ImageView imageView6, TextView textView8, Button button, LinearLayout linearLayout10, ImageView imageView7, TextView textView9, TextView textView10) {
        this.rootView = relativeLayout;
        this.topBarAccident = relativeLayout2;
        this.btnCloseAccident = imageView;
        this.tvAccidentTitle = textView;
        this.tabsLayout = linearLayout;
        this.linear12 = linearLayout2;
        this.textview10 = textView2;
        this.view13 = view;
        this.linear14 = linearLayout3;
        this.textview11 = textView3;
        this.bottomNavAccident = linearLayout4;
        this.linear15 = linearLayout5;
        this.imageview7 = imageView2;
        this.textview12 = textView4;
        this.linear16 = linearLayout6;
        this.imageview8 = imageView3;
        this.textview13 = textView5;
        this.linear17 = linearLayout7;
        this.imageview9 = imageView4;
        this.textview14 = textView6;
        this.linear18 = linearLayout8;
        this.imageview10 = imageView5;
        this.textview15 = textView7;
        this.linear19 = linearLayout9;
        this.imageview11 = imageView6;
        this.textview16 = textView8;
        this.btnRegisterAccidentAction = button;
        this.linear20 = linearLayout10;
        this.imageview12 = imageView7;
        this.textview17 = textView9;
        this.textview18 = textView10;
    }

    public static AccidentRegistrationBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBarAccident);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnCloseAccident);
        TextView textView = (TextView) findChildViewById(view, R.id.tvAccidentTitle);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.tabsLayout);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear12);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview10);
        View viewFindChildViewById = findChildViewById(view, R.id.view13);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear14);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview11);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.bottomNavAccident);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.linear15);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview7);
        TextView textView4 = (TextView) findChildViewById(view, R.id.textview12);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.linear16);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.imageview8);
        TextView textView5 = (TextView) findChildViewById(view, R.id.textview13);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.linear17);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.imageview9);
        TextView textView6 = (TextView) findChildViewById(view, R.id.textview14);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.linear18);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.imageview10);
        TextView textView7 = (TextView) findChildViewById(view, R.id.textview15);
        LinearLayout linearLayout9 = (LinearLayout) findChildViewById(view, R.id.linear19);
        ImageView imageView6 = (ImageView) findChildViewById(view, R.id.imageview11);
        TextView textView8 = (TextView) findChildViewById(view, R.id.textview16);
        Button button = (Button) findChildViewById(view, R.id.btnRegisterAccidentAction);
        LinearLayout linearLayout10 = (LinearLayout) findChildViewById(view, R.id.linear20);
        ImageView imageView7 = (ImageView) findChildViewById(view, R.id.imageview12);
        TextView textView9 = (TextView) findChildViewById(view, R.id.textview17);
        TextView textView10 = (TextView) findChildViewById(view, R.id.textview18);
        if (relativeLayout2 == null || imageView == null || textView == null || linearLayout == null || linearLayout2 == null || textView2 == null || viewFindChildViewById == null || linearLayout3 == null || textView3 == null || linearLayout4 == null || linearLayout5 == null || imageView2 == null || textView4 == null || linearLayout6 == null || imageView3 == null || textView5 == null || linearLayout7 == null || imageView4 == null || textView6 == null || linearLayout8 == null || imageView5 == null || textView7 == null || linearLayout9 == null || imageView6 == null || textView8 == null || button == null || linearLayout10 == null || imageView7 == null || textView9 == null || textView10 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new AccidentRegistrationBinding(relativeLayout, relativeLayout2, imageView, textView, linearLayout, linearLayout2, textView2, viewFindChildViewById, linearLayout3, textView3, linearLayout4, linearLayout5, imageView2, textView4, linearLayout6, imageView3, textView5, linearLayout7, imageView4, textView6, linearLayout8, imageView5, textView7, linearLayout9, imageView6, textView8, button, linearLayout10, imageView7, textView9, textView10);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static AccidentRegistrationBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static AccidentRegistrationBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.accident_registration, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
