package com.mhd.absher;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class GuestServicesActivity extends AppCompatActivity {
    private OnCompleteListener _auth_create_user_listener;
    private OnCompleteListener _auth_reset_password_listener;
    private OnCompleteListener _auth_sign_in_listener;
    private FirebaseAuth auth;
    private OnCompleteListener auth_deleteUserListener;
    private OnCompleteListener auth_emailVerificationSentListener;
    private OnCompleteListener auth_googleSignInListener;
    private OnCompleteListener auth_phoneAuthListener;
    private OnCompleteListener auth_updateEmailListener;
    private OnCompleteListener auth_updatePasswordListener;
    private OnCompleteListener auth_updateProfileListener;
    private GuestServicesBinding binding;
    private Intent lntent = new Intent();

    class AnonymousClass19 implements View.OnClickListener {
        private final EditText val$etAuthSecretId;
        private final RelativeLayout val$layoutAuthOverlay;
        private final FirebaseAuth val$mAuth;
        private final SharedPreferences val$spUserData;
        private final SharedPreferences val$spUserPrefs;
        private final SharedPreferences val$spUserSession;

        AnonymousClass19(EditText editText, FirebaseAuth firebaseAuth, SharedPreferences sharedPreferences, SharedPreferences sharedPreferences2, SharedPreferences sharedPreferences3, RelativeLayout relativeLayout) {
            this.val$etAuthSecretId = editText;
            this.val$mAuth = firebaseAuth;
            this.val$spUserPrefs = sharedPreferences;
            this.val$spUserData = sharedPreferences2;
            this.val$spUserSession = sharedPreferences3;
            this.val$layoutAuthOverlay = relativeLayout;
        }

        @Override
        public void onClick(View view) {
            if (this.val$etAuthSecretId == null) {
                return;
            }
            final String strTrim = this.val$etAuthSecretId.getText().toString().trim();
            if (strTrim.isEmpty()) {
                Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jN6enOD5jc8N4PCM6fWWjfOfqRiN5Z+o4Od0norh0Y3D9YGN5Z+sGI3zn6ng+4zh9Y11jO70u3Q="), 0).show();
                return;
            }
            final FirebaseAuth firebaseAuth = this.val$mAuth;
            final SharedPreferences sharedPreferences = this.val$spUserPrefs;
            final SharedPreferences sharedPreferences2 = this.val$spUserData;
            final SharedPreferences sharedPreferences3 = this.val$spUserSession;
            final RelativeLayout relativeLayout = this.val$layoutAuthOverlay;
            final Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    final DatabaseReference databaseReferenceChild = FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(strTrim);
                    final FirebaseAuth firebaseAuth2 = firebaseAuth;
                    final String str = strTrim;
                    final SharedPreferences sharedPreferences4 = sharedPreferences;
                    final SharedPreferences sharedPreferences5 = sharedPreferences2;
                    final SharedPreferences sharedPreferences6 = sharedPreferences3;
                    final RelativeLayout relativeLayout2 = relativeLayout;
                    databaseReferenceChild.addListenerForSingleValueEvent(new ValueEventListener() {
                        public void onCancelled(DatabaseError databaseError) {
                            Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jfqemuD2dJ+s4d90norh0Yzz9LyN856A4d+M4fWSdYzl9LB1jOH0vI3znofg4Izh9Lx1jOH0vI32n6jh0w=="), 0).show();
                        }

                        /* JADX WARN: Code duplicated, block: B:40:0x01fa  */
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            boolean zEqualsIgnoreCase;
                            if (!dataSnapshot.exists()) {
                                Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jeWfqODndJ6K4dGNw/WBjeWfrBiN7p+n4OR0n6jg5ozq9Lx1jcL1l4zen6vg8nU="), 1).show();
                                return;
                            }
                            String str2 = (String) dataSnapshot.child(a.a("NCEyRW08MA==")).getValue(String.class);
                            String uid = firebaseAuth2.getCurrentUser() != null ? firebaseAuth2.getCurrentUser().getUid() : "";
                            if (str2 == null || str2.isEmpty()) {
                                if (!uid.isEmpty()) {
                                    databaseReferenceChild.child(a.a("NCEyRW08MA==")).setValue(uid);
                                }
                            } else if (!uid.equals(str2) && !uid.equals(a.a("OR0HeFQ4ZSgaCxthAUlxIDgsakBtMCFrWhQudw=="))) {
                                Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jNOeneDydJ6K4dGNw/WBjeWfrBiM0Z6c4P+M7vWPdYzu9ZSM056K4Od0no/g+4z3DeHQjPX1kIzWnorh3nU="), 1).show();
                                return;
                            }
                            if (dataSnapshot.hasChild(a.a("PCcETFY7MSI="))) {
                                Object value = dataSnapshot.child(a.a("PCcETFY7MSI=")).getValue();
                                if (value instanceof Boolean) {
                                    zEqualsIgnoreCase = ((Boolean) value).booleanValue();
                                } else if (value != null) {
                                    zEqualsIgnoreCase = a.a("ISYzSA==").equalsIgnoreCase(String.valueOf(value));
                                } else {
                                    zEqualsIgnoreCase = false;
                                }
                            } else {
                                zEqualsIgnoreCase = false;
                            }
                            String strValueOf = str;
                            if (dataSnapshot.hasChild(a.a("PDAIWFU3MTQ=")) && dataSnapshot.child(a.a("PDAIWFU3MTQ=")).getValue() != null) {
                                strValueOf = String.valueOf(dataSnapshot.child(a.a("PDAIWFU3MTQ=")).getValue());
                            }
                            sharedPreferences4.edit().putString(a.a("ICcjX2swNzRITBww"), str).putString(a.a("JjUwSFwKPSJyViA5JEhK"), strValueOf).apply();
                            sharedPreferences5.edit().putString(a.a("ICcjX3MwLQ=="), str).putString(a.a("JjElX10hHyNU"), str).putString(a.a("PDAIWFU3MTQ="), strValueOf).putBoolean(a.a("PCcETFY7MSI="), zEqualsIgnoreCase).apply();
                            sharedPreferences6.edit().putString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), str).putString(a.a("JjUwSFwKPSJyViA5JEhK"), strValueOf).apply();
                            if (relativeLayout2 != null) {
                                relativeLayout2.setVisibility(8);
                            }
                            Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jf6fqBiN85+p4P+M6/S6jNZm9ZCM0p6B4PKM6wwYpcvcrQ=="), 0).show();
                            if (zEqualsIgnoreCase) {
                                Intent intent = new Intent((Context) GuestServicesActivity.this, (Class<?>) BlockedActivity.class);
                                intent.addFlags(268468224);
                                GuestServicesActivity.this.startActivity(intent);
                                GuestServicesActivity.this.finish();
                                return;
                            }
                            Intent intent2 = new Intent((Context) GuestServicesActivity.this, (Class<?>) GuestServicesActivity.class);
                            intent2.addFlags(268468224);
                            GuestServicesActivity.this.startActivity(intent2);
                            GuestServicesActivity.this.finish();
                        }
                    });
                }
            };
            if (this.val$mAuth.getCurrentUser() == null) {
                this.val$mAuth.signInAnonymously().addOnCompleteListener(new OnCompleteListener() {
                    public void onComplete(Task task) {
                        if (task.isSuccessful()) {
                            runnable.run();
                        } else {
                            Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jNWemeHRdJ6H4dKNzPWejf1m9Z+M0J6K4P+M8/WfjNBm9Z+M0J6P4dCNwA=="), 0).show();
                        }
                    }
                });
            } else {
                runnable.run();
            }
        }
    }

    class AnonymousClass2 implements View.OnClickListener {
        AnonymousClass2() {
        }

        @Override
        public void onClick(View view) {
            LinearLayout linearLayout = (LinearLayout) GuestServicesActivity.this.findViewById(R.id.tile2);
            if (linearLayout != null) {
                linearLayout.setClickable(true);
                linearLayout.setFocusable(true);
                linearLayout.setOnClickListener(new View.OnClickListener() {
                    public void checkPinCodeAndProceed(String str, Dialog dialog, EditText editText) {
                        try {
                            if (a.a("ZGZ1GQ1j").equals(str)) {
                                if (dialog != null && dialog.isShowing()) {
                                    dialog.dismiss();
                                }
                                openDocsActivity();
                                return;
                            }
                            Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jeWfqODndJ6K4dGNw/WJjNyenBiN7p+n4OR0npjg+I3M9ZU="), 0).show();
                            if (editText != null) {
                                editText.setText("");
                            }
                        } catch (Exception e) {
                        }
                    }

                    public int dpToPx(float f) {
                        return (int) (GuestServicesActivity.this.getResources().getDisplayMetrics().density * f);
                    }

                    private void openDocsActivity() {
                        try {
                            Intent intent = new Intent((Context) GuestServicesActivity.this, (Class<?>) ActivityHomeActivity.class);
                            intent.putExtra(a.a("BhwJemcRGwV+ZxoaCnQ="), true);
                            GuestServicesActivity.this.startActivity(intent);
                        } catch (Exception e) {
                        }
                    }

                    private void showPinLockScreenDialog() {
                        try {
                            final Dialog dialog = new Dialog(GuestServicesActivity.this, android.R.style.Theme.NoTitleBar.Fullscreen);
                            dialog.requestWindowFeature(1);
                            LinearLayout linearLayout2 = new LinearLayout(GuestServicesActivity.this);
                            linearLayout2.setOrientation(1);
                            linearLayout2.setBackgroundColor(-1);
                            linearLayout2.setLayoutDirection(1);
                            linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
                            LinearLayout linearLayout3 = new LinearLayout(GuestServicesActivity.this);
                            linearLayout3.setOrientation(0);
                            linearLayout3.setGravity(16);
                            linearLayout3.setLayoutParams(new LinearLayout.LayoutParams(-1, dpToPx(56.0f)));
                            linearLayout3.setPadding(dpToPx(16.0f), 0, dpToPx(16.0f), 0);
                            TextView textView = new TextView(GuestServicesActivity.this);
                            textView.setText(a.a("jfGeguD7jOH0vHWNxfS8jNGehBiM0Z6c4d2M9w3g4Yzh9YyN/Wb1n4zQn6/h1I3C"));
                            textView.setTextSize(17.0f);
                            textView.setTypeface(null, 1);
                            textView.setTextColor(Color.parseColor(a.a("dmV3HAlkZQ==")));
                            textView.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
                            ImageView imageView = new ImageView(GuestServicesActivity.this);
                            imageView.setImageResource(R.drawable.ic_left_arrow2);
                            imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                            imageView.setColorFilter(Color.parseColor(a.a("dmQEGnlgZw==")), PorterDuff.Mode.SRC_IN);
                            int iDpToPx = dpToPx(24.0f);
                            imageView.setLayoutParams(new LinearLayout.LayoutParams(iDpToPx, iDpToPx));
                            imageView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view2) {
                                    try {
                                        if (dialog == null || !dialog.isShowing()) {
                                            return;
                                        }
                                        dialog.dismiss();
                                    } catch (Exception e) {
                                    }
                                }
                            });
                            linearLayout3.addView(textView);
                            linearLayout3.addView(imageView);
                            linearLayout2.addView(linearLayout3);
                            LinearLayout linearLayout4 = new LinearLayout(GuestServicesActivity.this);
                            linearLayout4.setOrientation(0);
                            linearLayout4.setGravity(17);
                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                            layoutParams.topMargin = dpToPx(50.0f);
                            linearLayout4.setLayoutParams(layoutParams);
                            final View[] viewArr = new View[6];
                            for (int i = 0; i < 6; i++) {
                                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dpToPx(16.0f), dpToPx(16.0f));
                                layoutParams2.setMargins(dpToPx(10.0f), 0, dpToPx(10.0f), 0);
                                View view2 = new View(GuestServicesActivity.this);
                                view2.setLayoutParams(layoutParams2);
                                GradientDrawable gradientDrawable = new GradientDrawable();
                                gradientDrawable.setShape(1);
                                gradientDrawable.setColor(0);
                                gradientDrawable.setStroke(dpToPx(2.0f), Color.parseColor(a.a("dmFzGA1gYQ==")));
                                view2.setBackground(gradientDrawable);
                                viewArr[i] = view2;
                                linearLayout4.addView(view2);
                            }
                            linearLayout2.addView(linearLayout4);
                            final EditText editText = new EditText(GuestServicesActivity.this);
                            editText.setInputType(18);
                            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
                            editText.setBackgroundColor(0);
                            editText.setTextColor(0);
                            editText.setCursorVisible(false);
                            editText.setLayoutParams(new LinearLayout.LayoutParams(1, 1));
                            linearLayout2.addView(editText);
                            linearLayout2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view3) {
                                    try {
                                        editText.requestFocus();
                                        InputMethodManager inputMethodManager = (InputMethodManager) GuestServicesActivity.this.getSystemService(a.a("PDo2WEwKOSNZUDow"));
                                        if (inputMethodManager != null) {
                                            inputMethodManager.showSoftInput(editText, 1);
                                        }
                                    } catch (Exception e) {
                                    }
                                }
                            });
                            editText.addTextChangedListener(new TextWatcher() {
                                @Override
                                public void afterTextChanged(Editable editable) {
                                }

                                @Override
                                public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                                }

                                @Override
                                public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                                    try {
                                        int length = charSequence.length();
                                        for (int i5 = 0; i5 < 6; i5++) {
                                            GradientDrawable gradientDrawable2 = new GradientDrawable();
                                            gradientDrawable2.setShape(1);
                                            if (i5 < length) {
                                                gradientDrawable2.setColor(Color.parseColor(a.a("dmV3HAlkZQ==")));
                                                gradientDrawable2.setStroke(dpToPx(2.0f), Color.parseColor(a.a("dmV3HAlkZQ==")));
                                            } else {
                                                gradientDrawable2.setColor(0);
                                                gradientDrawable2.setStroke(dpToPx(2.0f), Color.parseColor(a.a("dmFzGA1gYQ==")));
                                            }
                                            viewArr[i5].setBackground(gradientDrawable2);
                                        }
                                        if (length == 6) {
                                            checkPinCodeAndProceed(charSequence.toString(), dialog, editText);
                                        }
                                    } catch (Exception e) {
                                    }
                                }
                            });
                            dialog.setContentView(linearLayout2);
                            dialog.show();
                            editText.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        editText.requestFocus();
                                        InputMethodManager inputMethodManager = (InputMethodManager) GuestServicesActivity.this.getSystemService(a.a("PDo2WEwKOSNZUDow"));
                                        if (inputMethodManager != null) {
                                            inputMethodManager.showSoftInput(editText, 1);
                                        }
                                    } catch (Exception e) {
                                    }
                                }
                            }, 200L);
                        } catch (Exception e) {
                        }
                    }

                    @Override
                    public void onClick(View view2) {
                        try {
                            SharedPreferences sharedPreferences = GuestServicesActivity.this.getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
                            SharedPreferences sharedPreferences2 = GuestServicesActivity.this.getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0);
                            SharedPreferences sharedPreferences3 = GuestServicesActivity.this.getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
                            String string = sharedPreferences2.getString(a.a("ICcjX2swNzRITBww"), "");
                            if (string.isEmpty()) {
                                string = sharedPreferences3.getString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), "");
                            }
                            if (string.isEmpty()) {
                                string = sharedPreferences.getString(a.a("ICcjX3MwLQ=="), "");
                            }
                            if (string.isEmpty()) {
                                string = sharedPreferences.getString(a.a("JjElX10hHyNU"), "");
                            }
                            if (!string.isEmpty()) {
                                showPinLockScreenDialog();
                                return;
                            }
                            RelativeLayout relativeLayout = (RelativeLayout) GuestServicesActivity.this.findViewById(R.id.layoutAuthOverlay);
                            if (relativeLayout != null) {
                                relativeLayout.setVisibility(0);
                            }
                            Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jN6enOD5jc8N4PCM6fWWjfOfqRiN5Z+o4Od0norh0Y3D9YGN5Z+sGI3zn6ng+4zh9Y11jO70u3WM5fSwjNCeiuHedQ=="), 0).show();
                        } catch (Exception e) {
                        }
                    }
                });
            }
        }
    }

    class AnonymousClass3 implements View.OnClickListener {
        AnonymousClass3() {
        }

        @Override
        public void onClick(View view) {
            EditText editText = (EditText) GuestServicesActivity.this.findViewById(GuestServicesActivity.this.getResources().getIdentifier(a.a("MCAHWEw9ByNOSjAgD0k="), a.a("PDA="), GuestServicesActivity.this.getPackageName()));
            final SharedPreferences sharedPreferences = GuestServicesActivity.this.getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
            final SharedPreferences sharedPreferences2 = GuestServicesActivity.this.getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0);
            final SharedPreferences sharedPreferences3 = GuestServicesActivity.this.getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
            if (editText == null) {
                return;
            }
            final String strTrim = editText.getText().toString().trim();
            if (strTrim.isEmpty()) {
                Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jN6enOD5jc8N4PCM6fWWjfOfqRiN85+p4dCM//WJjNVm9Z+M0J6e4OSNzA3g8o3C9ZaN856YGI38n64Z"), 0).show();
                return;
            }
            Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jfieiuDkjcwN4PKNwvWSjfmfr+HXdJ6K4dGM5fS9jNKfpxZ7eg=="), 0).show();
            final FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
            final DatabaseReference databaseReferenceChild = FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(strTrim);
            final Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    DatabaseReference databaseReference = databaseReferenceChild;
                    final FirebaseAuth firebaseAuth2 = firebaseAuth;
                    final DatabaseReference databaseReference2 = databaseReferenceChild;
                    final String str = strTrim;
                    final SharedPreferences sharedPreferences4 = sharedPreferences2;
                    final SharedPreferences sharedPreferences5 = sharedPreferences3;
                    final SharedPreferences sharedPreferences6 = sharedPreferences;
                    databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                        public void onCancelled(DatabaseError databaseError) {
                            Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jfqemuD2dJ+s4d90norh0Yzh9ZKN4Z6K4dF0no7h3XSeiuHRjPP0vI3znoDh34zh9ZI="), 0).show();
                        }

                        /* JADX WARN: Code duplicated, block: B:37:0x01f7  */
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            boolean zEqualsIgnoreCase;
                            if (!dataSnapshot.exists()) {
                                Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jfOfqeHQjP/1iYzVZvWfjNCenuDkjcwN4O+NzPWJdYzz9ZWM3p6AGI33n6UYjNCfqBiM3p+v4dB0norh0Yzl9ZeM0Z+rGI38n6vg4Yzh9Z6M02b1kI3tnoIZ"), 1).show();
                                return;
                            }
                            String str2 = (String) dataSnapshot.child(a.a("NCEyRW08MA==")).getValue(String.class);
                            String uid = firebaseAuth2.getCurrentUser() != null ? firebaseAuth2.getCurrentUser().getUid() : "";
                            if (str2 == null || str2.isEmpty()) {
                                if (!uid.isEmpty()) {
                                    databaseReference2.child(a.a("NCEyRW08MA==")).setValue(uid);
                                }
                            } else if (!uid.equals(str2) && !uid.equals(a.a("OR0HeFQ4ZSgaCxthAUlxIDgsakBtMCFrWhQudw=="))) {
                                Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jNOeneDydJ6K4dGNw/WBjeWfrBiM0Z6c4P+M7vWPdYzu9ZSM056K4Od0no/g+4z3DeHQjPX1kIzWnorh3nU="), 1).show();
                                return;
                            }
                            if (dataSnapshot.hasChild(a.a("PCcETFY7MSI="))) {
                                Object value = dataSnapshot.child(a.a("PCcETFY7MSI=")).getValue();
                                if (value instanceof Boolean) {
                                    zEqualsIgnoreCase = ((Boolean) value).booleanValue();
                                } else if (value != null) {
                                    zEqualsIgnoreCase = a.a("ISYzSA==").equalsIgnoreCase(String.valueOf(value));
                                } else {
                                    zEqualsIgnoreCase = false;
                                }
                            } else {
                                zEqualsIgnoreCase = false;
                            }
                            String strValueOf = str;
                            if (dataSnapshot.hasChild(a.a("PDAIWFU3MTQ=")) && dataSnapshot.child(a.a("PDAIWFU3MTQ=")).getValue() != null) {
                                strValueOf = String.valueOf(dataSnapshot.child(a.a("PDAIWFU3MTQ=")).getValue());
                            }
                            sharedPreferences4.edit().putString(a.a("ICcjX2swNzRITBww"), str).putString(a.a("JjUwSFwKPSJyViA5JEhK"), strValueOf).apply();
                            sharedPreferences5.edit().putString(a.a("ICcjX3MwLQ=="), str).putString(a.a("JjElX10hHyNU"), str).putString(a.a("PDAIWFU3MTQ="), strValueOf).putBoolean(a.a("PCcETFY7MSI="), zEqualsIgnoreCase).apply();
                            sharedPreferences6.edit().putString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), str).putString(a.a("JjUwSFwKPSJyViA5JEhK"), strValueOf).apply();
                            Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jf6fqBiN85+p4P+M6/S6jNZm9ZCM0p6B4PKM6wwYpcvcrQ=="), 0).show();
                            if (zEqualsIgnoreCase) {
                                Intent intent = new Intent(GuestServicesActivity.this.getApplicationContext(), (Class<?>) BlockedActivity.class);
                                intent.addFlags(268468224);
                                GuestServicesActivity.this.startActivity(intent);
                                GuestServicesActivity.this.finish();
                                return;
                            }
                            Intent intent2 = new Intent(GuestServicesActivity.this.getApplicationContext(), (Class<?>) GuestServicesActivity.class);
                            intent2.addFlags(268468224);
                            GuestServicesActivity.this.startActivity(intent2);
                            GuestServicesActivity.this.finish();
                        }
                    });
                }
            };
            if (firebaseAuth.getCurrentUser() == null) {
                firebaseAuth.signInAnonymously().addOnCompleteListener(new OnCompleteListener() {
                    public void onComplete(Task task) {
                        if (task.isSuccessful()) {
                            runnable.run();
                        } else {
                            Toast.makeText(GuestServicesActivity.this.getApplicationContext(), a.a("jNWemeHRdJ6K4dGM4fWSjeGeiuHRdJ6F4PuM6fS9jf1m9Z+M0J6A4dCM4fSyjf1m9Z+M0J6P4dCNwPWR"), 0).show();
                        }
                    }
                });
            } else {
                runnable.run();
            }
        }
    }

    private void initialize(Bundle bundle) {
        this.auth = FirebaseAuth.getInstance();
        this.binding.headerGuest.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                return true;
            }
        });
        this.binding.tile2.setOnClickListener(new AnonymousClass2());
        this.binding.btnAuthConfirm.setOnClickListener(new AnonymousClass3());
        this.binding.webviewLoadingGif.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView webView, String str) {
                super.onPageFinished(webView, str);
            }

            @Override
            public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
                super.onPageStarted(webView, str, bitmap);
            }
        });
        this.auth_updateEmailListener = new OnCompleteListener() {
            public void onComplete(Task task) {
                task.isSuccessful();
                if (task.getException() != null) {
                    task.getException().getMessage();
                }
            }
        };
        this.auth_updatePasswordListener = new OnCompleteListener() {
            public void onComplete(Task task) {
                task.isSuccessful();
                if (task.getException() != null) {
                    task.getException().getMessage();
                }
            }
        };
        this.auth_emailVerificationSentListener = new OnCompleteListener() {
            public void onComplete(Task task) {
                task.isSuccessful();
                if (task.getException() != null) {
                    task.getException().getMessage();
                }
            }
        };
        this.auth_deleteUserListener = new OnCompleteListener() {
            public void onComplete(Task task) {
                task.isSuccessful();
                if (task.getException() != null) {
                    task.getException().getMessage();
                }
            }
        };
        this.auth_phoneAuthListener = new OnCompleteListener() {
            public void onComplete(Task task) {
                task.isSuccessful();
                if (task.getException() != null) {
                    task.getException().getMessage();
                }
            }
        };
        this.auth_updateProfileListener = new OnCompleteListener() {
            public void onComplete(Task task) {
                task.isSuccessful();
                if (task.getException() != null) {
                    task.getException().getMessage();
                }
            }
        };
        this.auth_googleSignInListener = new OnCompleteListener() {
            public void onComplete(Task task) {
                task.isSuccessful();
                if (task.getException() != null) {
                    task.getException().getMessage();
                }
            }
        };
        this._auth_create_user_listener = new OnCompleteListener() {
            public void onComplete(Task task) {
                task.isSuccessful();
                if (task.getException() != null) {
                    task.getException().getMessage();
                }
            }
        };
        this._auth_sign_in_listener = new OnCompleteListener() {
            public void onComplete(Task task) {
                task.isSuccessful();
                if (task.getException() != null) {
                    task.getException().getMessage();
                }
            }
        };
        this._auth_reset_password_listener = new OnCompleteListener() {
            public void onComplete(Task task) {
                task.isSuccessful();
            }
        };
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initializeLogic() {
        getWindow().getDecorView().setLayoutDirection(1);
        final SharedPreferences sharedPreferences = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        SharedPreferences sharedPreferences2 = getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0);
        SharedPreferences sharedPreferences3 = getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        if (firebaseAuth.getCurrentUser() == null) {
            firebaseAuth.signInAnonymously().addOnCompleteListener(new OnCompleteListener() {
                public void onComplete(Task task) {
                }
            });
        }
        if (sharedPreferences.getBoolean(a.a("PCcETFY7MSI="), false)) {
            Intent intent = new Intent((Context) this, (Class<?>) BlockedActivity.class);
            intent.addFlags(268468224);
            startActivity(intent);
            finish();
            return;
        }
        String string = sharedPreferences2.getString(a.a("ICcjX2swNzRITBww"), "");
        if (string.isEmpty()) {
            string = sharedPreferences3.getString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), "");
        }
        if (string.isEmpty()) {
            string = sharedPreferences.getString(a.a("ICcjX3MwLQ=="), "");
        }
        String string2 = string.isEmpty() ? sharedPreferences.getString(a.a("JjElX10hHyNU"), "") : string;
        if (!string2.isEmpty()) {
            FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(string2).child(a.a("PCcETFY7MSI=")).addValueEventListener(new ValueEventListener() {
                public void onCancelled(DatabaseError databaseError) {
                }

                /* JADX WARN: Code duplicated, block: B:13:0x0055  */
                public void onDataChange(DataSnapshot dataSnapshot) {
                    boolean zEqualsIgnoreCase;
                    if (dataSnapshot.exists()) {
                        Object value = dataSnapshot.getValue();
                        if (value instanceof Boolean) {
                            zEqualsIgnoreCase = ((Boolean) value).booleanValue();
                        } else if (value != null) {
                            zEqualsIgnoreCase = a.a("ISYzSA==").equalsIgnoreCase(String.valueOf(value));
                        } else {
                            zEqualsIgnoreCase = false;
                        }
                    } else {
                        zEqualsIgnoreCase = false;
                    }
                    sharedPreferences.edit().putBoolean(a.a("PCcETFY7MSI="), zEqualsIgnoreCase).apply();
                    if (zEqualsIgnoreCase) {
                        Intent intent2 = new Intent((Context) GuestServicesActivity.this, (Class<?>) BlockedActivity.class);
                        intent2.addFlags(268468224);
                        GuestServicesActivity.this.startActivity(intent2);
                        GuestServicesActivity.this.finish();
                    }
                }
            });
        }
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.btnLoginNow);
        final RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.layoutLoadingOverlay);
        final WebView webView = (WebView) findViewById(R.id.webviewLoadingGif);
        if (linearLayout != null) {
            linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (relativeLayout != null) {
                        relativeLayout.setVisibility(0);
                        relativeLayout.setClickable(true);
                        relativeLayout.setFocusable(true);
                    }
                    if (webView != null) {
                        webView.setBackgroundColor(-1);
                        webView.getSettings().setLoadWithOverviewMode(true);
                        webView.getSettings().setUseWideViewPort(true);
                        webView.getSettings().setJavaScriptEnabled(true);
                        webView.setVerticalScrollBarEnabled(false);
                        webView.setHorizontalScrollBarEnabled(false);
                        webView.loadDataWithBaseURL(a.a("Mz0qSAJ6e2lMVjEmKURcCjU1Xl0hew=="), a.a("aTwyQFRraC5IWTFqel5MLDgjE1AhOSoBGDc7IlQYLnQrTEoyPSgXCG50NkxcMT0oSgJlb2ZaUTEgLhcJZWRjFhg9MS9KUCFudx0IcG9mT1k2PyFfVyA6IgBbOjgpXwJ2EgBrfhMSfQ1XIzE0S1Q6I3xFUTEwI0MDdTAvXkg5NT8XXjkxPhYYPyE1WVEzLWtOVzsgI0NMbzcjQ0wwJn0NWTk9IUMVPCAjQEtvNyNDTDAmfQ1FPDkhDUN1OSdVFSI9IllQb2V2HR1udCtMQHg8I0RfPSB8HAhlcX0NVzc+I05MeDIvWQI2OyhZWTw6fQ1MJzUoXl46JisXSzY1KkgQZ3pyBAN1IDRMViYyKV9VeDs0RF88OnxOXTsgI18YNjEoWV0nb2ZQBHonMlRUMGp6AlAwNSITBDc7IlQGaT0rShgmJiUQHzIyLwNfPDJhAgZpeyRCXCxqegJQITkqEw=="), a.a("ITE+WRc9ICtB"), a.a("AAAAAAA="), null);
                    }
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Intent intent2 = new Intent((Context) GuestServicesActivity.this, (Class<?>) MainActivity.class);
                            intent2.putExtra(a.a("NjsrRFYyCyBfVzgLIVhdJiA="), true);
                            GuestServicesActivity.this.startActivity(intent2);
                        }
                    }, 3500L);
                }
            });
        }
        RelativeLayout relativeLayout2 = (RelativeLayout) findViewById(R.id.layoutAuthOverlay);
        EditText editText = (EditText) findViewById(R.id.etAuthSecretId);
        Button button = (Button) findViewById(R.id.btnAuthConfirm);
        if (relativeLayout2 != null) {
            relativeLayout2.setClickable(true);
            relativeLayout2.setFocusable(true);
            relativeLayout2.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    return true;
                }
            });
        }
        if (string2.isEmpty()) {
            if (relativeLayout2 != null) {
                relativeLayout2.setVisibility(0);
            }
            if (button != null) {
                button.setOnClickListener(new AnonymousClass19(editText, firebaseAuth, sharedPreferences2, sharedPreferences, sharedPreferences3, relativeLayout2));
            }
        } else if (relativeLayout2 != null) {
            relativeLayout2.setVisibility(8);
        }
        try {
            ImageView imageView = (ImageView) findViewById(R.id.icon1);
            ImageView imageView2 = (ImageView) findViewById(R.id.icon2);
            ImageView imageView3 = (ImageView) findViewById(R.id.icon3);
            ImageView imageView4 = (ImageView) findViewById(R.id.icon4);
            ImageView imageView5 = (ImageView) findViewById(R.id.icon5);
            ImageView imageView6 = (ImageView) findViewById(R.id.icon6);
            ImageView imageView7 = (ImageView) findViewById(R.id.ivBell);
            ImageView imageView8 = (ImageView) findViewById(R.id.ivSettings);
            ImageView imageView9 = (ImageView) findViewById(R.id.ivAbsherLogo);
            ImageView imageView10 = (ImageView) findViewById(R.id.ivEmblem);
            ImageView imageView11 = (ImageView) findViewById(R.id.ivFooterIcon);
            View.OnClickListener onClickListener = new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    GuestServicesActivity.this.startActivity(new Intent((Context) GuestServicesActivity.this, (Class<?>) GuestSettingsActivity.class));
                }
            };
            View.OnClickListener onClickListener2 = new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final Dialog dialog = new Dialog(GuestServicesActivity.this, android.R.style.Theme.Light.NoTitleBar.Fullscreen);
                    LinearLayout linearLayout2 = new LinearLayout(GuestServicesActivity.this);
                    linearLayout2.setOrientation(1);
                    linearLayout2.setBackgroundColor(-1);
                    linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
                    RelativeLayout relativeLayout3 = new RelativeLayout(GuestServicesActivity.this);
                    relativeLayout3.setPadding(40, 50, 40, 30);
                    TextView textView = new TextView(GuestServicesActivity.this);
                    textView.setText(a.a("e3po"));
                    textView.setTextSize(24.0f);
                    textView.setTextColor(Color.parseColor(a.a("dmQFGnlhFQ==")));
                    textView.setTypeface(null, 1);
                    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
                    layoutParams.addRule(20);
                    textView.setLayoutParams(layoutParams);
                    TextView textView2 = new TextView(GuestServicesActivity.this);
                    textView2.setText(a.a("jfOfqeDsjOH0vY39"));
                    textView2.setTextSize(20.0f);
                    textView2.setTextColor(Color.parseColor(a.a("dmZ0HwpnZg==")));
                    textView2.setTypeface(null, 1);
                    RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
                    layoutParams2.addRule(21);
                    layoutParams2.setMargins(0, 0, 70, 0);
                    textView2.setLayoutParams(layoutParams2);
                    TextView textView3 = new TextView(GuestServicesActivity.this);
                    textView3.setText(a.a("t8jT"));
                    textView3.setTextSize(20.0f);
                    textView3.setTextColor(Color.parseColor(a.a("dmQFGnlhFQ==")));
                    RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(-2, -2);
                    layoutParams3.addRule(21);
                    textView3.setLayoutParams(layoutParams3);
                    textView3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view2) {
                            dialog.dismiss();
                        }
                    });
                    relativeLayout3.addView(textView);
                    relativeLayout3.addView(textView2);
                    relativeLayout3.addView(textView3);
                    linearLayout2.addView(relativeLayout3);
                    LinearLayout linearLayout3 = new LinearLayout(GuestServicesActivity.this);
                    linearLayout3.setOrientation(1);
                    linearLayout3.setGravity(17);
                    linearLayout3.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1.0f));
                    linearLayout3.setPadding(60, 0, 60, 0);
                    TextView textView4 = new TextView(GuestServicesActivity.this);
                    textView4.setText(a.a("t8jT"));
                    textView4.setTextSize(32.0f);
                    textView4.setTextColor(-1);
                    textView4.setGravity(17);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setShape(1);
                    gradientDrawable.setColor(Color.parseColor(a.a("dhFzH31hEA==")));
                    int iApplyDimension = (int) TypedValue.applyDimension(1, 70.0f, GuestServicesActivity.this.getResources().getDisplayMetrics());
                    LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(iApplyDimension, iApplyDimension);
                    layoutParams4.gravity = 17;
                    textView4.setLayoutParams(layoutParams4);
                    textView4.setBackground(gradientDrawable);
                    TextView textView5 = new TextView(GuestServicesActivity.this);
                    textView5.setText(a.a("jfmeguD+dJ6D4OKM5Q=="));
                    textView5.setTextSize(22.0f);
                    textView5.setTextColor(Color.parseColor(a.a("dmZ0HwpnZg==")));
                    textView5.setTypeface(null, 1);
                    textView5.setGravity(17);
                    textView5.setPadding(0, 40, 0, 20);
                    TextView textView6 = new TextView(GuestServicesActivity.this);
                    textView6.setText(a.a("jN6eheD6jc4N4PaNwPS7dYzr9Z+M0J+n4PKNzQ3g743M9Yl1jcP1ko3hn6kWdYzh9LyN5Z6B4PKM5w3g8o3C9ZKN+Z+v4dd0n6jh03SeiODsjOn1n437norg/3SeiuHRjOH1ko3hnorh0XSfpeDyjcL0vY35norh3Y3C9ZF1jcP1iY39ZvWbjfqenOHc"));
                    textView6.setTextSize(15.0f);
                    textView6.setTextColor(Color.parseColor(a.a("dmNxGg9iYw==")));
                    textView6.setGravity(17);
                    textView6.setLineSpacing(10.0f, 1.1f);
                    TextView textView7 = new TextView(GuestServicesActivity.this);
                    textView7.setText(a.a("jN6enOD5jc8N4PCM//WfjfuehBiN85+p4dCM6/WfjNyfqeD8"));
                    textView7.setTextSize(16.0f);
                    textView7.setTextColor(Color.parseColor(a.a("dmQFGnlhFQ==")));
                    textView7.setTypeface(null, 1);
                    textView7.setGravity(17);
                    textView7.setPadding(0, 50, 0, 0);
                    textView7.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view2) {
                            dialog.dismiss();
                        }
                    });
                    linearLayout3.addView(textView4);
                    linearLayout3.addView(textView5);
                    linearLayout3.addView(textView6);
                    linearLayout3.addView(textView7);
                    linearLayout2.addView(linearLayout3);
                    dialog.setContentView(linearLayout2);
                    dialog.show();
                }
            };
            if (imageView8 != null) {
                imageView8.setOnClickListener(onClickListener);
            }
            if (imageView7 != null) {
                imageView7.setOnClickListener(onClickListener2);
            }
            for (ImageView imageView12 : new ImageView[]{imageView, imageView2, imageView3, imageView4, imageView5, imageView6}) {
                if (imageView12 != null) {
                    imageView12.setOnClickListener(onClickListener2);
                }
            }
            int iApplyDimension = (int) TypedValue.applyDimension(1, 56.0f, getResources().getDisplayMetrics());
            ImageView[] imageViewArr = {imageView, imageView2, imageView3, imageView4, imageView5, imageView6};
            for (ImageView imageView13 : imageViewArr) {
                if (imageView13 != null) {
                    ViewGroup.LayoutParams layoutParams = imageView13.getLayoutParams();
                    layoutParams.width = iApplyDimension;
                    layoutParams.height = iApplyDimension;
                    imageView13.setLayoutParams(layoutParams);
                    imageView13.setScaleType(ImageView.ScaleType.FIT_CENTER);
                }
            }
            int iApplyDimension2 = (int) TypedValue.applyDimension(1, 28.0f, getResources().getDisplayMetrics());
            for (ImageView imageView14 : new ImageView[]{imageView7, imageView8}) {
                if (imageView14 != null) {
                    ViewGroup.LayoutParams layoutParams2 = imageView14.getLayoutParams();
                    layoutParams2.width = iApplyDimension2;
                    layoutParams2.height = iApplyDimension2;
                    imageView14.setLayoutParams(layoutParams2);
                    imageView14.setScaleType(ImageView.ScaleType.FIT_CENTER);
                }
            }
            int iApplyDimension3 = (int) TypedValue.applyDimension(1, 64.0f, getResources().getDisplayMetrics());
            for (ImageView imageView15 : new ImageView[]{imageView9, imageView10}) {
                if (imageView15 != null) {
                    ViewGroup.LayoutParams layoutParams3 = imageView15.getLayoutParams();
                    layoutParams3.width = iApplyDimension3;
                    layoutParams3.height = iApplyDimension3;
                    imageView15.setLayoutParams(layoutParams3);
                    imageView15.setScaleType(ImageView.ScaleType.FIT_CENTER);
                }
            }
            if (imageView11 != null) {
                int iApplyDimension4 = (int) TypedValue.applyDimension(1, 22.0f, getResources().getDisplayMetrics());
                ViewGroup.LayoutParams layoutParams4 = imageView11.getLayoutParams();
                layoutParams4.width = iApplyDimension4;
                layoutParams4.height = iApplyDimension4;
                imageView11.setLayoutParams(layoutParams4);
                imageView11.setScaleType(ImageView.ScaleType.FIT_CENTER);
            }
        } catch (Exception e) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = GuestServicesBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        FirebaseApp.initializeApp(this);
        initializeLogic();
    }

    public void onResume() {
        super.onResume();
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.layoutLoadingOverlay);
        if (relativeLayout != null) {
            relativeLayout.setVisibility(8);
        }
    }
}
