package com.mhd.absher;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;

public class ServicePlaceholderActivity extends AppCompatActivity {
    public static final String EXTRA_ICON_RES = a.a("MCwyX1kKPSVCVgomI14=");

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.service_placeholder);
        ImageView imageView = (ImageView) findViewById(R.id.ivServiceIcon);
        TextView textView = (TextView) findViewById(R.id.tvMainMessage);
        TextView textView2 = (TextView) findViewById(R.id.tvSubMessage);
        int intExtra = getIntent().getIntExtra(EXTRA_ICON_RES, 0);
        if (intExtra != 0) {
            imageView.setImageResource(intExtra);
        }
        String stringExtra = getIntent().getStringExtra(a.a("IT0yQV0="));
        if (stringExtra != null) {
            textView.setText(stringExtra);
        }
        textView2.setText(a.a("jNOeneHSdJ6K4dGM6PWXjNGehBiN7p+n4OR0n6jg/4zh9ZWN/Wb1lY3zn6nh34zh9LM="));
    }
}
