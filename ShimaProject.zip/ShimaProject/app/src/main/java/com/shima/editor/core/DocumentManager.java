package com.shima.editor.core;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** In-memory tab manager. It stores metadata for all tabs and bounds full buffers with an LRU limit. */
public final class DocumentManager {
  private final int maxOpenBuffers;
  private final LinkedHashMap<String, OpenDocument> documents =
      new LinkedHashMap<String, OpenDocument>(16, .75f, true);
  private final Map<String, UndoRedoManager> histories = new LinkedHashMap<>();
  private String activeId = "";

  public DocumentManager() {
    this(12);
  }

  public DocumentManager(int maxOpenBuffers) {
    this.maxOpenBuffers = Math.max(1, maxOpenBuffers);
  }

  public synchronized OpenDocument open(
      String path, CharSequence text, boolean readOnly, Charset encoding, OpenDocument.LineEnding ending) {
    String id = path == null ? "" : path;
    OpenDocument existing = documents.get(id);
    if (existing != null) {
      activeId = id;
      return existing;
    }
    OpenDocument document =
        new OpenDocument(
            id,
            id,
            text == null ? "" : text,
            readOnly,
            encoding == null ? StandardCharsets.UTF_8 : encoding,
            ending);
    documents.put(id, document);
    histories.put(id, new UndoRedoManager());
    activeId = id;
    trimInactive();
    return document;
  }

  public synchronized OpenDocument select(String path) {
    if (path == null || !documents.containsKey(path)) return null;
    activeId = path;
    documents.get(path); // touch access order
    return documents.get(path);
  }

  public synchronized OpenDocument active() {
    return documents.get(activeId);
  }

  public synchronized OpenDocument get(String path) {
    return documents.get(path);
  }

  public synchronized List<OpenDocument> snapshot() {
    return Collections.unmodifiableList(new ArrayList<>(documents.values()));
  }

  public synchronized boolean close(String path) {
    if (path == null || !documents.containsKey(path)) return false;
    documents.remove(path);
    histories.remove(path);
    if (path.equals(activeId)) activeId = documents.isEmpty() ? "" : documents.keySet().iterator().next();
    return true;
  }

  public synchronized void closeAll() {
    documents.clear();
    histories.clear();
    activeId = "";
  }

  public synchronized void replace(String path, long start, long end, CharSequence value) {
    OpenDocument document = documents.get(path);
    if (document == null || document.readOnly) throw new IllegalStateException("المستند غير قابل للتحرير");
    String before = document.document.readRange(start, end).toString();
    document.document.replace(start, end, value);
    document.dirty = true;
    histories.get(path).record(start, before, value == null ? "" : value.toString());
  }

  public synchronized boolean undo(String path) {
    OpenDocument document = documents.get(path);
    UndoRedoManager history = histories.get(path);
    if (document == null || history == null) return false;
    boolean changed = history.undo(document.document);
    if (changed) document.dirty = true;
    return changed;
  }

  public synchronized boolean redo(String path) {
    OpenDocument document = documents.get(path);
    UndoRedoManager history = histories.get(path);
    if (document == null || history == null) return false;
    boolean changed = history.redo(document.document);
    if (changed) document.dirty = true;
    return changed;
  }

  private void trimInactive() {
    while (documents.size() > maxOpenBuffers) {
      String oldest = documents.keySet().iterator().next();
      if (oldest.equals(activeId)) {
        String next = documents.keySet().iterator().next();
        oldest = next;
      }
      documents.remove(oldest);
      histories.remove(oldest);
    }
  }
}
