package com.almlkid.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.*;
import android.widget.*;
import com.almlkid.kay.ui.AlmlkEditor;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.EditorSearchEngine;
import com.almlkid.kay.ui.KayStyleCompletionEngine;
import com.almlkid.kay.ui.ProjectDiagnostic;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.ui.SmaliDefinitionResolver;
import almlk.JavaImportOrganizer;
import com.shima.demo.R;
import com.shima.demo.UiStrings;
import com.shima.demo.ThemeConfig;
import com.shima.performance.EditorTextSnapshot;
import com.shima.performance.EncodingManager;
import com.shima.performance.FileSystemRepository;
import com.shima.performance.InstantSessionStore;
import com.shima.editor.core.AtomicSaveManager;
import com.shima.editor.core.SavePolicy;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Multi-tab editor with file header, line numbers and a keyboard-only quick-key bar. */
public class AIDEEditorPager extends LinearLayout {
  private static final int EXPAND_SELECTION = 0x53484D42;
  private static final int MORE_MENU = 0x53484D47;

  public interface QuickFixListener {
    void createMissingMember(ProjectSymbolIndex.MissingMember member);
  }

  public interface SessionListener {
    void restored(boolean success);
  }

  public interface DefinitionListener {
    void requested(ProjectSymbolIndex.DefinitionTarget target);
  }

  public interface UsageListener {
    void requested(String fileName, String source, int selectionStart, int selectionEnd);
  }

  public interface DiagnosticsListener {
    void updated(String fileName, String reference, String source,
        List<CodeLanguageTools.Diagnostic> diagnostics);
  }

  public interface FileChangedListener {
    void changed(String fileName, String reference);
  }

  public interface ReplaceListener {
    void completed(int replacements);
  }

  /** مساهمة أداة اختيار حية؛ null يعني أن الأداة غير ظاهرة في السياق الحالي. */
  public interface SelectionToolContributor {
    EditorMenuRegistry.DynamicCommand contribute(EditorMenuRegistry.Context context);
  }

  public interface DefinitionRequestListener {
    void requested(String fileName, String source, int selectionStart, int selectionEnd);
  }

  private final LinkedHashMap<String, LinearLayout> tabs = new LinkedHashMap<>();
  private final LinkedHashMap<String, String> fileContents = new LinkedHashMap<>();
  // The legacy map is kept only so old sessions can be ignored safely; new sessions never write
  // source content to disk.
  private final LinkedHashMap<String, java.io.File> lazySessionFiles = new LinkedHashMap<>();
  private final LinkedHashMap<String, String> lazySessionReferences = new LinkedHashMap<>();
  private final LinkedHashMap<String, String> sessionReferences = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionCursors = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionScrollX = new LinkedHashMap<>();
  private final LinkedHashMap<String, Integer> sessionScrollY = new LinkedHashMap<>();
  private LinearLayout tabStrip, quickBar, quickKeys;
  private View fileHeader;
  private View editorRow;
  private TextView headerName, headerPath;
  private ImageView headerIcon;
  private AlmlkEditor code;
  private String activeFile;
  private String loadingFile;
  // بند الإحلال: التراجع/الإعادة مدمجان في موديل almlk (UndoRedoStack) — لا تاريخ خارجي.
  private boolean historyLocked;
  private boolean keyboardVisible, dismissedForCurrentKeyboard;
  private QuickFixListener quickFixListener;
  private DefinitionListener definitionListener;
  private DefinitionRequestListener definitionRequestListener;
  private UsageListener usageListener;
  private DiagnosticsListener diagnosticsListener;
  private FileChangedListener fileChangedListener;
  private List<ProjectDiagnostic> projectDiagnostics = Collections.emptyList();
  private int quickFixGeneration, definitionGeneration, goToGeneration;
  private final EditorMenuRegistry editorMenuRegistry = new EditorMenuRegistry();
  private final ArrayList<ProjectSymbolIndex.MissingMember> pendingQuickFixes = new ArrayList<>();
  private long pendingQuickFixVersion = -1;
  private int pendingQuickFixStart = -1, pendingQuickFixEnd = -1;
  private final ArrayList<SelectionToolContributor> selectionToolContributors = new ArrayList<>();
  private PopupWindow completionWindow;
  private ListView completionList;
  private EditorCompletionAdapter completionAdapter;
  private java.util.concurrent.ExecutorService completionWorker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  // Session restore/file reads use a separate lane so they never delay typing or completion.
  private java.util.concurrent.ExecutorService sessionWorker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  // Completion lookups must not queue behind session restore, file I/O, or definition requests.
  private java.util.concurrent.ExecutorService completionLookupWorker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  private FileSystemRepository fileRepository;
  private AtomicSaveManager autoSaveManager;
  private InstantSessionStore sessionStore;
  private java.util.concurrent.Future<?> autoSaveTask;
  private final Runnable autoSaveRunnable = this::queueAutoSave;
  private int completionGeneration;
  // The snapshot is updated by changed ranges on the UI thread and copied only on the worker.
  private final EditorTextSnapshot completionSnapshot = new EditorTextSnapshot();
  private final CompletionLookupCache completionCache = new CompletionLookupCache();
  private java.util.concurrent.Future<?> completionLookupFuture;
  private long lastEditorErrorTime;
  private final Runnable completionTask = this::showLiveCompletions;
  private int largestVisibleHeight;

  public AIDEEditorPager(Context c) {
    super(c);
    init();
  }

  public AIDEEditorPager(Context c, AttributeSet a) {
    super(c, a);
    init();
  }

  public AIDEEditorPager(Context c, AttributeSet a, int s) {
    super(c, a, s);
    init();
  }

  private void init() {
    fileRepository = new FileSystemRepository(getContext());
    autoSaveManager = new AtomicSaveManager(getContext());
    // Constructed from the worker below: SharedPreferences may initialize from disk once.
    setLayoutDirection(LAYOUT_DIRECTION_LTR);
    setOrientation(VERTICAL);
    setBackgroundColor(Color.BLACK);
    addTabs();
    addFileHeader();
    addEditor();
    addQuickKeys();
    applyTheme();
    watchKeyboard();
    setVisibility(GONE);
  }

  private void addTabs() {
    HorizontalScrollView scroll = new HorizontalScrollView(getContext());
    scroll.setHorizontalScrollBarEnabled(false);
    scroll.setFillViewport(true);
    scroll.setBackgroundColor(Color.rgb(34, 34, 34));
    tabStrip = new LinearLayout(getContext());
    tabStrip.setOrientation(HORIZONTAL);
    tabStrip.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    scroll.addView(tabStrip, new HorizontalScrollView.LayoutParams(-2, -1));
    addView(scroll, new LayoutParams(-1, dp(46)));
  }

  private void addFileHeader() {
    LinearLayout header = new LinearLayout(getContext());
    header.setOrientation(HORIZONTAL);
    header.setGravity(Gravity.CENTER_VERTICAL);
    header.setPadding(dp(12), dp(5), dp(12), dp(5));
    header.setBackgroundColor(Color.BLACK);
    header.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    headerIcon = new ImageView(getContext());
    headerIcon.setImageResource(R.drawable.file_type_java);
    headerIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
    header.addView(headerIcon, new LinearLayout.LayoutParams(dp(48), dp(48)));
    LinearLayout labels = new LinearLayout(getContext());
    labels.setOrientation(VERTICAL);
    labels.setPadding(dp(8), 0, 0, 0);
    headerName = text("MainActivity.java", 17, Color.WHITE);
    headerName.setTypeface(null, Typeface.BOLD);
    headerName.setSingleLine(false);
    headerName.setMaxLines(2);
    headerName.setEllipsize(android.text.TextUtils.TruncateAt.END);
    headerPath = text("/storage/emulated/0/AppProjects", 12, Color.LTGRAY);
    headerPath.setSingleLine(true);
    headerPath.setEllipsize(android.text.TextUtils.TruncateAt.START);
    labels.addView(headerName, new LinearLayout.LayoutParams(-1, 0, 1));
    labels.addView(headerPath, new LinearLayout.LayoutParams(-1, 0, 1));
    header.addView(labels, new LinearLayout.LayoutParams(0, -1, 1));
    fileHeader = header;
    addView(header, new LayoutParams(-1, dp(61)));
    View line = new View(getContext());
    line.setBackgroundColor(Color.rgb(41, 182, 246));
    addView(line, new LayoutParams(-1, dp(2)));
  }

  private void addEditor() {
    LinearLayout row = new LinearLayout(getContext());
    row.setOrientation(HORIZONTAL);
    row.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    row.setBackgroundColor(Color.BLACK);
    editorRow = row;
    // بند الإحلال: أرقام الأسطر داخلية في لوحة الرسم (الجالتر) — لا View خارجية.
    code = new AlmlkEditor(getContext());
    applyEditorSettings();
    code.setLineSpacing(dp(3), 1);
    code.setChangeListener(version -> {
      if (!historyLocked && loadingFile == null) {
        removeCallbacks(autoSaveRunnable);
        postDelayed(autoSaveRunnable, 850L);
        FileChangedListener listener = fileChangedListener;
        if (listener != null && activeFile != null)
          listener.changed(activeFile, getActiveFileReference());
      }
    });
    code.setDiagnosticsListener(
        items -> {
          DiagnosticsListener listener = diagnosticsListener;
          if (listener != null && activeFile != null)
            listener.updated(
                activeFile,
                getActiveFileReference(),
                code.getText().toString(),
                items == null ? Collections.emptyList() : items);
        });
    code.setCustomSelectionActionModeCallback(
        new ActionMode.Callback() {
          private PopupWindow selectionMenu;
          private String selectionMenuPage;
          private boolean actionModeActive;

          @Override
          public boolean onCreateActionMode(ActionMode mode, android.view.Menu menu) {
            actionModeActive = true;
            code.normalizeSelectionToTouchedIdentifier();
            // بند 3 — فتح قائمة التحديد يجب ألا يهزّ لوحة المفاتيح: إن كانت ظاهرة قبل القائمة
            // تُعاد إلى وضعها فور بدء وضع الإجراء حتى لا تختفي ثم تعود.
            android.graphics.Rect imeFrame = new android.graphics.Rect();
            code.getWindowVisibleDisplayFrame(imeFrame);
            int imeHeightDiff = code.getRootView().getHeight() - imeFrame.bottom;
            boolean imeWasVisible =
                imeHeightDiff > getResources().getDisplayMetrics().density * 100;
            if (imeWasVisible) {
              final android.view.inputmethod.InputMethodManager imm =
                  (android.view.inputmethod.InputMethodManager)
                      getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
              if (imm != null) {
                code.postDelayed(
                    () -> {
                      if (actionModeActive && code.hasFocus()) imm.showSoftInput(code, 0);
                    },
                    80);
              }
            }
            // شريط التحديد: قص/نسخ عند وجود مدى؛ وفي الفراغ يظهر لصق + تحديد الكل مباشرة.
            // بقية الأوامر النصية تبقى في القائمة المتدرجة التي يفتحها المزيد.
            mode.setTitle(UiStrings.get(getContext(), "ui_selection_title"));
            styleSelectionIcon(menu, almlk.CodeEditorView.ID_CUT, R.drawable.ic_vectoric_cut);
            styleSelectionIcon(menu, almlk.CodeEditorView.ID_COPY, R.drawable.ic_vectoric_copy);
            styleSelectionIcon(menu, almlk.CodeEditorView.ID_PASTE, R.drawable.ic_vectoric_paste);
            new android.view.MenuInflater(getContext())
                .inflate(R.menu.editor_selection_toolbar, menu);
            android.view.MenuItem builtinSelectAll =
                menu.findItem(almlk.CodeEditorView.ID_SELECT_ALL);
            if (builtinSelectAll != null) builtinSelectAll.setVisible(false);
            styleSelectionIcon(
                menu, R.id.editor_selection_select_all, R.drawable.ic_vectoric_select_all);
            android.view.MenuItem expand = menu.add(0, EXPAND_SELECTION, 0, UiStrings.get(getContext(), "keybind_expand_selection"));
            expand.setIcon(R.drawable.ic_vectoric_expand);
            expand.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);
            android.view.MenuItem more = menu.add(0, MORE_MENU, 9, UiStrings.get(getContext(), "command_more"));
            more.setIcon(R.drawable.ic_vectoric_more);
            more.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);
            applySelectionToolbarState(menu);
            return true;
          }

          @Override
          public boolean onPrepareActionMode(ActionMode mode, android.view.Menu menu) {
            applySelectionToolbarState(menu);
            if (selectionMenu != null && selectionMenu.isShowing()) {
              final String page = selectionMenuPage;
              post(() -> {
                if (actionModeActive) showSelectionMenu(mode, page);
              });
            }
            return true;
          }

          /** نافذة مدمجة بعرض محتوى (~dp250) برأس أزرق للفرعية — شكل لقطات المرجع. */
          /**
           * معاملة اللون: لقطة نسخة/مدى عند الفتح، ثم تحقق ذري عند OK. الإلغاء لا يستدعي أي
           * كتابة، والتأكيد الناجح يمر باستبدال واحد فقط فتكون له خطوة Undo واحدة.
           */
          private void editSelectedColor(ActionMode mode) {
            if (!isActiveFileWritable()) {
              Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_file_read_only"), Toast.LENGTH_SHORT).show();
              return;
            }
            final AlmlkEditor.ColorLiteralEdit edit = code.beginColorLiteralEdit();
            if (edit == null) return;
            net.margaritov.preference.colorpicker.ColorPickerDialog picker =
                new net.margaritov.preference.colorpicker.ColorPickerDialog(
                    getContext(), edit.originalArgb());
            picker.setTitle(UiStrings.get(getContext(), "command_color"));
            picker.setAlphaSliderVisible(true);
            picker.setHexValueEnabled(true);
            picker.setOnColorChangedListener(
                color -> {
                  if (!isActiveFileWritable()) {
                    Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_read_only_no_change"), Toast.LENGTH_SHORT)
                        .show();
                    mode.finish();
                    return;
                  }
                  AlmlkEditor.ColorLiteralEditResult result =
                      code.applyColorLiteralEdit(edit, color);
                  if (result == AlmlkEditor.ColorLiteralEditResult.STALE) {
                    Toast.makeText(
                            getContext(),
                            UiStrings.get(getContext(), "ui_color_document_changed"),
                            Toast.LENGTH_LONG)
                        .show();
                  }
                  mode.finish();
                });
            picker.show();
          }

          /** يعرض الجذر فورًا ثم يضيف إصلاح Java حقيقيًا فقط إن نتج؛ XML لا يمر بالمحلل الجافوي. */
          private void probeQuickFixThenShow(ActionMode mode) {
            clearPendingQuickFixes();
            showSelectionMenu(mode, EditorMenuRegistry.PAGE_ROOT);
            final int request = ++quickFixGeneration;
            if (isXmlFile()) return; // MissingMember مفهوم جافوي؛ مزود إصلاحات XML غير منفَّذ بعد.
            final int selectionStart = code.getSelectionStart();
            final int selectionEnd = code.getSelectionEnd();
            final long documentVersion = code.getDocument().version();
            final String source = code.getText().toString();
            completionWorker.execute(
                () -> {
                  ProjectSymbolIndex.MissingMember result = null;
                  try {
                    result = ProjectSymbolIndex.analyzeSelection(source, selectionStart, selectionEnd);
                  } catch (Throwable ignored) {
                  }
                  final ProjectSymbolIndex.MissingMember found = result;
                  post(
                      () -> {
                        if (request != quickFixGeneration || found == null
                            || code.getDocument().version() != documentVersion
                            || code.getSelectionStart() != selectionStart
                            || code.getSelectionEnd() != selectionEnd) return;
                        clearPendingQuickFixes();
                        pendingQuickFixVersion = documentVersion;
                        pendingQuickFixStart = selectionStart;
                        pendingQuickFixEnd = selectionEnd;
                        pendingQuickFixes.add(found);
                        mode.invalidate();
                        if (selectionMenu != null && selectionMenu.isShowing()
                            && EditorMenuRegistry.PAGE_ROOT.equals(selectionMenuPage))
                          showSelectionMenu(mode, EditorMenuRegistry.PAGE_ROOT);
                      });
                });
          }

          private void showSelectionMenu(ActionMode mode, String page) {
            selectionMenuPage = page;
            if (selectionMenu != null) selectionMenu.dismiss();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            LinearLayout container =
                (LinearLayout) inflater.inflate(R.layout.ide_overflow_menu, null, false);
            String headerKey = editorMenuRegistry.titleForPage(page);
            String header = headerKey == null ? null : UiStrings.get(getContext(), headerKey);
            if (header != null) {
              View headerRow = inflater.inflate(R.layout.ide_overflow_entry, container, false);
              TextView headerTitle = headerRow.findViewById(R.id.ideOverflowEntryTitle);
              headerRow.findViewById(R.id.ideOverflowEntryArrow).setVisibility(GONE);
              headerTitle.setText(header);
              headerTitle.setTextColor(Color.rgb(41, 182, 246));
              headerRow.setOnClickListener(
                  v -> showSelectionMenu(mode, EditorMenuRegistry.PAGE_ROOT));
              container.addView(headerRow);
            }
            EditorMenuRegistry.Context context = editorMenuContext(mode);
            for (EditorMenuRegistry.Entry entry : editorMenuRegistry.entries(page, context)) {
              View rowView = inflater.inflate(R.layout.ide_overflow_entry, container, false);
              TextView titleView = rowView.findViewById(R.id.ideOverflowEntryTitle);
              TextView arrowView = rowView.findViewById(R.id.ideOverflowEntryArrow);
              String localizedTitle = UiStrings.get(getContext(), entry.title);
              String localizedReason =
                  entry.disabledReason.isEmpty()
                      ? ""
                      : UiStrings.get(getContext(), entry.disabledReason);
              if (entry.enabled || localizedReason.isEmpty()) {
                titleView.setText(localizedTitle);
              } else {
                titleView.setMaxLines(2);
                titleView.setTextSize(14);
                titleView.setText(localizedTitle + "\n" + localizedReason);
              }
              arrowView.setVisibility(entry.isSubmenu() ? VISIBLE : GONE);
              rowView.setEnabled(entry.enabled);
              rowView.setAlpha(entry.enabled ? 1f : 0.48f);
              rowView.setContentDescription(
                  localizedReason.isEmpty()
                      ? localizedTitle
                      : localizedTitle + ": " + localizedReason);
              rowView.setOnClickListener(v -> {
                if (!v.isEnabled()) return;
                if (entry.isSubmenu()) {
                  showSelectionMenu(mode, entry.subpage);
                  return;
                }
                selectionMenu.dismiss();
                if (entry.dynamicAction != null) post(entry.dynamicAction);
                else post(() -> executeEditorMenuCommand(entry.id, mode));
              });
              container.addView(rowView);
            }
            selectionMenu =
                new PopupWindow(container, dp(250), ViewGroup.LayoutParams.WRAP_CONTENT, false);
            // عزل تام عن الكيبورد: غير focusable فلا تخطف التركيز ولا تُخفي الكيبورد،
            // ولا تُعاد قياسها عند تغيّر حالته — فلا رعشة ولا إغلاق فوري (علّة «المزيد»).
            selectionMenu.setInputMethodMode(PopupWindow.INPUT_METHOD_NOT_NEEDED);
            selectionMenu.setSoftInputMode(
                android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED);
            selectionMenu.setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(Color.rgb(48, 48, 48)));
            selectionMenu.setOutsideTouchable(true);
            selectionMenu.setElevation(dp(10));
            selectionMenu.setAnimationStyle(android.R.style.Animation_Dialog);
            selectionMenu.showAtLocation(
                AIDEEditorPager.this, Gravity.TOP | Gravity.END, dp(6), dp(30));
          }

          /** التنفيذ الوحيد للأوامر الثابتة؛ أوامر النطاق تنفذ قبل finish لأن teardown يمحو التحديد. */
          private void executeEditorMenuCommand(String id, ActionMode mode) {
            switch (id) {
              case "color":
                editSelectedColor(mode);
                break;
              case "goto":
                resolveDefinitionOnDemand(mode);
                break;
              case "documentation":
                // التوثيق يقرأ التحديد الحالي؛ نبقي ActionMode كما في المسار السابق.
                runHostCommand("documentation");
                break;
              case "organize_imports":
                organizeImports();
                mode.finish();
                break;
              case "surround_try":
                surroundWithTryCatch();
                mode.finish();
                break;
              case "comment":
                commentLines();
                mode.finish();
                break;
              case "uncomment":
                uncommentLines();
                mode.finish();
                break;
              case "replace": {
                int from = code.getSelectionStart();
                int to = code.getSelectionEnd();
                String selectedText = almlk.CodeMenuCommands.selectedText(
                    code.getText().toString(), from, to);
                mode.finish();
                runHostCommand("replace", selectedText);
                break;
              }
              case "format_code":
                formatSource();
                mode.finish();
                break;
              case "configure_style":
                // المرحلة الثامنة: الإعدادات شاشة مضيف، فلا تُنفَّذ داخل المحرر.
                mode.finish();
                runHostCommand("configure_style");
                break;
              case "find_usages":
              case "find_extended":
                // مسار Java لكلا البندين؛ وفي XML يبحثان عن اسم المورد بعد تثبيت المدى (المرحلة السابعة).
                resolveUsagesOnDemand(mode);
                break;
              case "find_text":
                mode.finish();
                runHostCommand("find");
                break;
              case "rename":
                // التقط الرمز وافتح الحوار بينما المدى ما زال محفوظًا.
                renameCurrentSelection();
                mode.finish();
                break;
              case "inline":
                refactorInline();
                mode.finish();
                break;
              case "introduce":
                refactorIntroduce();
                mode.finish();
                break;
              case "extract_method":
                refactorExtract();
                mode.finish();
                break;
              case "breakpoint":
                mode.finish();
                boolean bpSet = code.toggleBreakpointAtCaret();
                Toast.makeText(
                        getContext(),
                        UiStrings.get(getContext(), bpSet ? "ui_breakpoint_added" : "ui_breakpoint_removed"),
                        Toast.LENGTH_SHORT)
                    .show();
                break;
              case "learn_style":
                mode.finish();
                runHostCommand("learn_style");
                break;
              case "create_setters": {
                int selectionStart = code.getSelectionStart();
                int selectionEnd = code.getSelectionEnd();
                mode.finish();
                codegenSetters(selectionStart, selectionEnd);
                break;
              }
              case "create_constructor": {
                int selectionStart = code.getSelectionStart();
                int selectionEnd = code.getSelectionEnd();
                mode.finish();
                codegenConstructor(selectionStart, selectionEnd);
                break;
              }
              case "extract_resources":
                codegenExtractResource();
                mode.finish();
                break;
              case "close":
                mode.finish();
                runHostCommand("close_file");
                break;
              default:
                break; // الأوامر غير المنفذة معطلة أصلًا في السجل مع سبب ظاهر.
            }
          }

          private void resolveDefinitionOnDemand(ActionMode mode) {
            final int rawSelectionStart = code.getSelectionStart();
            final int rawSelectionEnd = code.getSelectionEnd();
            final int selectionStart = Math.min(rawSelectionStart, rawSelectionEnd);
            final int selectionEnd = Math.max(rawSelectionStart, rawSelectionEnd);
            final String source = code.getText().toString();
            final String sourceFile = activeFile;
            mode.finish();
            final int request = ++definitionGeneration;
            completionWorker.execute(
                () -> {
                  try {
                    final ProjectSymbolIndex.DefinitionTarget target =
                        sourceFile.toLowerCase(java.util.Locale.US).endsWith(".smali")
                            ? SmaliDefinitionResolver.resolve(
                                sourceFile, source, selectionStart, selectionEnd)
                            : ProjectSymbolIndex.resolveDefinition(
                                sourceFile, source, selectionStart, selectionEnd);
                    post(
                        () -> {
                          if (request != definitionGeneration) return;
                          if (target != null && definitionListener != null) {
                            if (usageListener != null
                                && ProjectSymbolIndex.isDefinitionSelection(
                                    sourceFile, source, selectionStart, selectionEnd, target)) {
                              usageListener.requested(
                                  sourceFile, source, selectionStart, selectionEnd);
                            } else {
                              definitionListener.requested(target);
                            }
                          } else if (target == null && definitionRequestListener != null) {
                            definitionRequestListener.requested(
                                sourceFile, source, selectionStart, selectionEnd);
                          } else {
                            Toast.makeText(
                                    getContext(),
                                    UiStrings.get(getContext(), "ui_error_definition_not_found"),
                                    Toast.LENGTH_SHORT)
                                .show();
                          }
                        });
                  } catch (Throwable error) {
                    post(
                        () -> {
                          if (request == definitionGeneration) showEditorError(error);
                        });
                  }
                });
          }

          private void resolveUsagesOnDemand(ActionMode mode) {
            final String source = code.getText().toString();
            final int[] snapped = usageSelection(source, code.getSelectionStart(), code.getSelectionEnd());
            final int selectionStart = snapped[0];
            final int selectionEnd = snapped[1];
            final String sourceFile = activeFile;
            mode.finish();
            final int request = ++definitionGeneration;
            completionWorker.execute(
                () ->
                    post(
                        () -> {
                          if (request != definitionGeneration) return;
                          if (usageListener != null)
                            usageListener.requested(sourceFile, source, selectionStart, selectionEnd);
                        }));
          }

          @Override
          public boolean onActionItemClicked(ActionMode mode, android.view.MenuItem item) {
            int id = item.getItemId();
            if (id == R.id.editor_selection_select_all) {
              code.selectAll();
              return true;
            }
            if (id == android.R.id.selectAll
                || id == android.R.id.cut
                || id == android.R.id.copy
                || id == android.R.id.paste) {
              boolean handled = code.onTextContextMenuItem(id);
              if (handled && id != android.R.id.selectAll) mode.finish();
              return handled;
            }
            if (id == EXPAND_SELECTION) {
              expandCodeSelection();
              return true;
            }
            if (id == MORE_MENU) {
              probeQuickFixThenShow(mode);
              return true;
            }
            return false;
          }

          @Override
          public void onDestroyActionMode(ActionMode mode) {
            actionModeActive = false;
            quickFixGeneration++;
            definitionGeneration++;
            clearPendingQuickFixes();
            if (selectionMenu != null) {
              selectionMenu.dismiss();
              selectionMenu = null;
            }
          }
        });
    code.addTextChangedListener(
        new android.text.TextWatcher() {
          public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // التراجع/الإعادة مدمجان بموديل المحرك (بند الإحلال) — لا تتبع خارجي.
          }

          public void onTextChanged(CharSequence s, int start, int before, int count) {
            completionSnapshot.applyChange(s, start, before, count);
            cancelCompletionLookup();
            if (!historyLocked
                && isXmlFile()
                && count == 1
                && start > 0
                && start < s.length()
                && s.charAt(start - 1) == '<'
                && s.charAt(start) == '/') {
              final int marker = start + 1;
              post(() -> completeXmlClosingTag(marker));
            }
            pendingEdits = true;
            removeCallbacks(completionTask);
            completionGeneration++;
            if (!historyLocked) {
              boolean refreshCompletions = false;
              if (count > 0 && start + count <= s.length()) {
                char last = s.charAt(start + count - 1);
                boolean identLast = Character.isJavaIdentifierPart(last) && last != '.';
                refreshCompletions =
                    (identLast && almlk.AppSettings.completeAfterLetter(getContext()))
                        || (last == '.' && almlk.AppSettings.completeAfterDot(getContext()))
                        || last == '<'
                        || last == ':'
                        || last == '@';
              } else if (count == 0 && before > 0 && start > 0 && start <= s.length()) {
                char previous = s.charAt(start - 1);
                boolean identPrev = Character.isJavaIdentifierPart(previous) && previous != '.';
                refreshCompletions =
                    (identPrev && almlk.AppSettings.completeAfterLetter(getContext()))
                        || (previous == '.' && almlk.AppSettings.completeAfterDot(getContext()));
              }
              if (refreshCompletions) postDelayed(completionTask, 24);
              else dismissCompletions();
            } else dismissCompletions();
          }

          public void afterTextChanged(android.text.Editable e) {
            // كل تعديل قد يقلب أهلية التراجع/الإعادة — الشريط يلتقطها لحظيًا كالمرجع.
            notifyHistoryState();
          }
        });
    row.addView(code, new LinearLayout.LayoutParams(0, -1, 1));
    addView(row, new LayoutParams(-1, 0, 1));
  }

  /** مزود أدوات اختيار قابل للتوسعة؛ الأب «أدوات..» يختفي إن لم ينتج أي مساهم أمرًا ظاهرًا. */
  public void addSelectionToolContributor(SelectionToolContributor contributor) {
    if (contributor != null && !selectionToolContributors.contains(contributor))
      selectionToolContributors.add(contributor);
  }

  public void removeSelectionToolContributor(SelectionToolContributor contributor) {
    selectionToolContributors.remove(contributor);
  }

  private void clearPendingQuickFixes() {
    pendingQuickFixes.clear();
    pendingQuickFixVersion = -1;
    pendingQuickFixStart = pendingQuickFixEnd = -1;
  }

  private boolean pendingQuickFixContextCurrent() {
    return code != null
        && pendingQuickFixVersion == code.getDocument().version()
        && pendingQuickFixStart == code.getSelectionStart()
        && pendingQuickFixEnd == code.getSelectionEnd();
  }

  private EditorMenuRegistry.Context editorMenuContext(ActionMode mode) {
    EditorMenuRegistry.Context context = new EditorMenuRegistry.Context();
    context.xml = isXmlFile();
    context.layoutXml = isActiveLayoutXml();
    context.writable = isActiveFileWritable();
    context.hasOpenFile = hasOpenFile();
    context.hasSelection = code != null && code.hasSelection();
    context.hasText = code != null && code.length() > 0;
    context.hasFieldTarget = code != null && !context.xml && activeFile != null
        && activeFile.toLowerCase(java.util.Locale.US).endsWith(".java")
        && almlk.CodeGen.hasFieldTarget(code.getText().toString(),
            code.getSelectionStart(), code.getSelectionEnd());
    context.hasColor = code != null && code.colorLiteralForSelection() != null;
    context.hasClipboardText = code != null && code.hasClipboardText();
    int[] expanded = expandedCodeSelectionRange();
    context.canExpand = expanded != null;

    ArrayList<EditorMenuRegistry.DynamicCommand> fixes = new ArrayList<>();
    int currentFixCount = pendingQuickFixContextCurrent() ? pendingQuickFixes.size() : 0;
    for (int i = 0; i < currentFixCount && i < 6; i++) {
      final ProjectSymbolIndex.MissingMember fix = pendingQuickFixes.get(i);
      fixes.add(
          new EditorMenuRegistry.DynamicCommand(
              "fix." + i,
              UiStrings.format(
                  getContext(), "ui_quick_fix_create_method", fix.methodName, fix.className),
              context.writable && quickFixListener != null,
              !context.writable
                  ? UiStrings.get(getContext(), "ui_file_read_only")
                  : (quickFixListener == null
                      ? UiStrings.get(getContext(), "ui_no_quick_fix_executor")
                      : ""),
              () -> {
                // تحقق ثانٍ لحظة التنفيذ: لا يُطبَّق إصلاح من لقطة مستند/تحديد باهتة.
                if (!pendingQuickFixContextCurrent()) {
                  Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_quick_fix_context_changed"), Toast.LENGTH_SHORT)
                      .show();
                  return;
                }
                if (!isActiveFileWritable()) {
                  Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_file_read_only"), Toast.LENGTH_SHORT).show();
                  return;
                }
                if (mode != null) mode.finish();
                if (quickFixListener != null) quickFixListener.createMissingMember(fix);
              }));
    }
    context.fixes = fixes;

    ArrayList<EditorMenuRegistry.DynamicCommand> tools = new ArrayList<>();
    for (int i = 0; i < selectionToolContributors.size(); i++) {
      try {
        EditorMenuRegistry.DynamicCommand command =
            selectionToolContributors.get(i).contribute(context);
        if (command != null) tools.add(command);
      } catch (Throwable ignored) {
        // مساهم خارجي معطوب لا يسقط قائمة المحرر ولا يولّد أبًا فارغًا.
      }
    }
    context.tools = tools;
    return context;
  }

  private void applySelectionToolbarState(android.view.Menu menu) {
    EditorMenuRegistry.Context context = editorMenuContext(null);
    int[] toolbarIds = {
      EXPAND_SELECTION,
      almlk.CodeEditorView.ID_CUT,
      almlk.CodeEditorView.ID_COPY,
      almlk.CodeEditorView.ID_PASTE,
      R.id.editor_selection_select_all,
      MORE_MENU
    };
    for (int toolbarId : toolbarIds) {
      android.view.MenuItem item = menu.findItem(toolbarId);
      if (item != null) item.setVisible(false);
    }
    for (EditorMenuRegistry.Entry entry :
        editorMenuRegistry.entries(EditorMenuRegistry.PAGE_TOOLBAR, context)) {
      int itemId;
      switch (entry.id) {
        case "expand": itemId = EXPAND_SELECTION; break;
        case "cut": itemId = almlk.CodeEditorView.ID_CUT; break;
        case "copy": itemId = almlk.CodeEditorView.ID_COPY; break;
        case "paste": itemId = almlk.CodeEditorView.ID_PASTE; break;
        case "select_all": itemId = R.id.editor_selection_select_all; break;
        case "more": itemId = MORE_MENU; break;
        default: continue;
      }
      android.view.MenuItem item = menu.findItem(itemId);
      if (item == null) continue;
      item.setVisible(true);
      item.setEnabled(entry.enabled);
      String localizedTitle = UiStrings.get(getContext(), entry.title);
      String localizedReason =
          entry.disabledReason.isEmpty() ? "" : UiStrings.get(getContext(), entry.disabledReason);
      item.setTitle(localizedTitle);
      if (android.os.Build.VERSION.SDK_INT >= 26)
        item.setContentDescription(
            localizedReason.isEmpty() ? localizedTitle : localizedTitle + ": " + localizedReason);
    }
  }

  private boolean isActiveLayoutXml() {
    if (!isXmlFile()) return false;
    String reference = getActiveFileReference();
    String path = android.net.Uri.decode(reference == null || reference.isEmpty() ? activeFile : reference)
        .replace('\\', '/')
        .toLowerCase(java.util.Locale.US);
    if (!path.endsWith(".xml")) return false;
    int slash = path.lastIndexOf('/');
    if (slash <= 0) return false;
    int parentSlash = path.lastIndexOf('/', slash - 1);
    String parent = path.substring(parentSlash + 1, slash);
    return "layout".equals(parent) || parent.startsWith("layout-");
  }

  private boolean isActiveFileWritable() {
    if (!hasOpenFile()) return false;
    // Virtual Android/JDK classes are source views only, never editor destinations.
    if (activeFile.toLowerCase(java.util.Locale.US).endsWith(".class")) return false;
    String reference = getActiveFileReference();
    if (reference == null || reference.isEmpty()) return true;
    try {
      android.net.Uri uri = android.net.Uri.parse(reference);
      if ("content".equalsIgnoreCase(uri.getScheme())) {
        androidx.documentfile.provider.DocumentFile file =
            androidx.documentfile.provider.DocumentFile.fromSingleUri(getContext(), uri);
        return file == null || file.canWrite();
      }
      String path = "file".equalsIgnoreCase(uri.getScheme()) ? uri.getPath() : reference;
      java.io.File file = new java.io.File(path == null ? reference : path);
      return !file.exists() || file.canWrite();
    } catch (Throwable ignored) {
      return true;
    }
  }

  private int[] expandedCodeSelectionRange() {
    if (code == null) return null;
    String text = code.getText().toString();
    int start = Math.max(0, Math.min(code.getSelectionStart(), code.getSelectionEnd()));
    int end = Math.min(text.length(), Math.max(code.getSelectionStart(), code.getSelectionEnd()));
    int left = start, right = end;
    while (left > 0 && Character.isJavaIdentifierPart(text.charAt(left - 1))) left--;
    while (right < text.length() && Character.isJavaIdentifierPart(text.charAt(right))) right++;
    int dotBefore = left - 1;
    while (dotBefore >= 0 && Character.isWhitespace(text.charAt(dotBefore))) dotBefore--;
    if (dotBefore >= 0 && text.charAt(dotBefore) == '.') {
      left = dotBefore;
      while (left > 0 && Character.isJavaIdentifierPart(text.charAt(left - 1))) left--;
    }
    int cursor = right;
    while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
    if (cursor < text.length() && text.charAt(cursor) == '.') {
      cursor++;
      while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
      while (cursor < text.length() && Character.isJavaIdentifierPart(text.charAt(cursor)))
        cursor++;
    }
    while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
    if (cursor < text.length() && text.charAt(cursor) == '(') {
      int depth = 0;
      char quote = 0;
      boolean escape = false;
      for (int i = cursor; i < text.length(); i++) {
        char value = text.charAt(i);
        if (quote != 0) {
          if (escape) escape = false;
          else if (value == '\\') escape = true;
          else if (value == quote) quote = 0;
        } else if (value == '"' || value == '\'') quote = value;
        else if (value == '(') depth++;
        else if (value == ')' && --depth == 0) {
          right = i + 1;
          break;
        }
      }
    } else right = Math.max(right, cursor);
    if (left == start && right == end) {
      left = text.lastIndexOf('\n', start - 1) + 1;
      int lineEnd = text.indexOf('\n', end);
      right = lineEnd < 0 ? text.length() : lineEnd;
    }
    if (left < right && (left != start || right != end)) return new int[] {left, right};
    return null;
  }

  private void expandCodeSelection() {
    int[] range = expandedCodeSelectionRange();
    if (range != null) code.setSelection(range[0], range[1]);
  }

  private void addQuickKeys() {
    quickBar = new LinearLayout(getContext());
    quickBar.setOrientation(HORIZONTAL);
    quickBar.setGravity(Gravity.CENTER_VERTICAL);
    quickBar.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    quickBar.setBackgroundColor(Color.rgb(31, 31, 31));
    quickBar.setElevation(dp(6));
    quickBar.setContentDescription(UiStrings.get(getContext(), "ui_selection_toolbar_content_description"));
    HorizontalScrollView scroll = new HorizontalScrollView(getContext());
    scroll.setHorizontalScrollBarEnabled(false);
    scroll.setFillViewport(false);
    quickKeys = new LinearLayout(getContext());
    quickKeys.setOrientation(HORIZONTAL);
    quickKeys.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    buildQuickKeys();
    scroll.addView(quickKeys, new HorizontalScrollView.LayoutParams(-2, -1));
    quickBar.addView(scroll, new LinearLayout.LayoutParams(0, dp(42), 1));
    TextView close = text("×", 28, Color.WHITE);
    close.setGravity(Gravity.CENTER);
    close.setBackgroundColor(Color.rgb(31, 31, 31));
    close.setOnClickListener(
        v -> {
          dismissedForCurrentKeyboard = true;
          quickBar.setVisibility(GONE);
        });
    quickBar.addView(close, new LinearLayout.LayoutParams(dp(46), dp(42)));
    addView(quickBar, new LayoutParams(-1, dp(42)));
    quickBar.setVisibility(GONE);
  }

  private void watchKeyboard() {
    getViewTreeObserver()
        .addOnGlobalLayoutListener(
            () -> {
              Rect area = new Rect();
              getWindowVisibleDisplayFrame(area);
              int current = area.height();
              if (current > largestVisibleHeight) largestVisibleHeight = current;
              int total = getRootView().getHeight();
              boolean visible =
                  (largestVisibleHeight - current) > Math.max(dp(170), largestVisibleHeight / 6)
                      || (total - area.bottom) > Math.max(dp(170), total / 6);
              if (visible != keyboardVisible) {
                keyboardVisible = visible;
                if (!visible) {
                  dismissedForCurrentKeyboard = false;
                  dismissCompletions();
                  quickBar.setVisibility(GONE);
                  fileHeader.setVisibility(VISIBLE);
                } else {
                  fileHeader.setVisibility(GONE);
                  if (!dismissedForCurrentKeyboard && !quickBarDisabled())
                    quickBar.setVisibility(VISIBLE);
                }
              }
            });
  }

  private static final class SessionData {
    String selected;
    final LinkedHashMap<String, String> files = new LinkedHashMap<>();
  }

  public void restoreSessionAsync(SessionListener listener) {
    // Only metadata is read here. The selected file is loaded later, on demand.
    sessionWorker.execute(
        () -> {
          if (sessionStore == null) sessionStore = new InstantSessionStore(getContext());
          InstantSessionStore.Snapshot snapshot = sessionStore.load();
          if (snapshot.tabs.isEmpty()) {
            restoreSessionInBackground(listener); // one-time compatibility with old builds
            return;
          }
          post(() -> applyInstantSession(snapshot, listener));
        });
  }

  private void applyInstantSession(InstantSessionStore.Snapshot snapshot, SessionListener listener) {
    lazySessionReferences.clear();
    sessionReferences.clear();
    sessionCursors.clear();
    sessionScrollX.clear();
    sessionScrollY.clear();
    // تقرير فتح الملفات — مُطهّر الجلسة (checkOpenFile على طريقة AIDE): تُسقط التبويبات التي
    // مرجعها ملف محذوف — لكن فقط عندما يكون التحقق ممكنًا فعليًا (وصول مباشر للتخزين)،
    // وإلا بقيت المراجع محفوظة ليُعاد تحميلها بعد منح الإذن (لا ضياع للجلسة).
    final boolean canVerifyFiles = canVerifyFileExistence();
    int restored = 0;
    for (InstantSessionStore.Tab tab : snapshot.tabs) {
      if (canVerifyFiles
          && tab.reference != null
          && tab.reference.startsWith("/")
          && !new java.io.File(tab.reference).isFile()) {
        continue; // مرجع ميّت — لا تبويبات وهمية تتعطل لاحقًا.
      }
      if (!tabs.containsKey(tab.name)) addTab(tab.name);
      sessionReferences.put(tab.name, tab.reference);
      if (!tab.reference.isEmpty()) lazySessionReferences.put(tab.name, tab.reference);
      sessionCursors.put(tab.name, tab.cursor);
      sessionScrollX.put(tab.name, tab.scrollX);
      sessionScrollY.put(tab.name, tab.scrollY);
      restored++;
    }
    // دلالة checkOpenFile المرجعية: اللقطة المنقّاة تُكتب فورًا — لا عودة للمراجع الميتة.
    final boolean pruned = restored < snapshot.tabs.size();
    if (restored == 0) {
      if (pruned)
        sessionWorker.execute(
            () -> {
              if (sessionStore == null) sessionStore = new InstantSessionStore(getContext());
              sessionStore.clear();
            });
      if (listener != null) listener.restored(false);
      return;
    }
    String first =
        snapshot.selected != null && tabs.containsKey(snapshot.selected)
            ? snapshot.selected
            : tabs.keySet().iterator().next();
    setVisibility(VISIBLE);
    if (listener != null) listener.restored(true);
    postOnAnimation(
        () -> {
          selectFile(first);
          if (pruned) saveSession();
        });
  }

  /** التحقق من الوجود ممكن فقط مع وصول مباشر للتخزين (وإلا false-سلبي يقتل تبويبات سليمة). */
  private boolean canVerifyFileExistence() {
    if (android.os.Build.VERSION.SDK_INT < 30) return true;
    try {
      return android.os.Environment.isExternalStorageManager();
    } catch (Throwable ignored) {
      return false;
    }
  }

  private void restoreSessionInBackground(SessionListener listener) {
    java.io.File session = new java.io.File(getContext().getFilesDir(), "editor-session.bin");
    if (!session.isFile()) {
      if (listener != null) post(() -> listener.restored(false));
      return;
    }
    try (java.io.DataInputStream input =
        new java.io.DataInputStream(
            new java.io.BufferedInputStream(new java.io.FileInputStream(session)))) {
      int version = input.readInt();
      String selected = input.readUTF();
      int count = Math.min(12, Math.max(0, input.readInt()));
      if (version == 4 || version == 3) {
        LinkedHashMap<String, java.io.File> lazyFiles = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> cursors = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> scrollXs = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> scrollYs = new LinkedHashMap<>();
        java.io.File directory = new java.io.File(getContext().getFilesDir(), "session-tabs");
        for (int i = 0; i < count; i++) {
          String name = input.readUTF();
          String storedName = input.readUTF();
          lazyFiles.put(name, new java.io.File(directory, storedName));
          if (version == 4) {
            cursors.put(name, Math.max(0, input.readInt()));
            scrollXs.put(name, Math.max(0, input.readInt()));
            scrollYs.put(name, Math.max(0, input.readInt()));
          }
        }
        post(() -> applyLazySession(selected, lazyFiles, cursors, scrollXs, scrollYs, listener));
        return;
      }
      if (version == 2 && count > 0) {
        String firstName = input.readUTF();
        String firstContent = readSessionContent(input);
        post(
            () -> {
              applyFirstSessionFile(firstName, firstContent);
              if (listener != null) listener.restored(true);
            });
        SessionData remaining = new SessionData();
        remaining.selected = selected;
        for (int i = 1; i < count; i++) {
          String name = input.readUTF();
          remaining.files.put(name, readSessionContent(input));
        }
        if (!remaining.files.isEmpty()) post(() -> appendSessionFiles(remaining));
        return;
      }
      if (version != 1) throw new java.io.IOException("Unsupported session version");
      SessionData legacy = new SessionData();
      legacy.selected = selected;
      for (int i = 0; i < count; i++) {
        String name = input.readUTF();
        legacy.files.put(name, readSessionContent(input));
      }
      post(
          () -> {
            boolean success = applyLegacySession(legacy);
            if (listener != null) listener.restored(success);
          });
    } catch (Exception error) {
      session.delete();
      post(
          () -> {
            if (listener != null) listener.restored(false);
          });
    }
  }

  private String readSessionContent(java.io.DataInputStream input) throws java.io.IOException {
    int length = input.readInt();
    if (length < 0 || length > 1200000) throw new java.io.IOException("Invalid session file");
    byte[] bytes = new byte[length];
    input.readFully(bytes);
    return EncodingManager.decodeUtf8(bytes);
  }

  private void applyLazySession(
      String selected,
      LinkedHashMap<String, java.io.File> files,
      LinkedHashMap<String, Integer> cursors,
      LinkedHashMap<String, Integer> scrollXs,
      LinkedHashMap<String, Integer> scrollYs,
      SessionListener listener) {
    if (files.isEmpty()) {
      if (listener != null) listener.restored(false);
      return;
    }
    lazySessionFiles.clear();
    lazySessionFiles.putAll(files);
    sessionCursors.clear();
    sessionCursors.putAll(cursors);
    sessionScrollX.clear();
    sessionScrollX.putAll(scrollXs);
    sessionScrollY.clear();
    sessionScrollY.putAll(scrollYs);
    for (String name : files.keySet()) if (!tabs.containsKey(name)) addTab(name);
    String first = files.containsKey(selected) ? selected : files.keySet().iterator().next();
    setVisibility(VISIBLE);
    if (listener != null) listener.restored(true);
    postOnAnimation(() -> selectFile(first));
  }

  private void applyFirstSessionFile(String name, String content) {
    if (!tabs.containsKey(name)) addTab(name);
    fileContents.put(name, content);
    selectFile(name);
    setVisibility(VISIBLE);
  }

  private void appendSessionFiles(SessionData data) {
    for (Map.Entry<String, String> entry : data.files.entrySet()) {
      if (!tabs.containsKey(entry.getKey())) addTab(entry.getKey());
      fileContents.put(entry.getKey(), entry.getValue());
    }
  }

  private boolean applyLegacySession(SessionData data) {
    if (data == null || data.files.isEmpty()) return false;
    for (Map.Entry<String, String> entry : data.files.entrySet()) {
      if (!tabs.containsKey(entry.getKey())) addTab(entry.getKey());
      fileContents.put(entry.getKey(), entry.getValue());
    }
    selectFile(tabs.containsKey(data.selected) ? data.selected : tabs.keySet().iterator().next());
    setVisibility(VISIBLE);
    return true;
  }

  private void queueAutoSave() {
    if (autoSaveManager == null || activeFile == null || code == null || loadingFile != null) return;
    String reference = sessionReferences.get(activeFile);
    if (reference == null || reference.isEmpty()) return;
    // The copy is delayed until the debounce has elapsed, so typing itself never copies the full
    // document or touches disk on the UI thread.
    String snapshot = code.getText().toString();
    autoSaveManager.requestSave(activeFile, reference, snapshot, SavePolicy.editorDefault(), null);
  }

  public void saveSession() {
    removeCallbacks(autoSaveRunnable);
    rememberActiveViewport();
    // تقرير فتح الملفات — لا نعيد كتابة نص الـ placeholder فوق محتوى الفتح المؤجل.
    if (activeFile != null
        && code != null
        && !activeFile.equals(loadingFile)
        && !openingFiles.contains(activeFile))
      fileContents.put(activeFile, code.getText().toString());
    final String selected = activeFile == null ? "" : activeFile;
    final ArrayList<InstantSessionStore.Tab> metadata = new ArrayList<>();
    for (String name : tabs.keySet()) {
      if (metadata.size() >= InstantSessionStore.MAX_TABS) break;
      metadata.add(
          new InstantSessionStore.Tab(
              name,
              sessionReferences.containsKey(name) ? sessionReferences.get(name) : "",
              sessionCursors.containsKey(name) ? sessionCursors.get(name) : 0,
              sessionScrollX.containsKey(name) ? sessionScrollX.get(name) : 0,
              sessionScrollY.containsKey(name) ? sessionScrollY.get(name) : 0));
    }
    final InstantSessionStore.Snapshot snapshot =
        new InstantSessionStore.Snapshot(selected, metadata);
    sessionWorker.execute(
        () -> {
          if (sessionStore == null) sessionStore = new InstantSessionStore(getContext());
          sessionStore.save(snapshot);
          // Remove content snapshots produced by pre-architecture versions.
          deleteQuietly(new java.io.File(getContext().getFilesDir(), "editor-session.bin"));
          deleteTree(new java.io.File(getContext().getFilesDir(), "session-tabs"));
        });
  }

  private void deleteQuietly(java.io.File file) {
    if (file != null) file.delete();
  }

  private void deleteTree(java.io.File file) {
    if (file == null || !file.exists()) return;
    if (file.isDirectory()) {
      java.io.File[] children = file.listFiles();
      if (children != null) for (java.io.File child : children) deleteTree(child);
    }
    file.delete();
  }

  // Legacy v1-v4 reader/writer retained only for one-time migration; saveSession() never calls it.
  private void writeSession(
      String selected,
      LinkedHashMap<String, String> snapshot,
      LinkedHashMap<String, Integer> cursors,
      LinkedHashMap<String, Integer> scrollXs,
      LinkedHashMap<String, Integer> scrollYs,
      LinkedHashMap<String, java.io.File> lazyFiles) {
    java.io.File target = new java.io.File(getContext().getFilesDir(), "editor-session.bin");
    java.io.File temporary = new java.io.File(getContext().getFilesDir(), "editor-session.tmp");
    java.io.File directory = new java.io.File(getContext().getFilesDir(), "session-tabs");
    if (snapshot.isEmpty()) {
      target.delete();
      temporary.delete();
      return;
    }
    directory.mkdirs();
    try (java.io.DataOutputStream output =
        new java.io.DataOutputStream(
            new java.io.BufferedOutputStream(new java.io.FileOutputStream(temporary)))) {
      output.writeInt(4);
      output.writeUTF(selected);
      output.writeInt(snapshot.size());
      for (Map.Entry<String, String> entry : snapshot.entrySet()) {
        String storedName = sessionFileName(entry.getKey());
        java.io.File storedFile = new java.io.File(directory, storedName);
        String content = entry.getValue();
        if (content != null) writeSessionTab(storedFile, content);
        else {
          java.io.File previous = lazyFiles.get(entry.getKey());
          if (!storedFile.isFile() && previous != null && previous.isFile())
            copyFile(previous, storedFile);
          if (!storedFile.isFile()) writeSessionTab(storedFile, "");
        }
        output.writeUTF(entry.getKey());
        output.writeUTF(storedName);
        output.writeInt(cursors.containsKey(entry.getKey()) ? cursors.get(entry.getKey()) : 0);
        output.writeInt(scrollXs.containsKey(entry.getKey()) ? scrollXs.get(entry.getKey()) : 0);
        output.writeInt(scrollYs.containsKey(entry.getKey()) ? scrollYs.get(entry.getKey()) : 0);
      }
    } catch (Exception error) {
      temporary.delete();
      return;
    }
    if (target.exists()) target.delete();
    temporary.renameTo(target);
  }

  private String sessionFileName(String name) {
    int forward = name.hashCode();
    int reverse = new StringBuilder(name).reverse().toString().hashCode();
    return Integer.toHexString(forward) + "-" + Integer.toHexString(reverse) + ".txt";
  }

  private void writeSessionTab(java.io.File target, String content) throws java.io.IOException {
    byte[] bytes = EncodingManager.encodeUtf8(content);
    if (bytes.length > 1200000) bytes = new byte[0];
    java.io.File temporary = new java.io.File(target.getParentFile(), target.getName() + ".tmp");
    try (java.io.FileOutputStream output = new java.io.FileOutputStream(temporary)) {
      output.write(bytes);
      output.flush();
    }
    if (target.exists()) target.delete();
    if (!temporary.renameTo(target)) throw new java.io.IOException("Session tab rename failed");
  }

  private void copyFile(java.io.File source, java.io.File target) throws java.io.IOException {
    try (java.io.FileInputStream input = new java.io.FileInputStream(source);
        java.io.FileOutputStream output = new java.io.FileOutputStream(target)) {
      byte[] buffer = new byte[8192];
      int read;
      while ((read = input.read(buffer)) >= 0) output.write(buffer, 0, read);
    }
  }

  public void openFile(String name) {
    openFile(name, null, "");
  }

  public void openFile(String name, String content) {
    openFile(name, content, "");
  }

  /** Opens a tab and associates it with a stable file path/SAF URI for metadata-only restore. */
  public void openFile(String name, String content, String reference) {
    if (name == null || name.trim().isEmpty()) return;
    name = uniqueTabNameFor(name, reference);
    if (!tabs.containsKey(name)) addTab(name);
    String safeReference = reference == null ? "" : reference;
    if (!safeReference.isEmpty()) sessionReferences.put(name, safeReference);
    lazySessionFiles.remove(name);
    lazySessionReferences.remove(name);
    openingFiles.remove(name);
    if (content != null) fileContents.put(name, content);
    else if (!fileContents.containsKey(name) && safeReference.isEmpty()) {
      String systemSource = ProjectSymbolIndex.systemSourceForFile(name);
      fileContents.put(name, systemSource == null ? sample(name) : systemSource);
    }
    selectFile(name);
    setVisibility(VISIBLE);
  }

  /**
   * تقرير فتح الملفات — «فتح فوري» على طريقة AIDE: التبويب يُنشأ ويُنتقل إليه لحظة النقرة
   * بمحتوى مؤقت «جارٍ فتح الملف…»، ثم تقرأ almlk.FileContentService (خدمة مستقرة لا تموت مع
   * إغلاق الدرج أو تبديل اللوحات) وتحقن المحتوى دون إعادة بناء التبويب.
   */
  public void openFilePending(String name, String reference) {
    if (name == null || name.trim().isEmpty()) return;
    final String tabName = uniqueTabNameFor(name, reference);
    if (!tabs.containsKey(tabName)) addTab(tabName);
    final String safeReference = reference == null ? "" : reference;
    if (!safeReference.isEmpty()) sessionReferences.put(tabName, safeReference);
    lazySessionFiles.remove(tabName);
    lazySessionReferences.remove(tabName);
    // ملف مفتوح من قبل ومحتواه حي → انتقال فوري بلا أي قراءة (أسرع مسار في AIDE).
    // لكن placeholder عتيق (من جولة غير مكتملة) لا يعدّ محتوى — يعاد فتحه.
    String existing = fileContents.get(tabName);
    if (existing != null && !PendingOpen.TEXT.equals(existing)) {
      selectFile(tabName);
      setVisibility(VISIBLE);
      return;
    }
    openingFiles.add(tabName);
    fileContents.put(tabName, PendingOpen.TEXT);
    selectFile(tabName);
    setVisibility(VISIBLE);
    almlk.FileContentService.get()
        .open(
            getContext(),
            tabName,
            safeReference,
            (fileName, success, content) -> {
              if (!tabName.equals(fileName)) return;
              openingFiles.remove(tabName);
              // النجاح فقط يُخزَّن محتوى؛ الفشل نصّ مرئي عابر حتى تبقى إعادة النقر
              // محاولة قراءة جديدة لا مشاهدة عطل قديم.
              if (success) fileContents.put(tabName, content);
              else fileContents.remove(tabName);
              if (!tabName.equals(activeFile) || code == null) return;
              historyLocked = true;
              code.setHint(null);
              code.setText(content);
              historyLocked = false;
              restoreViewport(tabName);
              code.setAnalysisPaused(false);
              code.post(code::refreshNow);
              if (tabName.equals(pendingMatchFile)) {
                final int line = pendingMatchLine, column = pendingMatchColumn;
                pendingMatchFile = null;
                code.post(() -> goToMatch(tabName, line, column));
              }
            });
  }

  private static final class PendingOpen {
    static final String TEXT = "\u0000shima-pending-open\u0000";
  }

  /** أسماء التبويبات في حالة فتح مؤجل — تقرّر عوضًا عنها الوصول الحقيقي للمحتوى. */
  private final java.util.HashSet<String> openingFiles = new java.util.HashSet<>();

  private void addTab(String name) {
    LinearLayout holder = new LinearLayout(getContext());
    holder.setOrientation(VERTICAL);
    TextView label = text(name, 14, Color.LTGRAY);
    label.setGravity(Gravity.CENTER);
    label.setSingleLine(false);
    label.setMaxLines(2);
    label.setEllipsize(android.text.TextUtils.TruncateAt.END);
    label.setPadding(dp(10), 0, dp(10), 0);
    holder.addView(label, new LinearLayout.LayoutParams(dp(175), 0, 1));
    View line = new View(getContext());
    holder.addView(line, new LinearLayout.LayoutParams(-1, dp(3)));
    holder.setOnClickListener(v -> selectFile(name));
    holder.setOnLongClickListener(
        v -> {
          showTabMenu(v, name);
          return true;
        });
    tabs.put(name, holder);
    tabStrip.addView(holder, new LinearLayout.LayoutParams(dp(175), -1));
  }

  // ======== قائمة الضغط المطول على التبويب — بهيكل filetab_menu المرجعي ========

  /** يُستدعى حين تفرغ التبويبات من قائمة التبويب — تضبطه MainActivity لإظهار الواجهة الفارغة. */
  private Runnable tabsClosedListener;

  public void setTabsClosedListener(Runnable listener) {
    tabsClosedListener = listener;
  }

  /** قائمة التبويب المرجعية: إغلاق (فرعية: إغلاق/إغلاق البقية/إغلاق الكل) + أوامر الجافا. */
  private void showTabMenu(View anchor, String name) {
    android.widget.PopupMenu menu = new android.widget.PopupMenu(getContext(), anchor);
    android.view.SubMenu close =
        menu.getMenu().addSubMenu(0, 401, 0, UiStrings.get(getContext(), "ui_action_close"));
    close.add(0, 402, 0, UiStrings.get(getContext(), "ui_action_close"));
    close.add(0, 403, 1, UiStrings.get(getContext(), "ui_close_others"));
    close.add(0, 404, 2, UiStrings.get(getContext(), "menu_close_all"));
    boolean javaTab = name.toLowerCase(java.util.Locale.US).endsWith(".java");
    if (javaTab) {
      menu.getMenu().add(0, 405, 1, UiStrings.get(getContext(), "command_organize_imports"));
      menu.getMenu().add(0, 406, 2, UiStrings.get(getContext(), "command_format_code"));
    }
    menu.setOnMenuItemClickListener(
        item -> {
          switch (item.getItemId()) {
            case 402:
              closeTab(name);
              return true;
            case 403:
              closeOthers(name);
              return true;
            case 404:
              closeAll();
              saveSession();
              if (tabsClosedListener != null) tabsClosedListener.run();
              return true;
            case 405:
              runOnTab(name, this::organizeImports);
              return true;
            case 406:
              runOnTab(name, this::formatSource);
              return true;
            default:
              return false;
          }
        });
    menu.show();
  }

  /** تنفيذ أمر على تبويب محدد: تحديده أولًا إن لم يكن النشط ثم التنفيذ بعد اكتمال التحميل. */
  private void runOnTab(String name, Runnable command) {
    if (name.equals(activeFile)) {
      command.run();
      return;
    }
    selectFile(name);
    post(
        () -> {
          if (!name.equals(activeFile)) return;
          if (!openingFiles.contains(name)) {
            command.run();
            return;
          }
          // تحميل كسول لم يكتمل بعد — محاولة أخيرة بعد مهلة قصيرة.
          postDelayed(
              () -> {
                if (name.equals(activeFile) && !openingFiles.contains(name)) command.run();
              },
              400);
        });
  }

  /** إغلاق تبويب محدد بالاسم — نفس تنظيف closeCurrent مع اختيار جارٍ للبقاء. */
  public void closeTab(String name) {
    if (name == null || !tabs.containsKey(name)) return;
    LinearLayout tab = tabs.remove(name);
    if (tab != null) tabStrip.removeView(tab);
    fileContents.remove(name);
    lazySessionFiles.remove(name);
    lazySessionReferences.remove(name);
    sessionReferences.remove(name);
    sessionCursors.remove(name);
    sessionScrollX.remove(name);
    sessionScrollY.remove(name);
    openingFiles.remove(name);
    boolean wasActive = name.equals(activeFile);
    if (tabs.isEmpty()) {
      activeFile = null;
      code.setText("");
      setVisibility(GONE);
      saveSession();
      if (tabsClosedListener != null) tabsClosedListener.run();
      return;
    }
    if (wasActive) {
      activeFile = null;
      selectFile(tabs.keySet().iterator().next());
    }
    saveSession();
  }

  /** إغلاق كل التبويبات عدا المحدد — بند «إغلاق البقية» المرجعي. */
  public void closeOthers(String name) {
    if (name == null || !tabs.containsKey(name)) return;
    for (String other : new ArrayList<>(tabs.keySet())) {
      if (other.equals(name)) continue;
      LinearLayout tab = tabs.remove(other);
      if (tab != null) tabStrip.removeView(tab);
      fileContents.remove(other);
      lazySessionFiles.remove(other);
      lazySessionReferences.remove(other);
      sessionReferences.remove(other);
      sessionCursors.remove(other);
      sessionScrollX.remove(other);
      sessionScrollY.remove(other);
      openingFiles.remove(other);
    }
    if (!name.equals(activeFile)) {
      activeFile = null;
      selectFile(name);
    }
    saveSession();
  }

  // ======== تفريد أسماء التبويبات — ملفان بنفس الاسم لا يتصادمان (build.gradle الأب/الابن) ========

  /**
   * إن وجد تبويب بنفس الاسم لكن بمرجع مختلف، يُولَّد اسم عرض يتضمن المجلد الأب
   * (app/build.gradle) وصعودًا حتى التفرد، ولاحقة رقمية للمراجع غير المسارية.
   */
  private String uniqueTabNameFor(String name, String reference) {
    String safeReference = reference == null ? "" : reference;
    if (safeReference.isEmpty()) return name;
    if (!collides(name, safeReference)) return name;
    if (safeReference.startsWith("/")) {
      String[] parts = safeReference.replace('\\', '/').split("/");
      String candidate = name;
      for (int up = parts.length - 2; up >= 1; up--) {
        candidate = parts[up] + "/" + candidate;
        if (!collides(candidate, safeReference)) return candidate;
      }
    }
    for (int n = 2; n < 100; n++) {
      String candidate = name + " (" + n + ")";
      if (!collides(candidate, safeReference)) return candidate;
    }
    return name;
  }

  /** تصادم: تبويب موجود بهذا الاسم ومرجعه المعروف مختلف عن المطلوب فتحه. */
  private boolean collides(String name, String reference) {
    if (!tabs.containsKey(name)) return false;
    String existing = sessionReferences.get(name);
    return existing != null && !existing.isEmpty() && !existing.equals(reference);
  }

  private void rememberActiveViewport() {
    if (activeFile == null || code == null) return;
    sessionCursors.put(activeFile, Math.max(0, code.getSelectionStart()));
    sessionScrollX.put(activeFile, Math.max(0, code.getScrollX()));
    sessionScrollY.put(activeFile, Math.max(0, code.getScrollY()));
  }

  private void restoreViewport(String name) {
    int cursor = sessionCursors.containsKey(name) ? sessionCursors.get(name) : 0;
    int x = sessionScrollX.containsKey(name) ? sessionScrollX.get(name) : 0;
    int y = sessionScrollY.containsKey(name) ? sessionScrollY.get(name) : 0;
    code.post(
        () -> {
          if (!name.equals(activeFile)) return;
          code.setSelection(Math.min(Math.max(0, cursor), code.length()));
          code.scrollTo(x, y);
        });
  }

  private void selectFile(String name) {
    goToGeneration++;
    dismissCompletions();
    cancelCompletionLookup();
    // تبديل الملف قبل اكتمال قفزة بحث معلقة في ملف آخر يلغيها حتى لا تنفذ لاحقًا فجأة.
    if (pendingMatchFile != null && !pendingMatchFile.equals(name)) pendingMatchFile = null;
    completionCache.clear();
    rememberActiveViewport();
    if (name != null && !name.equals(activeFile)) pushNavigationPoint();
    // تقرير فتح الملفات — لا نعيد كتابة نص الـ placeholder فوق محتوى الفتح المؤجل.
    if (activeFile != null
        && code != null
        && !activeFile.equals(loadingFile)
        && !openingFiles.contains(activeFile))
      fileContents.put(activeFile, code.getText().toString());
    activeFile = name;
    applyProjectDiagnosticsToActiveFile();
    notifyHistoryState(); // تبديل التبويب يحدّث شريط الأدوات (زر المعاينة/أهلية التراجع).
    for (String key : tabs.keySet()) {
      LinearLayout h = tabs.get(key);
      TextView label = (TextView) h.getChildAt(0);
      boolean active = key.equals(name);
      label.setTextColor(active ? Color.WHITE : Color.LTGRAY);
      label.setTypeface(null, active ? Typeface.BOLD : Typeface.NORMAL);
      h.getChildAt(1).setBackgroundColor(active ? Color.rgb(41, 182, 246) : Color.TRANSPARENT);
    }
    // الرأس: الاسم القصير (بلا بادئة التفريد) + المسار الحقيقي للملف إن كان مرجعه معروفًا.
    String shortName = name == null ? "" : name.substring(name.lastIndexOf('/') + 1);
    headerName.setText(shortName);
    headerIcon.setImageResource(iconForFile(name == null ? "" : name));
    String headerReference = name == null ? null : sessionReferences.get(name);
    if (headerReference != null && headerReference.startsWith("/")) {
      int cut = headerReference.lastIndexOf('/');
      headerPath.setText(cut > 0 ? headerReference.substring(0, cut) : headerReference);
    } else if (name != null
        && name.toLowerCase(java.util.Locale.US).endsWith(".class")) {
      int cut = name.lastIndexOf('/');
      String packageName = cut > 0 ? name.substring(0, cut).replace('/', '.') : "";
      headerPath.setText(
          packageName.isEmpty() ? "Android SDK" : "Android SDK · " + packageName);
    } else headerPath.setText("/storage/emulated/0/AppProjects/" + UiStrings.get(getContext(), "ui_default_project_folder_name") + "/" + shortName);
    historyLocked = true;
    String lazyReference = lazySessionReferences.get(name);
    java.io.File legacyLazyFile = lazySessionFiles.get(name);
    boolean lazyRestore =
        !fileContents.containsKey(name)
            && ((lazyReference != null && !lazyReference.isEmpty()) || legacyLazyFile != null);
    code.setAnalysisPaused(lazyRestore);
    code.setFileName(name);
    // Keep the core range model aligned with the currently visible tab before the next setText
    // callback applies the replacement incrementally.
    code.resetCoreModel(name, code.getText());
    if (lazyRestore) {
      loadingFile = name;
      code.setHint(R.string.session_restoring_file);
      code.setText("");
      loadLazySessionReference(
          name, lazyReference != null && !lazyReference.isEmpty()
              ? lazyReference
              : legacyLazyFile.getAbsolutePath());
    } else {
      loadingFile = null;
      code.setHint(null);
      String displayedContent = fileContents.get(name);
      if (PendingOpen.TEXT.equals(displayedContent))
        displayedContent = UiStrings.get(getContext(), "ui_pending_open_file");
      if (displayedContent == null) displayedContent = ProjectSymbolIndex.systemSourceForFile(name);
      code.setText(displayedContent != null ? displayedContent : sample(name));
      restoreViewport(name);
    }
    historyLocked = false;
    code.clearHistory();
    if (!lazyRestore) code.refreshNow();
    scheduleIdleSessionSave();
    lastFileSelectTime = System.currentTimeMillis();
  }

  // تقرير 03 — حفظ الجلسة عند الخمول: metadata فقط بعد 800ms من آخر تنقل بين التبويبات.
  private final Runnable idleSessionSave = this::saveSession;

  private void scheduleIdleSessionSave() {
    removeCallbacks(idleSessionSave);
    postDelayed(idleSessionSave, 800);
  }

  /** تقرير 01/03 — تحرير كاشات الذاكرة المؤقتة عند طلب النظام onTrimMemory. */
  public void trimMemoryCaches() {
    completionCache.clear();
    dismissCompletions();
  }

  /** المرحلة 4: رموز الشريط السريع من الإعداد (quick_key_symbol) أو الافتراضيات. */
  private void buildQuickKeys() {
    quickKeys.removeAllViews();
    String custom =
        almlk.AppSettings.prefs(getContext()).getString("quick_key_symbol", "");
    java.util.List<String> values = new java.util.ArrayList<>();
    if (custom == null || custom.trim().isEmpty()) {
      java.util.Collections.addAll(
          values,
          "→", "{", "}", "(", ")", ";", "=", ",", ".", "\"", "'", "|", "&", "[", "]",
          "<", ">", "/", "\\", "+", "-", "*", "%", "!", "?", "#", "@", ":", "_");
    } else {
      for (char c : custom.trim().toCharArray()) values.add(String.valueOf(c));
    }
    for (String value : values) {
      TextView key = text(value, 18, Color.WHITE);
      key.setGravity(Gravity.CENTER);
      key.setPadding(0, 0, 0, 0);
      key.setBackground(selectable());
      key.setOnClickListener(v -> smartInsert(((TextView) v).getText().toString()));
      quickKeys.addView(key, new LinearLayout.LayoutParams(dp(38), dp(40)));
    }
  }

  private boolean quickBarDisabled() {
    return almlk.AppSettings.prefs(getContext()).getBoolean("disable_quickkeybar", false);
  }

  /** المرحلة 4: خط/خلفية/شريط سريع من الإعدادات المتقدمة. */
  public void applyAdvancedSettings() {
    if (code == null) return;
    android.content.SharedPreferences sp = almlk.AppSettings.prefs(getContext());
    code.setFontPath(sp.getString("advanced_setting_editor_font", ""));
    code.setBackgroundImagePath(sp.getString("advanced_setting_editor_bg", ""));
    if (quickBar != null && quickBarDisabled()) quickBar.setVisibility(GONE);
    if (quickKeys != null) buildQuickKeys();
  }

  /** المرحلة 1: تطبيق إعدادات المحرر (خط/حجم تبويب/شريط تبويبات) من المصدر الموحّد. */
  public void applyEditorSettings() {
    if (code == null) return;
    android.content.Context settingsCtx = getContext();
    code.setTextSizePx(
        getResources().getDisplayMetrics().scaledDensity
            * almlk.AppSettings.fontSizeSp(settingsCtx));
    code.setTabSizeChars(almlk.AppSettings.tabSize(settingsCtx));
    if (tabStrip != null)
      tabStrip.setVisibility(almlk.AppSettings.editorTabs(settingsCtx) ? VISIBLE : GONE);
  }

  private volatile boolean pendingEdits;

  public boolean hasPendingEdits() {
    return pendingEdits;
  }

  public void markSaved() {
    pendingEdits = false;
  }

  /** بند 3 — إعادة لوحة المفاتيح إلى وضعها الظاهر بعد الانتقال أو القوائم دون اهتزاز. */
  public void ensureKeyboardVisible() {
    if (code == null) return;
    boolean hardKeyboard =
        getResources().getConfiguration().keyboard
            != android.content.res.Configuration.KEYBOARD_NOKEYS;
    if (hardKeyboard && !almlk.AppSettings.forceSoftKeyboard(getContext())) return;
    code.requestFocus();
    android.view.inputmethod.InputMethodManager imm =
        (android.view.inputmethod.InputMethodManager)
            getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.showSoftInput(code, 0);
  }

  // ===== سجل التنقل: «العودة» تعيد الكلاس والموضع السابق بعد الانتقال لعنصر أو تبديل ملف =====
  private static final class NavPoint {
    String file;
    int offset;
    int scrollY;
  }
  private final ArrayDeque<NavPoint> navigationBackStack = new ArrayDeque<>();
  private boolean navRestore;
  private long lastFileSelectTime;

  private void pushNavigationPoint() {
    if (!almlk.AppSettings.prefs(getContext()).getBoolean("experimental_nav_history", true)) return;
    if (navRestore || activeFile == null || code == null) return;
    int offset = Math.max(0, code.getSelectionStart());
    NavPoint top = navigationBackStack.peek();
    // لا تكرار لنفس الموضع تقريبًا حتى لا يضغط المستخدم «عودة» بلا أثر ظاهر.
    if (top != null
        && top.file != null
        && top.file.equals(activeFile)
        && Math.abs(top.offset - offset) < 40) return;
    NavPoint point = new NavPoint();
    point.file = activeFile;
    point.offset = offset;
    point.scrollY = code.getScrollY();
    navigationBackStack.push(point);
    while (navigationBackStack.size() > 50) navigationBackStack.removeLast();
  }

  /** يعيد آخر كلاس/موضع قبل الانتقال. true إن وُجدت نقطة رجوع. */
  public boolean navigateBack() {
    while (!navigationBackStack.isEmpty()) {
      final NavPoint point = navigationBackStack.pop();
      if (point == null || point.file == null || !tabs.containsKey(point.file)) continue;
      navRestore = true;
      try {
        if (!point.file.equals(activeFile)) selectFile(point.file);
        code.post(
            () -> {
              if (code == null) return;
              code.setSelection(Math.max(0, Math.min(point.offset, code.length())));
              code.scrollTo(code.getScrollX(), Math.max(0, point.scrollY));
            });
      } finally {
        code.post(() -> navRestore = false);
      }
      return true;
    }
    return false;
  }

  /** الانتقال الفوري: إن كان الملف مفتوحًا في تبويب يُفعَّل مباشرة — بلا قراءة ولا عمال. */
  public boolean activateTabIfOpen(String name) {
    if (name == null || !tabs.containsKey(name)) return false;
    selectFile(name);
    return true;
  }

  private void loadLazySessionReference(String name, String reference) {
    sessionWorker.execute(
        () -> {
          String restored = "";
          Throwable error = null;
          try {
            restored = fileRepository.readTextBlocking(reference, name, 8 * 1024 * 1024);
          } catch (Throwable failure) {
            error = failure;
          }
          final String value = restored;
          final Throwable failure = error;
          post(
              () -> {
                if (failure == null) {
                  lazySessionReferences.remove(name);
                  lazySessionFiles.remove(name);
                  fileContents.put(name, value);
                }
                // تقرير AIDE — بروتوكول CurrentFiles_: فشل القراءة (مثلًا غياب صلاحية التخزين)
                // لا يحذف مراجع الجلسة؛ تبقى قابلة للاسترجاع عبر retryLazySessionReferences().
                if (!name.equals(activeFile)) return;
                if (name.equals(loadingFile) && code.length() == 0) {
                  historyLocked = true;
                  code.setHint(failure == null ? null : UiStrings.get(getContext(), "ui_error_open_file_utf8"));
                  code.setText(
                      failure == null
                          ? value
                          : UiStrings.format(
                              getContext(), "ui_error_open_file_details", UiStrings.message(getContext(), failure)));
                  historyLocked = false;
                  loadingFile = null;
                  restoreViewport(name);
                  code.setAnalysisPaused(false);
                  // بند 1 — التلوين يطبق فور اكتمال الفتح، بلا تأخير.
                  code.post(code::refreshNow);
                  // قفزة نتيجة بحث مؤجلة: تنفذ بعد حقن المحتوى واستعادة العرض (ترتيب المرجع).
                  if (failure == null && name.equals(pendingMatchFile)) {
                    final int line = pendingMatchLine, column = pendingMatchColumn;
                    pendingMatchFile = null;
                    code.post(() -> jumpToLineColumn(line, column));
                  }
                } else if (name.equals(loadingFile)) {
                  loadingFile = null;
                  code.setHint(null);
                  code.setAnalysisPaused(false);
                  code.post(code::refreshNow);
                }
              });
        });
  }

  /**
   * تقرير AIDE — استعادة ما تعذّر فتحه (غياب إذن التخزين مثلًا): نعيد تحميل كل تبويب ما
   * تزال مراجعه محفوظة ولم يُملأ محتواه. آمنة التكرار وتستدعى بعد منح الصلاحية/عند العودة.
   */
  public void retryLazySessionReferences() {
    if (lazySessionReferences.isEmpty()) return;
    final ArrayList<String> pending = new ArrayList<>();
    final ArrayList<String> refs = new ArrayList<>();
    for (Map.Entry<String, String> pendingRef : lazySessionReferences.entrySet()) {
      if (fileContents.containsKey(pendingRef.getKey())) continue;
      pending.add(pendingRef.getKey());
      refs.add(pendingRef.getValue());
    }
    for (int i = 0; i < pending.size(); i++) {
      loadLazySessionReference(pending.get(i), refs.get(i));
    }
  }

  private void smartInsert(String value) {
    String text = code.getText().toString();
    int start = Math.max(0, Math.min(code.getSelectionStart(), code.getSelectionEnd()));
    int end = Math.max(start, Math.max(code.getSelectionStart(), code.getSelectionEnd()));
    if ("→".equals(value)) {
      code.setSelection(Math.min(text.length(), end + 1));
      code.requestFocus();
      return;
    }
    String close = null;
    if ("{".equals(value)) close = "}";
    else if ("(".equals(value)) close = ")";
    else if ("[".equals(value)) close = "]";
    else if ("<".equals(value) && isXmlFile()) close = ">";
    else if ("\"".equals(value)) close = "\"";
    if (close != null) {
      if ("\"".equals(value) && start == end && isEscaped(text, start)) {
        // الإدراج الذكي عبر استبدال المحرك الموحّد — يُسجَّل تراجعًا (بند الإحلال).
        code.replaceRange(start, start, value);
        code.setSelection(start + 1);
      } else if ("\"".equals(value) && start == end && isInsideDoubleQuote(text, start)) {
        if (start < text.length() && text.charAt(start) == '"')
          code.setSelection(start + 1);
        else {
          code.replaceRange(start, start, value);
          code.setSelection(start + 1);
        }
      } else {
        String selected = text.substring(start, end);
        code.replaceRange(start, end, value + selected + close);
        code.setSelection(start + value.length(), start + value.length() + selected.length());
      }
    } else if (start == end
        && value.length() == 1
        && "})]>\"".indexOf(value.charAt(0)) >= 0
        && start < text.length()
        && text.charAt(start) == value.charAt(0)) {
      code.setSelection(start + 1);
    } else {
      code.replaceRange(start, end, value);
      code.setSelection(start + value.length());
    }
    code.requestFocus();
  }

  private boolean isXmlFile() {
    return almlk.XmlCodeFormatter.isXmlName(activeFile);
  }

  private boolean isEscaped(CharSequence text, int offset) {
    int slashes = 0;
    for (int i = offset - 1; i >= 0 && text.charAt(i) == '\\'; i--) slashes++;
    return (slashes & 1) != 0;
  }

  private boolean isInsideDoubleQuote(CharSequence text, int offset) {
    boolean quoted = false, escaped = false;
    int lineStart = offset;
    while (lineStart > 0 && text.charAt(lineStart - 1) != '\n') lineStart--;
    for (int i = lineStart; i < offset; i++) {
      char value = text.charAt(i);
      if (escaped) escaped = false;
      else if (value == '\\') escaped = true;
      else if (value == '"') quoted = !quoted;
    }
    return quoted;
  }

  private void completeXmlClosingTag(int marker) {
    String text = code.getText().toString();
    if (text.isEmpty() || marker < 2 || marker > text.length()) return;
    if (text.charAt(marker - 2) != '<' || text.charAt(marker - 1) != '/') return;
    String tag = findUnclosedXmlTag(text, marker - 2);
    if (tag == null || tag.isEmpty()) return;
    historyLocked = true;
    if (marker < text.length() && text.charAt(marker) == '>') {
      code.replaceRange(marker, marker, tag);
      code.setSelection(marker + tag.length() + 1);
    } else {
      code.replaceRange(marker, marker, tag + ">");
      code.setSelection(marker + tag.length() + 1);
    }
    historyLocked = false;
  }

  private String findUnclosedXmlTag(CharSequence text, int limit) {
    ArrayDeque<String> stack = new ArrayDeque<>();
    int i = 0;
    while (i < limit) {
      int open = indexOf(text, '<', i, limit);
      if (open < 0 || open + 1 >= limit) break;
      if (startsWith(text, open, "<!--")) {
        int close = indexOf(text, "-->", open + 4, limit);
        i = close < 0 ? limit : close + 3;
        continue;
      }
      int close = xmlTagEnd(text, open + 1, limit);
      if (close < 0) {
        int nameStart = open + 1;
        while (nameStart < limit && Character.isWhitespace(text.charAt(nameStart))) nameStart++;
        int nameEnd = nameStart;
        while (nameEnd < limit && isXmlNameCharacter(text.charAt(nameEnd))) nameEnd++;
        if (nameEnd > nameStart) stack.push(text.subSequence(nameStart, nameEnd).toString());
        break;
      }
      char kind = text.charAt(open + 1);
      if (kind != '!' && kind != '?') {
        boolean closing = kind == '/';
        int nameStart = open + (closing ? 2 : 1);
        while (nameStart < close && Character.isWhitespace(text.charAt(nameStart))) nameStart++;
        int nameEnd = nameStart;
        while (nameEnd < close && isXmlNameCharacter(text.charAt(nameEnd))) nameEnd++;
        if (nameEnd > nameStart) {
          String name = text.subSequence(nameStart, nameEnd).toString();
          if (closing) {
            while (!stack.isEmpty()) {
              String current = stack.pop();
              if (current.equals(name)) break;
            }
          } else {
            int tail = close - 1;
            while (tail > nameEnd && Character.isWhitespace(text.charAt(tail))) tail--;
            if (text.charAt(tail) != '/') stack.push(name);
          }
        }
      }
      i = close + 1;
    }
    return stack.isEmpty() ? null : stack.peek();
  }

  private int xmlTagEnd(CharSequence text, int from, int limit) {
    char quote = 0;
    for (int i = from; i < limit; i++) {
      char value = text.charAt(i);
      if (quote != 0) {
        if (value == quote) quote = 0;
      } else if (value == '"' || value == '\'') quote = value;
      else if (value == '>') return i;
    }
    return -1;
  }

  private boolean isXmlNameCharacter(char value) {
    return Character.isLetterOrDigit(value)
        || value == '_'
        || value == '-'
        || value == ':'
        || value == '.';
  }

  private int indexOf(CharSequence text, char needle, int from, int limit) {
    for (int i = Math.max(0, from); i < Math.min(limit, text.length()); i++)
      if (text.charAt(i) == needle) return i;
    return -1;
  }

  private int indexOf(CharSequence text, String needle, int from, int limit) {
    int last = Math.min(limit, text.length()) - needle.length();
    for (int i = Math.max(0, from); i <= last; i++) {
      if (startsWith(text, i, needle)) return i;
    }
    return -1;
  }

  private boolean startsWith(CharSequence text, int offset, String value) {
    if (offset < 0 || offset + value.length() > text.length()) return false;
    for (int i = 0; i < value.length(); i++)
      if (text.charAt(offset + i) != value.charAt(i)) return false;
    return true;
  }

  public void applyTheme() {
    ThemeConfig theme = new ThemeConfig(getContext());
    int background = theme.color(ThemeConfig.BACKGROUND);
    int plain = theme.color(ThemeConfig.PLAIN);
    int chrome = theme.isDark() ? Color.rgb(34, 34, 34) : Color.rgb(238, 238, 238);
    setBackgroundColor(background);
    if (editorRow != null) editorRow.setBackgroundColor(background);
    if (fileHeader != null) fileHeader.setBackgroundColor(background);
    if (tabStrip != null) {
      tabStrip.setBackgroundColor(chrome);
      if (tabStrip.getParent() instanceof View)
        ((View) tabStrip.getParent()).setBackgroundColor(chrome);
    }
    if (quickBar != null) quickBar.setBackgroundColor(chrome);
    if (headerName != null) headerName.setTextColor(plain);
    if (headerPath != null) headerPath.setTextColor(theme.isDark() ? Color.LTGRAY : Color.DKGRAY);
    if (code != null) code.applyTheme();
    for (LinearLayout holder : tabs.values()) {
      TextView label = (TextView) holder.getChildAt(0);
      label.setTextColor(
          holder == tabs.get(activeFile) ? plain : (theme.isDark() ? Color.LTGRAY : Color.DKGRAY));
    }
  }

  public boolean hasOpenFile() {
    return activeFile != null;
  }

  /** Go To يُسمح به فقط على عنصر اختاره المستخدم صراحةً في موضعه الحالي. */
  public boolean hasExplicitEditorSelection() {
    return code != null && code.getSelectionStart() != code.getSelectionEnd();
  }

  /** أهلية الكتابة الحية نفسها التي يستهلكها سجل أوامر المحرر. */
  public boolean isActiveFileWritableNow() {
    return isActiveFileWritable();
  }

  public String getActiveFile() {
    return activeFile;
  }

  /** استبدال محتوى التبويب النشط بنص المصمم — عبر موديل المحرك فيبقى قابلًا للتراجع ويُحفظ تلقائيًا. */
  public void replaceActiveContent(String newText) {
    if (code == null || newText == null || activeFile == null || !isActiveFileWritable()) return;
    String current = code.getText().toString();
    if (current.equals(newText)) return;
    code.replaceRange(0, current.length(), newText);
  }

  /** نص التحديد إن وجد وإلا الكلمة تحت المؤشر — قناة أمر التوثيق المرجعي. */
  /**
   * استعلام التوثيق — المرحلة السابعة.
   *
   * <p>في XML يُقرأ مرجع المورد ويُستعلم بنوعه واسمه (فالاسم المجرّد وحده غامض)، وفي غير XML
   * تبقى الكلمة تحت المؤشر كما كانت.
   */
  public String documentationQuery() {
    if (code == null) return "";
    String text = code.getText().toString();
    if (isXmlFile() && text != null && !text.isEmpty()) {
      int offset = Math.max(0, Math.min(code.getSelectionStart(), text.length() - 1));
      almlk.XmlResourceReference reference = almlk.XmlResourceReference.at(text, offset);
      if (reference != null) {
        return reference.framework
            ? "android R." + reference.type + " " + reference.name
            : reference.type + " " + reference.name;
      }
    }
    return selectedOrCursorWord();
  }

  public String selectedOrCursorWord() {
    if (code == null) return "";
    String text = code.getText().toString();
    int start = Math.max(0, Math.min(code.getSelectionStart(), text.length()));
    int end = Math.max(0, Math.min(code.getSelectionEnd(), text.length()));
    if (start != end) return text.substring(Math.min(start, end), Math.max(start, end)).trim();
    int back = start;
    while (back > 0 && Character.isJavaIdentifierPart(text.charAt(back - 1))) back--;
    int forward = start;
    while (forward < text.length() && Character.isJavaIdentifierPart(text.charAt(forward)))
      forward++;
    return back < forward ? text.substring(back, forward) : "";
  }

  /** أسماء التبويبات المفتوحة بترتيبها — لقائمة «قائمة الملفات المفتوحة» المرجعية. */
  public java.util.List<String> openFileNames() {
    return new java.util.ArrayList<>(tabs.keySet());
  }

  /** تفعيل تبويب مفتوح بالاسم — قناة حوار الملفات المفتوحة. */
  public void showOpenFile(String name) {
    if (name != null && tabs.containsKey(name)) selectFile(name);
  }

  /** المرجع المستقر للتبويب النشط (مسار كامل أو SAF URI) — الاسم وحده لا يكفي لفحص الموقع. */
  public String getActiveFileReference() {
    if (activeFile == null) return "";
    String reference = sessionReferences.get(activeFile);
    return reference == null ? "" : reference;
  }

  public String getTextContent() {
    return code == null ? "" : code.getText().toString();
  }

  public void undoEdit() {
    if (code.undo()) code.requestFocus();
    notifyHistoryState();
  }

  public void redoEdit() {
    if (code.redo()) code.requestFocus();
    notifyHistoryState();
  }

  // ===== شريط وضع التحرير (دلالة المرجع): إشعار فوري بتغير أهلية التراجع/الإعادة =====
  private Runnable historyStateListener;

  public void setHistoryStateListener(Runnable listener) {
    historyStateListener = listener;
  }

  private void notifyHistoryState() {
    if (historyStateListener != null) historyStateListener.run();
  }

  /** حالة سجل التراجع للمحرك — تغذّي أهلية أمري undo/redo قبل عرض أي قائمة. */
  public boolean canUndoEdit() {
    return code != null && code.canUndo();
  }

  public boolean canRedoEdit() {
    return code != null && code.canRedo();
  }

  /** تعليق/إلغاء تعليق أسطر التحديد — استبدال واحد على موديل المحرك قابل للتراجع. */
  public void toggleLineComment() {
    applyLineComment(null);
  }

  /** أمر المرجع «Outcomment Code»: تعليق صريح لأسطر التحديد. */
  public void commentLines() {
    applyLineComment(Boolean.TRUE);
  }

  /** أمر المرجع «Un-Outcomment Code»: فك طبقة تعليق واحدة عن أسطر التحديد. */
  public void uncommentLines() {
    applyLineComment(Boolean.FALSE);
  }

  private void applyLineComment(Boolean force) {
    if (code == null || !isActiveFileWritable()) return;
    // XML has its own comment grammar; Java-style // is never inserted into markup.
    if (isXmlFile()) {
      applyXmlComment(force);
      return;
    }
    String text = code.getText().toString();
    almlk.CodeMenuCommands.Edit edit =
        almlk.CodeMenuCommands.commentLines(
            text, code.getSelectionStart(), code.getSelectionEnd(), force);
    if (edit == null) return;
    code.replaceRange(edit.start, edit.end, edit.replacement);
    code.setSelection(
        Math.min(edit.selectionStart, code.length()), Math.min(edit.selectionEnd, code.length()));
    code.refreshNow();
  }

  /**
   * تعليق/فك تعليق XML عبر محرك {@code almlk} — استبدال واحد قابل للتراجع.
   *
   * <p>الرفض يظهر سببًا صريحًا بدل الفشل الصامت، ولا تُكتب أي بايتة عند الرفض.
   */
  private void applyXmlComment(Boolean force) {
    String text = code.getText().toString();
    int selStart = code.getSelectionStart();
    int selEnd = code.getSelectionEnd();
    almlk.XmlCommentEditor.Outcome outcome =
        force == null
            ? almlk.XmlCommentEditor.toggle(text, selStart, selEnd)
            : force
                ? almlk.XmlCommentEditor.comment(text, selStart, selEnd)
                : almlk.XmlCommentEditor.uncomment(text, selStart, selEnd);
    if (outcome == null) return;
    if (!outcome.applies()) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), outcome.rejection), Toast.LENGTH_SHORT).show();
      return;
    }
    if (outcome.start < 0 || outcome.end > code.length() || outcome.start > outcome.end) return;
    code.replaceRange(outcome.start, outcome.end, outcome.text);
    int caret = Math.min(outcome.start + outcome.text.length(), code.length());
    code.setSelection(outcome.start, caret);
    code.refreshNow();
  }

  /** ينظم imports فعلية ويضيف مرشّحات حزم المشروع دون تغيير جسم الملف خارج كتلة الترويسة. */
  public void organizeImports() {
    if (code == null || isXmlFile() || !isActiveFileWritable()) return;
    String text = code.getText().toString();
    ArrayList<String> candidates = new ArrayList<>();
    for (String className : JavaImportOrganizer.classLikeIdentifiers(text)) {
      String packageName = ProjectSymbolIndex.packageOf(className);
      if (packageName != null && !packageName.isEmpty())
        candidates.add(packageName + "." + className);
    }
    String organized = JavaImportOrganizer.organize(
        text, candidates, almlk.CodeStyle.maxSingleImports(getContext()));
    if (organized == null || organized.equals(text)) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_imports_already_organized"), Toast.LENGTH_SHORT).show();
      return;
    }
    int oldStart = Math.max(0, code.getSelectionStart());
    int oldEnd = Math.max(oldStart, code.getSelectionEnd());
    int firstType = JavaImportOrganizer.firstTypeOffset(text);
    int delta = organized.length() - text.length();
    int newStart = firstType >= 0 && oldStart >= firstType ? oldStart + delta : oldStart;
    int newEnd = firstType >= 0 && oldEnd >= firstType ? oldEnd + delta : oldEnd;
    newStart = Math.max(0, Math.min(newStart, organized.length()));
    newEnd = Math.max(newStart, Math.min(newEnd, organized.length()));
    code.replaceRange(0, text.length(), organized);
    code.setSelection(newStart, newEnd);
    code.refreshNow();
    Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_imports_organized"), Toast.LENGTH_SHORT).show();
  }

  /** «الإحاطة بـ try/catch»: يحول نطاق الأسطر إلى تعديل واحد قابل للتراجع. */
  public void surroundWithTryCatch() {
    if (code == null || isXmlFile() || !isActiveFileWritable()) return;
    String text = code.getText().toString();
    int indentSize = almlk.CodeStyle.indentSizeFor(getContext(), activeFile);
    StringBuilder indentUnit = new StringBuilder();
    for (int i = 0; i < indentSize; i++) indentUnit.append(' ');
    almlk.CodeMenuCommands.Edit edit = almlk.CodeMenuCommands.surroundWithTryCatch(
        text, code.getSelectionStart(), code.getSelectionEnd(), indentUnit.toString());
    if (edit == null) return;
    code.replaceRange(edit.start, edit.end, edit.replacement);
    code.setSelection(
        Math.min(edit.selectionStart, code.length()), Math.min(edit.selectionEnd, code.length()));
    code.refreshNow();
  }

  /** مستمع أوامر المضيف: عناصر القائمة التي تنفذ حوارات/أوامر IDE (بحث/استبدال/إغلاق). */
  public interface HostCommandListener {
    void run(String commandId);
    default void run(String commandId, String argument) { run(commandId); }
  }

  private HostCommandListener hostCommandListener;

  public void setHostCommandListener(HostCommandListener listener) {
    hostCommandListener = listener;
  }

  private void runHostCommand(String commandId) {
    HostCommandListener listener = hostCommandListener;
    if (listener != null) listener.run(commandId);
  }

  private void runHostCommand(String commandId, String argument) {
    HostCommandListener listener = hostCommandListener;
    if (listener != null) listener.run(commandId, argument == null ? "" : argument);
  }

  /** أمر «تحديد الكل» من الفهرس/القوائم — يمر عبر تحديد المحرك نفسه. */
  public void selectAllText() {
    if (code == null) return;
    code.requestFocus();
    code.selectAll();
  }

  /** يحوّل عنصر قائمة تحديد مدمجًا إلى أيقونة تولبار دائمة كما في تولبار المرجع. */
  private void styleSelectionIcon(android.view.Menu menu, int id, int iconRes) {
    android.view.MenuItem item = menu.findItem(id);
    if (item == null) return;
    item.setIcon(iconRes);
    item.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);
  }

  /** أيقونة القلم: دخول وضع التحرير مباشرة — تركيز المحرر وإظهار لوحة المفاتيح. */
  public boolean beginEditingSession() {
    if (code == null || activeFile == null) return false;
    code.requestFocus();
    android.view.inputmethod.InputMethodManager imm =
        (android.view.inputmethod.InputMethodManager)
            getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    if (imm != null) imm.showSoftInput(code, 0);
    return true;
  }

  public boolean findText(String query) {
    return findText(query, false, false, false, true);
  }

  /** Finds the next local-document match without scanning the rest of the project. */
  public boolean findText(
      String query, boolean caseSensitive, boolean wholeWord, boolean regularExpression,
      boolean forward) {
    if (query == null || query.isEmpty() || code == null) return false;
    String text = code.getText().toString();
    EditorSearchEngine.Query search =
        new EditorSearchEngine.Query(query, caseSensitive, wholeWord, regularExpression);
    int at;
    int end;
    if (regularExpression) {
      List<EditorSearchEngine.Match> matches = EditorSearchEngine.findAll(text, search, 50000);
      EditorSearchEngine.Match selected = null;
      if (forward) {
        int from = Math.max(0, code.getSelectionEnd());
        for (EditorSearchEngine.Match match : matches) {
          if (match.start >= from) { selected = match; break; }
        }
        if (selected == null && !matches.isEmpty()) selected = matches.get(0);
      } else {
        int before = Math.max(0, code.getSelectionStart());
        for (EditorSearchEngine.Match match : matches) {
          if (match.start < before) selected = match;
          else break;
        }
        if (selected == null && !matches.isEmpty()) selected = matches.get(matches.size() - 1);
      }
      if (selected == null) return false;
      at = selected.start;
      end = selected.end;
    } else {
      at = forward
          ? EditorSearchEngine.findNext(text, search, Math.max(0, code.getSelectionEnd()), true)
          : EditorSearchEngine.findPrevious(text, search, Math.max(0, code.getSelectionStart()), true);
      if (at < 0) return false;
      end = Math.min(text.length(), at + query.length());
    }
    if (at < 0) return false;
    code.requestFocus();
    code.setSelection(at, end);
    final int destination = at;
    code.post(() -> code.bringPointIntoView(destination));
    return true;
  }

  public int replaceAll(String from, String to) {
    return replaceAll(from, to, false, false, false);
  }

  /** Replaces matches in the active document and keeps the cursor near its previous location. */
  public int replaceAll(
      String from, String to, boolean caseSensitive, boolean wholeWord, boolean regularExpression) {
    if (from == null || from.isEmpty() || code == null) return 0;
    String before = code.getText().toString();
    EditorSearchEngine.Query search =
        new EditorSearchEngine.Query(from, caseSensitive, wholeWord, regularExpression);
    List<EditorSearchEngine.Match> matches = EditorSearchEngine.findAll(before, search, 50000);
    if (matches.isEmpty()) return 0;
    int cursor = Math.max(0, code.getSelectionStart());
    String updated = EditorSearchEngine.replaceAll(before, search, to);
    historyLocked = true;
    code.setText(updated);
    historyLocked = false;
    code.setSelection(Math.min(cursor, code.length()));
    code.refreshNow();
    return matches.size();
  }

  /** Runs the expensive match/build phase away from the UI thread, then applies one edit. */
  public void replaceAllAsync(
      String from,
      String to,
      boolean caseSensitive,
      boolean wholeWord,
      boolean regularExpression,
      ReplaceListener listener) {
    if (code == null || from == null || from.isEmpty()) {
      if (listener != null) post(() -> listener.completed(0));
      return;
    }
    final String before = code.getText().toString();
    final int cursor = Math.max(0, code.getSelectionStart());
    final EditorSearchEngine.Query search =
        new EditorSearchEngine.Query(from, caseSensitive, wholeWord, regularExpression);
    completionLookupWorker.execute(
        () -> {
          List<EditorSearchEngine.Match> matches =
              EditorSearchEngine.findAll(before, search, 50000);
          if (matches.isEmpty()) {
            post(() -> { if (listener != null) listener.completed(0); });
            return;
          }
          final String updated = EditorSearchEngine.replaceAll(before, search, to);
          post(() -> {
            if (code == null || !before.equals(code.getText().toString())) {
              if (listener != null) listener.completed(0);
              return;
            }
            historyLocked = true;
            code.setText(updated);
            historyLocked = false;
            code.setSelection(Math.min(cursor, code.length()));
            code.refreshNow();
            if (listener != null) listener.completed(matches.size());
          });
        });
  }

  // ===== الانتقال الدقيق لنتيجة بحث: بالسطر/العمود على النص الحي كما في المرجع =====
  private String pendingMatchFile;
  private int pendingMatchLine, pendingMatchColumn;

  /**
   * ينتقل لموضع تطابق (سطر/عمود) في ملف. إن كان محتوى الملف قيد التحميل الكسول تُؤجل
   * القفزة حتى اكتمال الحقن — نفس ترتيب المرجع: الفتح يسبق القفزة دائمًا.
   */
  public boolean goToMatch(String name, int line, int column) {
    if (code == null || name == null) return false;
    if (!name.equals(activeFile) && !activateTabIfOpen(name)) return false;
    if (name.equals(loadingFile) || openingFiles.contains(name)) {
      pendingMatchFile = name;
      pendingMatchLine = line;
      pendingMatchColumn = column;
      return true;
    }
    pendingMatchFile = null;
    return jumpToLineColumn(line, column);
  }

  /** يحسب الإزاحة من السطر/العمود على نص المحرر الحي وقت القفزة (قص العمود عند نهاية السطر). */
  private boolean jumpToLineColumn(int line, int column) {
    if (code == null) return false;
    if (System.currentTimeMillis() - lastFileSelectTime > 400) pushNavigationPoint();
    String text = code.getText().toString();
    int at = 0;
    for (int n = 1; n < line; n++) {
      int next = text.indexOf('\n', at);
      if (next < 0) break;
      at = next + 1;
    }
    int lineEnd = text.indexOf('\n', at);
    if (lineEnd < 0) lineEnd = text.length();
    final int target = Math.min(Math.min(at + Math.max(0, column - 1), lineEnd), code.length());
    // دلالة المرجع: نتيجة البحث تفتح والعنصر نفسه محدد بالتظليل — لا مؤشر صامت.
    int wordStart = target, wordEnd = target;
    while (wordStart > 0 && Character.isJavaIdentifierPart(text.charAt(wordStart - 1))) wordStart--;
    while (wordEnd < text.length() && Character.isJavaIdentifierPart(text.charAt(wordEnd)))
      wordEnd++;
    final int selectionStart = wordEnd > wordStart ? wordStart : target;
    final int selectionEnd = wordEnd > wordStart ? wordEnd : target;
    code.requestFocus();
    code.setSelection(selectionStart, selectionEnd);
    // كشف الموضع بعد اكتمال تخطيط النص المحقون حديثًا: تمريرة فورية + تمريرة مؤكدة —
    // الملف المفتوح للتو يحتاج دورة قياس كاملة قبل أن يصل التمرير فعليًا للموضع.
    final Runnable reveal =
        () -> {
          if (code == null) return;
          code.setSelection(selectionStart, selectionEnd);
          code.bringPointIntoView(selectionEnd);
        };
    code.post(reveal);
    code.postDelayed(reveal, 140);
    return true;
  }

  /** مرجع الملف النشط من جلسة المحرر مباشرة — دقيق حتى مع أسماء التبويبات المفردة. */
  public String activeFileReference() {
    if (activeFile == null) return "";
    String reference = sessionReferences.get(activeFile);
    return reference == null ? "" : reference;
  }

  /**
   * يفعّل تبويبًا مفتوحًا محتواه حي (غير كسول) بمرجعه الثابت — أو بالاسم عند غياب المرجع.
   * يعيد اسم التبويب المفعّل أو null. يمنع GoTo من إعادة حقن محتوى القرص فوق تعديلات حية.
   */
  public String selectIfOpenLive(String reference, String shortName) {
    String found = null;
    if (reference != null && !reference.isEmpty()) {
      for (Map.Entry<String, String> entry : sessionReferences.entrySet())
        if (reference.equals(entry.getValue()) && tabs.containsKey(entry.getKey())) {
          found = entry.getKey();
          break;
        }
    }
    if (found == null
        && (reference == null || reference.isEmpty())
        && shortName != null
        && tabs.containsKey(shortName)) {
      found = shortName;
    }
    if (found == null) return null;
    // التحميل الكسول لم يكتمل = النص غير حي بعد — الفتح عبر القرص أسلم من قفزة على نص فارغ.
    if (lazySessionFiles.containsKey(found)
        || lazySessionReferences.containsKey(found)
        || found.equals(loadingFile)) return null;
    selectFile(found);
    return found;
  }

  /** Activates an already open tab by exact reference, including a tab whose lazy load is pending. */
  public String activateTabByReference(String reference, String shortName) {
    String found = null;
    if (reference != null && !reference.isEmpty()) {
      for (Map.Entry<String, String> entry : sessionReferences.entrySet())
        if (reference.equals(entry.getValue()) && tabs.containsKey(entry.getKey())) {
          found = entry.getKey();
          break;
        }
    } else if (shortName != null && tabs.containsKey(shortName)) {
      found = shortName;
    }
    if (found == null) return null;
    selectFile(found);
    return found;
  }

  /**
   * قفزة GoTo المحصّنة ضد الإزاحات البائتة: تُحل الإزاحة المفهرسة على نص المحرر الحي وقت
   * القفزة — إن بقيت تشير إلى الرمز ككلمة كاملة فهي دقيقة، وإلا أقرب ظهور كلمة كاملة للرمز
   * (نفس مبدأ قفز نتائج البحث الحي في المرجع). تعيد الإزاحة النهائية أو ‎-1.
   */
  public int goToSymbol(String symbol, int indexedOffset) {
    if (code == null) return -1;
    if (System.currentTimeMillis() - lastFileSelectTime > 400) pushNavigationPoint();
    String text = code.getText().toString();
    int resolved = resolveLiveSymbolOffset(text, symbol, indexedOffset);
    final int target = Math.max(0, Math.min(resolved, code.length()));
    final int request = ++goToGeneration;
    final String requestedFile = activeFile;
    code.requestFocus();
    // A tab's posted restoreViewport used to run after this selection and collapse it to a caret.
    // Queue the identifier selection after all pending tab-restore work so every Go To arrival is
    // visibly distinguished, including asynchronously opened system-class source stubs.
    code.post(
        () -> {
          if (code == null
              || request != goToGeneration
              || !java.util.Objects.equals(requestedFile, activeFile)) return;
          String liveText = code.getText().toString();
          int liveTarget = Math.max(
              0, Math.min(resolveLiveSymbolOffset(liveText, symbol, target), code.length()));
          if (symbol != null && !symbol.isEmpty()
              && isWholeWordAt(liveText, liveTarget, symbol))
            code.setSelection(liveTarget, liveTarget + symbol.length());
          else
            code.setSelection(liveTarget);
          code.bringPointIntoView(liveTarget);
        });
    return target;
  }

  private static int resolveLiveSymbolOffset(String text, String symbol, int indexedOffset) {
    int clamped = Math.max(0, Math.min(indexedOffset, text.length()));
    if (symbol == null || symbol.isEmpty()) return clamped;
    if (isWholeWordAt(text, clamped, symbol)) return clamped;
    int best = -1;
    long bestDistance = Long.MAX_VALUE;
    int from = 0;
    while (true) {
      int at = text.indexOf(symbol, from);
      if (at < 0) break;
      if (isWholeWordAt(text, at, symbol)) {
        long distance = Math.abs((long) at - clamped);
        if (distance < bestDistance) {
          bestDistance = distance;
          best = at;
        }
      }
      from = at + 1;
    }
    return best >= 0 ? best : clamped;
  }

  private static boolean isWholeWordAt(String text, int at, String symbol) {
    int end = at + symbol.length();
    if (at < 0 || end > text.length()) return false;
    if (!text.regionMatches(at, symbol, 0, symbol.length())) return false;
    if (at > 0 && Character.isJavaIdentifierPart(text.charAt(at - 1))) return false;
    return end >= text.length() || !Character.isJavaIdentifierPart(text.charAt(end));
  }

  public boolean goToOffset(int offset) {
    if (code == null) return false;
    // سجّل الموضع الحالي قبل القفز لكن ليس مباشرة بعد تبديل ملف (قيد الاستعادة أو انتقال متسلسل).
    if (System.currentTimeMillis() - lastFileSelectTime > 400) pushNavigationPoint();
    int target = Math.max(0, Math.min(offset, code.length()));
    code.requestFocus();
    code.setSelection(target);
    code.post(() -> code.bringPointIntoView(target));
    return true;
  }

  public boolean goToLine(int line) {
    if (line < 1) return false;
    String text = code.getText().toString();
    int at = 0;
    for (int n = 1; n < line; n++) {
      at = text.indexOf('\n', at);
      if (at < 0) return false;
      at++;
    }
    code.requestFocus();
    final int target = Math.min(at, code.length());
    code.setSelection(target);
    // فحص القبول: الانتقال يجب أن يمرر العرض للسطر الهدف كما يفعل البحث تمامًا.
    code.post(() -> code.bringPointIntoView(target));
    return true;
  }

  public void formatSource() {
    if (code == null || !isActiveFileWritable()) return;
    // المرحلة السادسة: منسق XML بنيوي مستقل — إحلال كامل لتعطيل منسق جافا في XML.
    if (isXmlFile()) {
      formatXmlSource();
      return;
    }
    String original = code.getText().toString();
    String formatted = code.formatCode();
    if (original.equals(formatted)) return;
    int semanticCursor = semanticPosition(original, Math.max(0, code.getSelectionStart()));
    historyLocked = true;
    // التنسيق استبدال واحد قابل للتراجع داخل موديل المحرك (بند الإحلال).
    code.replaceRange(0, original.length(), formatted);
    code.setSelection(offsetForSemanticPosition(formatted, semanticCursor));
    historyLocked = false;
    code.refreshNow();
  }

  /**
   * تنسيق XML بنيوي: إعادة إزاحة فقط، فالمحتوى لا يُمس.
   *
   * <p>عقد التنفيذ المعتمد من دراسة المرجع: بوابة لغة → لقطة موضع → تنفيذ → استعادة موضع →
   * لا فشل صامت. ويُنفَّذ استبدالًا ذريًا واحدًا في موديل المحرك بدل الكتابة المباشرة على القرص
   * حتى يبقى التنسيق قابلًا للتراجع.
   */
  private void formatXmlSource() {
    String original = code.getText().toString();
    int indentSize = almlk.XmlCodeFormatter.resolveIndentSize(getContext());
    String formatted = almlk.XmlCodeFormatter.format(original, indentSize);
    if (original.equals(formatted)) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_xml_already_formatted"), Toast.LENGTH_SHORT).show();
      return;
    }
    // التنسيق يغيّر المسافات البادئة فقط، فإسقاط المؤشر على عدّ المحارف غير المسافية يبقى صحيحًا.
    int semanticCursor = semanticPosition(original, Math.max(0, code.getSelectionStart()));
    historyLocked = true;
    code.replaceRange(0, original.length(), formatted);
    code.setSelection(offsetForSemanticPosition(formatted, semanticCursor));
    historyLocked = false;
    code.refreshNow();
  }

  private int semanticPosition(String text, int offset) {
    int count = 0;
    for (int i = 0; i < Math.min(offset, text.length()); i++)
      if (!Character.isWhitespace(text.charAt(i))) count++;
    return count;
  }

  private int offsetForSemanticPosition(String text, int semanticPosition) {
    int count = 0;
    for (int i = 0; i < text.length(); i++) {
      if (!Character.isWhitespace(text.charAt(i)) && count++ >= semanticPosition) return i;
    }
    return text.length();
  }

  public void setQuickFixListener(QuickFixListener listener) {
    quickFixListener = listener;
  }

  public void setDefinitionListener(DefinitionListener listener) {
    definitionListener = listener;
  }

  public void setDefinitionRequestListener(DefinitionRequestListener listener) {
    definitionRequestListener = listener;
  }

  public void setUsageListener(UsageListener listener) {
    usageListener = listener;
  }

  public void setDiagnosticsListener(DiagnosticsListener listener) {
    diagnosticsListener = listener;
  }

  public void setFileChangedListener(FileChangedListener listener) {
    fileChangedListener = listener;
  }

  /** Updates current-editor markers from the complete, file-qualified project snapshot. */
  public void setProjectDiagnostics(List<ProjectDiagnostic> values) {
    projectDiagnostics =
        values == null || values.isEmpty()
            ? Collections.emptyList()
            : new ArrayList<>(values);
    applyProjectDiagnosticsToActiveFile();
  }

  private void applyProjectDiagnosticsToActiveFile() {
    if (code == null) return;
    ArrayList<ProjectDiagnostic> active = new ArrayList<>();
    if (activeFile != null) {
      String reference = getActiveFileReference();
      String shortName = activeFile.substring(activeFile.lastIndexOf('/') + 1);
      for (ProjectDiagnostic item : projectDiagnostics) {
        if (item == null) continue;
        if (!reference.isEmpty() && reference.equals(item.reference)) active.add(item);
        else if (reference.isEmpty()
            && (activeFile.equals(item.fileName) || shortName.equals(item.fileName))) active.add(item);
      }
    }
    code.setProjectDiagnostics(active);
  }

  public void requestUsageForCurrentSelection() {
    if (code == null || usageListener == null || activeFile == null) return;
    String text = code.getText().toString();
    int[] range = usageSelection(text, code.getSelectionStart(), code.getSelectionEnd());
    usageListener.requested(activeFile, text, range[0], range[1]);
  }

  /**
   * يثبّت مدى البحث على **اسم** المورد في XML — المرحلة السابعة.
   *
   * <p>بلا هذا التثبيت يُبحث في البادئة {@code @id/} كلها فلا توجد نتائج. وبما أن حدود الاسم
   * في {@code @id/x} و{@code R.id.x} ليست محارف معرفية، يجد المحرك القائم الصيغ كلها معًا
   * بلا محرك بحث جديد.
   */
  private int[] usageSelection(String text, int selStart, int selEnd) {
    if (!isXmlFile() || text == null || text.isEmpty()) return new int[] {selStart, selEnd};
    almlk.XmlResourceReference reference =
        almlk.XmlResourceReference.at(text, Math.max(0, Math.min(selStart, text.length() - 1)));
    return reference == null
        ? new int[] {selStart, selEnd}
        : new int[] {reference.nameStart, reference.nameEnd};
  }

  /** Entry point for the toolbar/menu Go To action, independent of ActionMode. */
  public void requestDefinitionForCurrentSelection() {
    if (code == null || activeFile == null) return;
    final int rawSelectionStart = code.getSelectionStart();
    final int rawSelectionEnd = code.getSelectionEnd();
    final int selectionStart = Math.min(rawSelectionStart, rawSelectionEnd);
    final int selectionEnd = Math.max(rawSelectionStart, rawSelectionEnd);
    if (selectionStart == selectionEnd) {
      Toast.makeText(
              getContext(),
              UiStrings.get(getContext(), "ui_error_symbol_selection_required"),
              Toast.LENGTH_SHORT)
          .show();
      return;
    }
    final String source = code.getText().toString();
    final int request = ++definitionGeneration;
    final String requestedFile = activeFile;
    completionWorker.execute(
        () -> {
          try {
            // المرحلة السابعة: مراجع XML (@type/name) يحلها المضيف من جذر المشروع، فلا
            // يُمرَّر XML إلى محلل رموز Java.
            final ProjectSymbolIndex.DefinitionTarget target =
                requestedFile.toLowerCase(java.util.Locale.US).endsWith(".smali")
                    ? SmaliDefinitionResolver.resolve(
                        requestedFile, source, selectionStart, selectionEnd)
                    : almlk.XmlCodeFormatter.isXmlName(requestedFile)
                        ? null
                        : ProjectSymbolIndex.resolveDefinition(
                            requestedFile, source, selectionStart, selectionEnd);
            post(
                () -> {
                  if (request != definitionGeneration) return;
                  if (target != null && definitionListener != null) {
                    if (usageListener != null
                        && ProjectSymbolIndex.isDefinitionSelection(
                            requestedFile, source, selectionStart, selectionEnd, target)) {
                      usageListener.requested(
                          requestedFile, source, selectionStart, selectionEnd);
                    } else {
                      definitionListener.requested(target);
                    }
                  } else if (definitionRequestListener != null) {
                    definitionRequestListener.requested(
                        requestedFile, source, selectionStart, selectionEnd);
                  } else {
                    Toast.makeText(
                            getContext(),
                            UiStrings.get(getContext(), "ui_error_definition_not_found"),
                            Toast.LENGTH_SHORT)
                        .show();
                  }
                });
          } catch (Throwable error) {
            post(() -> {
              if (request == definitionGeneration) showEditorError(error);
            });
          }
        });
  }

  public void refreshSemanticDiagnostics() {
    if (code != null && activeFile != null) code.refreshNow();
  }

  public java.util.List<com.almlkid.kay.ui.CodeLanguageTools.Diagnostic> diagnostics() {
    code.refreshNow();
    return code.getDiagnostics();
  }

  private void showLiveCompletions() {
    if (code == null || !code.hasFocus() || code.getSelectionStart() != code.getSelectionEnd())
      return;
    final String requestedFile = activeFile;
    final int cursor = code.getSelectionStart();
    final int request = ++completionGeneration;
    completionLookupFuture =
        completionLookupWorker.submit(
            () -> {
              try {
                // Copy the document on the worker, never from the key event/UI callback.
                EditorTextSnapshot.Value snapshot = completionSnapshot.copy();
                if (request != completionGeneration) return;
                final java.util.List<ProjectSymbolIndex.CompletionItem> items =
                    cachedOrComputeCompletions(requestedFile, snapshot.text, cursor);
                post(
                    () -> {
                      if (request != completionGeneration
                          || code.getSelectionStart() != cursor
                          || !java.util.Objects.equals(requestedFile, activeFile)) return;
                      displayLiveCompletions(items);
                    });
              } catch (Throwable error) {
                post(() -> showEditorError(error));
              }
            });
  }

  private List<ProjectSymbolIndex.CompletionItem> cachedOrComputeCompletions(
      String file, String source, int cursor) {
    int safeCursor = Math.max(0, Math.min(cursor, source.length()));
    int tokenStart = CodeLanguageTools.completionStart(source, safeCursor);
    String prefix = source.substring(tokenStart, safeCursor);
    String context = source.substring(Math.max(0, tokenStart - 256), tokenStart);
    String after = source.substring(safeCursor);
    // Exclude the active prefix so typing the next character can reuse the same base result.
    int sourceHash = 31 * source.substring(0, tokenStart).hashCode() + after.hashCode();
    List<ProjectSymbolIndex.CompletionItem> cached =
        completionCache.lookup(file, prefix, context, after, sourceHash);
    if (cached != null) return cached;

    List<ProjectSymbolIndex.CompletionItem> computed =
        KayStyleCompletionEngine.complete(file, source, safeCursor);
    completionCache.store(file, prefix, context, after, sourceHash, computed);
    return computed == null ? Collections.emptyList() : computed;
  }

  private void cancelCompletionLookup() {
    if (completionLookupFuture != null) {
      completionLookupFuture.cancel(true);
      completionLookupFuture = null;
    }
  }

  private void displayLiveCompletions(
      java.util.List<ProjectSymbolIndex.CompletionItem> items) {
    if (items == null || items.isEmpty()) {
      dismissCompletions();
      return;
    }
    if (!almlk.AppSettings.completeAllTypes(getContext())) {
      String source = code == null ? "" : code.currentText();
      java.util.List<ProjectSymbolIndex.CompletionItem> filtered = new java.util.ArrayList<>();
      for (ProjectSymbolIndex.CompletionItem item : items)
        if (item.kind != ProjectSymbolIndex.CompletionItem.CLASS || source.contains(item.label))
          filtered.add(item);
      items = filtered;
      if (items.isEmpty()) {
        dismissCompletions();
        return;
      }
    }
    if (completionAdapter == null) completionAdapter = new EditorCompletionAdapter(getContext());
    completionAdapter.setItems(items);
    if (completionList == null) {
      completionList = (ListView)
          LayoutInflater.from(getContext()).inflate(R.layout.code_completion_popup, null, false);
      completionList.setAdapter(completionAdapter);
      completionList.setOnItemClickListener((parent, view, position, id) -> {
        if (completionAdapter == null || position >= completionAdapter.getCount()) return;
        applyTypedCompletion(completionAdapter.getItem(position));
        dismissCompletions();
      });
    }
    int width = Math.min(dp(310), getResources().getDisplayMetrics().widthPixels - dp(24));
    int height = Math.min(dp(190), dp(8 + Math.min(4, items.size()) * 44));
    if (completionWindow == null) {
      completionWindow = new PopupWindow(completionList, width, height, false);
      completionWindow.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFF292929));
      completionWindow.setOutsideTouchable(true);
      completionWindow.setTouchable(true);
      completionWindow.setElevation(dp(10));
    } else {
      completionWindow.setWidth(width);
      completionWindow.setHeight(height);
    }
    int[] location = new int[2];
    code.getLocationOnScreen(location);
    int cursor = Math.max(0, code.getSelectionStart());
    int x = location[0] + dp(8);
    int y = location[1] + dp(38);
    // بند الإحلال: موضع المؤشر يؤخذ من مقاسات اللوحة مباشرة (بديل android.text.Layout).
    if (cursor <= code.length()) {
      int[] position = code.offsetToViewPosition(cursor);
      x = location[0] + position[0];
      y = location[1] + position[1];
    }
    x = Math.max(dp(8), Math.min(x,
        getResources().getDisplayMetrics().widthPixels - width - dp(8)));
    Rect visibleFrame = new Rect();
    getWindowVisibleDisplayFrame(visibleFrame);
    int bottomLimit = visibleFrame.bottom - dp(6);
    if (quickBar != null && quickBar.getVisibility() == VISIBLE) {
      int[] quickLocation = new int[2];
      quickBar.getLocationOnScreen(quickLocation);
      bottomLimit = Math.min(bottomLimit, quickLocation[1] - dp(4));
    }
    y = Math.max(dp(70), Math.min(y, bottomLimit - height));
    if (completionWindow.isShowing()) completionWindow.update(x, y, width, height);
    else completionWindow.showAtLocation(this, Gravity.NO_GRAVITY, x, y);
  }

  private void showEditorError(Throwable error) {
    long now = android.os.SystemClock.uptimeMillis();
    if (now - lastEditorErrorTime < 3000 || !isAttachedToWindow()) return;
    lastEditorErrorTime = now;
    dismissCompletions();
    new android.app.AlertDialog.Builder(getContext())
        .setTitle(UiStrings.get(getContext(), "ui_editor_error_title"))
        .setMessage(
            UiStrings.format(
                getContext(),
                "ui_editor_error_body",
                error.getClass().getSimpleName(),
                UiStrings.message(getContext(), error).isEmpty() ? "" : "\n" + UiStrings.message(getContext(), error)))
        .setPositiveButton(UiStrings.get(getContext(), "ui_action_ok"), null)
        .show();
  }

  private void dismissCompletions() {
    completionGeneration++;
    cancelCompletionLookup();
    if (completionWindow != null) {
      completionWindow.dismiss();
      completionWindow = null;
    }
  }

  /** أمر «الإكمال» اليدوي: يعرض نفس النافذة الحية المنمطة دون شرط التركيز. */
  public void showCompletionPopup() {
    if (code == null || activeFile == null) return;
    final String requestedFile = activeFile;
    final int cursor = Math.max(0, code.getSelectionStart());
    final int request = ++completionGeneration;
    completionLookupFuture =
        completionLookupWorker.submit(
            () -> {
              try {
                EditorTextSnapshot.Value snapshot = completionSnapshot.copy();
                if (request != completionGeneration) return;
                final java.util.List<ProjectSymbolIndex.CompletionItem> items =
                    cachedOrComputeCompletions(requestedFile, snapshot.text, cursor);
                post(
                    () -> {
                      if (request == completionGeneration) displayLiveCompletions(items);
                    });
              } catch (Throwable error) {
                post(() -> showEditorError(error));
              }
            });
  }

  /** التزام منمط مفوّض إلى المحرر (المرحلة 3: توقيع + مؤشر + استيراد تلقائي). */
  public void applyTypedCompletion(ProjectSymbolIndex.CompletionItem item) {
    if (code != null) code.applyTypedCompletion(item);
  }
  /** المرحلة 2: إعادة تسمية حقيقية للرمز/المورد المحدد — الملف النشط ثم ملفات المشروع. */
  public void renameCurrentSelection() {
    if (code == null || !code.hasSelection()) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_symbol_or_resource_first"), Toast.LENGTH_SHORT).show();
      return;
    }
    String text = code.getText().toString();
    String symbol = selectionToken(text, code.getSelectionStart(), code.getSelectionEnd());
    if (symbol == null || symbol.isEmpty()) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_place_cursor_on_symbol_or_resource"), Toast.LENGTH_SHORT).show();
      return;
    }
    promptRename(symbol);
  }

  // ---------------- المرحلة 3: إعادة البناء (Inline/Introduce/Extract) ----------------
  public void refactorInline() {
    if (code == null || !code.hasSelection()) { Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_variable_first"), Toast.LENGTH_SHORT).show(); return; }
    String text = code.getText().toString();
    String var = selectionToken(text, code.getSelectionStart(), code.getSelectionEnd());
    if (var == null) { Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_variable_name"), Toast.LENGTH_SHORT).show(); return; }
    String result = almlk.Refactor.inlineVariable(text, var);
    if (result == null) {
      Toast.makeText(getContext(), UiStrings.format(getContext(), "ui_inline_variable_failed", var), Toast.LENGTH_LONG).show();
      return;
    }
    code.replaceRange(0, text.length(), result);
    Toast.makeText(getContext(), UiStrings.format(getContext(), "ui_inline_variable_done", var), Toast.LENGTH_SHORT).show();
  }

  public void refactorIntroduce() {
    if (code == null || !code.hasSelection()) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_range_first"), Toast.LENGTH_SHORT).show();
      return;
    }
    final int selectionStart = code.getSelectionStart();
    final int selectionEnd = code.getSelectionEnd();
    final long documentVersion = code.getDocument().version();
    final String fileAtStart = activeFile;
    promptRefactorName(UiStrings.get(getContext(), "ui_new_variable_name_hint"), (name) -> {
      if (!java.util.Objects.equals(fileAtStart, activeFile)
          || code.getDocument().version() != documentVersion) {
        Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_document_changed_during_dialog"), Toast.LENGTH_LONG).show();
        return;
      }
      String text = code.getText().toString();
      String result = almlk.Refactor.introduceVariable(text, selectionStart, selectionEnd, name);
      if (result == null) { Toast.makeText(
            getContext(),
            UiStrings.format(getContext(), "ui_invalid_symbol_selection", name),
            Toast.LENGTH_LONG)
            .show(); return; }
      code.replaceRange(0, text.length(), result);
    });
  }

  public void refactorExtract() {
    if (code == null || !code.hasSelection()) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_range_first"), Toast.LENGTH_SHORT).show();
      return;
    }
    final int selectionStart = code.getSelectionStart();
    final int selectionEnd = code.getSelectionEnd();
    final long documentVersion = code.getDocument().version();
    final String fileAtStart = activeFile;
    promptRefactorName(UiStrings.get(getContext(), "ui_new_method_name_hint"), (name) -> {
      if (!java.util.Objects.equals(fileAtStart, activeFile)
          || code.getDocument().version() != documentVersion) {
        Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_document_changed_during_dialog"), Toast.LENGTH_LONG).show();
        return;
      }
      String text = code.getText().toString();
      String result = almlk.Refactor.extractMethod(text, selectionStart, selectionEnd, name);
      if (result == null) { Toast.makeText(
            getContext(),
            UiStrings.format(getContext(), "ui_invalid_symbol_selection", name),
            Toast.LENGTH_LONG)
            .show(); return; }
      code.replaceRange(0, text.length(), result);
    });
  }

  private void promptRefactorName(String hint, java.util.function.Consumer<String> apply) {
    if (code == null || !code.hasSelection()) { Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_range_first"), Toast.LENGTH_SHORT).show(); return; }
    final android.widget.EditText input = new android.widget.EditText(getContext());
    input.setHint(hint);
    new android.app.AlertDialog.Builder(getContext())
        .setTitle(hint)
        .setView(input)
        .setPositiveButton(UiStrings.get(getContext(), "ui_action_apply"), (d, w) -> {
          String name = input.getText().toString().trim();
          String reason = almlk.Renamer.validate("x", name);
          if (reason != null) {
            Toast.makeText(getContext(), UiStrings.get(getContext(), reason), Toast.LENGTH_LONG).show();
            return;
          }
          apply.accept(name);
        })
        .setNegativeButton(UiStrings.get(getContext(), "dialog_cancel"), null)
        .show();
  }

  /** يستخرج رمز/مورد التحديد؛ ولـXML يأخذ الجزء بعد آخر «/» (اسم المورد). */
  private String selectionToken(String text, int s, int e) {
    if (s < 0 || e > text.length() || s >= e) return null;
    String token = text.substring(s, e).trim();
    if (isXmlFile()) { int slash = token.lastIndexOf('/'); if (slash >= 0) token = token.substring(slash + 1); }
    for (int i = 0; i < token.length(); i++)
      if (!Character.isJavaIdentifierPart(token.charAt(i))) return null;
    return token.isEmpty() ? null : token;
  }

  private void promptRename(final String symbol) {
    final android.widget.EditText input = new android.widget.EditText(getContext());
    input.setText(symbol);
    input.selectAll();
    new android.app.AlertDialog.Builder(getContext())
        .setTitle(UiStrings.format(getContext(), "ui_rename_symbol_title", symbol))
        .setView(input)
        .setPositiveButton(UiStrings.get(getContext(), "ui_action_rename"), (d, w) -> {
          String reason = almlk.Renamer.validate(symbol, input.getText().toString());
          if (reason != null) {
            Toast.makeText(getContext(), UiStrings.get(getContext(), reason), Toast.LENGTH_LONG).show();
            return;
          }
          applyRename(symbol, input.getText().toString().trim());
        })
        .setNegativeButton(UiStrings.get(getContext(), "dialog_cancel"), null)
        .show();
  }

  /** يطبّق إعادة التسمية على الملف النشط (بتراجع واحد) ثم بقية ملفات المشروع على خيط خلفي. */
  private void applyRename(final String symbol, final String newName) {
    final String activeText = code.getText().toString();
    final boolean xml = isXmlFile();
    String newText = xml ? almlk.Renamer.renameResource(activeText, symbol, newName)
        : almlk.Renamer.renameAll(activeText, symbol, newName);
    if (!newText.equals(activeText)) code.replaceRange(0, activeText.length(), newText);
    final java.util.List<String> files = ProjectSymbolIndex.projectJavaFiles();
    final String active = activeFile;
    completionWorker.execute(() -> {
      int changed = 0;
      for (String path : files) {
        if (path == null || path.equals(active)) continue;
        try {
          String ref = com.shima.performance.FileSystemRepository.referenceForFile(new java.io.File(path));
          String content = fileRepository.readTextBlocking(ref, path, 8 * 1024 * 1024);
          if (content == null) continue;
          String updated = xml ? almlk.Renamer.renameResource(content, symbol, newName)
              : almlk.Renamer.renameAll(content, symbol, newName);
          if (!updated.equals(content)) { fileRepository.writeTextBlocking(ref, updated); changed++; }
        } catch (Throwable ignored) { }
      }
      final int n = changed;
      post(() -> Toast.makeText(getContext(),
          UiStrings.format(getContext(), "ui_rename_complete", symbol, newName, n + 1),
          Toast.LENGTH_LONG).show());
    });
  }


  // ---------------- توليد الأعضاء المستهدفة في Java ----------------
  private static int commonPrefixLength(String first, String second) {
    int limit = Math.min(first.length(), second.length());
    int offset = 0;
    while (offset < limit && first.charAt(offset) == second.charAt(offset)) offset++;
    return offset;
  }

  public void codegenSetters() {
    if (code == null) return;
    codegenSetters(code.getSelectionStart(), code.getSelectionEnd());
  }

  private void codegenSetters(int selectionStart, int selectionEnd) {
    if (code == null || !isActiveFileWritable()) return;
    String text = code.getText().toString();
    if (!almlk.CodeGen.hasFieldTarget(text, selectionStart, selectionEnd)) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_field_or_name"), Toast.LENGTH_LONG).show();
      return;
    }
    String result = almlk.CodeGen.createSettersGetters(text, selectionStart, selectionEnd);
    if (result == null) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_accessors_already_exist"), Toast.LENGTH_LONG).show();
      return;
    }
    int start = Math.max(0, Math.min(selectionStart, selectionEnd));
    int end = Math.max(start, Math.max(selectionStart, selectionEnd));
    int insertionPoint = commonPrefixLength(text, result);
    int delta = result.length() - text.length();
    if (start >= insertionPoint) start += delta;
    if (end >= insertionPoint) end += delta;
    code.replaceRange(0, text.length(), result);
    code.setSelection(Math.min(start, code.length()), Math.min(end, code.length()));
    code.refreshNow();
    Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_field_accessors_generated"), Toast.LENGTH_SHORT).show();
  }

  public void codegenConstructor() {
    if (code == null) return;
    codegenConstructor(code.getSelectionStart(), code.getSelectionEnd());
  }

  private void codegenConstructor(int selectionStart, int selectionEnd) {
    if (code == null || !isActiveFileWritable()) return;
    String text = code.getText().toString();
    String result = almlk.CodeGen.createConstructor(text, selectionStart, selectionEnd);
    if (result == null) {
      Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_constructor_exists_or_type_missing"), Toast.LENGTH_LONG).show();
      return;
    }
    int start = Math.max(0, Math.min(selectionStart, selectionEnd));
    int end = Math.max(start, Math.max(selectionStart, selectionEnd));
    int insertionPoint = commonPrefixLength(text, result);
    int delta = result.length() - text.length();
    if (start >= insertionPoint) start += delta;
    if (end >= insertionPoint) end += delta;
    code.replaceRange(0, text.length(), result);
    code.setSelection(Math.min(start, code.length()), Math.min(end, code.length()));
    code.refreshNow();
    Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_constructor_generated"), Toast.LENGTH_SHORT).show();
  }

  public void codegenExtractResource() {
    if (code == null || !code.hasSelection()) { Toast.makeText(getContext(), UiStrings.get(getContext(), "ui_select_text_first"), Toast.LENGTH_SHORT).show(); return; }
    final String text = code.getText().toString();
    final int s0 = code.getSelectionStart(), e0 = code.getSelectionEnd();
    final String value = text.substring(s0, e0);
    final android.widget.EditText input = new android.widget.EditText(getContext());
    input.setHint(UiStrings.get(getContext(), "ui_resource_name_hint"));
    new android.app.AlertDialog.Builder(getContext())
        .setTitle(UiStrings.format(getContext(), "ui_extract_resource_title", value))
        .setView(input)
        .setPositiveButton(UiStrings.get(getContext(), "ui_action_extract"), (d, w) -> {
          String name = input.getText().toString().trim();
          String result = almlk.CodeGen.extractResource(text, s0, e0, name);
          if (result == null) { Toast.makeText(
            getContext(),
            UiStrings.format(getContext(), "ui_invalid_symbol_selection", name),
            Toast.LENGTH_LONG)
            .show(); return; }
          code.replaceRange(0, text.length(), result);
          appendStringResource(name, value);
        })
        .setNegativeButton(UiStrings.get(getContext(), "dialog_cancel"), null)
        .show();
  }

  /** يلحق {@code <string>} بـres/values/strings.xml ضمن جذر المشروع المشتق من الملف النشط. */
  private void appendStringResource(final String name, final String value) {
    final String active = activeFile;
    completionWorker.execute(() -> {
      try {
        java.io.File dir = active == null ? null : new java.io.File(active).getParentFile();
        while (dir != null && !(new java.io.File(dir, "res").isDirectory())) dir = dir.getParentFile();
        if (dir == null) return;
        java.io.File values = new java.io.File(dir, "res/values");
        values.mkdirs();
        java.io.File strings = new java.io.File(values, "strings.xml");
        String content = strings.exists()
            ? new String(java.nio.file.Files.readAllBytes(strings.toPath()), "UTF-8")
            : "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n</resources>\n";
        int close = content.lastIndexOf("</resources>");
        if (close < 0) close = content.length();
        String updated = content.substring(0, close) + almlk.CodeGen.stringEntry(name, value) + content.substring(close);
        java.nio.file.Files.write(strings.toPath(), updated.getBytes("UTF-8"));
        post(
            () ->
                Toast.makeText(
                        getContext(),
                        UiStrings.format(getContext(), "ui_resource_added_to_strings", name),
                        Toast.LENGTH_SHORT)
                    .show());
      } catch (Throwable ignored) { }
    });
  }

  public java.util.List<String> completions() {
    java.util.List<ProjectSymbolIndex.CompletionItem> detailed =
        KayStyleCompletionEngine.complete(
            activeFile, code.getText().toString(), code.getSelectionStart());
    java.util.ArrayList<String> values = new java.util.ArrayList<>();
    for (ProjectSymbolIndex.CompletionItem item : detailed) values.add(item.insertText);
    return values;
  }

  public void applyCompletion(String value) {
    code.applyCompletion(value);
  }

  public void closeCurrent() {
    if (activeFile == null) return;
    LinearLayout tab = tabs.remove(activeFile);
    if (tab != null) tabStrip.removeView(tab);
    fileContents.remove(activeFile);
    lazySessionFiles.remove(activeFile);
    lazySessionReferences.remove(activeFile);
    sessionReferences.remove(activeFile);
    sessionCursors.remove(activeFile);
    sessionScrollX.remove(activeFile);
    sessionScrollY.remove(activeFile);
    activeFile = null;
    if (tabs.isEmpty()) {
      setVisibility(GONE);
      code.setText("");
    } else selectFile(tabs.keySet().iterator().next());
  }

  public void closeAll() {
    tabs.clear();
    fileContents.clear();
    lazySessionFiles.clear();
    lazySessionReferences.clear();
    sessionReferences.clear();
    sessionCursors.clear();
    sessionScrollX.clear();
    sessionScrollY.clear();
    loadingFile = null;
    tabStrip.removeAllViews();
    activeFile = null;
    code.setText("");
    setVisibility(GONE);
  }

  private int iconForFile(String name) {
    String n = name == null ? "" : name.toLowerCase(java.util.Locale.US);
    if (n.endsWith(".java") || n.endsWith(".kt") || n.endsWith(".class"))
      return R.drawable.file_type_java;
    if (n.endsWith(".xml")) return R.drawable.file_type_xml;
    if (n.endsWith(".gradle") || n.endsWith(".gradle.kts")) {
      return R.drawable.project_properties;
    }
    if (n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".aar") || n.endsWith(".apk") || n.endsWith(".dex")) {
      return R.drawable.file_type_zip;
    }
    if (n.endsWith(".txt") || n.endsWith(".md") || n.endsWith(".properties") || n.endsWith(".json") || n.endsWith(".csv") || n.endsWith(".smali"))
      return R.drawable.file_type_txt;
    return R.drawable.file_type_unknown;
  }

  private android.graphics.drawable.Drawable selectable() {
    android.util.TypedValue out = new android.util.TypedValue();
    getContext().getTheme().resolveAttribute(android.R.attr.selectableItemBackground, out, true);
    return getResources().getDrawable(out.resourceId);
  }

  private TextView text(String value, int size, int color) {
    TextView t = new TextView(getContext());
    t.setText(value);
    t.setTextSize(size);
    t.setTextColor(color);
    return t;
  }

  @Override
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (completionWorker.isShutdown())
      completionWorker = java.util.concurrent.Executors.newSingleThreadExecutor();
    if (sessionWorker.isShutdown())
      sessionWorker = java.util.concurrent.Executors.newSingleThreadExecutor();
    if (completionLookupWorker.isShutdown())
      completionLookupWorker = java.util.concurrent.Executors.newSingleThreadExecutor();
    if (fileRepository == null) fileRepository = new FileSystemRepository(getContext());
    if (autoSaveManager == null) autoSaveManager = new AtomicSaveManager(getContext());
  }

  @Override
  protected void onDetachedFromWindow() {
    removeCallbacks(completionTask);
    dismissCompletions();
    quickFixGeneration++;
    clearPendingQuickFixes();
    completionWorker.shutdownNow();
    sessionWorker.shutdownNow();
    completionLookupWorker.shutdownNow();
    if (fileRepository != null) {
      fileRepository.close();
      fileRepository = null;
    }
    if (autoSaveManager != null) {
      autoSaveManager.close();
      autoSaveManager = null;
    }
    super.onDetachedFromWindow();
  }

  private int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }

  private String sample(String name) {
    if (name.endsWith(".xml"))
      return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
          + "<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
          + "    android:layout_width=\"match_parent\"\n"
          + "    android:layout_height=\"match_parent\" />";
    return "package com.example.myapp;\n\n"
        + "import android.app.Activity;\n"
        + "import android.os.Bundle;\n\n"
        + "public class "
        + name.replace(".java", "")
        + " extends Activity {\n"
        + "    @Override\n"
        + "    protected void onCreate(Bundle state) {\n"
        + "        super.onCreate(state);\n"
        + "    }\n"
        + "}";
  }
}
