package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class MainBinding {
    public final LinearLayout boxPassword;
    public final LinearLayout boxUsername;
    public final ImageView btnBack;
    public final Button btnLogin;
    public final CheckBox cbRememberMe;
    public final EditText etPassword;
    public final EditText etUsername;
    public final ImageView imageview22;
    public final ImageView imageview23;
    public final ImageView imageview24;
    public final RelativeLayout layoutLoadingOverlay;
    public final LinearLayout linear47;
    public final LinearLayout linear48;
    public final LinearLayout linear51;
    public final LinearLayout linear52;
    public final RelativeLayout relativelayout8;
    public final RelativeLayout rootView;
    public final TextView textview28;
    public final TextView textview29;
    public final TextView textview30;
    public final TextView textview31;
    public final TextView textview32;
    public final TextView tvError;
    public final TextView tvForgotPassword;
    public final View view49;
    public final View view50;
    public final ScrollView vscroll2;
    public final WebView webviewLoadingGif;

    private MainBinding(RelativeLayout relativeLayout, ScrollView scrollView, LinearLayout linearLayout, RelativeLayout relativeLayout2, ImageView imageView, LinearLayout linearLayout2, ImageView imageView2, ImageView imageView3, TextView textView, View view, LinearLayout linearLayout3, TextView textView2, EditText editText, View view2, LinearLayout linearLayout4, TextView textView3, EditText editText2, LinearLayout linearLayout5, TextView textView4, CheckBox checkBox, LinearLayout linearLayout6, TextView textView5, ImageView imageView4, TextView textView6, Button button, TextView textView7, RelativeLayout relativeLayout3, WebView webView) {
        this.rootView = relativeLayout;
        this.vscroll2 = scrollView;
        this.linear47 = linearLayout;
        this.relativelayout8 = relativeLayout2;
        this.btnBack = imageView;
        this.linear48 = linearLayout2;
        this.imageview22 = imageView2;
        this.imageview23 = imageView3;
        this.textview28 = textView;
        this.view49 = view;
        this.boxUsername = linearLayout3;
        this.textview29 = textView2;
        this.etUsername = editText;
        this.view50 = view2;
        this.boxPassword = linearLayout4;
        this.textview30 = textView3;
        this.etPassword = editText2;
        this.linear51 = linearLayout5;
        this.textview31 = textView4;
        this.cbRememberMe = checkBox;
        this.linear52 = linearLayout6;
        this.textview32 = textView5;
        this.imageview24 = imageView4;
        this.tvError = textView6;
        this.btnLogin = button;
        this.tvForgotPassword = textView7;
        this.layoutLoadingOverlay = relativeLayout3;
        this.webviewLoadingGif = webView;
    }

    public static MainBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.vscroll2);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear47);
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.relativelayout8);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBack);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear48);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview22);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.imageview23);
        TextView textView = (TextView) findChildViewById(view, R.id.textview28);
        View viewFindChildViewById = findChildViewById(view, R.id.view49);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.boxUsername);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview29);
        EditText editText = (EditText) findChildViewById(view, R.id.etUsername);
        View viewFindChildViewById2 = findChildViewById(view, R.id.view50);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.boxPassword);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview30);
        EditText editText2 = (EditText) findChildViewById(view, R.id.etPassword);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.linear51);
        TextView textView4 = (TextView) findChildViewById(view, R.id.textview31);
        CheckBox checkBox = (CheckBox) findChildViewById(view, R.id.cbRememberMe);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.linear52);
        TextView textView5 = (TextView) findChildViewById(view, R.id.textview32);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.imageview24);
        TextView textView6 = (TextView) findChildViewById(view, R.id.tvError);
        Button button = (Button) findChildViewById(view, R.id.btnLogin);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tvForgotPassword);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.layoutLoadingOverlay);
        WebView webView = (WebView) findChildViewById(view, R.id.webviewLoadingGif);
        if (scrollView == null || linearLayout == null || relativeLayout2 == null || imageView == null || linearLayout2 == null || imageView2 == null || imageView3 == null || textView == null || viewFindChildViewById == null || linearLayout3 == null || textView2 == null || editText == null || viewFindChildViewById2 == null || linearLayout4 == null || textView3 == null || editText2 == null || linearLayout5 == null || textView4 == null || checkBox == null || linearLayout6 == null || textView5 == null || imageView4 == null || textView6 == null || button == null || textView7 == null || relativeLayout3 == null || webView == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new MainBinding(relativeLayout, scrollView, linearLayout, relativeLayout2, imageView, linearLayout2, imageView2, imageView3, textView, viewFindChildViewById, linearLayout3, textView2, editText, viewFindChildViewById2, linearLayout4, textView3, editText2, linearLayout5, textView4, checkBox, linearLayout6, textView5, imageView4, textView6, button, textView7, relativeLayout3, webView);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static MainBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static MainBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.main, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
