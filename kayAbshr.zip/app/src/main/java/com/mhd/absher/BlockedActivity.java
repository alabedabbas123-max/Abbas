package com.mhd.absher;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class BlockedActivity extends AppCompatActivity {
    private ValueEventListener banListener;
    private DatabaseReference dbRef;
    private String whatsappNumber = a.a("YmVyGwFkZHUc");

    private void attachClickListenerToButtons(View view, View.OnClickListener onClickListener) {
        CharSequence text;
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                attachClickListenerToButtons(viewGroup.getChildAt(i), onClickListener);
            }
            return;
        }
        if (view == null || !(view instanceof TextView) || (text = ((TextView) view).getText()) == null) {
            return;
        }
        if (text.toString().contains(a.a("jNyeiuD/jPX1n438")) || text.toString().contains(a.a("jfOfqeD/jc71n43hn6k=")) || text.toString().contains(a.a("YmVzGA9sZnQZ")) || text.toString().contains(a.a("YmVyGwFkZHUc"))) {
            view.setOnClickListener(onClickListener);
        }
    }

    private void checkFirebaseBanAndSupportPhone() {
        String string = getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0).getString(a.a("ICcjX2swNzRITBww"), "");
        if (string.isEmpty()) {
            return;
        }
        this.dbRef = FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(string);
        this.banListener = this.dbRef.addValueEventListener(new ValueEventListener() {
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }

            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String strValueOf;
                if (dataSnapshot.exists()) {
                    Boolean bool = (Boolean) dataSnapshot.child(a.a("PCcETFY7MSI=")).getValue(Boolean.class);
                    if (bool == null || !bool.booleanValue()) {
                        BlockedActivity.this.startActivity(new Intent((Context) BlockedActivity.this, (Class<?>) GuestServicesActivity.class));
                        BlockedActivity.this.finish();
                    } else {
                        if (!dataSnapshot.hasChild(a.a("JiE2XVcnIBZFVzsx")) || (strValueOf = String.valueOf(dataSnapshot.child(a.a("JiE2XVcnIBZFVzsx")).getValue())) == null || strValueOf.isEmpty()) {
                            return;
                        }
                        BlockedActivity.this.whatsappNumber = strValueOf;
                        BlockedActivity.this.updatePhoneNumberOnUI(BlockedActivity.this.whatsappNumber);
                    }
                }
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void openWhatsAppChat(String str) {
        String strReplaceAll = str.replaceAll(a.a("Dgp2AAEI"), "");
        if (!strReplaceAll.startsWith(a.a("bGJx")) && !strReplaceAll.startsWith(a.a("bGJw"))) {
            StringBuilder sb = new StringBuilder(a.a("bGJx"));
            if (strReplaceAll.startsWith(a.a("ZQ=="))) {
                strReplaceAll = strReplaceAll.substring(1);
            }
            strReplaceAll = sb.append(strReplaceAll).toString();
        }
        try {
            startActivity(new Intent(a.a("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="), Uri.parse(a.a("PSAyXUtve2lMSDx6MUVZIScnXUh7NylAFyYxKEkHJTwpQ11o") + strReplaceAll + a.a("cyAjVUxo") + Uri.encode(a.a("jfOfqeDmjcL1n4zRZvWBjNCfp+HWjcP1tHWM5fSwjftm9LmM12b1n4zQnoDg7Yz3Aw==")))));
        } catch (Exception e) {
            Toast.makeText((Context) this, (CharSequence) a.a("jf6elODljPcN4dSM7PWVdY3O9Z+N/p6e4PKM7gw="), 1).show();
        }
    }

    private void setupClickListeners() {
        View viewFindViewById;
        View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BlockedActivity.this.openWhatsAppChat(BlockedActivity.this.whatsappNumber);
            }
        };
        for (String str : new String[]{a.a("NyAoblc7ICdOTAI8J1lLNCQ2"), a.a("NyAoelA0IDVsSCU="), a.a("NyAock89NTJeWSUk"), a.a("NyEyWVc7ZQ=="), a.a("NyEyWVc7Zg=="), a.a("ISIWRVc7MQhYVTcxNA=="), a.a("ITE+WU48MTEcDg=="), a.a("OT0oSFknZQ=="), a.a("OT0oSFknZg==")}) {
            int identifier = getResources().getIdentifier(str, a.a("PDA="), getPackageName());
            if (identifier != 0 && (viewFindViewById = findViewById(identifier)) != null) {
                if ((str.equals(a.a("ISIWRVc7MQhYVTcxNA==")) || str.equals(a.a("ITE+WU48MTEcDg=="))) && (viewFindViewById instanceof TextView)) {
                    ((TextView) viewFindViewById).setText(this.whatsappNumber);
                }
                viewFindViewById.setOnClickListener(onClickListener);
            }
        }
        View viewFindViewById2 = findViewById(android.R.id.content);
        if (viewFindViewById2 != null) {
            attachClickListenerToButtons(viewFindViewById2, onClickListener);
        }
    }

    public void updatePhoneNumberOnUI(String str) {
        for (String str2 : new String[]{a.a("ISIWRVc7MQhYVTcxNA=="), a.a("ITE+WU48MTEcDg==")}) {
            int identifier = getResources().getIdentifier(str2, a.a("PDA="), getPackageName());
            if (identifier != 0) {
                View viewFindViewById = findViewById(identifier);
                if (viewFindViewById instanceof TextView) {
                    ((TextView) viewFindViewById).setText(str);
                }
            }
        }
    }

    public void onBackPressed() {
        moveTaskToBack(true);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int identifier = getResources().getIdentifier(a.a("NzgpTlMwMA=="), a.a("OTU/Qk0h"), getPackageName());
        if (identifier == 0) {
            identifier = getResources().getIdentifier(a.a("NDcyRE48ID9yWjk7JUZdMQ=="), a.a("OTU/Qk0h"), getPackageName());
        }
        if (identifier != 0) {
            setContentView(identifier);
        }
        getWindow().getDecorView().setLayoutDirection(1);
        setupClickListeners();
        checkFirebaseBanAndSupportPhone();
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.dbRef == null || this.banListener == null) {
            return;
        }
        this.dbRef.removeEventListener(this.banListener);
    }
}
