package com.mhd.absher;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class PassportDetailsActivity extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.passport_details);
        getWindow().getDecorView().setLayoutDirection(1);
        View viewFindViewById = findViewById(R.id.btnBack);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    PassportDetailsActivity.this.finish();
                }
            });
        }
    }
}
