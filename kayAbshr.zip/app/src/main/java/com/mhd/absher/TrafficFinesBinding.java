package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class TrafficFinesBinding {
    public final LinearLayout bottomAreaTraffic;
    public final TextView btnBackTraffic;
    public final LinearLayout btnHandledObjections;
    public final TextView btnSearchTraffic;
    public final LinearLayout emptyContent;
    public final ImageView imgEmpty;
    public final View indicatorPaid;
    public final LinearLayout indicatorRow;
    public final View indicatorUnpaid;
    public final RelativeLayout rootTraffic;
    public final LinearLayout tabsRow;
    public final TextView textview174;
    public final RelativeLayout topBarTraffic;
    public final TextView tvEmptyMain;
    public final TextView tvEmptySub;
    public final TextView tvTabPaid;
    public final TextView tvTabUnpaid;
    public final TextView tvTitleTraffic;

    private TrafficFinesBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, TextView textView, TextView textView2, TextView textView3, LinearLayout linearLayout, TextView textView4, TextView textView5, LinearLayout linearLayout2, View view, View view2, LinearLayout linearLayout3, ImageView imageView, TextView textView6, TextView textView7, LinearLayout linearLayout4, LinearLayout linearLayout5, TextView textView8) {
        this.rootTraffic = relativeLayout;
        this.topBarTraffic = relativeLayout2;
        this.btnBackTraffic = textView;
        this.tvTitleTraffic = textView2;
        this.btnSearchTraffic = textView3;
        this.tabsRow = linearLayout;
        this.tvTabUnpaid = textView4;
        this.tvTabPaid = textView5;
        this.indicatorRow = linearLayout2;
        this.indicatorUnpaid = view;
        this.indicatorPaid = view2;
        this.emptyContent = linearLayout3;
        this.imgEmpty = imageView;
        this.tvEmptyMain = textView6;
        this.tvEmptySub = textView7;
        this.bottomAreaTraffic = linearLayout4;
        this.btnHandledObjections = linearLayout5;
        this.textview174 = textView8;
    }

    public static TrafficFinesBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBarTraffic);
        TextView textView = (TextView) findChildViewById(view, R.id.btnBackTraffic);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvTitleTraffic);
        TextView textView3 = (TextView) findChildViewById(view, R.id.btnSearchTraffic);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.tabsRow);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tvTabUnpaid);
        TextView textView5 = (TextView) findChildViewById(view, R.id.tvTabPaid);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.indicatorRow);
        View viewFindChildViewById = findChildViewById(view, R.id.indicatorUnpaid);
        View viewFindChildViewById2 = findChildViewById(view, R.id.indicatorPaid);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.emptyContent);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.imgEmpty);
        TextView textView6 = (TextView) findChildViewById(view, R.id.tvEmptyMain);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tvEmptySub);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.bottomAreaTraffic);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.btnHandledObjections);
        TextView textView8 = (TextView) findChildViewById(view, R.id.textview174);
        if (relativeLayout2 == null || textView == null || textView2 == null || textView3 == null || linearLayout == null || textView4 == null || textView5 == null || linearLayout2 == null || viewFindChildViewById == null || viewFindChildViewById2 == null || linearLayout3 == null || imageView == null || textView6 == null || textView7 == null || linearLayout4 == null || linearLayout5 == null || textView8 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new TrafficFinesBinding(relativeLayout, relativeLayout2, textView, textView2, textView3, linearLayout, textView4, textView5, linearLayout2, viewFindChildViewById, viewFindChildViewById2, linearLayout3, imageView, textView6, textView7, linearLayout4, linearLayout5, textView8);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static TrafficFinesBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static TrafficFinesBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.traffic_fines, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootTraffic;
    }
}
