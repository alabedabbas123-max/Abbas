package com.shima.demo;

import java.util.*;

/**
 * The IDE command catalogue. UI controls only submit an id; eligibility, dynamic titles and
 * execution routing live inside the command objects — the same command serves the palette,
 * the cascading menus, toolbar icons and shortcuts without duplicated menu code.
 */
public final class CommandCenter {
  public interface Host {
    boolean hasProject();

    boolean hasEditor();

    boolean canUndo();

    boolean canRedo();

    /** لغة الملف الحي لضمان ألا تنفذ أوامر Java النصية على XML قبل توفير بدائل XML الآمنة. */
    boolean isXmlEditor();

    /** حالة الكتابة الحية للملف النشط. */
    boolean isEditorWritable();

    /** هل التبويب الحالي ملف تخطيط XML يدعمه المصمم. */
    boolean isLayoutXmlEditor();

    boolean panelsShowing();

    void execute(String id);
  }

  /** Per-command live condition evaluated right before a menu or palette is displayed. */
  public interface StateCheck {
    boolean test(Host h);
  }

  /** Dynamic title provider (reference pattern: items such as show/hide panels flip text). */
  public interface TitleProvider {
    String title(Host h);
  }

  public static final class Command {
    public final String id, title, group;
    public final boolean needsProject, needsEditor;
    final StateCheck liveState;
    final TitleProvider dynamicTitle;

    Command(String i, String t, String g, boolean p, boolean e, StateCheck s, TitleProvider d) {
      id = i;
      title = t;
      group = g;
      needsProject = p;
      needsEditor = e;
      liveState = s;
      dynamicTitle = d;
    }

    public boolean enabled(Host h) {
      return (!needsProject || h.hasProject())
          && (!needsEditor || h.hasEditor())
          && (liveState == null || liveState.test(h));
    }

    /** Title shown right now; falls back to the static title when no provider is attached. */
    public String titleFor(Host h) {
      return dynamicTitle == null ? title : dynamicTitle.title(h);
    }
  }

  private final LinkedHashMap<String, Command> all = new LinkedHashMap<>();
  private final LinkedHashMap<String, String[]> menus = new LinkedHashMap<>();

  public CommandCenter() {
    add("run", "تشغيل المشروع", "البناء", true, false);
    add("build_debug", "بناء APK للتصحيح", "البناء", true, false);
    add("build_release", "بناء APK للإصدار", "البناء", true, false);
    add("clean", "تنظيف نواتج البناء", "البناء", true, false);
    add("terminal", "طرفية المشروع", "البناء", true, false);
    add("save", "حفظ الملف", "المحرر", true, true, Host::isEditorWritable, null);
    add("undo", "تراجع", "المحرر", false, true, Host::canUndo, null);
    add("redo", "إعادة", "المحرر", false, true, Host::canRedo, null);
    add("find", "بحث في الملف", "المحرر", false, true);
    add("replace", "بحث واستبدال", "المحرر", false, true, Host::isEditorWritable, null);
    add("goto_line", "الانتقال إلى سطر", "المحرر", false, true);
    add("goto_definition", "الانتقال إلى التعريف", "المحرر", false, true);
    add("design", "تصميم الواجهة", "المحرر", false, true,
        h -> h.isLayoutXmlEditor() && h.isEditorWritable(), null);
    add("format", "تنسيق المصدر", "المحرر", false, true,
        h -> !h.isXmlEditor() && h.isEditorWritable(), null);
    add("comment", "تعليق / إلغاء تعليق الأسطر", "المحرر", false, true,
        h -> !h.isXmlEditor() && h.isEditorWritable(), null);
    add("select_all", "تحديد الكل", "المحرر", false, true);
    add("analyze", "فحص بناء الجمل", "المحرر", false, true);
    add("complete", "الإكمال التلقائي", "المحرر", false, true);
    add("find_usages", "استعراض الاستخدامات", "المحرر", false, true);
    add("goto_element", "انتقال إلى العنصر", "المحرر", false, true);
    add(
        "panels",
        "اللوحات المتتالية",
        "العرض",
        false,
        false,
        null,
        h -> h.panelsShowing() ? "إخفاء اللوحات المتتالية" : "اللوحات المتتالية");
    add("show_errors", "الأخطاء", "العرض", false, false);
    add("show_search_results", "نتائج البحث", "العرض", false, false);
    add("show_build_output", "مخرجات البناء والتشغيل", "العرض", false, false);
    add("show_debugger", "المصحح", "العرض", false, false);
    add("show_logcat", "LogCat", "العرض", false, false);
    add("close_file", "إغلاق الملف الحالي", "المحرر", false, true);
    add("close_all", "إغلاق جميع الملفات", "المحرر", false, true);
    add("files", "ملفات المشروع", "الملفات", false, false);
    add("new_file", "ملف جديد", "الملفات", true, false);
    add("new_folder", "مجلد جديد", "الملفات", true, false);
    add("refresh", "تحديث شجرة المشروع", "الملفات", false, false);
    add("git_status", "Git: الحالة", "Git", true, false);
    add("git_log", "Git: آخر الالتزامات", "Git", true, false);
    add("git_add", "Git: إضافة التغييرات", "Git", true, false);
    add("git_commit", "Git: إنشاء التزام", "Git", true, false);
    add("git_pull", "Git: سحب", "Git", true, false);
    add("git_push", "Git: رفع", "Git", true, false);
    add("theme", "نظام الألوان", "عام", false, false);
    add("permissions", "صلاحيات التطبيق", "عام", false, false);
    add("settings", "الإعدادات", "عام", false, false);
    add("about", "حول التطبيق", "عام", false, false);

    // سياقات القوائم المتدرجة — نفس الأمر يظهر في أكثر من سياق كما في سجل المرجع.
    menus.put("code", new String[] {
      "analyze", "complete", "format", "comment", "select_all", "goto_line", "goto_definition",
      "close_file", "close_all"
    });
    menus.put("view", new String[] {
      "files", "panels", "show_errors", "show_search_results", "show_build_output",
      "show_debugger", "show_logcat", "theme"
    });
    menus.put("find", new String[] {"find", "replace", "find_usages", "goto_element", "goto_line"});
    menus.put("project", new String[] {
      "run", "build_debug", "build_release", "clean", "new_file", "new_folder", "refresh", "files"
    });
    menus.put("git", new String[] {
      "git_status", "git_log", "git_add", "git_commit", "git_pull", "git_push"
    });
    menus.put("tools", new String[] {"terminal", "permissions", "theme", "about"});
  }

  private void add(String i, String t, String g, boolean p, boolean e) {
    add(i, t, g, p, e, null, null);
  }

  private void add(
      String i, String t, String g, boolean p, boolean e, StateCheck s, TitleProvider d) {
    all.put(i, new Command(i, t, g, p, e, s, d));
  }

  public Command get(String id) {
    return all.get(id);
  }

  public List<String> groups() {
    LinkedHashSet<String> s = new LinkedHashSet<>();
    for (Command c : all.values()) s.add(c.group);
    return new ArrayList<>(s);
  }

  public List<Command> inGroup(String group) {
    ArrayList<Command> r = new ArrayList<>();
    for (Command c : all.values()) if (c.group.equals(group)) r.add(c);
    return r;
  }

  /** Commands registered for one cascading-menu context, in display order. */
  public List<Command> inMenu(String menuId) {
    ArrayList<Command> r = new ArrayList<>();
    String[] ids = menus.get(menuId);
    if (ids != null) for (String id : ids) if (all.containsKey(id)) r.add(all.get(id));
    return r;
  }

  public boolean dispatch(String id, Host host) {
    Command c = all.get(id);
    if (c == null || !c.enabled(host)) return false;
    host.execute(id);
    return true;
  }
}
