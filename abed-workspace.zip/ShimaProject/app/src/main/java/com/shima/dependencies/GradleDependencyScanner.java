package com.shima.dependencies;

import android.os.Handler;
import android.os.Looper;
import android.content.Context;
import com.shima.demo.UiStrings;
import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * تقرير 04 — فاحص مكتبات dependencies.
 *
 * يقرأ ملفات Gradle قراءة نصية فقط (بدون تنفيذ أي سكربت)، يستخرج الإحداثيات والنطاقات، يفحص
 * المخزن المحلي و libs/ وكاش Gradle، ثم يُنتج تقرير حالة عربيًا يُعرض في لوحة Build دون أن
 * يُبطئ المحرر. التحميل نفسه لا يحدث تلقائيًا — الفاحص يقترحه فقط، كيلا تُنزَّل أرشيفات مجهولة.
 */
public final class GradleDependencyScanner {

  public interface Listener {
    void onReport(List<String> lines);
  }

  /** حالات الاعتمادية كما في التقرير: DECLARED / LOCAL_FOUND / DOWNLOAD_REQUIRED. */
  private static final String STATE_DECLARED = "declared";
  private static final String STATE_LOCAL = "local";
  private static final String STATE_NEEDS_DOWNLOAD = "download_required";

  private static final class Dependency {
    String group = "";
    String name = "";
    String version = "";
    String scope = "";
    String state = STATE_DECLARED;
    String artifact = "";

    String coordinates() {
      return group + ":" + name + ":" + version;
    }
  }

  private static final Set<String> SKIPPED_DIRS =
      new HashSet<>(
          Arrays.asList(
              ".git", ".gradle", "build", "out", "target", "node_modules", ".idea", ".cxx",
              "captures"));

  // implementation 'group:name:version' / api("group:name:version") / classpath "g:n:v"
  private static final Pattern COORDINATES =
      Pattern.compile(
          "(implementation|api|compileOnly|runtimeOnly|testImplementation"
              + "|androidTestImplementation|kapt|ksp|classpath)\\s*"
              + "(?:\\(\\s*)?[\"']([A-Za-z0-9_.\\-]+):([A-Za-z0-9_.\\-]+):([A-Za-z0-9_.\\-+]+)[\"']");

  private static final Pattern PLUGIN =
      Pattern.compile("(?:^|[\\s{(])(?:id|kotlin)\\s*\\(?\\s*[\"']([a-z][A-Za-z0-9_.\\-]+)[\"']",
          Pattern.MULTILINE);

  private static final int MAX_BUILD_FILES = 64;
  private static final int MAX_SCANNED_DIRS = 4_000;
  private static final int MAX_DECLARATIONS = 500;

  private GradleDependencyScanner() {}

  /** ينفذ الفحص في خيط خلفي ويعيد التقرير إلى الخيط الرئيسي — بلا أي I/O على Main Thread. */
  public static void scanAsync(Context context, File projectRoot, Listener listener) {
    if (listener == null) return;
    final Context app = context == null ? null : context.getApplicationContext();
    ExecutorService worker =
        Executors.newSingleThreadExecutor(
            runnable -> {
              Thread thread = new Thread(runnable, "shima-dependency-scan");
              thread.setPriority(Thread.MIN_PRIORITY + 2);
              return thread;
            });
    Handler main = new Handler(Looper.getMainLooper());
    worker.execute(
        () -> {
          List<String> lines;
          try {
            lines = scan(app, projectRoot);
          } catch (Throwable failure) {
            lines = new ArrayList<>();
            lines.add(UiStrings.format(app, "ui_dependency_scan_failed", UiStrings.message(app, failure)));
          }
          final List<String> result = lines;
          main.post(() -> listener.onReport(result));
          worker.shutdown();
        });
  }

  /** الفحص الفعلي: scan metadata → parse declarations → local resolution → plan. */
  private static List<String> scan(Context context, File projectRoot) {
    ArrayList<String> report = new ArrayList<>();
    report.add(UiStrings.get(context, "ui_dependency_scan_header"));
    if (projectRoot == null || !projectRoot.isDirectory()) {
      report.add(UiStrings.get(context, "ui_dependency_project_folder_missing"));
      return report;
    }

    ArrayList<File> buildFiles = new ArrayList<>();
    ArrayList<File> libArtifacts = new ArrayList<>();
    ArrayDeque<File> pending = new ArrayDeque<>();
    pending.add(projectRoot);
    int inspectedDirs = 0;
    while (!pending.isEmpty() && inspectedDirs++ < MAX_SCANNED_DIRS) {
      File directory = pending.removeFirst();
      File[] children = directory.listFiles();
      if (children == null) continue;
      for (File child : children) {
        if (child.isDirectory()) {
          if (SKIPPED_DIRS.contains(child.getName().toLowerCase(Locale.US))) continue;
          if ("libs".equals(child.getName().toLowerCase(Locale.US))) collectArtifacts(child, libArtifacts);
          pending.addLast(child);
        } else {
          String name = child.getName().toLowerCase(Locale.US);
          if ((name.equals("build.gradle") || name.equals("build.gradle.kts")
                  || name.equals("settings.gradle") || name.equals("settings.gradle.kts"))
              && buildFiles.size() < MAX_BUILD_FILES) buildFiles.add(child);
        }
      }
    }

    LinkedHashMap<String, Dependency> declared = new LinkedHashMap<>();
    HashSet<String> plugins = new HashSet<>();
    for (File buildFile : buildFiles) {
      String text = readSmall(buildFile);
      if (text.isEmpty()) continue;
      Matcher coords = COORDINATES.matcher(text);
      while (coords.find() && declared.size() < MAX_DECLARATIONS) {
        Dependency dependency = new Dependency();
        dependency.scope = coords.group(1);
        dependency.group = coords.group(2);
        dependency.name = coords.group(3);
        dependency.version = coords.group(4);
        // الأولوية لأول تصريح: duplicate coordinates من سكوبات مختلفة لا تكرر الإدخال.
        declared.putIfAbsent(dependency.coordinates(), dependency);
      }
      Matcher pluginIds = PLUGIN.matcher(text);
      while (pluginIds.find()) plugins.add(pluginIds.group(1));
    }

    if (declared.isEmpty()) {
      report.add(UiStrings.get(context, "ui_dependency_none_found"));
    } else {
      File gradleCache = gradleCacheRoot();
      int local = 0, missing = 0;
      for (Dependency dependency : declared.values()) {
        resolveLocally(dependency, libArtifacts, gradleCache);
        if (STATE_LOCAL.equals(dependency.state)) local++;
        else if (STATE_NEEDS_DOWNLOAD.equals(dependency.state)) missing++;
      }
      report.add(
          String.format(
              Locale.US,
              UiStrings.get(context, "ui_dependency_scan_summary"),
              declared.size(), local, missing, buildFiles.size()));
      for (Dependency dependency : declared.values()) {
        String marker = STATE_LOCAL.equals(dependency.state) ? "✔" : "⬇";
        String stateLabel =
            UiStrings.get(
                context,
                STATE_LOCAL.equals(dependency.state)
                    ? "ui_dependency_state_local"
                    : STATE_NEEDS_DOWNLOAD.equals(dependency.state)
                        ? "ui_dependency_state_download"
                        : "ui_dependency_state_declared");
        String line =
            UiStrings.format(
                context,
                "ui_dependency_report_line",
                marker,
                stateLabel,
                dependency.coordinates(),
                dependency.scope);
        if (!dependency.artifact.isEmpty())
          line += UiStrings.format(context, "ui_dependency_artifact_suffix", dependency.artifact);
        report.add(line);
      }
      if (missing > 0)
        report.add(UiStrings.get(context, "ui_dependency_download_suggestion"));
    }
    if (!plugins.isEmpty()) {
      ArrayList<String> ordered = new ArrayList<>(plugins);
      Collections.sort(ordered);
      report.add(
          UiStrings.format(
              context,
              "ui_dependency_declared_plugins",
              join(ordered, UiStrings.get(context, "ui_list_separator"))));
    }
    report.add(UiStrings.get(context, "ui_dependency_scan_footer"));
    return report;
  }

  /** يطابق الاعتمادية مع libs/ أولًا ثم مع كاش Gradle — بدون أي تنزيل. */
  private static void resolveLocally(
      Dependency dependency, List<File> libArtifacts, File gradleCache) {
    String expectedPrefix = (dependency.name + "-" + dependency.version).toLowerCase(Locale.US);
    for (File artifact : libArtifacts) {
      if (artifact.getName().toLowerCase(Locale.US).startsWith(expectedPrefix)) {
        dependency.state = STATE_LOCAL;
        dependency.artifact = artifact.getName();
        return;
      }
    }
    if (gradleCache != null) {
      File cached =
          new File(
              gradleCache,
              dependency.group + File.separator + dependency.name + File.separator + dependency.version);
      if (cached.isDirectory()) {
        dependency.state = STATE_LOCAL;
        dependency.artifact = "gradle-cache";
        return;
      }
    }
    dependency.state = STATE_NEEDS_DOWNLOAD;
  }

  private static void collectArtifacts(File libs, List<File> output) {
    File[] files = libs.listFiles();
    if (files == null) return;
    for (File file : files) {
      if (!file.isFile()) continue;
      String name = file.getName().toLowerCase(Locale.US);
      if ((name.endsWith(".jar") || name.endsWith(".aar")) && file.length() > 0) output.add(file);
    }
  }

  private static File gradleCacheRoot() {
    try {
      File home = new File(System.getProperty("user.home", ""), ".gradle");
      File modules = new File(home, "caches/modules-2/files-2.1");
      return modules.isDirectory() ? modules : null;
    } catch (Throwable ignored) {
      return null;
    }
  }

  private static String readSmall(File file) {
    try {
      if (file.length() > 512 * 1024) return "";
      java.io.InputStream input = new java.io.FileInputStream(file);
      try {
        return com.shima.performance.EncodingManager.readUtf8(input, 512 * 1024);
      } finally {
        input.close();
      }
    } catch (Throwable ignored) {
      return "";
    }
  }

  private static String join(List<String> values, String separator) {
    StringBuilder joined = new StringBuilder();
    for (String value : values) {
      if (joined.length() > 0) joined.append(separator);
      joined.append(value);
    }
    return joined.toString();
  }
}
