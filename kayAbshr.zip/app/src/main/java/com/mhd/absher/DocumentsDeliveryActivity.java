package com.mhd.absher;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class DocumentsDeliveryActivity extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.documents_delivery);
        View viewFindViewById = findViewById(R.id.btnBack);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DocumentsDeliveryActivity.this.finish();
                }
            });
        }
        View viewFindViewById2 = findViewById(R.id.tabReceived);
        View viewFindViewById3 = findViewById(R.id.tabSent);
        final View viewFindViewById4 = findViewById(R.id.indicatorReceived);
        final View viewFindViewById5 = findViewById(R.id.indicatorSent);
        if (viewFindViewById2 != null) {
            viewFindViewById2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (viewFindViewById4 != null) {
                        viewFindViewById4.setVisibility(0);
                    }
                    if (viewFindViewById5 != null) {
                        viewFindViewById5.setVisibility(4);
                    }
                }
            });
        }
        if (viewFindViewById3 != null) {
            viewFindViewById3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (viewFindViewById5 != null) {
                        viewFindViewById5.setVisibility(0);
                    }
                    if (viewFindViewById4 != null) {
                        viewFindViewById4.setVisibility(4);
                    }
                }
            });
        }
    }
}
