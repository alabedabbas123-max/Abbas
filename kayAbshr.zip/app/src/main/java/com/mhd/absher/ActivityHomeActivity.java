package com.mhd.absher;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Locale;

public class ActivityHomeActivity extends AppCompatActivity {
    private DatabaseReference dbRef;
    private boolean isNavigatingToBlocked = false;
    private ValueEventListener userDataListener;

    private void checkAndApplyDocsOnlyMode() {
        if (getIntent() == null || !getIntent().getBooleanExtra(a.a("BhwJemcRGwV+ZxoaCnQ="), false)) {
            return;
        }
        hideOldTitleViews(findViewById(android.R.id.content));
        View viewFindViewById = findViewById(android.R.id.content);
        if (viewFindViewById instanceof ViewGroup) {
            hideAllExceptDocsContainer((ViewGroup) viewFindViewById);
        }
        setupDigitalDocumentsHeaderAndSectionTitles();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void checkNetworkAndSyncData() {
        if (!isNetworkConnected()) {
            Toast.makeText((Context) this, (CharSequence) a.a("je2eneDkjOH0s43YZvSyjfiehRiN/p+l4dSM9w3g8o3C9Z+N/p6Y4PKNwg3g/Yzh9LyN8Z+r4P+M9/S+jf5m9LyN856e4P+M6PWXjfOfqBiN85+p4P+M8fWQjN6frxk="), 1).show();
            if (openScreen(a.a("GzsPQ0wwJihITBQ3MkROPCA/"), a.a("OzsPQ0wwJihITBQ3MkROPCA/"), a.a("GzsPQ0wwJihITA=="))) {
                return;
            }
            finish();
            return;
        }
        try {
            final SharedPreferences sharedPreferences = getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0);
            final SharedPreferences sharedPreferences2 = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
            SharedPreferences sharedPreferences3 = getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
            SharedPreferences sharedPreferences4 = getSharedPreferences(a.a("ACcjX3w0ICd9SjAyNQ=="), 0);
            String string = sharedPreferences3.getString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), "");
            if (string.isEmpty()) {
                string = sharedPreferences.getString(a.a("ICcjX2swNzRITBww"), "");
            }
            if (string.isEmpty()) {
                string = sharedPreferences2.getString(a.a("ICcjX3MwLQ=="), "");
            }
            if (string.isEmpty()) {
                string = sharedPreferences4.getString(a.a("JjElX10hHyNU"), sharedPreferences2.getString(a.a("JjElX10hHyNU"), ""));
            }
            if (string.isEmpty()) {
                Toast.makeText((Context) this, (CharSequence) a.a("jNCfqBiM3p6H4dB0norh0Yz/9ZOM3J6cGI3tn6nh3HSeiuHRjcP1gY3ln6wYjfOfqeDmjPf0so3YZvSyjeWegeHcdJ6I4OyM4fWXjf1m9ZKN556B4d+Nwg3g8o3C9ZeN+p+l4dF1"), 0).show();
                return;
            }
            this.dbRef = FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(string);
            this.userDataListener = new ValueEventListener() {
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }

                /* JADX WARN: Code duplicated, block: B:132:0x0850  */
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    boolean zEqualsIgnoreCase;
                    boolean zBooleanValue;
                    boolean z;
                    boolean zBooleanValue2;
                    boolean zBooleanValue3;
                    boolean zBooleanValue4;
                    String str;
                    if (!dataSnapshot.exists() || ActivityHomeActivity.this.isNavigatingToBlocked) {
                        return;
                    }
                    if (dataSnapshot.hasChild(a.a("PCcETFY7MSI="))) {
                        Object value = dataSnapshot.child(a.a("PCcETFY7MSI=")).getValue();
                        if (value instanceof Boolean) {
                            zEqualsIgnoreCase = ((Boolean) value).booleanValue();
                        } else if (value != null) {
                            zEqualsIgnoreCase = a.a("ISYzSA==").equalsIgnoreCase(String.valueOf(value));
                        } else {
                            zEqualsIgnoreCase = false;
                        }
                    } else {
                        zEqualsIgnoreCase = false;
                    }
                    if (zEqualsIgnoreCase) {
                        ActivityHomeActivity.this.isNavigatingToBlocked = true;
                        sharedPreferences2.edit().putBoolean(a.a("PCcETFY7MSI="), true).apply();
                        if (ActivityHomeActivity.this.dbRef != null && ActivityHomeActivity.this.userDataListener != null) {
                            ActivityHomeActivity.this.dbRef.removeEventListener(ActivityHomeActivity.this.userDataListener);
                        }
                        ActivityHomeActivity.this.openBlockedScreen();
                        return;
                    }
                    sharedPreferences2.edit().putBoolean(a.a("PCcETFY7MSI="), false).apply();
                    SharedPreferences.Editor editorEdit = sharedPreferences2.edit();
                    if (dataSnapshot.hasChild(a.a("NjU0SWwsJCM=")) && (str = (String) dataSnapshot.child(a.a("NjU0SWwsJCM=")).getValue(String.class)) != null && !str.isEmpty()) {
                        editorEdit.putString(a.a("NjU0SWwsJCM="), str);
                    }
                    if (dataSnapshot.hasChild(a.a("JjwpWns8IC9XXTsdIg=="))) {
                        Object value2 = dataSnapshot.child(a.a("JjwpWns8IC9XXTsdIg==")).getValue();
                        zBooleanValue = value2 instanceof Boolean ? ((Boolean) value2).booleanValue() : a.a("ISYzSA==").equalsIgnoreCase(String.valueOf(value2));
                    } else {
                        zBooleanValue = false;
                    }
                    if (dataSnapshot.hasChild(a.a("JjwpWmowJy9JXTsgD0k="))) {
                        Object value3 = dataSnapshot.child(a.a("JjwpWmowJy9JXTsgD0k=")).getValue();
                        if (value3 instanceof Boolean) {
                            zBooleanValue4 = ((Boolean) value3).booleanValue();
                        } else {
                            zBooleanValue4 = !a.a("MzUqXl0=").equalsIgnoreCase(String.valueOf(value3));
                        }
                        z = zBooleanValue4;
                    } else {
                        z = true;
                    }
                    if (dataSnapshot.hasChild(a.a("JjwpWm48Jy9ZVycdIg=="))) {
                        Object value4 = dataSnapshot.child(a.a("JjwpWm48Jy9ZVycdIg==")).getValue();
                        zBooleanValue2 = value4 instanceof Boolean ? ((Boolean) value4).booleanValue() : a.a("ISYzSA==").equalsIgnoreCase(String.valueOf(value4));
                    } else {
                        zBooleanValue2 = false;
                    }
                    if (dataSnapshot.hasChild(a.a("JjwpWnQ8NyNDSzA="))) {
                        Object value5 = dataSnapshot.child(a.a("JjwpWnQ8NyNDSzA=")).getValue();
                        if (value5 instanceof Boolean) {
                            zBooleanValue3 = ((Boolean) value5).booleanValue();
                        } else {
                            zBooleanValue3 = !a.a("MzUqXl0=").equalsIgnoreCase(String.valueOf(value5));
                        }
                    } else {
                        zBooleanValue3 = true;
                    }
                    editorEdit.putBoolean(a.a("JjwpWns8IC9XXTsdIg=="), zBooleanValue);
                    editorEdit.putBoolean(a.a("JjwpWmowJy9JXTsgD0k="), z);
                    editorEdit.putBoolean(a.a("JjwpWm48Jy9ZVycdIg=="), zBooleanValue2);
                    editorEdit.putBoolean(a.a("JjwpWnQ8NyNDSzA="), zBooleanValue3);
                    editorEdit.apply();
                    ActivityHomeActivity.this.updateCardsVisibility(zBooleanValue, z, zBooleanValue2, zBooleanValue3);
                    String safeString = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("ICcjX3E4NSFI"), a.a("ACcjX3E4NSFI"), a.a("ICcjX2c8OSdKXQ=="), a.a("JSYpS1E5MQ9AWTIx"));
                    if (safeString != null && !safeString.trim().isEmpty()) {
                        editorEdit.putString(a.a("ICcjX3E4NSFI"), safeString);
                        editorEdit.apply();
                        ActivityHomeActivity.this.updateUserImageUI(safeString);
                    }
                    String safeString2 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("OzUrSHkn"), a.a("GzUrSHkn"), a.a("OzUrSGc0Jg=="), a.a("OzUrSA=="));
                    if (safeString2 != null) {
                        editorEdit.putString(a.a("OzUrSHkn"), safeString2);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvUserName, safeString2);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardNameHome, safeString2);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_citizen_name_ar, safeString2);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseNameAr, safeString2);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_name_ar, safeString2);
                    }
                    String safeString3 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("OzUrSH07"), a.a("GzUrSH07"), a.a("OzUrSGcwOg=="));
                    if (safeString3 != null) {
                        editorEdit.putString(a.a("OzUrSH07"), safeString3);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardNameEn, safeString3);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseNameEn, safeString3);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_name_en, safeString3);
                        ActivityHomeActivity.this.setTextByName(a.a("ISIZTlEhPTxIVgo6J0BdCjEo"), safeString3);
                        ActivityHomeActivity.this.setTextByName(a.a("ISIFREw8LiNDdjQ5I2hW"), safeString3);
                        ActivityHomeActivity.this.setTextByName(a.a("ISIZTlEhPTxIVgo6J0BdCjEoSlQ8Jy4="), safeString3);
                    }
                    String safeString4 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("PDAIWFU3MTQ="), a.a("HDAIWFU3MTQ="), a.a("PDAZQ004NiNf"), a.a("PDA="));
                    if (safeString4 != null) {
                        editorEdit.putString(a.a("PDAIWFU3MTQ="), safeString4);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvUserId, safeString4);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardIdHome, ActivityHomeActivity.this.toArabicNumbers(safeString4));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_citizen_id_number, ActivityHomeActivity.this.toArabicNumbers(safeString4));
                        ActivityHomeActivity.this.setTextByName(a.a("ISIZTlEhPTxIVgo9InJWIDkkSEoKMSg="), safeString4);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseIdNumberAr, ActivityHomeActivity.this.toArabicNumbers(safeString4));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseIdNumberEn, safeString4);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_id_number, ActivityHomeActivity.this.toArabicNumbers(safeString4));
                        ActivityHomeActivity.this.updateQRCodes(safeString4);
                        sharedPreferences.edit().putString(a.a("JjUwSFwKPSJyViA5JEhK"), safeString4).apply();
                    }
                    String safeString5 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("Nz00WVARNTJI"), a.a("Fz00WVARNTJI"), a.a("Nz00WVAKMCdZXQ=="));
                    if (safeString5 != null) {
                        editorEdit.putString(a.a("Nz00WVARNTJI"), safeString5);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardBirthDate, ActivityHomeActivity.this.toArabicNumbers(safeString5));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_citizen_birth_date, ActivityHomeActivity.this.toArabicNumbers(safeString5));
                        ActivityHomeActivity.this.setTextByName(a.a("ISIZTlEhPTxIVgo2L19MPQsiTEwwCyND"), ActivityHomeActivity.this.toEnglishNumbers(safeString5));
                        ActivityHomeActivity.this.setTextByName(a.a("ISIFREw8LiNDejwmMkV8NCAjaFY="), ActivityHomeActivity.this.toEnglishNumbers(safeString5));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseBirthDateAr, ActivityHomeActivity.this.toArabicNumbers(safeString5));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseBirthDateEn, ActivityHomeActivity.this.toEnglishNumbers(safeString5));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_birth_date, ActivityHomeActivity.this.toArabicNumbers(safeString5));
                    }
                    String safeString6 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("OzUyRFc7NSpETCw="), a.a("GzUyRFc7NSpETCw="), a.a("OzUyRFc7NSpETCwLJ18="));
                    if (safeString6 != null) {
                        editorEdit.putString(a.a("OzUyRFc7NSpETCw="), safeString6);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardNationality, safeString6);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseNationalityAr, safeString6);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_nationality, safeString6);
                        String safeString7 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("OzUyRFc7NSpETCwRKA=="), a.a("GzUyRFc7NSpETCwRKA=="), a.a("OzUyRFc7NSpETCwLI0M="));
                        if (safeString7 == null || safeString7.trim().isEmpty()) {
                            safeString7 = ActivityHomeActivity.getEnglishNationality(safeString6);
                        }
                        editorEdit.putString(a.a("OzUyRFc7NSpETCwRKA=="), safeString7);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseNationalityEn, safeString7);
                    }
                    String safeString8 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("OT0lSFYmMRJUSDA="), a.a("GT0lSFYmMRJUSDA="), a.a("OT0lSFYmMRlZQSUx"));
                    if (safeString8 != null) {
                        editorEdit.putString(a.a("OT0lSFYmMRJUSDA="), safeString8);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseTypeAr, safeString8);
                        String safeString9 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("OT0lSFYmMRJUSDARKA=="), a.a("GT0lSFYmMRJUSDARKA=="), a.a("OT0lSFYmMRlZQSUxGUhW"));
                        if (safeString9 == null || safeString9.trim().isEmpty()) {
                            safeString9 = ActivityHomeActivity.getEnglishLicenseType(safeString8);
                        }
                        editorEdit.putString(a.a("OT0lSFYmMRJUSDARKA=="), safeString9);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseTypeEn, safeString9);
                    }
                    String safeString10 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("NzgpQlwBLTZI"), a.a("FzgpQlwBLTZI"), a.a("NzgpQlwKID9dXQ=="));
                    if (safeString10 != null) {
                        editorEdit.putString(a.a("NzgpQlwBLTZI"), safeString10);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseBloodTypeAr, safeString10);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseBloodTypeEn, safeString10);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_blood_type, safeString10);
                    }
                    String safeString11 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("PCc1WF0RNTJI"), a.a("HCc1WF0RNTJI"), a.a("PCc1WF0KMCdZXQ=="));
                    if (safeString11 != null) {
                        editorEdit.putString(a.a("PCc1WF0RNTJI"), safeString11);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseIssueDateAr, ActivityHomeActivity.this.toArabicNumbers(safeString11));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseIssueDateEn, ActivityHomeActivity.this.toEnglishNumbers(safeString11));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_issue_date, ActivityHomeActivity.this.toArabicNumbers(safeString11));
                    }
                    String safeString12 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("JSYpS10mJy9CVg=="), a.a("BSYpS10mJy9CVg=="));
                    if (safeString12 != null) {
                        editorEdit.putString(a.a("JSYpS10mJy9CVg=="), safeString12);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardProfession, safeString12);
                    }
                    String safeString13 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("MCw2REosECdZXQ=="), a.a("ECw2REosECdZXQ=="), a.a("MCw2REosCyJMTDA="));
                    if (safeString13 != null) {
                        editorEdit.putString(a.a("MCw2REosECdZXQ=="), safeString13);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardExpiryDate, ActivityHomeActivity.this.toArabicNumbers(safeString13));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_citizen_expiry_date, ActivityHomeActivity.this.toArabicNumbers(safeString13));
                        ActivityHomeActivity.this.setTextByName(a.a("ISIZTlEhPTxIVgoxPl1RJy0ZSVkhMRlIVg=="), ActivityHomeActivity.this.toEnglishNumbers(safeString13));
                        ActivityHomeActivity.this.setTextByName(a.a("ISIFREw8LiNDfS0kL19BETUySH07"), ActivityHomeActivity.this.toEnglishNumbers(safeString13));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseExpiryDateAr, ActivityHomeActivity.this.toArabicNumbers(safeString13));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvLicenseExpiryDateEn, ActivityHomeActivity.this.toEnglishNumbers(safeString13));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_expiry_date, ActivityHomeActivity.this.toArabicNumbers(safeString13));
                    }
                    String safeString14 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("Njs2VHYgOSRISg=="), a.a("Fjs2VHYgOSRISg=="), a.a("IzE0XlE6Og=="), a.a("Njs2VGc7IStPXSc="));
                    if (safeString14 != null) {
                        editorEdit.putString(a.a("Njs2VHYgOSRISg=="), safeString14);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardCopyNumber, ActivityHomeActivity.this.toArabicNumbers(safeString14));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_citizen_copy_number, ActivityHomeActivity.this.toArabicNumbers(safeString14));
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_version_number, ActivityHomeActivity.this.toArabicNumbers(safeString14));
                    }
                    String safeString15 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("JzEqRF88Oyg="), a.a("BzEqRF88Oyg="));
                    if (safeString15 != null) {
                        editorEdit.putString(a.a("JzEqRF88Oyg="), safeString15);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardReligion, safeString15);
                    }
                    String safeString16 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("MDk2QVcsMTRkXA=="), a.a("EDk2QVcsMTRkXA=="), a.a("MDk2QVcsMTRyUTE="));
                    if (safeString16 != null) {
                        editorEdit.putString(a.a("MDk2QVcsMTRkXA=="), safeString16);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardEmployerId, ActivityHomeActivity.this.toArabicNumbers(safeString16));
                    }
                    String safeString17 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("PCc1WF0FOCdOXQ=="), a.a("HCc1WF0FOCdOXQ=="), a.a("PCc1WF0KJCpMWzA="));
                    if (safeString17 != null) {
                        editorEdit.putString(a.a("PCc1WF0FOCdOXQ=="), safeString17);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardIssuePlace, safeString17);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_issue_place, safeString17);
                    }
                    String safeString18 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("Iz01REwFITRdVyYx"), a.a("Az01REwFITRdVyYx"), a.a("Iz01REwKJDNfSDonIw=="));
                    if (safeString18 == null) {
                        safeString18 = a.a("jeafp+DyjPf1kXWM//WfjfKfqeHfjO8=");
                    }
                    editorEdit.putString(a.a("Iz01REwFITRdVyYx"), safeString18);
                    editorEdit.apply();
                    ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_visit_purpose, safeString18);
                    String safeString19 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("MDk2QVcsMTRjWTgx"), a.a("EDk2QVcsMTRjWTgx"), a.a("MDk2QVcsMTRyVjQ5Iw=="));
                    if (safeString19 != null) {
                        editorEdit.putString(a.a("MDk2QVcsMTRjWTgx"), safeString19);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardEmployerName, safeString19);
                    }
                    String safeString20 = ActivityHomeActivity.this.getSafeString(dataSnapshot, a.a("Nz00WVAFOCdOXQ=="), a.a("Fz00WVAFOCdOXQ=="), a.a("Nz00WVAKJCpMWzA="));
                    if (safeString20 != null) {
                        editorEdit.putString(a.a("Nz00WVAFOCdOXQ=="), safeString20);
                        editorEdit.apply();
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tvCardBirthPlace, safeString20);
                        ActivityHomeActivity.this.setTextIfNotNull(R.id.tv_citizen_birth_place, safeString20);
                    }
                    editorEdit.apply();
                    ActivityHomeActivity.this.setupSharedPreferencesAndUI();
                }
            };
            this.dbRef.addValueEventListener(this.userDataListener);
        } catch (Exception e) {
            Toast.makeText((Context) this, (CharSequence) a.a("jfqemuD2dJ+s4d90norh0Yzh9ZKN4Z6K4dF0noXh14zh9YGN+56EGI3zn6ng/Y3M9Z+M0p6K4P8="), 0).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private TextView createSectionTitle(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextSize(2, 20.0f);
        textView.setTypeface(null, 1);
        textView.setTextColor(Color.parseColor(a.a("dmUHHHlkFQ==")));
        textView.setGravity(5);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(8));
        textView.setLayoutParams(layoutParams);
        return textView;
    }

    private int dpToPx(int i) {
        return (int) TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    private void generateDenseQRCodeToImageView(String str, ImageView imageView) {
        Bitmap bitmapDecodeResource;
        if (str == null || str.trim().isEmpty() || imageView == null) {
            return;
        }
        try {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 150; i++) {
                sb.append(" ");
            }
            String str2 = String.valueOf(str.trim()) + sb.toString();
            Hashtable hashtable = new Hashtable();
            hashtable.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hashtable.put(EncodeHintType.CHARACTER_SET, a.a("AAAAAAA="));
            hashtable.put(EncodeHintType.MARGIN, 1);
            BitMatrix bitMatrixEncode = new QRCodeWriter().encode(str2, BarcodeFormat.QR_CODE, 200, 200, hashtable);
            int width = bitMatrixEncode.getWidth();
            int height = bitMatrixEncode.getHeight();
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            for (int i2 = 0; i2 < width; i2++) {
                for (int i3 = 0; i3 < height; i3++) {
                    bitmapCreateBitmap.setPixel(i2, i3, bitMatrixEncode.get(i2, i3) ? -16777216 : -1);
                }
            }
            try {
                int identifier = getResources().getIdentifier(a.a("PTwocgo="), a.a("MSYnWlk3OCM="), getPackageName());
                if (identifier != 0 && (bitmapDecodeResource = BitmapFactory.decodeResource(getResources(), identifier)) != null) {
                    Canvas canvas = new Canvas(bitmapCreateBitmap);
                    int i4 = width / 4;
                    int i5 = height / 4;
                    int i6 = (width - i4) / 2;
                    int i7 = (height - i5) / 2;
                    Paint paint = new Paint();
                    paint.setColor(-1);
                    canvas.drawRect(i6 - 2, i7 - 2, i6 + i4 + 2, i7 + i5 + 2, paint);
                    canvas.drawBitmap(Bitmap.createScaledBitmap(bitmapDecodeResource, i4, i5, false), i6, i7, (Paint) null);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            imageView.setImageBitmap(bitmapCreateBitmap);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public static String getEnglishLicenseType(String str) {
        if (str == null || str.trim().isEmpty()) {
            return a.a("BSYvW1khMQ==");
        }
        String strTrim = str.trim();
        if (strTrim.contains(a.a("jfqemOHdjPP0sg=="))) {
            return a.a("BSYvW1khMQ==");
        }
        if (strTrim.contains(a.a("jNKfr+HRdJ6D4PKM8w=="))) {
            return a.a("BSYvW1khMWZ5SjQ6NV1XJyA=");
        }
        if (strTrim.contains(a.a("je2fqOHdjcP0sg==")) || strTrim.contains(a.a("jNKfr+HRdJ6U4PKNww=="))) {
            return a.a("BSEkQVE2dBJfWTsnNkJKIQ==");
        }
        if (strTrim.contains(a.a("jfuenODyjOr1kQ=="))) {
            return a.a("GDsyQko2LSVBXQ==");
        }
        return (strTrim.contains(a.a("jfeemeDvjOH0vA==")) || strTrim.contains(a.a("jfOemeDvjOH0vA=="))) ? a.a("HTEnW0F1GSdOUDw6I19B") : strTrim;
    }

    public static String getEnglishNationality(String str) {
        if (str == null || str.trim().isEmpty()) {
            return a.a("BhUTaXE=");
        }
        String lowerCase = str.trim().toLowerCase();
        if (lowerCase.contains(a.a("jeeelOHdjOk=")) || lowerCase.contains(a.a("JjUzSVE="))) {
            return a.a("BhUTaXE=");
        }
        if (lowerCase.contains(a.a("jN6fqOHT")) || lowerCase.contains(a.a("LDErSFY="))) {
            return a.a("DBELaHY=");
        }
        if (lowerCase.contains(a.a("jNGemODk")) || lowerCase.contains(a.a("MDM/XUw="))) {
            return a.a("EBMffWw=");
        }
        if (lowerCase.contains(a.a("jeefpeD6jOH0vg==")) || lowerCase.contains(a.a("JiEiTFY="))) {
            return a.a("BgECbHY=");
        }
        if (lowerCase.contains(a.a("jeefpeDkjcz1nw==")) || lowerCase.contains(a.a("jeefpeDkjcw=")) || lowerCase.contains(a.a("Ji00RFk="))) {
            return a.a("Bg0UZHk=");
        }
        if (lowerCase.contains(a.a("jfeenOD6jcA=")) || lowerCase.contains(a.a("jfOenOD6jcA=")) || lowerCase.contains(a.a("Pzs0SVk7"))) {
            return a.a("HxsUaXkb");
        }
        if (lowerCase.contains(a.a("jfyeiuHWjPX1ko3zn6s=")) || lowerCase.contains(a.a("JTUtREshNSg="))) {
            return a.a("BRUNZGsBFQg=");
        }
        if (lowerCase.contains(a.a("jNOfq+D6")) || lowerCase.contains(a.a("PDoiRFk="))) {
            return a.a("HBoCZHk=");
        }
        if (lowerCase.contains(a.a("jfyfq+D5jcL1n437n6fg4Q==")) || lowerCase.contains(a.a("jfyfq+DvjcL1n437n6fg4Q==")) || lowerCase.contains(a.a("jfyfq+HXjcL1n437n6fg4Q==")) || lowerCase.contains(a.a("NzUoSlQ0MCNeUA=="))) {
            return a.a("FxUIanQUEAN+cA==");
        }
        if (lowerCase.contains(a.a("jNWfqeD9jcz0vg==")) || lowerCase.contains(a.a("JTwvQVElJC9DXSY="))) {
            return a.a("BRwPYXEFBA9jfQY=");
        }
        if (lowerCase.contains(a.a("jfOehuHfjc71kIzenoo=")) || lowerCase.contains(a.a("jfeehuHfjc71kIzenoo=")) || lowerCase.contains(a.a("jfGehuHfjc71kIzenoo=")) || lowerCase.contains(a.a("jfmeheDh")) || lowerCase.contains(a.a("MCAuRFclPSc="))) {
            return a.a("EAAOZHcFHQc=");
        }
        if (lowerCase.contains(a.a("jNGeiuHRjcw=")) || lowerCase.contains(a.a("ODUqRA=="))) {
            return a.a("GBUKZA==");
        }
        if (lowerCase.contains(a.a("jfOfq+D6jc70vozenp7h34zh")) || lowerCase.contains(a.a("jfGfq+D6jc70vozenp7h34zh")) || lowerCase.contains(a.a("jfOfq+D6jc70vo3nn6fg8g==")) || lowerCase.contains(a.a("jfGfq+D6jc70vo3nn6fg8g==")) || lowerCase.contains(a.a("PDoiQlYwJy9M"))) {
            return a.a("HBoCYnYQBw9s");
        }
        if (lowerCase.contains(a.a("jNGel+DkjO4=")) || lowerCase.contains(a.a("ODs0Qls2Ow=="))) {
            return a.a("GBsUYnsWGw==");
        }
        if (lowerCase.contains(a.a("jf6fpeHTjPU=")) || lowerCase.contains(a.a("ISEoREs8NQ=="))) {
            return a.a("AQEIZGscFQ==");
        }
        if (lowerCase.contains(a.a("jfien+DyjOD1iQ==")) || lowerCase.contains(a.a("NDghSEo8NQ=="))) {
            return a.a("FBgBaGocFQ==");
        }
        if (lowerCase.contains(a.a("jNCeheHTjOH0vg==")) || lowerCase.contains(a.a("OTEkTFY6Og=="))) {
            return a.a("GREEbHYaGg==");
        }
        if (lowerCase.contains(a.a("jNWfqeDmjPH0sozS")) || lowerCase.contains(a.a("JTUqSEshPShI"))) {
            return a.a("BRUKaGsBHQho");
        }
        if (lowerCase.contains(a.a("je2enODyjcQ=")) || lowerCase.contains(a.a("PCYnXA=="))) {
            return a.a("HAYHfA==");
        }
        if (lowerCase.contains(a.a("jNefpeHfjOw=")) || lowerCase.contains(a.a("PiExTFEh"))) {
            return a.a("HgERbHEB");
        }
        if (lowerCase.contains(a.a("jfOfqODyjPf1n43+")) || lowerCase.contains(a.a("jfGfqODyjPf1n43+")) || lowerCase.contains(a.a("IDUj"))) {
            return a.a("ABUD");
        }
        if (lowerCase.contains(a.a("jNaemuDk")) || lowerCase.contains(a.a("JDUyTEo="))) {
            return a.a("BBUSbGo=");
        }
        if (lowerCase.contains(a.a("jfyegODkjcz0vg==")) || lowerCase.contains(a.a("NzUuX1k8Og=="))) {
            return a.a("FxUOf3kcGg==");
        }
        if (lowerCase.contains(a.a("je2fqODyjcA=")) || lowerCase.contains(a.a("OjknQw=="))) {
            return a.a("GhkHYw==");
        }
        if (lowerCase.contains(a.a("jNKfp+D9jOH0vA==")) || lowerCase.contains(a.a("OzE2TFQ="))) {
            return a.a("GxEWbHQ=");
        }
        if (lowerCase.contains(a.a("jeeenOHfjcL1n4zSn67g8g==")) || lowerCase.contains(a.a("JiYvQVk7Pyc="))) {
            return a.a("BgYPDXQUGg1s");
        }
        if (lowerCase.contains(a.a("jfOfrODvjOH0vo3nnofg8o3A")) || lowerCase.contains(a.a("jfefrODvjOH0vo3nnofg8o3A")) || lowerCase.contains(a.a("NDIhRVk7PTVZWTs="))) {
            return a.a("FBIBZXkbHRV5eRs=");
        }
        if (lowerCase.contains(a.a("jf6enOHWjcz1nw==")) || lowerCase.contains(a.a("ISE0Rl0s"))) {
            return a.a("AQEUZn0M");
        }
        if (lowerCase.contains(a.a("jeGfpeHQjOH0vA==")) || lowerCase.contains(a.a("JjsrTFQ8NQ=="))) {
            return a.a("BhsLbHQcFQ==");
        }
        return (lowerCase.contains(a.a("jf6emeDyjOk=")) || lowerCase.contains(a.a("NjwnSQ=="))) ? a.a("FhwHaQ==") : str.trim().toUpperCase();
    }

    public String getSafeString(DataSnapshot dataSnapshot, String... strArr) {
        for (String str : strArr) {
            if (dataSnapshot.hasChild(str) && dataSnapshot.child(str).getValue() != null) {
                return String.valueOf(dataSnapshot.child(str).getValue());
            }
        }
        return null;
    }

    private boolean hideAllExceptDocsContainer(ViewGroup viewGroup) {
        boolean z = false;
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View childAt = viewGroup.getChildAt(i);
            if (isDocsViewOrContainsDocs(childAt)) {
                childAt.setVisibility(0);
                z = true;
                if ((childAt instanceof ViewGroup) && childAt.getId() != com.mhd.absher.R.id.documentCardCitizen && childAt.getId() != com.mhd.absher.R.id.documentCard1 && childAt.getId() != com.mhd.absher.R.id.documentCardVisitor && childAt.getId() != com.mhd.absher.R.id.documentCard2) {
                    hideAllExceptDocsContainer((ViewGroup) childAt);
                }
            } else {
                childAt.setVisibility(8);
            }
        }
        return z;
    }

    private void hideOldTitleViews(View view) {
        CharSequence text;
        if (view == null) {
            return;
        }
        if (view.getId() == com.mhd.absher.R.id.tvShowAllDocs) {
            view.setVisibility(8);
        }
        if ((view instanceof TextView) && (text = ((TextView) view).getText()) != null && text.toString().contains(a.a("jNyehuDyjOD0uozeZvWfjNCenOHXjcP0so39"))) {
            view.setVisibility(8);
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                hideOldTitleViews(viewGroup.getChildAt(i));
            }
        }
    }

    private boolean isDocsViewOrContainsDocs(View view) {
        if (view == null) {
            return false;
        }
        int id = view.getId();
        if (id == com.mhd.absher.R.id.documentCardCitizen || id == com.mhd.absher.R.id.documentCard1 || id == com.mhd.absher.R.id.documentCardVisitor || id == com.mhd.absher.R.id.documentCard2) {
            return true;
        }
        Object tag = view.getTag();
        if (tag != null) {
            String strValueOf = String.valueOf(tag);
            if (strValueOf.contains(a.a("ERsFfmcdEQdpfQc=")) || strValueOf.contains(a.a("ERsFfmcBHRJhfQ=="))) {
                return true;
            }
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            if (isDocsViewOrContainsDocs(viewGroup.getChildAt(i))) {
                return true;
            }
        }
        return false;
    }

    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(a.a("NjsoQ102IC9bUSEt"));
        if (connectivityManager == null) {
            return false;
        }
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void openBlockedScreen() {
        if (openScreen(a.a("FzgpTlMwMAdOTDwiL1lB"), a.a("NzgpTlMwMAdOTDwiL1lB"), a.a("FzgpTlMwMA=="), a.a("NzgpTlMwMA=="))) {
            finish();
        } else {
            Toast.makeText((Context) this, (CharSequence) a.a("jf6elODljPcN4dSM7PWVdYzy9Z+N4J6EGI3zn6ng+Iz+9Yl0"), 1).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean openScreen(String... strArr) {
        for (String str : strArr) {
            try {
                if (!str.contains(a.a("ew=="))) {
                    str = a.a("NjsrA1U9MGhMWiY8I18W") + str;
                }
                Class<?> cls = Class.forName(str);
                if (cls.equals(getClass())) {
                    return true;
                }
                startActivity(new Intent((Context) this, cls));
                return true;
            } catch (ClassNotFoundException e) {
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean openScreenWithCardType(String str, String... strArr) {
        boolean z = false;
        for (String str2 : strArr) {
            try {
                if (!str2.contains(a.a("ew=="))) {
                    str2 = a.a("NjsrA1U9MGhMWiY8I18W") + str2;
                }
                Intent intent = new Intent((Context) this, Class.forName(str2));
                intent.putExtra(a.a("NjU0SWchLTZI"), str);
                startActivity(intent);
                z = true;
                break;
            } catch (ClassNotFoundException e) {
            }
        }
        return z;
    }

    public void setTextByName(String str, String str2) {
        int identifier;
        TextView textView;
        if (str2 == null || str2.trim().isEmpty() || (identifier = getResources().getIdentifier(str, a.a("PDA="), getPackageName())) == 0 || (textView = (TextView) findViewById(identifier)) == null) {
            return;
        }
        textView.setText(str2);
    }

    public void setTextIfNotNull(int i, String str) {
        TextView textView;
        if (str == null || str.trim().isEmpty() || (textView = (TextView) findViewById(i)) == null) {
            return;
        }
        textView.setText(str);
    }

    private void setupBottomNavView(int i, final String... strArr) {
        View viewFindViewById = findViewById(i);
        if (viewFindViewById != null) {
            viewFindViewById.setClickable(true);
            viewFindViewById.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreen(strArr);
                }
            });
        }
    }

    private void setupClickListeners() {
        View viewFindViewById = findViewById(R.id.profileCard);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreen(a.a("BSYpS1E5MQdOTDwiL1lB"), a.a("JSYpS1E5MQdOTDwiL1lB"));
                }
            });
        }
        ImageView imageView = (ImageView) findViewById(R.id.ivSettings);
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreen(a.a("BjEyWVE7MzVsWyE9MERMLA=="), a.a("JjEyWVE7MzVsWyE9MERMLA=="));
                }
            });
        }
        TextView textView = (TextView) findViewById(R.id.tvShowAllDocs);
        if (textView != null) {
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View view) {
                    final RelativeLayout relativeLayout;
                    view.setEnabled(false);
                    RelativeLayout relativeLayout2 = (RelativeLayout) ActivityHomeActivity.this.findViewById(R.id.layoutLoadingOverlay);
                    final WebView webView = (WebView) ActivityHomeActivity.this.findViewById(R.id.webviewLoadingGif);
                    if (relativeLayout2 == null) {
                        ViewGroup viewGroup = (ViewGroup) ActivityHomeActivity.this.getWindow().getDecorView();
                        RelativeLayout relativeLayout3 = new RelativeLayout(ActivityHomeActivity.this);
                        relativeLayout3.setBackgroundColor(-1);
                        relativeLayout3.setClickable(true);
                        relativeLayout3.setFocusable(true);
                        WebView webView2 = new WebView(ActivityHomeActivity.this);
                        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
                        layoutParams.addRule(13);
                        relativeLayout3.addView(webView2, layoutParams);
                        viewGroup.addView(relativeLayout3, new ViewGroup.LayoutParams(-1, -1));
                        webView = webView2;
                        relativeLayout = relativeLayout3;
                    } else {
                        relativeLayout2.setVisibility(0);
                        relativeLayout2.setClickable(true);
                        relativeLayout2.setFocusable(true);
                        relativeLayout = relativeLayout2;
                    }
                    if (webView != null) {
                        webView.setBackgroundColor(-1);
                        webView.getSettings().setLoadWithOverviewMode(true);
                        webView.getSettings().setUseWideViewPort(true);
                        webView.getSettings().setJavaScriptEnabled(true);
                        webView.setVerticalScrollBarEnabled(false);
                        webView.setHorizontalScrollBarEnabled(false);
                        webView.loadDataWithBaseURL(a.a("Mz0qSAJ6e2lMVjEmKURcCjU1Xl0hew=="), a.a("aTwyQFRraC5IWTFqel5MLDgjE1AhOSoBGDc7IlQYLnQrTEoyPSgXCG50NkxcMT0oSgJlb2ZaUTEgLhcJZWRjFhg9MS9KUCFudx0IcG9mT1k2PyFfVyA6IgBbOjgpXwJ2EgBrfhMSfQ1XIzE0S1Q6I3xFUTEwI0MDdTAvXkg5NT8XXjkxPhYYPyE1WVEzLWtOVzsgI0NMbzcjQ0wwJn0NWTk9IUMVPCAjQEtvNyNDTDAmfQ1FPDkhDUN1OSdVFSI9IllQb2V2HR1udCtMQHg8I0RfPSB8HAhlcX0NVzc+I05MeDIvWQI2OyhZWTw6fQ1MJzUoXl46JisXSzY1KkgQZ3pyBAN1IDRMViYyKV9VeDs0RF88OnxOXTsgI18YNjEoWV0nb2ZQBHonMlRUMGp6AlAwNSITBDc7IlQGaT0rShgmJiUQHzIyLwNfPDJhAgZpeyRCXCxqegJQITkqEw=="), a.a("ITE+WRc9ICtB"), a.a("AAAAAAA="), null);
                    }
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (relativeLayout != null) {
                                relativeLayout.setVisibility(8);
                            }
                            if (webView != null) {
                                webView.loadUrl(a.a("NDYpWExvNipMVj4="));
                            }
                            if (view != null) {
                                view.setEnabled(true);
                            }
                            ActivityHomeActivity.this.openScreen(a.a("ET0hREw0OAJCWyA5I0NMJhUlWVEjPTJU"), a.a("MT0hREw0OBlJVzYhK0hWIScHTkw8Ii9ZQQ=="));
                        }
                    }, 3000L);
                }
            });
        }
        View viewFindViewById2 = findViewById(R.id.documentCardCitizen);
        if (viewFindViewById2 != null) {
            viewFindViewById2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreenWithCardType(a.a("Nj0yREIwOg=="), a.a("GzUyRFc7NSpkXBQ3MkROPCA/"), a.a("OzUyRFc7NSpyUTEVJVlRIz0yVA=="));
                }
            });
        }
        View viewFindViewById3 = findViewById(R.id.documentCard1);
        if (viewFindViewById3 != null) {
            viewFindViewById3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreenWithCardType(a.a("PDA="), a.a("GzUyRFc7NSpkXBQ3MkROPCA/"), a.a("OzUyRFc7NSpyUTEVJVlRIz0yVA=="));
                }
            });
        }
        View viewFindViewById4 = findViewById(R.id.documentCardVisitor);
        if (viewFindViewById4 != null) {
            viewFindViewById4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreenWithCardType(a.a("Iz01REw6Jg=="), a.a("GzUyRFc7NSpkXBQ3MkROPCA/"), a.a("OzUyRFc7NSpyUTEVJVlRIz0yVA=="));
                }
            });
        }
        View viewFindViewById5 = findViewById(R.id.documentCard2);
        if (viewFindViewById5 != null) {
            viewFindViewById5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreenWithCardType(a.a("OT0lSFYmMQ=="), a.a("GzUyRFc7NSpkXBQ3MkROPCA/"), a.a("OzUyRFc7NSpyUTEVJVlRIz0yVA=="));
                }
            });
        }
        View viewFindViewById6 = findViewById(R.id.cardVehicles);
        if (viewFindViewById6 != null) {
            viewFindViewById6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreen(a.a("AzEuRFs5MTVsWyE9MERMLA=="), a.a("IzEuRFs5MTVsWyE9MERMLA=="));
                }
            });
        }
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.cardVerification);
        if (linearLayout != null) {
            linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreen(a.a("AzE0RF48NydZUTo6FEhJIDE1WUsUNzJETjwgPw=="), a.a("IzE0RF48NydZUTo6GV9dJCEjXkwmFSVZUSM9MlQ="));
                }
            });
        }
        LinearLayout linearLayout2 = (LinearLayout) findViewById(R.id.cardDocumentsDelivery);
        if (linearLayout2 != null) {
            linearLayout2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreen(a.a("FDclRFwwOjJ/XTI9NVlKNCAvQlYUNzJETjwgPw=="), a.a("NDclRFwwOjJySjAzL15MJzUyRFc7FSVZUSM9MlQ="));
                }
            });
        }
        setupBottomNavView(R.id.navHome, a.a("FDcyRE48ID9lVzgxB05MPCIvWUE="), a.a("HTsrSHk2IC9bUSEt"), a.a("PTsrSHk2IC9bUSEt"), a.a("GDUvQ3k2IC9bUSEt"));
        setupBottomNavView(R.id.navServices, a.a("BjE0W1E2MTVsWyE9MERMLA=="), a.a("JjE0W1E2MTVsWyE9MERMLA=="), a.a("GC0VSEojPSVISxQ3MkROPCA/"), a.a("BjE0W1E2MTU="));
        setupBottomNavView(R.id.navFamily, a.a("EzUrRFQsFSVZUSM9MlQ="), a.a("MzUrRFQsFSVZUSM9MlQ="), a.a("EzUrRFQsGSNAWjAmNWxbIT0wREws"), a.a("EzUrRFQs"));
        setupBottomNavView(R.id.navWorkers, a.a("Ajs0Rl0nJwdOTDwiL1lB"), a.a("Ijs0Rl0nJwdOTDwiL1lB"), a.a("GTUkQk0nFSVZUSM9MlQ="), a.a("Ajs0Rl0nJw=="));
        setupBottomNavView(R.id.navOther, a.a("GiAuSEoUNzJETjwgPw=="), a.a("OiAuSEoUNzJETjwgPw=="), a.a("GiAuSEomFSVZUSM9MlQ="), a.a("ODs0SHk2IC9bUSEt"), a.a("GDs0SHk2IC9bUSEt"), a.a("GiAuSEoGMTRbUTYxNWxbIT0wREws"), a.a("GDEoWHk2IC9bUSEt"), a.a("BjEyWVE7MzVsWyE9MERMLA=="));
        LinearLayout linearLayout3 = (LinearLayout) findViewById(R.id.cardAbsherTravel);
        if (linearLayout3 != null) {
            linearLayout3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreen(a.a("FDY1RV0nADRMTjA4B05MPCIvWUE="), a.a("NDY1RV0nCzJfWSMxKmxbIT0wREws"));
                }
            });
        }
        LinearLayout linearLayout4 = (LinearLayout) findViewById(R.id.cardTrafficFines);
        if (linearLayout4 != null) {
            linearLayout4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityHomeActivity.this.openScreen(a.a("ASYnS148NwBEVjAnB05MPCIvWUE="), a.a("ISYnS148NxlLUTsxNWxbIT0wREws"));
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void setupDigitalDocumentsHeaderAndSectionTitles() {
        ViewGroup viewGroup;
        int iIndexOfChild;
        int iIndexOfChild2;
        int iIndexOfChild3;
        int iIndexOfChild4;
        View viewFindViewById = findViewById(R.id.documentCardCitizen);
        View viewFindViewById2 = findViewById(R.id.documentCard1);
        View viewFindViewById3 = findViewById(R.id.documentCardVisitor);
        View viewFindViewById4 = findViewById(R.id.documentCard2);
        if (viewFindViewById == null && viewFindViewById2 == null && viewFindViewById3 == null && viewFindViewById4 == null) {
            return;
        }
        if (viewFindViewById != null && (viewFindViewById.getParent() instanceof ViewGroup)) {
            viewGroup = (ViewGroup) viewFindViewById.getParent();
        } else if (viewFindViewById2 != null && (viewFindViewById2.getParent() instanceof ViewGroup)) {
            viewGroup = (ViewGroup) viewFindViewById2.getParent();
        } else if (viewFindViewById3 == null || !(viewFindViewById3.getParent() instanceof ViewGroup)) {
            viewGroup = (viewFindViewById4 == null || !(viewFindViewById4.getParent() instanceof ViewGroup)) ? null : (ViewGroup) viewFindViewById4.getParent();
        } else {
            viewGroup = (ViewGroup) viewFindViewById3.getParent();
        }
        if (viewGroup == null || viewGroup.findViewWithTag(a.a("ERsFfmcdEQdpfQcLB2l8EBA=")) != null) {
            return;
        }
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setTag(a.a("ERsFfmcdEQdpfQcLB2l8EBA="));
        linearLayout.setOrientation(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(dpToPx(16), dpToPx(20), dpToPx(16), dpToPx(12));
        linearLayout.setLayoutParams(layoutParams);
        TextView textView = new TextView(this);
        textView.setText(a.a("jfOfqeHdjO31n43yn68YjfOfqeDkjcT0vYzenoQ="));
        textView.setTextSize(2, 26.0f);
        textView.setTypeface(null, 1);
        textView.setTextColor(Color.parseColor(a.a("dmV3HAlkZQ==")));
        textView.setGravity(5);
        String arabicNumbers = toArabicNumbers(new SimpleDateFormat(a.a("EBEDaBgxdAtgdRh0P1RBLHQuF1U4dCc="), new Locale(a.a("NCY="))).format(new Date()));
        TextView textView2 = new TextView(this);
        textView2.setText(a.a("jfaeg+DkdJ6H4PiM6fSyjf9m9ZKM0Wb0uYzeZg==") + arabicNumbers);
        textView2.setTextSize(2, 14.0f);
        textView2.setTextColor(Color.parseColor(a.a("dmNxGg9iYw==")));
        textView2.setGravity(5);
        textView2.setPadding(0, dpToPx(6), 0, dpToPx(2));
        TextView textView3 = new TextView(this);
        textView3.setText(a.a("jfOenuD4jO4N4dGNwvWSjfmeguHfjO0="));
        textView3.setTextSize(2, 13.0f);
        textView3.setTextColor(Color.parseColor(a.a("dm1/FAFsbQ==")));
        textView3.setGravity(5);
        linearLayout.addView(textView);
        linearLayout.addView(textView2);
        linearLayout.addView(textView3);
        viewGroup.addView(linearLayout, 0);
        SharedPreferences sharedPreferences = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        boolean z = sharedPreferences.getBoolean(a.a("JjwpWns8IC9XXTsdIg=="), false);
        boolean z2 = sharedPreferences.getBoolean(a.a("JjwpWmowJy9JXTsgD0k="), true);
        boolean z3 = sharedPreferences.getBoolean(a.a("JjwpWm48Jy9ZVycdIg=="), false);
        boolean z4 = sharedPreferences.getBoolean(a.a("JjwpWnQ8NyNDSzA="), true);
        if (viewFindViewById != null && (iIndexOfChild4 = viewGroup.indexOfChild(viewFindViewById)) >= 0) {
            TextView textViewCreateSectionTitle = createSectionTitle(a.a("jNOfpeHfjO8N4dCNzvWfjeOfqw=="));
            textViewCreateSectionTitle.setTag(a.a("ERsFfmcBHRJhfQoXB398ChcPeXEPEQg="));
            textViewCreateSectionTitle.setVisibility(z ? 0 : 8);
            viewGroup.addView(textViewCreateSectionTitle, iIndexOfChild4);
        }
        if (viewFindViewById2 != null && (iIndexOfChild3 = viewGroup.indexOfChild(viewFindViewById2)) >= 0) {
            TextView textViewCreateSectionTitle2 = createSectionTitle(a.a("jNOfpeHfjO8N4dCNxPSyjNE="));
            textViewCreateSectionTitle2.setTag(a.a("ERsFfmcBHRJhfQoXB398ZA=="));
            textViewCreateSectionTitle2.setVisibility(z2 ? 0 : 8);
            viewGroup.addView(textViewCreateSectionTitle2, iIndexOfChild3);
        }
        if (viewFindViewById3 != null && (iIndexOfChild2 = viewGroup.indexOfChild(viewFindViewById3)) >= 0) {
            TextView textViewCreateSectionTitle3 = createSectionTitle(a.a("jNOfpeHfjO8N4OeM4fWejeU="));
            textViewCreateSectionTitle3.setTag(a.a("ERsFfmcBHRJhfQoXB398CgIPfnEBGxQ="));
            textViewCreateSectionTitle3.setVisibility(z3 ? 0 : 8);
            viewGroup.addView(textViewCreateSectionTitle3, iIndexOfChild2);
        }
        if (viewFindViewById4 == null || (iIndexOfChild = viewGroup.indexOfChild(viewFindViewById4)) < 0) {
            return;
        }
        TextView textViewCreateSectionTitle4 = createSectionTitle(a.a("jeWeg+DgjO8N4OaNzPWfjNaehA=="));
        textViewCreateSectionTitle4.setTag(a.a("ERsFfmcBHRJhfQoXB398Zw=="));
        textViewCreateSectionTitle4.setVisibility(z4 ? 0 : 8);
        viewGroup.addView(textViewCreateSectionTitle4, iIndexOfChild);
    }

    public void setupSharedPreferencesAndUI() {
        SharedPreferences sharedPreferences = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        String string = sharedPreferences.getString(a.a("OzUrSHkn"), "");
        String string2 = sharedPreferences.getString(a.a("OzUrSH07"), "");
        String string3 = sharedPreferences.getString(a.a("PDAIWFU3MTQ="), "");
        if (string3 == null || string3.trim().isEmpty()) {
            string3 = a.a("Z2BxHgtnY3QcAA==");
        }
        String string4 = sharedPreferences.getString(a.a("Nz00WVARNTJI"), "");
        String string5 = sharedPreferences.getString(a.a("OzUyRFc7NSpETCw="), "");
        String englishNationality = getEnglishNationality(string5);
        String string6 = sharedPreferences.getString(a.a("JSYpS10mJy9CVg=="), "");
        String string7 = sharedPreferences.getString(a.a("MCw2REosECdZXQ=="), "");
        String string8 = sharedPreferences.getString(a.a("Njs2VHYgOSRISg=="), "");
        String string9 = sharedPreferences.getString(a.a("JzEqRF88Oyg="), "");
        String string10 = sharedPreferences.getString(a.a("MDk2QVcsMTRkXA=="), "");
        String string11 = sharedPreferences.getString(a.a("PCc1WF0FOCdOXQ=="), "");
        String string12 = sharedPreferences.getString(a.a("MDk2QVcsMTRjWTgx"), "");
        String string13 = sharedPreferences.getString(a.a("Nz00WVAFOCdOXQ=="), "");
        String string14 = sharedPreferences.getString(a.a("OT0lSFYmMRJUSDA="), "");
        String englishLicenseType = getEnglishLicenseType(string14);
        String string15 = sharedPreferences.getString(a.a("NzgpQlwBLTZI"), "");
        String string16 = sharedPreferences.getString(a.a("PCc1WF0RNTJI"), "");
        String string17 = sharedPreferences.getString(a.a("ICcjX3E4NSFI"), "");
        String string18 = sharedPreferences.getString(a.a("Iz01REwFITRdVyYx"), a.a("jeafp+DyjPf1kXWM//WfjfKfqeHfjO8="));
        updateCardsVisibility(sharedPreferences.getBoolean(a.a("JjwpWns8IC9XXTsdIg=="), false), sharedPreferences.getBoolean(a.a("JjwpWmowJy9JXTsgD0k="), true), sharedPreferences.getBoolean(a.a("JjwpWm48Jy9ZVycdIg=="), false), sharedPreferences.getBoolean(a.a("JjwpWnQ8NyNDSzA="), true));
        if (!string17.isEmpty()) {
            updateUserImageUI(string17);
        }
        setTextIfNotNull(R.id.tvUserName, string);
        setTextIfNotNull(R.id.tvUserId, string3);
        setTextIfNotNull(R.id.tvCardNameHome, string);
        setTextIfNotNull(R.id.tvCardNameEn, string2);
        setTextIfNotNull(R.id.tvCardIdHome, toArabicNumbers(string3));
        setTextIfNotNull(R.id.tvCardBirthDate, toArabicNumbers(string4));
        setTextIfNotNull(R.id.tvCardNationality, string5);
        setTextIfNotNull(R.id.tvCardProfession, string6);
        setTextIfNotNull(R.id.tvCardExpiryDate, toArabicNumbers(string7));
        setTextIfNotNull(R.id.tvCardCopyNumber, toArabicNumbers(string8));
        setTextIfNotNull(R.id.tvCardReligion, string9);
        setTextIfNotNull(R.id.tvCardEmployerId, toArabicNumbers(string10));
        setTextIfNotNull(R.id.tvCardIssuePlace, string11);
        setTextIfNotNull(R.id.tvCardEmployerName, string12);
        setTextIfNotNull(R.id.tvCardBirthPlace, string13);
        setTextIfNotNull(R.id.tv_citizen_name_ar, string);
        setTextByName(a.a("ISIZTlEhPTxIVgo6J0BdCjEo"), string2);
        setTextByName(a.a("ISIFREw8LiNDdjQ5I2hW"), string2);
        setTextByName(a.a("ISIZTlEhPTxIVgo6J0BdCjEoSlQ8Jy4="), string2);
        setTextIfNotNull(R.id.tv_citizen_id_number, toArabicNumbers(string3));
        setTextByName(a.a("ISIZTlEhPTxIVgo9InJWIDkkSEoKMSg="), string3);
        setTextIfNotNull(R.id.tv_citizen_birth_date, toArabicNumbers(string4));
        setTextByName(a.a("ISIZTlEhPTxIVgo2L19MPQsiTEwwCyND"), toEnglishNumbers(string4));
        setTextByName(a.a("ISIFREw8LiNDejwmMkV8NCAjaFY="), toEnglishNumbers(string4));
        setTextIfNotNull(R.id.tv_citizen_expiry_date, toArabicNumbers(string7));
        setTextByName(a.a("ISIZTlEhPTxIVgoxPl1RJy0ZSVkhMRlIVg=="), toEnglishNumbers(string7));
        setTextByName(a.a("ISIFREw8LiNDfS0kL19BETUySH07"), toEnglishNumbers(string7));
        if (string13.isEmpty()) {
            string13 = string11;
        }
        setTextIfNotNull(R.id.tv_citizen_birth_place, string13);
        setTextIfNotNull(R.id.tv_citizen_copy_number, toArabicNumbers(string8.isEmpty() ? a.a("ZA==") : string8));
        setTextIfNotNull(R.id.tv_name_ar, string);
        setTextIfNotNull(R.id.tv_name_en, string2);
        setTextIfNotNull(R.id.tv_id_number, toArabicNumbers(string3));
        setTextIfNotNull(R.id.tv_issue_place, string11);
        setTextIfNotNull(R.id.tv_issue_date, toArabicNumbers(string16));
        setTextIfNotNull(R.id.tv_expiry_date, toArabicNumbers(string7));
        setTextIfNotNull(R.id.tv_birth_date, toArabicNumbers(string4));
        setTextIfNotNull(R.id.tv_nationality, string5);
        setTextIfNotNull(R.id.tv_visit_purpose, string18);
        setTextIfNotNull(R.id.tv_blood_type, string15.isEmpty() ? a.a("fhs=") : string15);
        if (string8.isEmpty()) {
            string8 = a.a("ZA==");
        }
        setTextIfNotNull(R.id.tv_version_number, toArabicNumbers(string8));
        setTextIfNotNull(R.id.tvLicenseNameAr, string);
        setTextIfNotNull(R.id.tvLicenseNameEn, string2);
        setTextIfNotNull(R.id.tvLicenseIdNumberAr, toArabicNumbers(string3));
        setTextIfNotNull(R.id.tvLicenseIdNumberEn, string3);
        setTextIfNotNull(R.id.tvLicenseBirthDateAr, toArabicNumbers(string4));
        setTextIfNotNull(R.id.tvLicenseBirthDateEn, toEnglishNumbers(string4));
        setTextIfNotNull(R.id.tvLicenseNationalityAr, string5);
        setTextIfNotNull(R.id.tvLicenseNationalityEn, englishNationality);
        setTextIfNotNull(R.id.tvLicenseTypeAr, string14);
        setTextIfNotNull(R.id.tvLicenseTypeEn, englishLicenseType);
        setTextIfNotNull(R.id.tvLicenseBloodTypeAr, string15);
        setTextIfNotNull(R.id.tvLicenseBloodTypeEn, string15);
        setTextIfNotNull(R.id.tvLicenseIssueDateAr, toArabicNumbers(string16));
        setTextIfNotNull(R.id.tvLicenseIssueDateEn, toEnglishNumbers(string16));
        setTextIfNotNull(R.id.tvLicenseExpiryDateAr, toArabicNumbers(string7));
        setTextIfNotNull(R.id.tvLicenseExpiryDateEn, toEnglishNumbers(string7));
        updateQRCodes(string3);
    }

    public String toArabicNumbers(String str) {
        return str == null ? "" : str.replace(a.a("ZQ=="), a.a("jPQ=")).replace(a.a("ZA=="), a.a("jPU=")).replace(a.a("Zw=="), a.a("jPY=")).replace(a.a("Zg=="), a.a("jPc=")).replace(a.a("YQ=="), a.a("jPA=")).replace(a.a("YA=="), a.a("jPE=")).replace(a.a("Yw=="), a.a("jPI=")).replace(a.a("Yg=="), a.a("jPM=")).replace(a.a("bQ=="), a.a("jPw=")).replace(a.a("bA=="), a.a("jP0="));
    }

    public String toEnglishNumbers(String str) {
        return str == null ? "" : str.replace(a.a("jPQ="), a.a("ZQ==")).replace(a.a("jPU="), a.a("ZA==")).replace(a.a("jPY="), a.a("Zw==")).replace(a.a("jPc="), a.a("Zg==")).replace(a.a("jPA="), a.a("YQ==")).replace(a.a("jPE="), a.a("YA==")).replace(a.a("jPI="), a.a("Yw==")).replace(a.a("jPM="), a.a("Yg==")).replace(a.a("jPw="), a.a("bQ==")).replace(a.a("jP0="), a.a("bA=="));
    }

    public void updateCardsVisibility(final boolean z, final boolean z2, final boolean z3, final boolean z4) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                View viewFindViewById = ActivityHomeActivity.this.findViewById(R.id.documentCardCitizen);
                View viewFindViewById2 = ActivityHomeActivity.this.findViewById(R.id.documentCard1);
                View viewFindViewById3 = ActivityHomeActivity.this.findViewById(R.id.documentCardVisitor);
                View viewFindViewById4 = ActivityHomeActivity.this.findViewById(R.id.documentCard2);
                if (viewFindViewById != null) {
                    viewFindViewById.setVisibility(z ? 0 : 8);
                }
                if (viewFindViewById2 != null) {
                    viewFindViewById2.setVisibility(z2 ? 0 : 8);
                }
                if (viewFindViewById3 != null) {
                    viewFindViewById3.setVisibility(z3 ? 0 : 8);
                }
                if (viewFindViewById4 != null) {
                    viewFindViewById4.setVisibility(z4 ? 0 : 8);
                }
                View viewFindViewWithTag = ActivityHomeActivity.this.getWindow().getDecorView().findViewWithTag(a.a("ERsFfmcBHRJhfQoXB398ChcPeXEPEQg="));
                if (viewFindViewWithTag instanceof TextView) {
                    viewFindViewWithTag.setVisibility(z ? 0 : 8);
                }
                View viewFindViewWithTag2 = ActivityHomeActivity.this.getWindow().getDecorView().findViewWithTag(a.a("ERsFfmcBHRJhfQoXB398ZA=="));
                if (viewFindViewWithTag2 instanceof TextView) {
                    viewFindViewWithTag2.setVisibility(z2 ? 0 : 8);
                }
                View viewFindViewWithTag3 = ActivityHomeActivity.this.getWindow().getDecorView().findViewWithTag(a.a("ERsFfmcBHRJhfQoXB398CgIPfnEBGxQ="));
                if (viewFindViewWithTag3 instanceof TextView) {
                    viewFindViewWithTag3.setVisibility(z3 ? 0 : 8);
                }
                View viewFindViewWithTag4 = ActivityHomeActivity.this.getWindow().getDecorView().findViewWithTag(a.a("ERsFfmcBHRJhfQoXB398Zw=="));
                if (viewFindViewWithTag4 instanceof TextView) {
                    viewFindViewWithTag4.setVisibility(z4 ? 0 : 8);
                }
            }
        });
    }

    public void updateQRCodes(String str) {
        if (str == null || str.trim().isEmpty()) {
            str = a.a("Z2BxHgtnY3QcAA==");
        }
        ImageView imageView = (ImageView) findViewById(R.id.imageview_qrcode);
        if (imageView != null) {
            generateDenseQRCodeToImageView(str, imageView);
        }
        ImageView imageView2 = (ImageView) findViewById(R.id.img_citizen_qrcode);
        if (imageView2 != null) {
            generateDenseQRCodeToImageView(str, imageView2);
        }
        ImageView imageView3 = (ImageView) findViewById(R.id.img_visitor_qrcode);
        if (imageView3 != null) {
            generateDenseQRCodeToImageView(str, imageView3);
        }
        ImageView imageView4 = (ImageView) findViewById(R.id.imageview_license_barcode);
        if (imageView4 != null) {
            generateDenseQRCodeToImageView(str, imageView4);
        }
    }

    public void updateUserImageUI(final String str) {
        if (str == null || str.trim().isEmpty()) {
            return;
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    byte[] bArrDecode = Base64.decode(str, 0);
                    Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArrDecode, 0, bArrDecode.length);
                    if (bitmapDecodeByteArray == null) {
                        return;
                    }
                    ImageView imageView = (ImageView) ActivityHomeActivity.this.findViewById(R.id.ivUserPhoto);
                    if (imageView != null) {
                        imageView.setImageBitmap(bitmapDecodeByteArray);
                    }
                    ImageView imageView2 = (ImageView) ActivityHomeActivity.this.findViewById(R.id.imageview_id_photo);
                    if (imageView2 != null) {
                        imageView2.setImageBitmap(bitmapDecodeByteArray);
                    }
                    ImageView imageView3 = (ImageView) ActivityHomeActivity.this.findViewById(R.id.img_citizen_user_photo);
                    if (imageView3 != null) {
                        imageView3.setImageBitmap(bitmapDecodeByteArray);
                    }
                    ImageView imageView4 = (ImageView) ActivityHomeActivity.this.findViewById(R.id.imageview_license_photo);
                    if (imageView4 != null) {
                        imageView4.setImageBitmap(bitmapDecodeByteArray);
                    }
                    ImageView imageView5 = (ImageView) ActivityHomeActivity.this.findViewById(R.id.img_user_photo);
                    if (imageView5 != null) {
                        imageView5.setImageBitmap(bitmapDecodeByteArray);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onBackPressed() {
        if (getIntent() != null && getIntent().getBooleanExtra(a.a("BhwJemcRGwV+ZxoaCnQ="), false)) {
            finish();
            return;
        }
        Intent intent = new Intent((Context) this, (Class<?>) OtpActivity.class);
        intent.addFlags(603979776);
        startActivity(intent);
        finish();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_home);
        getWindow().getDecorView().setLayoutDirection(1);
        setupSharedPreferencesAndUI();
        checkNetworkAndSyncData();
        setupClickListeners();
        checkAndApplyDocsOnlyMode();
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.dbRef == null || this.userDataListener == null) {
            return;
        }
        this.dbRef.removeEventListener(this.userDataListener);
    }

    protected void onResume() {
        super.onResume();
        setupSharedPreferencesAndUI();
    }
}
