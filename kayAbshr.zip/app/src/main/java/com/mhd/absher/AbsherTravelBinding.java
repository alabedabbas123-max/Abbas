package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class AbsherTravelBinding {
    public final LinearLayout bottomNav;
    public final ImageView btnBack;
    public final TextView btnCreateTrip;
    public final LinearLayout cardNotifications;
    public final ImageView imageview10;
    public final ImageView imageview6;
    public final ImageView imageview7;
    public final ImageView imageview8;
    public final ImageView imageview9;
    public final ImageView ivEmptyIcon;
    public final ImageView ivInfo;
    public final LinearLayout linear10;
    public final LinearLayout linear11;
    public final LinearLayout linear12;
    public final LinearLayout linear13;
    public final LinearLayout linear14;
    public final LinearLayout linear16;
    public final LinearLayout linear9;
    public final LinearLayout navHome;
    public final RelativeLayout relativelayout2;
    public final RelativeLayout rootAbsherTravel;
    public final RelativeLayout rowEnableNotif;
    public final ScrollView scrollContent;
    public final Space space15;
    public final TextView textview10;
    public final TextView textview6;
    public final TextView textview7;
    public final TextView textview8;
    public final TextView textview9;
    public final RelativeLayout topBar;
    public final TextView tvClose;
    public final TextView tvEmptySub;
    public final TextView tvEmptyTitle;
    public final TextView tvEnableNotif;
    public final TextView tvNotifSub;
    public final TextView tvNotifTitle;
    public final TextView tvTitle;

    private AbsherTravelBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, LinearLayout linearLayout, LinearLayout linearLayout2, ImageView imageView2, TextView textView2, LinearLayout linearLayout3, ImageView imageView3, TextView textView3, LinearLayout linearLayout4, ImageView imageView4, TextView textView4, LinearLayout linearLayout5, ImageView imageView5, TextView textView5, LinearLayout linearLayout6, ImageView imageView6, TextView textView6, ScrollView scrollView, LinearLayout linearLayout7, LinearLayout linearLayout8, RelativeLayout relativeLayout3, ImageView imageView7, LinearLayout linearLayout9, TextView textView7, TextView textView8, RelativeLayout relativeLayout4, TextView textView9, TextView textView10, Space space, LinearLayout linearLayout10, ImageView imageView8, TextView textView11, TextView textView12, TextView textView13) {
        this.rootAbsherTravel = relativeLayout;
        this.topBar = relativeLayout2;
        this.btnBack = imageView;
        this.tvTitle = textView;
        this.bottomNav = linearLayout;
        this.navHome = linearLayout2;
        this.imageview10 = imageView2;
        this.textview10 = textView2;
        this.linear12 = linearLayout3;
        this.imageview9 = imageView3;
        this.textview9 = textView3;
        this.linear11 = linearLayout4;
        this.imageview8 = imageView4;
        this.textview8 = textView4;
        this.linear10 = linearLayout5;
        this.imageview7 = imageView5;
        this.textview7 = textView5;
        this.linear9 = linearLayout6;
        this.imageview6 = imageView6;
        this.textview6 = textView6;
        this.scrollContent = scrollView;
        this.linear13 = linearLayout7;
        this.cardNotifications = linearLayout8;
        this.relativelayout2 = relativeLayout3;
        this.ivInfo = imageView7;
        this.linear14 = linearLayout9;
        this.tvNotifTitle = textView7;
        this.tvNotifSub = textView8;
        this.rowEnableNotif = relativeLayout4;
        this.tvEnableNotif = textView9;
        this.tvClose = textView10;
        this.space15 = space;
        this.linear16 = linearLayout10;
        this.ivEmptyIcon = imageView8;
        this.tvEmptyTitle = textView11;
        this.tvEmptySub = textView12;
        this.btnCreateTrip = textView13;
    }

    public static AbsherTravelBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBar);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBack);
        TextView textView = (TextView) findChildViewById(view, R.id.tvTitle);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.bottomNav);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.navHome);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview10);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview10);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear12);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.imageview9);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview9);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.linear11);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.imageview8);
        TextView textView4 = (TextView) findChildViewById(view, R.id.textview8);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.linear10);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.imageview7);
        TextView textView5 = (TextView) findChildViewById(view, R.id.textview7);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.linear9);
        ImageView imageView6 = (ImageView) findChildViewById(view, R.id.imageview6);
        TextView textView6 = (TextView) findChildViewById(view, R.id.textview6);
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.scrollContent);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.linear13);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.cardNotifications);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.relativelayout2);
        ImageView imageView7 = (ImageView) findChildViewById(view, R.id.ivInfo);
        LinearLayout linearLayout9 = (LinearLayout) findChildViewById(view, R.id.linear14);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tvNotifTitle);
        TextView textView8 = (TextView) findChildViewById(view, R.id.tvNotifSub);
        RelativeLayout relativeLayout4 = (RelativeLayout) findChildViewById(view, R.id.rowEnableNotif);
        TextView textView9 = (TextView) findChildViewById(view, R.id.tvEnableNotif);
        TextView textView10 = (TextView) findChildViewById(view, R.id.tvClose);
        Space space = (Space) findChildViewById(view, R.id.space15);
        LinearLayout linearLayout10 = (LinearLayout) findChildViewById(view, R.id.linear16);
        ImageView imageView8 = (ImageView) findChildViewById(view, R.id.ivEmptyIcon);
        TextView textView11 = (TextView) findChildViewById(view, R.id.tvEmptyTitle);
        TextView textView12 = (TextView) findChildViewById(view, R.id.tvEmptySub);
        TextView textView13 = (TextView) findChildViewById(view, R.id.btnCreateTrip);
        if (relativeLayout2 == null || imageView == null || textView == null || linearLayout == null || linearLayout2 == null || imageView2 == null || textView2 == null || linearLayout3 == null || imageView3 == null || textView3 == null || linearLayout4 == null || imageView4 == null || textView4 == null || linearLayout5 == null || imageView5 == null || textView5 == null || linearLayout6 == null || imageView6 == null || textView6 == null || scrollView == null || linearLayout7 == null || linearLayout8 == null || relativeLayout3 == null || imageView7 == null || linearLayout9 == null || textView7 == null || textView8 == null || relativeLayout4 == null || textView9 == null || textView10 == null || space == null || linearLayout10 == null || imageView8 == null || textView11 == null || textView12 == null || textView13 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new AbsherTravelBinding(relativeLayout, relativeLayout2, imageView, textView, linearLayout, linearLayout2, imageView2, textView2, linearLayout3, imageView3, textView3, linearLayout4, imageView4, textView4, linearLayout5, imageView5, textView5, linearLayout6, imageView6, textView6, scrollView, linearLayout7, linearLayout8, relativeLayout3, imageView7, linearLayout9, textView7, textView8, relativeLayout4, textView9, textView10, space, linearLayout10, imageView8, textView11, textView12, textView13);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static AbsherTravelBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static AbsherTravelBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.absher_travel, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootAbsherTravel;
    }
}
