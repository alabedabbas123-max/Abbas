# قواعد مستخرجة من التطبيق الأصلي
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-dontwarn **
