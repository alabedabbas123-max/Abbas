package com.shima.performance;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;
import java.util.Locale;

/**
 * Lightweight editor foundation that paints the viewport only.
 *
 * <p>Unlike EditText, it does not create an Android Layout/Span object for every character in the
 * document. The model retains lines; onDraw touches only the visible range.
 */
public class ViewportCodeEditorView extends View {
  private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
  private final Paint selectionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final Paint cursorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final LineArrayModel model = new LineArrayModel();
  private final ScaleGestureDetector scaleDetector;
  private final Runnable longPress = this::beginSelection;
  private float textSizePx;
  private float lineHeight;
  private float ascent;
  private float maxLineWidth;
  private float downX, downY, lastX, lastY;
  private long downTime;
  private boolean dragging;
  private boolean selecting;
  private int selectionAnchor;
  private int selectionStart;
  private int selectionEnd;
  private int cursor;
  private float scaleBase;
  private boolean scaling;

  public ViewportCodeEditorView(Context context) {
    super(context);
    scaleDetector = createScaleDetector(context);
    init();
  }

  public ViewportCodeEditorView(Context context, AttributeSet attrs) {
    super(context, attrs);
    scaleDetector = createScaleDetector(context);
    init();
  }

  public ViewportCodeEditorView(Context context, AttributeSet attrs, int style) {
    super(context, attrs, style);
    scaleDetector = createScaleDetector(context);
    init();
  }

  private void init() {
    setWillNotDraw(false);
    setFocusable(true);
    setFocusableInTouchMode(true);
    textPaint.setTypeface(Typeface.MONOSPACE);
    textPaint.setColor(Color.rgb(232, 232, 232));
    selectionPaint.setColor(0x663F8CFF);
    cursorPaint.setColor(0xFF55B7FF);
    setTextSizeSp(10);
    setBackgroundColor(Color.rgb(25, 25, 25));
    setHorizontalScrollBarEnabled(true);
    setVerticalScrollBarEnabled(true);
    setScrollBarStyle(SCROLLBARS_INSIDE_OVERLAY);
  }

  private ScaleGestureDetector createScaleDetector(Context context) {
    return new ScaleGestureDetector(
        context,
        new ScaleGestureDetector.SimpleOnScaleGestureListener() {
          @Override
          public boolean onScaleBegin(ScaleGestureDetector detector) {
            scaling = true;
            scaleBase = textSizePx;
            return true;
          }

          @Override
          public boolean onScale(ScaleGestureDetector detector) {
            float target = Math.max(dp(9), Math.min(dp(32), scaleBase * detector.getScaleFactor()));
            setTextSizePixels(target);
            return true;
          }

          @Override
          public void onScaleEnd(ScaleGestureDetector detector) {
            scaling = false;
            requestLayout();
            invalidate();
          }
        });
  }

  public LineArrayModel model() {
    return model;
  }

  public void setText(String text) {
    model.setText(text);
    cursor = Math.min(cursor, model.length());
    selectionStart = selectionEnd = cursor;
    maxLineWidth = 0;
    requestLayout();
    invalidate();
  }

  public String getText() {
    return model.substring(0, model.length());
  }

  public void setTextSizeSp(float size) {
    setTextSizePixels(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, size, getResources().getDisplayMetrics()));
  }

  public void setTextSizePixels(float pixels) {
    textSizePx = Math.max(dp(9), Math.min(dp(32), pixels));
    textPaint.setTextSize(textSizePx);
    Paint.FontMetrics metrics = textPaint.getFontMetrics();
    ascent = metrics.ascent;
    lineHeight = Math.max(1, metrics.descent - metrics.ascent + dp(4));
    maxLineWidth = 0;
    requestLayout();
    invalidate();
  }

  public int getCursorOffset() {
    return cursor;
  }

  public void setCursorOffset(int offset) {
    cursor = Math.max(0, Math.min(offset, model.length()));
    selectionStart = selectionEnd = cursor;
    invalidate();
  }

  public int getSelectionStartOffset() {
    return Math.min(selectionStart, selectionEnd);
  }

  public int getSelectionEndOffset() {
    return Math.max(selectionStart, selectionEnd);
  }

  public String getSelectedText() {
    return model.substring(getSelectionStartOffset(), getSelectionEndOffset());
  }

  @Override
  protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    int width = MeasureSpec.getSize(widthMeasureSpec);
    int height = MeasureSpec.getSize(heightMeasureSpec);
    if (MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.UNSPECIFIED)
      width = (int) (maxLineWidth + getPaddingLeft() + getPaddingRight());
    if (MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.UNSPECIFIED)
      height = (int) (model.lineCount() * lineHeight + getPaddingTop() + getPaddingBottom());
    setMeasuredDimension(Math.max(1, width), Math.max(1, height));
  }

  @Override
  protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    int first = Math.max(0, (int) ((getScrollY() - getPaddingTop()) / lineHeight) - 1);
    int last = Math.min(model.lineCount() - 1, (int) ((getScrollY() + getHeight()) / lineHeight) + 1);
    canvas.save();
    canvas.clipRect(0, 0, getWidth(), getHeight());
    for (int line = first; line <= last; line++) {
      String value = model.lineAt(line);
      float baseline = getPaddingTop() + line * lineHeight - getScrollY() - ascent;
      float x = getPaddingLeft() - getScrollX();
      drawLine(canvas, value, line, x, baseline);
      maxLineWidth = Math.max(maxLineWidth, textPaint.measureText(value));
    }
    drawCursor(canvas);
    canvas.restore();
  }

  private void drawLine(Canvas canvas, String value, int line, float x, float baseline) {
    int lineStart = model.lineStart(line);
    int lineEnd = model.lineEnd(line);
    int from = getSelectionStartOffset();
    int to = getSelectionEndOffset();
    if (to <= lineStart || from >= lineEnd) {
      canvas.drawText(value, x, baseline, textPaint);
      return;
    }
    int selectedFrom = Math.max(0, from - lineStart);
    int selectedTo = Math.min(value.length(), to - lineStart);
    float beforeWidth = textPaint.measureText(value, 0, selectedFrom);
    float selectedWidth = textPaint.measureText(value, selectedFrom, selectedTo);
    selectionPaint.setColor(0x66458BFF);
    canvas.drawRect(x + beforeWidth, baseline + ascent, x + beforeWidth + selectedWidth, baseline + ascent + lineHeight, selectionPaint);
    canvas.drawText(value, 0, selectedFrom, x, baseline, textPaint);
    canvas.drawText(value, selectedFrom, selectedTo, x + beforeWidth, baseline, textPaint);
    canvas.drawText(value, selectedTo, value.length(), x + beforeWidth + selectedWidth, baseline, textPaint);
  }

  private void drawCursor(Canvas canvas) {
    LineArrayModel.Position position = model.positionFor(cursor);
    String line = model.lineAt(position.line);
    float x = getPaddingLeft() + textPaint.measureText(line, 0, Math.min(position.column, line.length())) - getScrollX();
    float top = getPaddingTop() + position.line * lineHeight - getScrollY();
    canvas.drawRect(x, top, x + dp(1), top + lineHeight, cursorPaint);
  }

  @Override
  public boolean onTouchEvent(MotionEvent event) {
    scaleDetector.onTouchEvent(event);
    if (scaling || event.getPointerCount() > 1) return true;
    switch (event.getActionMasked()) {
      case MotionEvent.ACTION_DOWN:
        requestFocus();
        downX = lastX = event.getX();
        downY = lastY = event.getY();
        downTime = System.currentTimeMillis();
        dragging = false;
        selecting = false;
        removeCallbacks(longPress);
        postDelayed(longPress, ViewConfiguration.getLongPressTimeout());
        return true;
      case MotionEvent.ACTION_MOVE:
        float dx = event.getX() - lastX;
        float dy = event.getY() - lastY;
        if (Math.abs(event.getX() - downX) + Math.abs(event.getY() - downY) > dp(8)) {
          dragging = true;
          removeCallbacks(longPress);
        }
        if (selecting) {
          int offset = offsetAt(event.getX(), event.getY());
          selectionStart = Math.min(selectionAnchor, offset);
          selectionEnd = Math.max(selectionAnchor, offset);
          cursor = offset;
          invalidate();
        } else if (dragging) {
          scrollByInternal(-dx, -dy);
        }
        lastX = event.getX();
        lastY = event.getY();
        return true;
      case MotionEvent.ACTION_UP:
        removeCallbacks(longPress);
        if (!dragging && !selecting && System.currentTimeMillis() - downTime < ViewConfiguration.getLongPressTimeout()) {
          cursor = offsetAt(event.getX(), event.getY());
          selectionStart = selectionEnd = cursor;
          invalidate();
        }
        return true;
      case MotionEvent.ACTION_CANCEL:
        removeCallbacks(longPress);
        return true;
      default:
        return true;
    }
  }

  private void beginSelection() {
    if (dragging || scaling) return;
    selecting = true;
    selectionAnchor = offsetAt(downX, downY);
    cursor = selectionAnchor;
    selectionStart = selectionEnd = selectionAnchor;
    invalidate();
  }

  private int offsetAt(float viewX, float viewY) {
    int line = Math.max(0, Math.min(model.lineCount() - 1, (int) ((viewY + getScrollY() - getPaddingTop()) / lineHeight)));
    String value = model.lineAt(line);
    float target = viewX + getScrollX() - getPaddingLeft();
    int best = 0;
    float nearest = Float.MAX_VALUE;
    for (int i = 0; i <= value.length(); i++) {
      float distance = Math.abs(textPaint.measureText(value, 0, i) - target);
      if (distance < nearest) {
        nearest = distance;
        best = i;
      }
    }
    return model.offsetFor(line, best);
  }

  private void scrollByInternal(float dx, float dy) {
    int maxX = Math.max(0, (int) Math.ceil(maxLineWidth + getPaddingLeft() + getPaddingRight() - getWidth()));
    int maxY = Math.max(0, (int) Math.ceil(model.lineCount() * lineHeight + getPaddingTop() + getPaddingBottom() - getHeight()));
    int nextX = Math.max(0, Math.min(maxX, (int) (getScrollX() + dx)));
    int nextY = Math.max(0, Math.min(maxY, (int) (getScrollY() + dy)));
    scrollTo(nextX, nextY);
    invalidate();
  }

  private int dp(int value) {
    return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
  }
}
