package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.Map;
import java.util.regex.Pattern;

public final class EmailAddressResultParser extends ResultParser {
    private static final Pattern COMMA = Pattern.compile(",");

    @Override
    public EmailAddressParsedResult parse(Result result) {
        String str;
        String str2;
        String[] strArr;
        String[] strArrSplit;
        String str3;
        String massagedText = getMassagedText(result);
        if (!massagedText.startsWith("mailto:") && !massagedText.startsWith("MAILTO:")) {
            if (EmailDoCoMoResultParser.isBasicallyValidEmailAddress(massagedText)) {
                return new EmailAddressParsedResult(massagedText);
            }
            return null;
        }
        String strSubstring = massagedText.substring(7);
        int iIndexOf = strSubstring.indexOf(63);
        if (iIndexOf >= 0) {
            strSubstring = strSubstring.substring(0, iIndexOf);
        }
        try {
            String strUrlDecode = urlDecode(strSubstring);
            String[] strArrSplit2 = !strUrlDecode.isEmpty() ? COMMA.split(strUrlDecode) : null;
            Map nameValuePairs = parseNameValuePairs(massagedText);
            if (nameValuePairs != null) {
                String[] strArrSplit3 = (strArrSplit2 != null || (str3 = (String) nameValuePairs.get("to")) == null) ? strArrSplit2 : COMMA.split(str3);
                String str4 = (String) nameValuePairs.get("cc");
                strArrSplit = str4 != null ? COMMA.split(str4) : null;
                String str5 = (String) nameValuePairs.get("bcc");
                String[] strArrSplit4 = str5 != null ? COMMA.split(str5) : null;
                String str6 = (String) nameValuePairs.get("subject");
                str = (String) nameValuePairs.get("body");
                str2 = str6;
                strArr = strArrSplit4;
                strArrSplit2 = strArrSplit3;
            } else {
                str = null;
                str2 = null;
                strArr = null;
                strArrSplit = null;
            }
            return new EmailAddressParsedResult(strArrSplit2, strArrSplit, strArr, str2, str);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
