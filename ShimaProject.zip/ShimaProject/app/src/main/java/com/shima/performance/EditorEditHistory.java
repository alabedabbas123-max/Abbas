package com.shima.performance;

import android.text.Editable;
import java.util.ArrayDeque;

/**
 * Bounded edit history that stores changed ranges instead of copying the whole document per key.
 * This keeps undo/redo useful without turning every keystroke into a full-string allocation.
 */
public final class EditorEditHistory {
  private static final int MAX_CHANGES = 30;
  private final ArrayDeque<Edit> undo = new ArrayDeque<>();
  private final ArrayDeque<Edit> redo = new ArrayDeque<>();
  private Pending pending;

  public synchronized void beforeChange(CharSequence text, int start, int count) {
    if (text == null || start < 0 || count < 0 || start + count > text.length()) {
      pending = null;
      return;
    }
    pending = new Pending(start, text.subSequence(start, start + count).toString());
  }

  public synchronized void afterChange(CharSequence text, int start, int count) {
    if (pending == null || text == null || start < 0 || count < 0 || start + count > text.length()) {
      pending = null;
      return;
    }
    String inserted = text.subSequence(start, start + count).toString();
    Edit edit = new Edit(pending.start, pending.removed, inserted);
    pending = null;
    if (edit.before.equals(edit.after)) return;
    undo.push(edit);
    while (undo.size() > MAX_CHANGES) undo.removeLast();
    redo.clear();
  }

  public synchronized void cancelPending() {
    pending = null;
  }

  public synchronized void clear() {
    pending = null;
    undo.clear();
    redo.clear();
  }

  /** Records a replacement already computed by a formatter or refactoring command. */
  public synchronized void recordReplacement(int start, String before, String after) {
    if (before == null || after == null || before.equals(after)) return;
    undo.push(new Edit(Math.max(0, start), before, after));
    while (undo.size() > MAX_CHANGES) undo.removeLast();
    redo.clear();
  }

  public synchronized Edit undo(Editable text) {
    if (text == null || undo.isEmpty()) return null;
    Edit edit = undo.pop();
    replace(text, edit.start, edit.after.length(), edit.before);
    redo.push(edit);
    return edit;
  }

  public synchronized Edit redo(Editable text) {
    if (text == null || redo.isEmpty()) return null;
    Edit edit = redo.pop();
    replace(text, edit.start, edit.before.length(), edit.after);
    undo.push(edit);
    return edit;
  }

  private void replace(Editable text, int start, int oldLength, String value) {
    int safeStart = Math.max(0, Math.min(start, text.length()));
    int safeEnd = Math.max(safeStart, Math.min(text.length(), safeStart + oldLength));
    text.replace(safeStart, safeEnd, value);
  }

  public static final class Edit {
    public final int start;
    public final String before;
    public final String after;

    private Edit(int start, String before, String after) {
      this.start = start;
      this.before = before;
      this.after = after;
    }
  }

  private static final class Pending {
    final int start;
    final String removed;

    Pending(int start, String removed) {
      this.start = start;
      this.removed = removed;
    }
  }
}
