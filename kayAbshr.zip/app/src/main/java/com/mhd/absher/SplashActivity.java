package com.mhd.absher;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import com.google.firebase.FirebaseApp;

public class SplashActivity extends AppCompatActivity {
    private SplashBinding binding;

    private void initialize(Bundle bundle) {
    }

    private void initializeLogic() {
        getWindow().setBackgroundDrawable(new ColorDrawable(-1));
        AppCompatDelegate.setDefaultNightMode(1);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                SplashActivity.this.startActivity(new Intent((Context) SplashActivity.this, (Class<?>) GuestServicesActivity.class));
                SplashActivity.this.finish();
            }
        }, 3000L);
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = SplashBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        FirebaseApp.initializeApp(this);
        initializeLogic();
    }
}
