package com.almlkid.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.UsageSearchEngine;
import com.almlkid.ui.browsers.BrowserPager;
import com.shima.demo.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;

/**
 * The single horizontal pager used by the left drawer. Its first page is the file browser and the
 * following pages are the persistent IDE panes, in the same order as the original drawer:
 * Files, Errors, Search Results, Debugger, and LogCat. Pages are created once, so list and editor
 * state is retained while the user swipes between them.
 */
public final class SequentialPanelHost extends LinearLayout {
  public enum Panel {
    ERRORS("No errors"),
    SEARCH("Search Results"),
    BUILD("Build / Run"),
    DEBUGGER("Not running"),
    LOGCAT("LogCat");

    final String title;

    Panel(String title) {
      this.title = title;
    }
  }

  public interface UsageClickListener {
    void clicked(UsageSearchEngine.Usage usage);
  }

  public interface ErrorClickListener {
    void clicked(CodeLanguageTools.Diagnostic diagnostic);
  }

  public interface CloseListener {
    void closed();
  }

  private final ArrayList<View> pages = new ArrayList<>();
  private final ArrayList<Panel> panelOrder = new ArrayList<>();
  private final EnumMap<Panel, Integer> panelIndexes = new EnumMap<>(Panel.class);
  private final ArrayList<UsageSearchEngine.Usage> usages = new ArrayList<>();
  // صفوف العرض بنمط المرجع: String = رأس ملف، Usage = سطر نتيجة تحته.
  private final ArrayList<Object> searchRows = new ArrayList<>();
  private String searchHighlight = "";
  private int[] syntaxPalette;
  private int syntaxPlain = Color.WHITE;
  private final ArrayList<CodeLanguageTools.Diagnostic> diagnostics = new ArrayList<>();
  private final ArrayList<PanelHeader> headers = new ArrayList<>();
  private BrowserPager browser;
  private ViewPager pager;
  private ListView errorList, usageList;
  private TextView buildOutput, debuggerOutput, logcatOutput;
  private ImageView errorHeaderIcon;
  private TextView errorHeaderTitle;
  private UsageClickListener usageClickListener;
  private CloseListener closeListener;
  private UsageAdapter usageAdapter;
  private ErrorAdapter errorAdapter;
  private ErrorClickListener errorClickListener;
  private String errorSource = "";
  private String searchStatus = "";

  public SequentialPanelHost(Context context) {
    super(context);
    init();
  }

  /** Required by LayoutInflater for the XML drawer declaration. */
  public SequentialPanelHost(Context context, AttributeSet attrs) {
    super(context, attrs);
    init();
  }

  /** Required when the view is inflated with a style/theme attribute. */
  public SequentialPanelHost(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    init();
  }

  private void init() {
    setOrientation(VERTICAL);
    setBackgroundColor(Color.rgb(28, 28, 28));
    setFocusable(true);
    setFocusableInTouchMode(true);

    // Page zero is the real file browser. Keeping it inside this same ViewPager makes the drawer
    // transition continuous instead of opening a second overlay on top of the file drawer.
    browser = new BrowserPager(getContext());
    browser.setId(R.id.mainBrowserPager);
    pages.add(browser);

    // Do not insert BUILD into the swipe sequence: the requested visual order is exactly the five
    // pages shown by the reference screenshots. Build output remains available from the commands
    // menu and is placed after LogCat so it cannot disturb that sequence.
    addPanelPage(Panel.ERRORS, createErrorsPage());
    addPanelPage(Panel.SEARCH, createSearchPage());
    addPanelPage(Panel.DEBUGGER, createDebuggerPage());
    addPanelPage(Panel.LOGCAT, createLogcatPage());
    addPanelPage(Panel.BUILD, createBuildPage());

    pager = new ViewPager(getContext());
    pager.setOffscreenPageLimit(pages.size());
    pager.setAdapter(new PanelAdapter());
    addView(pager, new LayoutParams(-1, 0, 1));
    // تثبيت الجلسة على القسم المفتوح: كل تبديل يُحفظ فورًا، والإقلاع يستعيد آخر قسم.
    pager.addOnPageChangeListener(
        new ViewPager.SimpleOnPageChangeListener() {
          @Override
          public void onPageSelected(int position) {
            getContext()
                .getSharedPreferences("main_drawer", Context.MODE_PRIVATE)
                .edit()
                .putInt("last_page", position)
                .apply();
          }
        });
    int savedPage =
        getContext()
            .getSharedPreferences("main_drawer", Context.MODE_PRIVATE)
            .getInt("last_page", 0);
    if (savedPage > 0 && savedPage < pages.size()) pager.setCurrentItem(savedPage, false);
  }

  private void addPanelPage(Panel panel, View page) {
    panelOrder.add(panel);
    panelIndexes.put(panel, pages.size());
    pages.add(page);
  }

  public BrowserPager browser() {
    return browser;
  }

  private View createErrorsPage() {
    errorList = new ListView(getContext());
    errorList.setBackgroundColor(Color.rgb(28, 28, 28));
    errorList.setDivider(null);
    errorList.setDividerHeight(0);
    errorAdapter = new ErrorAdapter();
    errorList.setAdapter(errorAdapter);
    errorList.setOnItemClickListener(
        (parent, view, position, id) -> {
          if (position < diagnostics.size() && errorClickListener != null)
            errorClickListener.clicked(diagnostics.get(position));
        });
    PanelHeader page = panelPage(R.drawable.project_no_errors, "No errors", errorList);
    errorHeaderIcon = page.icon;
    errorHeaderTitle = page.title;
    headers.add(page);
    return page.root;
  }

  private View createSearchPage() {
    usageList = new ListView(getContext());
    usageList.setBackgroundColor(Color.rgb(28, 28, 28));
    usageList.setDivider(null);
    usageList.setDividerHeight(0);
    usageAdapter = new UsageAdapter();
    usageList.setAdapter(usageAdapter);
    usageList.setOnItemClickListener(
        (parent, view, position, id) -> {
          if (usageClickListener == null || usages.isEmpty() || position >= searchRows.size())
            return;
          Object row = searchRows.get(position);
          if (row instanceof UsageSearchEngine.Usage) {
            usageClickListener.clicked((UsageSearchEngine.Usage) row);
            return;
          }
          // نقر رأس الملف يفتح أول نتيجة فيه — نفس سلوك المرجع.
          for (int i = position + 1; i < searchRows.size(); i++) {
            Object next = searchRows.get(i);
            if (next instanceof UsageSearchEngine.Usage) {
              usageClickListener.clicked((UsageSearchEngine.Usage) next);
              return;
            }
          }
        });
    PanelHeader page = panelPage(R.drawable.search, "Search Results", usageList);
    headers.add(page);
    return page.root;
  }

  private View createDebuggerPage() {
    debuggerOutput = infoBody(R.drawable.debugger_stopped, "Tap in the sidebar of your Java files to set breakpoints");
    PanelHeader page = panelPage(R.drawable.debugger_stopped, "Not running", debuggerOutput);
    headers.add(page);
    return page.root;
  }

  private View createLogcatPage() {
    logcatOutput = textPage("1  <run the app to see its log output>");
    PanelHeader page = panelPage(R.drawable.file_type_unknown, "LogCat", logcatOutput);
    headers.add(page);
    return page.root;
  }

  private View createBuildPage() {
    buildOutput = textPage("لم يبدأ البناء أو التشغيل بعد.");
    PanelHeader page = panelPage(R.drawable.file_type_unknown, "Build / Run", buildOutput);
    headers.add(page);
    return page.root;
  }

  private PanelHeader panelPage(int iconResource, String caption, View body) {
    LinearLayout root = new LinearLayout(getContext());
    root.setOrientation(VERTICAL);
    root.setBackgroundColor(Color.rgb(28, 28, 28));

    LinearLayout header = new LinearLayout(getContext());
    header.setGravity(Gravity.CENTER_VERTICAL);
    header.setPadding(dp(16), 0, dp(4), 0);
    header.setBackgroundResource(R.drawable.browser_header_material);
    ImageView icon = new ImageView(getContext());
    icon.setImageResource(iconResource);
    icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
    header.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(56)));
    TextView title = label(caption, 16, Color.WHITE);
    title.setGravity(Gravity.CENTER_VERTICAL);
    title.setSingleLine(true);
    title.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
    LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, dp(56), 1);
    titleParams.leftMargin = dp(5);
    header.addView(title, titleParams);
    root.addView(header, new LinearLayout.LayoutParams(-1, dp(56)));
    root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
    return new PanelHeader(root, icon, title);
  }

  private TextView infoBody(int iconResource, String value) {
    TextView view = label(value, 16, Color.LTGRAY);
    view.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
    view.setPadding(dp(14), dp(12), dp(10), dp(12));
    view.setCompoundDrawablesWithIntrinsicBounds(iconResource, 0, 0, 0);
    view.setCompoundDrawablePadding(dp(12));
    return view;
  }

  private TextView textPage(String value) {
    TextView view = label(value, 14, Color.LTGRAY);
    view.setGravity(Gravity.TOP | Gravity.LEFT);
    view.setPadding(dp(1), dp(2), dp(10), dp(16));
    view.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
    view.setTextIsSelectable(true);
    return view;
  }

  public void showPage(Panel panel) {
    if (panel == null || pager == null) return;
    Integer index = panelIndexes.get(panel);
    if (index != null) pager.setCurrentItem(index, true);
  }

  /** Shows the file page before opening the drawer again. */
  public void showFilesPage() {
    if (pager != null) pager.setCurrentItem(0, true);
  }

  public Panel currentPanel() {
    int page = pager == null ? 0 : pager.getCurrentItem();
    for (Panel panel : panelOrder) {
      Integer index = panelIndexes.get(panel);
      if (index != null && index == page) return panel;
    }
    return null;
  }

  public void nextPage() {
    if (pager == null) return;
    int next = pager.getCurrentItem() + 1;
    if (next < pages.size()) pager.setCurrentItem(next, true);
  }

  /** Moves right to the previous drawer page; false means the drawer may close normally. */
  public boolean previousPageIfPossible() {
    if (pager == null || pager.getCurrentItem() <= 0) return false;
    pager.setCurrentItem(pager.getCurrentItem() - 1, true);
    return true;
  }

  public void setErrors(List<CodeLanguageTools.Diagnostic> values) {
    setErrors(values, "");
  }

  public void setErrors(List<CodeLanguageTools.Diagnostic> values, String source) {
    diagnostics.clear();
    if (values != null) diagnostics.addAll(values);
    errorSource = source == null ? "" : source;
    if (errorHeaderIcon != null)
      errorHeaderIcon.setImageResource(
          diagnostics.isEmpty() ? R.drawable.project_no_errors : R.drawable.project_errors);
    if (errorHeaderTitle != null)
      errorHeaderTitle.setText(diagnostics.isEmpty() ? "No errors" : "Errors (" + diagnostics.size() + ")");
    if (errorAdapter != null) errorAdapter.notifyDataSetChanged();
  }

  public void setErrorClickListener(ErrorClickListener listener) {
    errorClickListener = listener;
  }

  public void setSearchResults(List<UsageSearchEngine.Usage> values) {
    setSearchResults(values, searchHighlight);
  }

  /** نتائج بنمط المرجع: تجميع حسب الملف وإبراز الرمز المبحوث بخط سفلي داخل سطر ملوّن. */
  public void setSearchResults(List<UsageSearchEngine.Usage> values, String highlightTerm) {
    usages.clear();
    if (values != null) usages.addAll(values);
    searchHighlight = highlightTerm == null ? "" : highlightTerm;
    searchRows.clear();
    String currentFile = null;
    for (UsageSearchEngine.Usage usage : usages) {
      if (!usage.fileName.equals(currentFile)) {
        currentFile = usage.fileName;
        searchRows.add(currentFile);
      }
      searchRows.add(usage);
    }
    if (usageAdapter != null) usageAdapter.notifyDataSetChanged();
  }

  public void setSearchStatus(String status) {
    searchStatus = status == null ? "" : status;
    if (usageAdapter != null) usageAdapter.notifyDataSetChanged();
  }

  public void setBuildOutput(String output) {
    if (buildOutput != null) buildOutput.setText(output == null ? "" : output);
  }

  public void appendBuildOutput(String line) {
    if (buildOutput != null) buildOutput.append((line == null ? "" : line) + "\n");
  }

  public void setDebuggerState(String output) {
    if (debuggerOutput != null) debuggerOutput.setText(output == null ? "" : output);
  }

  public void setLogcat(String output) {
    if (logcatOutput != null) logcatOutput.setText(output == null ? "" : output);
  }

  public void setUsageClickListener(UsageClickListener listener) {
    usageClickListener = listener;
  }

  public void setCloseListener(CloseListener listener) {
    closeListener = listener;
  }

  private TextView label(String value, int size, int color) {
    TextView result = new TextView(getContext());
    result.setText(value);
    result.setTextSize(size);
    result.setTextColor(color);
    return result;
  }

  private int dp(int value) {
    return (int) (value * getResources().getDisplayMetrics().density + .5f);
  }

  private final class PanelAdapter extends PagerAdapter {
    @Override
    public int getCount() {
      return pages.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
      return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
      View page = pages.get(position);
      if (page.getParent() != container) {
        if (page.getParent() instanceof ViewGroup) ((ViewGroup) page.getParent()).removeView(page);
        container.addView(page);
      }
      return page;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
      if (object instanceof View && ((View) object).getParent() == container)
        container.removeView((View) object);
    }
  }

  private String sourceLine(int lineNumber) {
    if (errorSource.isEmpty() || lineNumber < 1) return "";
    int current = 1;
    int start = 0;
    for (int i = 0; i < errorSource.length(); i++) {
      if (errorSource.charAt(i) == '\n') {
        if (current == lineNumber) return errorSource.substring(start, i).trim();
        current++;
        start = i + 1;
      }
    }
    return current == lineNumber ? errorSource.substring(start).trim() : "";
  }

  private int colorFor(CodeLanguageTools.Diagnostic.Severity severity) {
    if (severity == CodeLanguageTools.Diagnostic.Severity.INFO) return Color.rgb(120, 190, 255);
    if (severity == CodeLanguageTools.Diagnostic.Severity.WARNING) return Color.rgb(255, 205, 120);
    return Color.rgb(255, 112, 112);
  }

  private final class ErrorAdapter extends BaseAdapter {
    @Override
    public int getCount() {
      return diagnostics.size();
    }

    @Override
    public Object getItem(int position) {
      return diagnostics.get(position);
    }

    @Override
    public long getItemId(int position) {
      return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      TextView view =
          convertView instanceof TextView
              ? (TextView) convertView
              : label("", 14, Color.LTGRAY);
      view.setPadding(dp(14), dp(12), dp(10), dp(12));
      view.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
      CodeLanguageTools.Diagnostic item = diagnostics.get(position);
      String location = "السطر " + item.line + "، العمود " + item.column;
      SpannableStringBuilder text = new SpannableStringBuilder(location);
      text.setSpan(
          new ForegroundColorSpan(colorFor(item.severity)),
          0,
          location.length(),
          Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
      text.append("\n");
      int messageStart = text.length();
      text.append(item.message == null ? "خطأ" : item.message);
      text.setSpan(
          new ForegroundColorSpan(Color.rgb(255, 205, 120)),
          messageStart,
          text.length(),
          Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
      String preview = sourceLine(item.line);
      if (!preview.isEmpty()) {
        text.append("\n› ");
        int codeStart = text.length();
        text.append(preview);
        text.setSpan(
            new ForegroundColorSpan(Color.rgb(128, 203, 196)),
            codeStart,
            text.length(),
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
      }
      view.setText(text);
      view.setTextColor(Color.WHITE);
      view.setTextIsSelectable(true);
      return view;
    }
  }

  /** لوحة ألوان الرموز من إعدادات الثيم نفسها التي يرسم بها المحرر (تُبنى مرة واحدة). */
  private void ensureSyntaxPalette() {
    if (syntaxPalette != null) return;
    com.shima.demo.ThemeConfig theme = new com.shima.demo.ThemeConfig(getContext());
    syntaxPlain = theme.color(com.shima.demo.ThemeConfig.PLAIN);
    int[] palette = new int[13];
    palette[0] = syntaxPlain;
    palette[CodeLanguageTools.KEYWORD] = theme.color(com.shima.demo.ThemeConfig.KEYWORD);
    palette[CodeLanguageTools.STRING] = theme.color(com.shima.demo.ThemeConfig.LITERAL);
    palette[CodeLanguageTools.COMMENT] = theme.color(com.shima.demo.ThemeConfig.COMMENT);
    palette[CodeLanguageTools.NUMBER] = theme.color(com.shima.demo.ThemeConfig.LITERAL);
    palette[CodeLanguageTools.ANNOTATION] = theme.color(com.shima.demo.ThemeConfig.TYPE);
    palette[CodeLanguageTools.TAG] = theme.color(com.shima.demo.ThemeConfig.TYPE);
    palette[CodeLanguageTools.IDENTIFIER] = theme.color(com.shima.demo.ThemeConfig.IDENTIFIER);
    palette[CodeLanguageTools.OPERATOR] = theme.color(com.shima.demo.ThemeConfig.OPERATOR);
    palette[CodeLanguageTools.NAMESPACE] = theme.color(com.shima.demo.ThemeConfig.NAMESPACE);
    palette[CodeLanguageTools.SEPARATOR] = theme.color(com.shima.demo.ThemeConfig.SEPARATOR);
    palette[CodeLanguageTools.FUNCTION] = theme.color(com.shima.demo.ThemeConfig.FUNCTION);
    palette[CodeLanguageTools.VARIABLE] = theme.color(com.shima.demo.ThemeConfig.VARIABLE);
    syntaxPalette = palette;
  }

  private int colorForType(int type) {
    return syntaxPalette != null && type >= 0 && type < syntaxPalette.length
        ? syntaxPalette[type]
        : syntaxPlain;
  }

  /** سطر النتيجة كما في المرجع: تلوين نحوي كامل وخط سفلي تحت كل ظهور للرمز المبحوث. */
  private CharSequence styledPreview(UsageSearchEngine.Usage usage) {
    String text = usage.preview;
    SpannableString span = new SpannableString(text);
    ensureSyntaxPalette();
    List<CodeLanguageTools.Range> ranges;
    try {
      ranges = CodeLanguageTools.highlight(usage.fileName, text);
    } catch (Throwable error) {
      ranges = Collections.emptyList();
    }
    for (CodeLanguageTools.Range range : ranges) {
      int start = Math.max(0, range.start), end = Math.min(text.length(), range.end);
      if (start < end)
        span.setSpan(
            new ForegroundColorSpan(colorForType(range.type)),
            start,
            end,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }
    if (!searchHighlight.isEmpty()) {
      int at = text.indexOf(searchHighlight);
      while (at >= 0) {
        span.setSpan(
            new UnderlineSpan(),
            at,
            at + searchHighlight.length(),
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        at = text.indexOf(searchHighlight, at + searchHighlight.length());
      }
    }
    return span;
  }

  private static String shortFileName(String path) {
    int slash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
    return slash < 0 ? path : path.substring(slash + 1);
  }

  /** أيقونة رأس الملف في النتائج حسب الامتداد — نفس خريطة أيقونات تبويبات المحرر. */
  private static int fileTypeIcon(String name) {
    String n = name == null ? "" : name.toLowerCase(java.util.Locale.US);
    if (n.endsWith(".java") || n.endsWith(".kt")) return R.drawable.file_type_java;
    if (n.endsWith(".xml")) return R.drawable.file_type_xml;
    if (n.endsWith(".gradle") || n.endsWith(".gradle.kts")) return R.drawable.project_properties;
    if (n.endsWith(".txt")
        || n.endsWith(".md")
        || n.endsWith(".properties")
        || n.endsWith(".json")
        || n.endsWith(".csv")) return R.drawable.file_type_txt;
    return R.drawable.file_type_unknown;
  }

  private final class UsageAdapter extends BaseAdapter {
    private static final int TYPE_STATUS = 0, TYPE_FILE = 1, TYPE_MATCH = 2;

    @Override
    public int getViewTypeCount() {
      return 3;
    }

    @Override
    public int getItemViewType(int position) {
      if (usages.isEmpty()) return TYPE_STATUS;
      return searchRows.get(position) instanceof String ? TYPE_FILE : TYPE_MATCH;
    }

    @Override
    public int getCount() {
      return usages.isEmpty() ? (searchStatus.isEmpty() ? 0 : 1) : searchRows.size();
    }

    @Override
    public Object getItem(int position) {
      return usages.isEmpty() ? null : searchRows.get(position);
    }

    @Override
    public long getItemId(int position) {
      return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      int type = getItemViewType(position);
      if (type == TYPE_STATUS) {
        TextView view =
            convertView instanceof TextView ? (TextView) convertView : label("", 13, Color.LTGRAY);
        view.setPadding(dp(14), dp(10), dp(8), dp(10));
        view.setText(searchStatus);
        return view;
      }
      if (type == TYPE_FILE) {
        LinearLayout row;
        if (convertView instanceof LinearLayout) {
          row = (LinearLayout) convertView;
        } else {
          row = new LinearLayout(getContext());
          row.setOrientation(HORIZONTAL);
          row.setGravity(Gravity.CENTER_VERTICAL);
          row.setPadding(dp(14), dp(12), dp(10), dp(4));
          ImageView icon = new ImageView(getContext());
          row.addView(icon, new LinearLayout.LayoutParams(dp(20), dp(20)));
          TextView name = label("", 15, Color.WHITE);
          name.setPadding(dp(10), 0, 0, 0);
          row.addView(name);
        }
        String fileName = (String) searchRows.get(position);
        // أيقونة بنوع الملف كما في المرجع: ملفات الجافا بأيقونتها لا بأيقونة كود عامة.
        ((ImageView) row.getChildAt(0)).setImageResource(fileTypeIcon(fileName));
        ((TextView) row.getChildAt(1)).setText(shortFileName(fileName));
        return row;
      }
      TextView view;
      if (convertView instanceof TextView) {
        view = (TextView) convertView;
      } else {
        view = label("", 13, Color.WHITE);
        view.setTypeface(Typeface.MONOSPACE);
        view.setPadding(dp(40), dp(4), dp(10), dp(8));
      }
      view.setText(styledPreview((UsageSearchEngine.Usage) searchRows.get(position)));
      return view;
    }
  }

  private static final class PanelHeader {
    final LinearLayout root;
    final ImageView icon;
    final TextView title;

    PanelHeader(LinearLayout root, ImageView icon, TextView title) {
      this.root = root;
      this.icon = icon;
      this.title = title;
    }
  }
}
