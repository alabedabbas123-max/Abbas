package com.mhd.absher;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import com.a.a.a.a.a;
import com.google.firebase.FirebaseApp;
import java.util.Random;

public class OtpActivity extends AppCompatActivity {
    private OtpBinding binding;

    private void initialize(Bundle bundle) {
        this.binding.webviewLoadingGif.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView webView, String str) {
                super.onPageFinished(webView, str);
            }

            @Override
            public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
                super.onPageStarted(webView, str, bitmap);
            }
        });
    }

    /* JADX WARN: Type inference failed for: r10v2, types: [com.mhd.absher.OtpActivity$4] */
    private void initializeLogic() {
        final EditText editText = (EditText) findViewById(R.id.etCode1);
        final EditText editText2 = (EditText) findViewById(R.id.etCode2);
        final EditText editText3 = (EditText) findViewById(R.id.etCode3);
        final EditText editText4 = (EditText) findViewById(R.id.etCode4);
        final TextView textView = (TextView) findViewById(R.id.tvTimer);
        final TextView textView2 = (TextView) findViewById(R.id.tvOtpError);
        final Button button = (Button) findViewById(R.id.btnResend);
        final RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.layoutLoadingOverlay);
        final WebView webView = (WebView) findViewById(R.id.webviewLoadingGif);
        if (Build.VERSION.SDK_INT >= 29) {
            int iApplyDimension = (int) TypedValue.applyDimension(1, 3.0f, getResources().getDisplayMetrics());
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(-15959478);
            gradientDrawable.setSize(iApplyDimension, 0);
            if (editText != null) {
                editText.setTextCursorDrawable(gradientDrawable);
            }
            if (editText2 != null) {
                editText2.setTextCursorDrawable(gradientDrawable);
            }
            if (editText3 != null) {
                editText3.setTextCursorDrawable(gradientDrawable);
            }
            if (editText4 != null) {
                editText4.setTextCursorDrawable(gradientDrawable);
            }
        }
        ImageView imageView = (ImageView) findViewById(R.id.imgAbsherLogo);
        if (imageView != null) {
            int iApplyDimension2 = (int) TypedValue.applyDimension(1, 140.0f, getResources().getDisplayMetrics());
            int iApplyDimension3 = (int) TypedValue.applyDimension(1, 90.0f, getResources().getDisplayMetrics());
            ViewGroup.LayoutParams layoutParams = imageView.getLayoutParams();
            if (layoutParams != null) {
                layoutParams.width = iApplyDimension2;
                layoutParams.height = iApplyDimension3;
                imageView.setLayoutParams(layoutParams);
            }
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView.setVisibility(0);
        }
        int intExtra = getIntent().getIntExtra(a.a("AxEUZH4cFwd5cRoaGW53ERE="), 0);
        if (intExtra == 0) {
            intExtra = new Random().nextInt(9000) + 1000;
        }
        final int[] iArr = {intExtra};
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(a.a("NDoiX1c8MGhdXSc5L15LPDsoA2gaBxJydhoAD2txFhUSZHcbBw==")) != 0) {
            requestPermissions(new String[]{a.a("NDoiX1c8MGhdXSc5L15LPDsoA2gaBxJydhoAD2txFhUSZHcbBw==")}, 101);
        }
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                NotificationManager notificationManager = (NotificationManager) OtpActivity.this.getSystemService(a.a("OzsyRF48NydZUTo6"));
                if (notificationManager != null) {
                    String strA = a.a("OiA2cls9NShDXTk=");
                    if (Build.VERSION.SDK_INT >= 26) {
                        notificationManager.createNotificationChannel(new NotificationChannel(strA, a.a("GgAWDXY6IC9LUTY1MkRXOyc="), 4));
                    }
                    Intent intent = new Intent();
                    intent.setClassName(OtpActivity.this.getPackageName(), String.valueOf(OtpActivity.this.getPackageName()) + a.a("exsyXXk2IC9bUSEt"));
                    PendingIntent activity = PendingIntent.getActivity(OtpActivity.this, 0, intent, 201326592);
                    String str = a.a("jeWfqODndJ6K4dGM7PWbjNefp+D6dA==") + iArr[0] + a.a("X43C9LyN+56D4d2Nwg3g8I3C9LF1jcP0vo3hnoQYjfeeheDhjPf1tHWM7PS9jeWfp+DkdJ6K4dGM9/S9jeZm9LKN7Z6c4OONxQ3h0Y3C9Z+N+Z6H4d+M4fS8");
                    Bitmap bitmapCreateBitmap = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bitmapCreateBitmap);
                    Paint paint = new Paint();
                    paint.setAntiAlias(true);
                    paint.setColor(Color.parseColor(a.a("dhcFbnsWFw==")));
                    canvas.drawCircle(48.0f, 48.0f, 48.0f, paint);
                    paint.setColor(-1);
                    canvas.drawCircle(48.0f, 36.0f, 16.0f, paint);
                    canvas.drawArc(new RectF(24.0f, 56.0f, 72.0f, 100.0f), 180.0f, 180.0f, true, paint);
                    notificationManager.notify(2001, new NotificationCompat.Builder(OtpActivity.this, strA).setSmallIcon(R.drawable.ic_left_arrow2).setContentTitle(a.a("FDY1RV0n")).setContentText(a.a("jeWfqODndJ6K4dGM7PWbjNefp+D6dA==") + iArr[0]).setStyle(new NotificationCompat.BigTextStyle().bigText(str)).setLargeIcon(bitmapCreateBitmap).setAutoCancel(true).setPriority(1).setContentIntent(activity).build());
                    Toast.makeText((Context) OtpActivity.this, (CharSequence) (a.a("jNyemOHRjcUN4OSNw/WKdYzh9LyN/p6A4deNxA3g/Yzl9YGM0J+kGI3zn6ng4Yzh9YyN/XwN") + iArr[0]), 1).show();
                }
            }
        };
        final Runnable runnable2 = new Runnable() {
            @Override
            public void run() {
                if (editText == null || editText2 == null || editText3 == null || editText4 == null) {
                    return;
                }
                String strTrim = editText.getText().toString().trim();
                String strTrim2 = editText2.getText().toString().trim();
                String strTrim3 = editText3.getText().toString().trim();
                String strTrim4 = editText4.getText().toString().trim();
                if (strTrim.length() <= 0 || strTrim2.length() <= 0 || strTrim3.length() <= 0 || strTrim4.length() <= 0) {
                    return;
                }
                if (Integer.parseInt(String.valueOf(strTrim) + strTrim2 + strTrim3 + strTrim4) != iArr[0]) {
                    if (textView2 != null) {
                        textView2.setText(a.a("jeWfqODndJ6K4dGM7PWVjNafrxiN7p+n4OR0npjg+I3M9ZU="));
                        return;
                    }
                    return;
                }
                if (textView2 != null) {
                    textView2.setText("");
                }
                InputMethodManager inputMethodManager = (InputMethodManager) OtpActivity.this.getSystemService(a.a("PDo2WEwKOSNZUDow"));
                if (inputMethodManager != null && editText4 != null) {
                    inputMethodManager.hideSoftInputFromWindow(editText4.getWindowToken(), 0);
                }
                if (relativeLayout != null) {
                    relativeLayout.setVisibility(0);
                    relativeLayout.setClickable(true);
                    relativeLayout.setFocusable(true);
                }
                if (webView != null) {
                    webView.setBackgroundColor(-1);
                    webView.getSettings().setLoadWithOverviewMode(true);
                    webView.getSettings().setUseWideViewPort(true);
                    webView.getSettings().setJavaScriptEnabled(true);
                    webView.setVerticalScrollBarEnabled(false);
                    webView.setHorizontalScrollBarEnabled(false);
                    webView.loadDataWithBaseURL(a.a("Mz0qSAJ6e2lMVjEmKURcCjU1Xl0hew=="), a.a("aTwyQFRraC5IWTFqel5MLDgjE1AhOSoBGDc7IlQYLnQrTEoyPSgXCG50NkxcMT0oSgJlb2ZaUTEgLhcJZWRjFhg9MS9KUCFudx0IcG9mT1k2PyFfVyA6IgBbOjgpXwJ2EgBrfhMSfQ1XIzE0S1Q6I3xFUTEwI0MDdTAvXkg5NT8XXjkxPhYYPyE1WVEzLWtOVzsgI0NMbzcjQ0wwJn0NWTk9IUMVPCAjQEtvNyNDTDAmfQ1FPDkhDUN1OSdVFSI9IllQb2V2HR1udCtMQHg8I0RfPSB8HAhlcX0NVzc+I05MeDIvWQI2OyhZWTw6fQ1MJzUoXl46JisXSzY1KkgQZ3pyBAN1IDRMViYyKV9VeDs0RF88OnxOXTsgI18YNjEoWV0nb2ZQBHonMlRUMGp6AlAwNSITBDc7IlQGaT0rShgmJiUQHzIyLwNfPDJhAgZpeyRCXCxqegJQITkqEw=="), a.a("ITE+WRc9ICtB"), a.a("AAAAAAA="), null);
                }
                Handler handler = new Handler(Looper.getMainLooper());
                final TextView textView3 = textView2;
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            OtpActivity.this.startActivity(new Intent((Context) OtpActivity.this, (Class<?>) ActivityHomeActivity.class));
                            OtpActivity.this.finish();
                        } catch (Exception e) {
                            if (textView3 != null) {
                                textView3.setText(a.a("jfqemuD2dJ+s4d90norh0Yzh9L6N/p+v4PKNwg3g8I3C9LF1jc71n434n6rg/HQHTkw8Ii9ZQR07K0h5NiAvW1EhLQ=="));
                            }
                        }
                    }
                }, 3000L);
            }
        };
        if (button != null) {
            button.setEnabled(false);
        }
        new CountDownTimer(60000L, 1000L) {
            @Override
            public void onFinish() {
                if (textView != null) {
                    textView.setText(a.a("jN6fqOHWjcD0u3WM4fS8jfafqxiN8Z6U4PKM6fWRdYzj9YmN556K4dF0norh0Yz39L2N5g=="));
                }
                if (button != null) {
                    button.setEnabled(true);
                    button.setBackgroundColor(Color.parseColor(a.a("dmQFGnlhFQ==")));
                }
            }

            @Override
            public void onTick(long j) {
                long j2 = j / 1000;
                if (textView != null) {
                    textView.setText(a.a("jN6fqOHWjcD0u3WM4/WBjfOeguD8dJ6I4OSM9fWfjNBm9Z+M0J6c4dCM9A3g/Yz/9Zd1ZHYX") + (j2 < 10 ? a.a("ZQ==") + j2 : Long.valueOf(j2)));
                }
            }
        }.start();
        if (editText != null) {
            editText.postDelayed(new Runnable() {
                @Override
                public void run() {
                    runnable.run();
                }
            }, 1500L);
        }
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    iArr[0] = new Random().nextInt(9000) + 1000;
                    runnable.run();
                }
            });
        }
        if (editText == null || editText2 == null || editText3 == null || editText4 == null) {
            return;
        }
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (charSequence.length() == 1) {
                    editText2.requestFocus();
                }
                runnable2.run();
            }
        });
        editText2.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (charSequence.length() == 1) {
                    editText3.requestFocus();
                }
                runnable2.run();
            }
        });
        editText2.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (i != 67 || keyEvent.getAction() != 0 || !editText2.getText().toString().isEmpty()) {
                    return false;
                }
                editText.requestFocus();
                editText.setSelection(editText.getText().length());
                return true;
            }
        });
        editText3.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (charSequence.length() == 1) {
                    editText4.requestFocus();
                }
                runnable2.run();
            }
        });
        editText3.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (i != 67 || keyEvent.getAction() != 0 || !editText3.getText().toString().isEmpty()) {
                    return false;
                }
                editText2.requestFocus();
                editText2.setSelection(editText2.getText().length());
                return true;
            }
        });
        editText4.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                runnable2.run();
            }
        });
        editText4.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (i != 67 || keyEvent.getAction() != 0 || !editText4.getText().toString().isEmpty()) {
                    return false;
                }
                editText3.requestFocus();
                editText3.setSelection(editText3.getText().length());
                return true;
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onBackPressed() {
        Intent intent = new Intent((Context) this, (Class<?>) MainActivity.class);
        intent.putExtra(a.a("NjsrRFYyCyBfVzgLIVhdJiA="), true);
        intent.addFlags(603979776);
        startActivity(intent);
        finish();
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = OtpBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        FirebaseApp.initializeApp(this);
        initializeLogic();
    }
}
