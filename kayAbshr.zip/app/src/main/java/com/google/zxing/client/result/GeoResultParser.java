package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class GeoResultParser extends ResultParser {
    private static final Pattern GEO_URL_PATTERN = Pattern.compile("geo:([\\-0-9.]+),([\\-0-9.]+)(?:,([\\-0-9.]+))?(?:\\?(.*))?", 2);

    @Override
    public GeoParsedResult parse(Result result) {
        double d = 0.0d;
        Matcher matcher = GEO_URL_PATTERN.matcher(getMassagedText(result));
        if (!matcher.matches()) {
            return null;
        }
        String strGroup = matcher.group(4);
        try {
            double d2 = Double.parseDouble(matcher.group(1));
            if (d2 > 90.0d || d2 < -90.0d) {
                return null;
            }
            double d3 = Double.parseDouble(matcher.group(2));
            if (d3 > 180.0d || d3 < -180.0d) {
                return null;
            }
            if (matcher.group(3) != null) {
                double d4 = Double.parseDouble(matcher.group(3));
                if (d4 < 0.0d) {
                    return null;
                }
                d = d4;
            }
            return new GeoParsedResult(d2, d3, d, strGroup);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
