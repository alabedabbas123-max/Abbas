package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class SplashBinding {
    public final ImageView ivSplashLogo;
    public final LinearLayout linear4;
    public final RelativeLayout rootView;
    public final TextView tvSplashAbsher;

    private SplashBinding(RelativeLayout relativeLayout, LinearLayout linearLayout, ImageView imageView, TextView textView) {
        this.rootView = relativeLayout;
        this.linear4 = linearLayout;
        this.ivSplashLogo = imageView;
        this.tvSplashAbsher = textView;
    }

    public static SplashBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear4);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.ivSplashLogo);
        TextView textView = (TextView) findChildViewById(view, R.id.tvSplashAbsher);
        if (linearLayout == null || imageView == null || textView == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new SplashBinding(relativeLayout, linearLayout, imageView, textView);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static SplashBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static SplashBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.splash, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
