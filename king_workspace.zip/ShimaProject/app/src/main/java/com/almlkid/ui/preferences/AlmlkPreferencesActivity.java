package com.almlkid.ui.preferences;

import android.app.ActionBar;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import com.shima.demo.AboutActivity;
import com.shima.demo.R;
import java.util.ArrayList;
import java.util.List;

/**
 * مضيف الإعدادات بتبويبيه — المرحلة 1 من خطة الإعدادات.
 *
 * <p>على منهج المرجع: تبويب Settings = قائمة الرؤوس من {@code preferences_headers.xml}
 * ويُضاف إليه رأس About برمجياً؛ تبويب Advanced = شظية مخفية تُبدَّل بالتبويبات.
 */
public class AlmlkPreferencesActivity extends PreferenceActivity
    implements ActionBar.TabListener {

  private static final String TAG_TAB_SETTINGS = "tag_tab_settings";
  private static final String TAG_TAB_ADVANCED = "tag_tab_advance_settings";
  private static final String TAG_FRAGMENT_ADVANCED = "tag_fragment_advance_settings";

  private AdvancedSettingsFragment advanced;
  private ListView headersList;

  @Override
  protected boolean isValidFragment(String fragmentName) {
    return ApplicationPreferencesFragment.class.getName().equals(fragmentName)
        || EditorPreferencesFragment.class.getName().equals(fragmentName)
        || CodestylePreferencesFragment.class.getName().equals(fragmentName)
        || CompilerPreferencesFragment.class.getName().equals(fragmentName)
        || DropboxPreferencesFragment.class.getName().equals(fragmentName)
        || SourceControlPreferencesFragment.class.getName().equals(fragmentName)
        || KeyBindingsPreferencesFragment.class.getName().equals(fragmentName)
        || AdvancedSettingsFragment.class.getName().equals(fragmentName);
  }

  @Override
  public void onBuildHeaders(List<Header> target) {
    List<Header> loaded = new ArrayList<>();
    loadHeadersFromResource(R.xml.preferences_headers, loaded);
    target.addAll(loaded);
    Header about = new Header();
    about.titleRes = R.string.preference_title_legal;
    about.summaryRes = R.string.preference_summary_legal;
    about.intent = new Intent(this, AboutActivity.class);
    target.add(about);
  }

  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    ActionBar bar = getActionBar();
    if (bar != null) {
      bar.setDisplayHomeAsUpEnabled(true);
      bar.setTitle(getApplicationInfo().loadLabel(getPackageManager()));
      bar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
      bar.addTab(
          bar.newTab()
              .setText(R.string.command_settings)
              .setTag(TAG_TAB_SETTINGS)
              .setTabListener(this));
      bar.addTab(
          bar.newTab()
              .setText(R.string.advanced_settings)
              .setTag(TAG_TAB_ADVANCED)
              .setTabListener(this));
      bar.getTabAt(0).select();
    }
    headersList = getListView();
    if (getFragmentManager().findFragmentByTag(TAG_FRAGMENT_ADVANCED) == null) {
      advanced = new AdvancedSettingsFragment();
      FragmentTransaction transaction = getFragmentManager().beginTransaction();
      transaction.add(android.R.id.content, advanced, TAG_FRAGMENT_ADVANCED);
      transaction.hide(advanced);
      transaction.commit();
    } else {
      advanced = (AdvancedSettingsFragment) getFragmentManager().findFragmentByTag(TAG_FRAGMENT_ADVANCED);
    }
  }

  @Override
  public void onTabSelected(ActionBar.Tab tab, FragmentTransaction transaction) {
    // حصانة تامة من «commit already called»: المعاملة التي يمررها الإطار تُترك فارغة فلا
    // يرتكبها إطلاقًا؛ الإظهار/الإخفاء بمعاملة مستقلة نملكها نحن ونرتكبها مرة واحدة.
    boolean showAdvanced = TAG_TAB_ADVANCED.equals(String.valueOf(tab.getTag()));
    if (headersList != null)
      headersList.setVisibility(showAdvanced ? View.GONE : View.VISIBLE);
    if (advanced != null) {
      FragmentTransaction own = getFragmentManager().beginTransaction();
      if (showAdvanced) own.show(advanced);
      else own.hide(advanced);
      own.commitAllowingStateLoss();
    }
  }

  @Override
  public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction transaction) {}

  @Override
  public void onTabReselected(ActionBar.Tab tab, FragmentTransaction transaction) {}

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      finish();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }
}
