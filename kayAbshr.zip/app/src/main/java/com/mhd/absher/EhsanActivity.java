package com.mhd.absher;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.FirebaseApp;

public class EhsanActivity extends AppCompatActivity {
    private EhsanBinding binding;

    private void initialize(Bundle bundle) {
    }

    private void initializeLogic() {
        View viewFindViewById = findViewById(R.id.btnBackEhsan);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    EhsanActivity.this.finish();
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = EhsanBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        FirebaseApp.initializeApp(this);
        initializeLogic();
    }
}
