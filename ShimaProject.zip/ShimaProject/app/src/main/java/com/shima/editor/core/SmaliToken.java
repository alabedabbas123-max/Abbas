package com.shima.editor.core;

public final class SmaliToken {
  public final int start;
  public final int end;
  public final SmaliTokenKind kind;

  public SmaliToken(int start, int end, SmaliTokenKind kind) {
    this.start = start;
    this.end = end;
    this.kind = kind == null ? SmaliTokenKind.PLAIN : kind;
  }
}
