package com.mhd.absher;

import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class IdPagerAdapter extends RecyclerView.Adapter {
    private final List images;

    public class IdViewHolder extends RecyclerView.ViewHolder {
        final ImageView imgIdPage;

        public IdViewHolder(ImageView imageView) {
            super(imageView);
            this.imgIdPage = imageView;
        }
    }

    public IdPagerAdapter(List list) {
        this.images = list;
    }

    public int getItemCount() {
        if (this.images == null) {
            return 0;
        }
        return this.images.size();
    }

    public void onBindViewHolder(IdViewHolder idViewHolder, int i) {
        idViewHolder.imgIdPage.setImageResource(((Integer) this.images.get(i)).intValue());
    }

    public IdViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        ImageView imageView = new ImageView(viewGroup.getContext());
        imageView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setAdjustViewBounds(true);
        return new IdViewHolder(imageView);
    }
}
