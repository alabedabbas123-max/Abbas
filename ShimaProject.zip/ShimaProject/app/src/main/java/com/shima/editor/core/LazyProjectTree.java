package com.shima.editor.core;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Lazy project tree contract; directory children are read only when expanded. */
public final class LazyProjectTree implements AutoCloseable {
  public interface Provider {
    List<ProjectNode> children(ProjectNode.Directory directory) throws Exception;
  }

  public interface Callback {
    void completed(ProjectNode.Directory directory, Throwable error);
  }

  private final Provider provider;
  private final ExecutorService worker = Executors.newFixedThreadPool(2, runnable -> {
    Thread thread = new Thread(runnable, "shima-project-tree");
    thread.setPriority(Thread.NORM_PRIORITY - 1);
    return thread;
  });

  public LazyProjectTree(Provider provider) {
    this.provider = provider;
  }

  public void expand(ProjectNode.Directory directory, Callback callback) {
    if (directory == null || provider == null) return;
    synchronized (directory) {
      directory.expanded = true;
      if (directory.childrenLoaded) {
        if (callback != null) callback.completed(directory, null);
        return;
      }
    }
    worker.execute(() -> {
      Throwable error = null;
      try {
        directory.replaceChildren(provider.children(directory));
      } catch (Throwable failure) {
        error = failure;
      }
      if (callback != null) callback.completed(directory, error);
    });
  }

  public void collapse(ProjectNode.Directory directory) {
    if (directory != null) directory.expanded = false;
  }

  public static ProjectNode.FileType typeFor(String name) {
    if (name == null) return ProjectNode.FileType.UNKNOWN;
    String value = name.toLowerCase(java.util.Locale.US);
    if (value.endsWith(".dex")) return ProjectNode.FileType.DEX;
    if (value.endsWith(".smali")) return ProjectNode.FileType.SMALI;
    if (value.endsWith(".java")) return ProjectNode.FileType.JAVA;
    if (value.endsWith(".kt") || value.endsWith(".kts")) return ProjectNode.FileType.KOTLIN;
    if (value.endsWith(".json")) return ProjectNode.FileType.JSON;
    if (value.endsWith(".xml")) return ProjectNode.FileType.XML;
    if (value.endsWith(".csv")) return ProjectNode.FileType.CSV;
    if (value.endsWith(".txt")) return ProjectNode.FileType.TXT;
    if (value.endsWith(".report")) return ProjectNode.FileType.REPORT;
    return ProjectNode.FileType.UNKNOWN;
  }

  @Override
  public void close() {
    worker.shutdownNow();
  }
}
