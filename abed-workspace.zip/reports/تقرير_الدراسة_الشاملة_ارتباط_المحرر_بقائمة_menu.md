# تقرير الدراسة الشاملة — ارتباط المحرر بقائمة menu (تحديد / بدون تحديد) ومطابقة المصدر 100%

> دراسة (بند 2) — **بانتظار الموافقة على عدد المراحل قبل أي تنفيذ**.
> المصادر: شيفرتنا (`EditorMenuRegistry`, `AIDEEditorPager`, `MainActivity`, `CommandCenter`) +
> قوائم المرجع `res/menu/{main_options_menu, editor_context_menu, editor_small_context_menu}.xml` +
> معالج المرجع `com/aide/p000ui/C0040Na.java` (من `abeed.zip`، 2238 صنف java). **لا نسخ — المطابقة سلوكًا.**
> اللقطات 1-4 = بدون تحديد، 5-9 = مع التحديد.

---

## أ) البنية الحالية عندنا (كيف ترتبط القوائم بالجافا)

- **بدون تحديد:** شريط الأدوات (`onCreateOptionsMenu` `MainActivity:597`) = تشغيل/تراجع/إعادة/قلم‑أو‑تصميم/⋯.
  زر ⋯ → `showIdeRootMenu` (`:1096`) = [وضع التحرير/التنقل، View…، GoTo، Save، More…].
  الفروع: `showIdeViewMenu` (Files/Errors/Search/Debugger/LogCat/File List) و`showIdeMoreMenu`
  (Find/Refactor/Code/Format/Project/Tools/Settings/Exit) وقائمة إنشاء الكود (Code…→Activity/AlertDialog/ViewListener).
  كلها تُرسل معرفات أوامر → `dispatch(id)` (`MainActivity:1363`) — **الـswitch الكبير المنفَّذ**.
- **مع التحديد:** `ActionMode` يبنيه `CodeEditorView.startSelectionActionMode` + المساهم المخصص
  (`AIDEEditorPager:215`)؛ الأهلية الحية من `EditorMenuRegistry.PAGE_TOOLBAR`؛ وعناصر ⋯ من `PAGE_ROOT`
  وفروعه؛ التنفيذ في `executeEditorMenuCommand(id, mode)` (`AIDEEditorPager`).

---

## ب) مصفوفة المطابقة — حالة كل أمر (منفَّذ ✔ / معطَّل‑stub ✘ / غير موجود ∅)

### بدون تحديد (اللقطات 1-4 ↔ `main_options_menu.xml`)
| الأمر (مرجع) | عندنا | Handler | الحالة |
|---|---|---|---|
| Run/Undo/Redo/Design/Edit | ✔ أيقونات شريط | `onOptionsItemSelected:677` | ✔ |
| View→Files/Errors/Search/Debugger/LogCat/FileList | ✔ | `dispatch` show_* / files | ✔ |
| GoTo | ✔ `goto_element` | `dispatch:1770` | ✔ |
| Save | ✔ | `dispatch:1749` | ✔ |
| More→Find (usages/in-file/in-project/goto-line/documentation) | ✔ | `dispatch` find/goto_line/documentation | ✔ |
| More→Refactor (rename/inline/introduce/extract) | ✘ stubs | — | **✘** |
| More→Code (organize/try/comment/uncomment/setters/constructor/extract-res/replace) | جزئي | `executeEditorMenuCommand` | **جزئي** |
| More→Format (format/learn/configure) | جزئي | configure✔ format✔ learn✘ | **جزئي** |
| More→Project (rebuild/variants/publish/close) | ∅/جزئي | clean✔ rebuild جزئي، variants/publish ∅ | **** |
| More→Tools / Settings / Exit | Settings✔ Exit∅ Tools جزئي | — | **جزئي** |
| Forward / StepIn/Out/Stop (debug) | ∅ | — | **∅** |

### مع التحديد (اللقطات 5-9 ↔ `editor_context_menu.xml`)
| الأمر (مرجع) | عندنا | الحالة |
|---|---|---|
| Color / Fix / Expand / Cut / Copy / Paste | ✔ (شريط أيقونات + أهلية حية) | ✔ |
| GoTo(definition) / Documentation | ✔ | ✔ |
| Breakpoint | ✘ `enabled=false` (`EditorMenuRegistry`) | **✘** |
| Refactor→Rename/Inline/Introduce/ExtractMethod | ✘ stubs | **✘** |
| Code→OrganizeImports / SurroundTry | ✔ | ✔ |
| Code→Comment/Uncomment | ✔ (Java+XML) | ✔ |
| Code→CreateSetters / CreateConstructor / ExtractResources | ✘ stubs | **✘** |
| Code→ReplaceTextually | ✔ | ✔ |
| Format→FormatCode / ConfigureStyle | ✔ | ✔ |
| Format→LearnCodeStyle | ✘ stub | **✘** |
| Find→Usages/Extended/Textually | ✔ | ✔ |
| CloseFile | ✔ | ✔ |

**مجموعة الفجوة (stubs/∅) التي تفصلنا عن 100%:**
`rename, inline, introduce, extract_method, create_setters, create_constructor, extract_resources,
learn_style, breakpoint` + رئيسي: `project_variants, publish_project, exit, forward, step_in/out/stop, tools-كاملة`.
المرجع **ينفّذها فعليًا** (المعالج `C0040Na` يتعامل مع `editorMenuRename/…`) — محركاتها obfuscated/native
فلزم **إعادة بنائها بأسلوبنا** (بند 2/3)، لا نسخها.

---

## ج) العمليات الخلفية
فحص `ps` = **0** عملية خلفية (لا GradleDaemon ولا خوادم)؛ لن أُبقي أي شيء يعمل — استجابة المحادثة سليمة.

---

## د) خطة المراحل المقترحة (= **5 مراحل**)

كل مرحلة جولة شحن مستقلة (دراسة مصغّرة→تنفيذ→بوابات→إحلال بند 4)، بترتيب يعتمد على بعضه:

1. **اكتمال القائمة الرئيسية (بدون تحديد) 100%:** ربط Project(rebuild/variants/publish/close) وTools وExit
   وForward وأوامر debug (step/stop) بـ`dispatch` فعلي أو أهلية صريحة، وإزالة أي عنصر ميت.
2. **Rename (Java + موارد XML):** إعادة تسمية حقيقية تحدّث كل الاستخدامات والفهارس (`ProjectSymbolIndex`/`XmlResourceIndex`).
3. **محرك Refactor:** Inline Variable + Introduce Variable + Extract Method (تحليل نطاق/استخدامات بأسلوبنا).
4. **توليد الكود:** Create Setters/Getters + Create Constructor + Extract Resources (كتابة مولِّدات نصية آمنة بسجلّ Undo).
5. **Breakpoint + Learn Code Style + الإحلال الشامل:** نقاط توقف مربوطة بالمصحح، تعلم النمط من المستند،
   ثم إزالة كل مسار ميت وتوحيد الأهلية وشبكة بوابات تغطي المصفوفة أعلاه كاملة.

**لماذا 5؟** الفجوة تنقسم طبيعيًا إلى 5 محركات مستقلة قابلة للشحن والاختبار منفردة؛ دمجها في جولة واحدة
يخالف نمطنا (بند 4: إحلال كامل مُتحقَّق) ويجعل البوابات غير قابلة للعزل.

---

## هـ) الالتزام بالبندود
- **بند 2:** هذه الدراسة سابقة للتنفيذ؛ لا نسخ من المرجع (محركاته obfuscated → إعادة بناء).
- **بند 3:** كل صنف جديد ضمن `almlk`/`almlkid` وبلا مكتبات خارجية.
- **بند 4:** كل مرحلة تُحِل fully وتزيل الميت وتبقي الواجهات (`dispatch`/`executeEditorMenuCommand`) مستقرة.

**بانتظار موافقتك على «5 مراحل» (أو تعديلها) ثم «ابدأ» لبدء المرحلة 1.**
