package almlk;

/**
 * بند almlk ← أسلوب تحديد العناصر في AIDE عند الانتقاء (identifier-aware):
 * حدود معرّف لغة Java حول نقطة ما — حروف/أرقام/«_»/«$» — فينتقي الضغط المزدوج المعرف
 * كاملًا بدل تقطيع كلمة عشوائي عند «_».
 */
public final class IdentifierBounds {

  /** بداية المعرف الحاوي للموضع (أو الموضع نفسه عندما لا يوجد معرف). */
  public static int start(CharSequence text, int offset) {
    if (text == null || offset <= 0 || offset > text.length()) return Math.max(0, offset);
    int at = Math.min(offset, text.length());
    int start = at;
    while (start > 0 && isPart(text.charAt(start - 1))) start--;
    return start;
  }

  /** نهاية المعرف الحاوي للموضع (حصرية). */
  public static int end(CharSequence text, int offset) {
    if (text == null || offset < 0) return 0;
    int end = offset;
    while (end < text.length() && isPart(text.charAt(end))) end++;
    return end;
  }

  /** هل الموضع داخل معرف (وليس على فراغ/علامة). */
  public static boolean inside(CharSequence text, int offset) {
    if (text == null || offset < 0 || offset >= text.length()) return false;
    return isPart(text.charAt(offset)) || (offset > 0 && isPart(text.charAt(offset - 1)));
  }

  /** قواعد المعرّف كما في مواصفة Java (Character.isJavaIdentifierPart). */
  public static boolean isPart(char c) {
    return Character.isJavaIdentifierPart(c);
  }

  /** يجب أن يبدأ معرف جافا بحرف/عملة/ندرسكور (يخدم فحص الكلمات المرشّحة للتعريف). */
  public static boolean isStart(char c) {
    return Character.isJavaIdentifierStart(c);
  }
}
