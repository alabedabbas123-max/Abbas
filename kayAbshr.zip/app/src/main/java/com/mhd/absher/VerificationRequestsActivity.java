package com.mhd.absher;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class VerificationRequestsActivity extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.verification_requests);
        getWindow().getDecorView().setLayoutDirection(1);
        ImageView imageView = (ImageView) findViewById(R.id.btnCloseVerification);
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    VerificationRequestsActivity.this.finish();
                }
            });
        }
    }
}
