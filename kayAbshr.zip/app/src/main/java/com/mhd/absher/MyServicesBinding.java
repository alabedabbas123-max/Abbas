package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class MyServicesBinding {
    public final LinearLayout bottomNavMyServices;
    public final ImageButton btnChat;
    public final ImageView btnCloseNotice;
    public final LinearLayout cardBirthRegistration;
    public final RelativeLayout cardNotice;
    public final LinearLayout cardRenewIqama;
    public final LinearLayout cardRenewLicense;
    public final LinearLayout cardVerification;
    public final LinearLayout contentMyServices;
    public final GridLayout gridServices;
    public final ImageView imageview35;
    public final ImageView imageview36;
    public final ImageView imageview37;
    public final ImageView imageview38;
    public final ImageView imageview39;
    public final ImageView imageview40;
    public final ImageView imageview41;
    public final ImageView imageview42;
    public final ImageView imageview43;
    public final ImageView imageview44;
    public final RelativeLayout infoCircle;
    public final ImageView ivAbsherLogo;
    public final ImageView ivBell;
    public final ImageView ivInterior;
    public final ImageView ivSearch;
    public final ImageView ivSettings;
    public final LinearLayout navFamily;
    public final LinearLayout navHome;
    public final LinearLayout navMyServices;
    public final LinearLayout navOther;
    public final LinearLayout navWorkers;
    public final LinearLayout noticeText;
    public final RelativeLayout rootMyServices;
    public final ScrollView scrollMyServices;
    public final RelativeLayout searchContainer;
    public final Space space42;
    public final TextView textview56;
    public final TextView textview57;
    public final TextView textview58;
    public final TextView textview59;
    public final TextView textview60;
    public final TextView textview61;
    public final TextView textview62;
    public final TextView textview63;
    public final TextView textview64;
    public final TextView textview65;
    public final TextView textview66;
    public final RelativeLayout topHeader;
    public final TextView tvSearchHint;
    public final TextView tvTitle;

    private MyServicesBinding(RelativeLayout relativeLayout, ScrollView scrollView, LinearLayout linearLayout, RelativeLayout relativeLayout2, ImageView imageView, ImageView imageView2, ImageView imageView3, ImageView imageView4, TextView textView, RelativeLayout relativeLayout3, ImageView imageView5, TextView textView2, RelativeLayout relativeLayout4, RelativeLayout relativeLayout5, ImageView imageView6, ImageView imageView7, LinearLayout linearLayout2, TextView textView3, TextView textView4, GridLayout gridLayout, LinearLayout linearLayout3, ImageView imageView8, TextView textView5, LinearLayout linearLayout4, ImageView imageView9, TextView textView6, LinearLayout linearLayout5, ImageView imageView10, TextView textView7, LinearLayout linearLayout6, ImageView imageView11, TextView textView8, Space space, ImageButton imageButton, LinearLayout linearLayout7, LinearLayout linearLayout8, ImageView imageView12, TextView textView9, LinearLayout linearLayout9, ImageView imageView13, TextView textView10, LinearLayout linearLayout10, ImageView imageView14, TextView textView11, LinearLayout linearLayout11, ImageView imageView15, TextView textView12, LinearLayout linearLayout12, ImageView imageView16, TextView textView13) {
        this.rootMyServices = relativeLayout;
        this.scrollMyServices = scrollView;
        this.contentMyServices = linearLayout;
        this.topHeader = relativeLayout2;
        this.ivAbsherLogo = imageView;
        this.ivInterior = imageView2;
        this.ivBell = imageView3;
        this.ivSettings = imageView4;
        this.tvTitle = textView;
        this.searchContainer = relativeLayout3;
        this.ivSearch = imageView5;
        this.tvSearchHint = textView2;
        this.cardNotice = relativeLayout4;
        this.infoCircle = relativeLayout5;
        this.imageview35 = imageView6;
        this.btnCloseNotice = imageView7;
        this.noticeText = linearLayout2;
        this.textview56 = textView3;
        this.textview57 = textView4;
        this.gridServices = gridLayout;
        this.cardRenewLicense = linearLayout3;
        this.imageview36 = imageView8;
        this.textview58 = textView5;
        this.cardBirthRegistration = linearLayout4;
        this.imageview37 = imageView9;
        this.textview59 = textView6;
        this.cardVerification = linearLayout5;
        this.imageview38 = imageView10;
        this.textview60 = textView7;
        this.cardRenewIqama = linearLayout6;
        this.imageview39 = imageView11;
        this.textview61 = textView8;
        this.space42 = space;
        this.btnChat = imageButton;
        this.bottomNavMyServices = linearLayout7;
        this.navHome = linearLayout8;
        this.imageview44 = imageView12;
        this.textview66 = textView9;
        this.navMyServices = linearLayout9;
        this.imageview43 = imageView13;
        this.textview65 = textView10;
        this.navFamily = linearLayout10;
        this.imageview42 = imageView14;
        this.textview64 = textView11;
        this.navWorkers = linearLayout11;
        this.imageview41 = imageView15;
        this.textview63 = textView12;
        this.navOther = linearLayout12;
        this.imageview40 = imageView16;
        this.textview62 = textView13;
    }

    public static MyServicesBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.scrollMyServices);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.contentMyServices);
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topHeader);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.ivAbsherLogo);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.ivInterior);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.ivBell);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.ivSettings);
        TextView textView = (TextView) findChildViewById(view, R.id.tvTitle);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.searchContainer);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.ivSearch);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvSearchHint);
        RelativeLayout relativeLayout4 = (RelativeLayout) findChildViewById(view, R.id.cardNotice);
        RelativeLayout relativeLayout5 = (RelativeLayout) findChildViewById(view, R.id.infoCircle);
        ImageView imageView6 = (ImageView) findChildViewById(view, R.id.imageview35);
        ImageView imageView7 = (ImageView) findChildViewById(view, R.id.btnCloseNotice);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.noticeText);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview56);
        TextView textView4 = (TextView) findChildViewById(view, R.id.textview57);
        GridLayout gridLayout = (GridLayout) findChildViewById(view, R.id.gridServices);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.cardRenewLicense);
        ImageView imageView8 = (ImageView) findChildViewById(view, R.id.imageview36);
        TextView textView5 = (TextView) findChildViewById(view, R.id.textview58);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.cardBirthRegistration);
        ImageView imageView9 = (ImageView) findChildViewById(view, R.id.imageview37);
        TextView textView6 = (TextView) findChildViewById(view, R.id.textview59);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.cardVerification);
        ImageView imageView10 = (ImageView) findChildViewById(view, R.id.imageview38);
        TextView textView7 = (TextView) findChildViewById(view, R.id.textview60);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.cardRenewIqama);
        ImageView imageView11 = (ImageView) findChildViewById(view, R.id.imageview39);
        TextView textView8 = (TextView) findChildViewById(view, R.id.textview61);
        Space space = (Space) findChildViewById(view, R.id.space42);
        ImageButton imageButton = (ImageButton) findChildViewById(view, R.id.btnChat);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.bottomNavMyServices);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.navHome);
        ImageView imageView12 = (ImageView) findChildViewById(view, R.id.imageview44);
        TextView textView9 = (TextView) findChildViewById(view, R.id.textview66);
        LinearLayout linearLayout9 = (LinearLayout) findChildViewById(view, R.id.navMyServices);
        ImageView imageView13 = (ImageView) findChildViewById(view, R.id.imageview43);
        TextView textView10 = (TextView) findChildViewById(view, R.id.textview65);
        LinearLayout linearLayout10 = (LinearLayout) findChildViewById(view, R.id.navFamily);
        ImageView imageView14 = (ImageView) findChildViewById(view, R.id.imageview42);
        TextView textView11 = (TextView) findChildViewById(view, R.id.textview64);
        LinearLayout linearLayout11 = (LinearLayout) findChildViewById(view, R.id.navWorkers);
        ImageView imageView15 = (ImageView) findChildViewById(view, R.id.imageview41);
        TextView textView12 = (TextView) findChildViewById(view, R.id.textview63);
        LinearLayout linearLayout12 = (LinearLayout) findChildViewById(view, R.id.navOther);
        ImageView imageView16 = (ImageView) findChildViewById(view, R.id.imageview40);
        TextView textView13 = (TextView) findChildViewById(view, R.id.textview62);
        if (scrollView == null || linearLayout == null || relativeLayout2 == null || imageView == null || imageView2 == null || imageView3 == null || imageView4 == null || textView == null || relativeLayout3 == null || imageView5 == null || textView2 == null || relativeLayout4 == null || relativeLayout5 == null || imageView6 == null || imageView7 == null || linearLayout2 == null || textView3 == null || textView4 == null || gridLayout == null || linearLayout3 == null || imageView8 == null || textView5 == null || linearLayout4 == null || imageView9 == null || textView6 == null || linearLayout5 == null || imageView10 == null || textView7 == null || linearLayout6 == null || imageView11 == null || textView8 == null || space == null || imageButton == null || linearLayout7 == null || linearLayout8 == null || imageView12 == null || textView9 == null || linearLayout9 == null || imageView13 == null || textView10 == null || linearLayout10 == null || imageView14 == null || textView11 == null || linearLayout11 == null || imageView15 == null || textView12 == null || linearLayout12 == null || imageView16 == null || textView13 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new MyServicesBinding(relativeLayout, scrollView, linearLayout, relativeLayout2, imageView, imageView2, imageView3, imageView4, textView, relativeLayout3, imageView5, textView2, relativeLayout4, relativeLayout5, imageView6, imageView7, linearLayout2, textView3, textView4, gridLayout, linearLayout3, imageView8, textView5, linearLayout4, imageView9, textView6, linearLayout5, imageView10, textView7, linearLayout6, imageView11, textView8, space, imageButton, linearLayout7, linearLayout8, imageView12, textView9, linearLayout9, imageView13, textView10, linearLayout10, imageView14, textView11, linearLayout11, imageView15, textView12, linearLayout12, imageView16, textView13);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static MyServicesBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static MyServicesBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.my_services, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootMyServices;
    }
}
