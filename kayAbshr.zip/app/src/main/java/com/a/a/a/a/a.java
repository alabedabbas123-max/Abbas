package com.a.a.a.a;

import android.util.Base64;
import java.io.UnsupportedEncodingException;

public final class a {
    public static String a(String str) {
        return new a().a(str, "UTF-8");
    }

    private static byte[] a(byte[] bArr, String str) {
        int length = bArr.length;
        int length2 = str.length();
        int i = 0;
        int i2 = 0;
        while (i2 < length) {
            if (i >= length2) {
                i = 0;
            }
            bArr[i2] = (byte) (bArr[i2] ^ str.charAt(i));
            i2++;
            i++;
        }
        return bArr;
    }

    public String a(String str, String str2) {
        try {
            return new String(a(Base64.decode(str, 2), str2), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return new String(a(Base64.decode(str, 2), str2));
        }
    }
}
