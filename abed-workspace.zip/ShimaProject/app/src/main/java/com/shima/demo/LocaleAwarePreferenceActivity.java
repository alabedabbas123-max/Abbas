package com.shima.demo;

import android.content.Context;
import android.preference.PreferenceActivity;

/** PreferenceActivity base that resolves resources in the currently selected app locale. */
public abstract class LocaleAwarePreferenceActivity extends PreferenceActivity {
  @Override
  protected void attachBaseContext(Context base) {
    super.attachBaseContext(ShimaApplication.localize(base));
  }
}
