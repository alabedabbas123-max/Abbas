import almlk.CodeStyle;
import almlk.DiagnosticUnderline;
import almlk.IdentifierBounds;
import almlk.LineBuffer;
import almlk.LineDocument;
import almlk.LineStyler;
import almlk.StyleRunBatcher;
import almlk.UndoRedoStack;
import almlk.XmlColorLiteral;
import almlk.XmlCodeFormatter;
import almlk.XmlCommentEditor;
import almlk.XmlResourceIndex;
import almlk.XmlResourceReference;
import almlk.XmlStructureScanner;
import com.almlkid.kay.ui.BuildDiagnosticsParser;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.ProjectDiagnostic;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.ui.SystemApiSourceProvider;
import com.almlkid.ui.EditorMenuRegistry;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import net.margaritov.preference.colorpicker.HexColorCodec;

/**
 * مجموعة الانحدار الدائمة — المرحلة التاسعة (القبول الشامل).
 *
 * <p><b>لماذا داخل المشروع لا في /tmp:</b> بوابات المراحل السابقة كانت تُولَّد في {@code /tmp}
 * فتُمسح كل جلسة، وكنا نُعيد بناءها من الذاكرة. هذه المجموعة تبقى مع المصدر وتُشغَّل بأمر واحد
 * ({@code ./qa.sh})، فلا انحدار يمرّ بصمت بعد اليوم.
 *
 * <p><b>بلا أي تبعية خارجية:</b> جافا صرفة — لا JUnit ولا androidx.test. البدائل الثلاثة تحت
 * {@code qa/stubs/} تُصرَّف بدل android.jar لتغطية سطح {@code android.content} الذي تلمسه
 * {@code almlk.CodeStyle} فقط.
 *
 * <p><b>حدّ التغطية المُعلَن:</b> تُشغَّل أصناف المنطق الصرفة، بما فيها الملوّن التزايدي وفهرس
 * قيم ألوان XML، مع سجل القوائم وأدوات اللغة. أصناف الرسم السبعة ({@code CodeCanvasView} ورفاقها)
 * يغطيها **البناء** و**فحص الحزمة** في {@code qa/acceptance.sh} لا هذه المجموعة — فهي تحتاج جهازًا.
 */
public class RegressionSuite {

  static int pass = 0;
  static int fail = 0;
  static final List<String> failures = new ArrayList<>();
  static String section = "";

  static final String SRC = "/home/user/ShimaProject/app/src/main/java";

  /** Local API-shaped class for exercising platform-source rendering without Android runtime. */
  public static final class ApiFixture {
    public static final int VISIBLE = 0;
    public ApiFixture() {}
    public int getId() { return 1; }
    public void setVisibility(int visibility) {}
  }

  // ───────────────────────────────── أدوات ─────────────────────────────────

  static void section(String title) {
    section = title;
    System.out.println("\n[" + title + "]");
  }

  static void check(String name, boolean ok, String detail) {
    if (ok) {
      pass++;
      System.out.println("  ✔ " + name);
    } else {
      fail++;
      failures.add(section + " › " + name + " — " + (detail == null ? "" : detail));
      System.out.println("  ✘ " + name + " — " + detail);
    }
  }

  static android.content.Context freshPrefs() {
    android.preference.PreferenceManager.reset();
    return new android.content.Context();
  }

  static void putPref(String key, String value) {
    android.preference.PreferenceManager.store.put(key, value);
  }

  /** تجريد المسافات البادئة — لمقارنة «المحتوى نفسه بلا إزاحة». */
  static String stripIndent(String text) {
    StringBuilder out = new StringBuilder();
    for (String line : text.replace("\r", "").split("\n", -1)) {
      int i = 0;
      while (i < line.length() && line.charAt(i) == ' ') i++;
      out.append(line.substring(i)).append('\n');
    }
    return out.toString();
  }

  static int leadingOf(String text, int lineIndex) {
    String[] lines = text.split("\n", -1);
    if (lineIndex >= lines.length) return -1;
    String line = lines[lineIndex];
    int i = 0;
    while (i < line.length() && line.charAt(i) == ' ') i++;
    return i;
  }

  static int count(String text, char c) {
    int n = 0;
    for (int i = 0; i < text.length(); i++) if (text.charAt(i) == c) n++;
    return n;
  }

  static int count(String text, String fragment) {
    if (text == null || fragment == null || fragment.isEmpty()) return 0;
    int total = 0;
    int offset = 0;
    while ((offset = text.indexOf(fragment, offset)) >= 0) {
      total++;
      offset += fragment.length();
    }
    return total;
  }

  /** البصمة غير البيضاء: كل المحارف عدا المسافة/الجدولة/السطر الجديد، بالترتيب. */
  static String nonWhitespaceSignature(String text) {
    StringBuilder out = new StringBuilder();
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c != ' ' && c != '\t' && c != '\n' && c != '\r') out.append(c);
    }
    return out.toString();
  }

  static String read(String relativePath) throws Exception {
    return new String(
        Files.readAllBytes(Paths.get("/home/user/ShimaProject", relativePath)),
        StandardCharsets.UTF_8);
  }

  static Map<String, String> stringResources(String relativePath) throws Exception {
    Map<String, String> result = new HashMap<>();
    Matcher matcher =
        Pattern.compile("<string\\s+name=\"([^\"]+)\"[^>]*>(.*?)</string>", Pattern.DOTALL)
            .matcher(read(relativePath));
    while (matcher.find()) {
      String value = matcher.group(2)
          .replace("&amp;", "&")
          .replace("&lt;", "<")
          .replace("&gt;", ">")
          .replace("&quot;", "\"")
          .replace("&apos;", "'");
      result.put(matcher.group(1), value);
    }
    return result;
  }

  static boolean containsInTree(String needle, String dir) throws Exception {
    File[] children = new File(dir).listFiles();
    if (children == null) return false;
    for (File child : children) {
      if (child.isDirectory()) {
        if (containsInTree(needle, child.getAbsolutePath())) return true;
      } else if (child.getName().endsWith(".java") || child.getName().endsWith(".xml")) {
        if (new String(Files.readAllBytes(child.toPath()), StandardCharsets.UTF_8).contains(needle)) {
          return true;
        }
      }
    }
    return false;
  }

  static EditorMenuRegistry.Entry entry(
      EditorMenuRegistry registry, String page, EditorMenuRegistry.Context context, String id) {
    for (EditorMenuRegistry.Entry e : registry.entries(page, context)) if (e.id.equals(id)) return e;
    return null;
  }

  static boolean callsBeforeModeFinish(String switchBody, String caseId, String call) {
    int start = switchBody.indexOf("case \"" + caseId + "\":");
    if (start < 0) return false;
    int end = switchBody.indexOf("\n              case ", start + 1);
    if (end < 0) end = switchBody.length();
    int callAt = switchBody.indexOf(call, start);
    int finishAt = switchBody.indexOf("mode.finish();", start);
    return callAt >= start && callAt < end && finishAt >= start && finishAt < end
        && callAt < finishAt;
  }

  // ─────────────────────────────── المدخل ───────────────────────────────

  public static void main(String[] args) throws Exception {
    structuralSoundness();
    xmlCompletion();
    coreAlmlk();
    phase6XmlEngine();
    phase7XmlSemantics();
    xmlColorStyling();
    phase8CodeStyle();
    menuRegistry();
    noDeadPaths();
    symbolNavigationSemantics();
    projectDiagnosticsAndBuildOutput();
    localeAndSettingsResources();

    System.out.println("\n══════════════════════════════════════════════════════");
    System.out.println("RegressionSuite: passed=" + pass + " failed=" + fail);
    if (fail > 0) {
      System.out.println("الإخفاقات:");
      for (String f : failures) System.out.println("  - " + f);
    }
    System.out.println("══════════════════════════════════════════════════════");
    if (fail > 0) System.exit(1);
  }

  // ═══════════════ Go To: المرجع يقفز إلى التعريف، والتعريف يعرض الاستخدامات ═══════════════
  static void symbolNavigationSemantics() throws Exception {
    section("Go To: التفريق بين موضع الاستخدام وموضع التعريف");
    ProjectSymbolIndex.clear();
    String owner =
        "class Owner {\n"
            + "  public void getStr() {}\n"
            + "  public static float mSoundVolume;\n"
            + "  void callLocal() { getStr(); }\n"
            + "}\n";
    String caller =
        "class Player {\n"
            + "  void play(Owner audio) {\n"
            + "    audio.getStr();\n"
            + "    float gain = audio.mSoundVolume;\n"
            + "  }\n"
            + "}\n";
    ProjectSymbolIndex.registerSource("Owner.java", "Owner.java", owner);
    ProjectSymbolIndex.registerSource("Player.java", "Player.java", caller);

    int methodDeclaration = owner.indexOf("getStr()");
    int localCall = owner.indexOf("getStr()", methodDeclaration + 1);
    int crossClassCall = caller.indexOf("getStr()");
    int fieldDeclaration = owner.indexOf("mSoundVolume;");
    int fieldUse = caller.indexOf("mSoundVolume");
    ProjectSymbolIndex.DefinitionTarget methodAtDefinition =
        ProjectSymbolIndex.resolveDefinition("Owner.java", owner,
            methodDeclaration, methodDeclaration + "getStr".length());
    ProjectSymbolIndex.DefinitionTarget methodAtLocalCall =
        ProjectSymbolIndex.resolveDefinition("Owner.java", owner,
            localCall, localCall + "getStr".length());
    ProjectSymbolIndex.DefinitionTarget methodAtCrossClassCall =
        ProjectSymbolIndex.resolveDefinition("Player.java", caller,
            crossClassCall, crossClassCall + "getStr".length());
    check("GoTo: تحديد تعريف الدالة يُميَّز عن استدعائها في الكلاس نفسه",
        methodAtDefinition != null && methodAtDefinition.offset == methodDeclaration
            && ProjectSymbolIndex.isDefinitionSelection("Owner.java", owner,
                methodDeclaration, methodDeclaration + "getStr".length(), methodAtDefinition)
            && methodAtLocalCall != null && methodAtLocalCall.offset == methodDeclaration
            && !ProjectSymbolIndex.isDefinitionSelection("Owner.java", owner,
                localCall, localCall + "getStr".length(), methodAtLocalCall),
        "لم يُفرَّق بين التعريف والاستدعاء داخل الملف");
    check("GoTo: استدعاء الدالة من كلاس آخر يبقى قفزة إلى تعريفها",
        methodAtCrossClassCall != null
            && "Owner.java".equals(methodAtCrossClassCall.fileName)
            && methodAtCrossClassCall.offset == methodDeclaration
            && !ProjectSymbolIndex.isDefinitionSelection("Player.java", caller,
                crossClassCall, crossClassCall + "getStr".length(), methodAtCrossClassCall),
        "لم تُحلّ الدالة العابرة للكلاسات أو صُنّف المرجع تعريفًا");

    ProjectSymbolIndex.DefinitionTarget fieldAtDefinition =
        ProjectSymbolIndex.resolveDefinition("Owner.java", owner,
            fieldDeclaration, fieldDeclaration + "mSoundVolume".length());
    ProjectSymbolIndex.DefinitionTarget fieldAtUse =
        ProjectSymbolIndex.resolveDefinition("Player.java", caller,
            fieldUse, fieldUse + "mSoundVolume".length());
    check("GoTo: تعريف الحقل يعرض استعمالاته، ومرجعه يقفز للتعريف",
        fieldAtDefinition != null && fieldAtDefinition.offset == fieldDeclaration
            && ProjectSymbolIndex.isDefinitionSelection("Owner.java", owner,
                fieldDeclaration, fieldDeclaration + "mSoundVolume".length(), fieldAtDefinition)
            && fieldAtUse != null && fieldAtUse.offset == fieldDeclaration
            && !ProjectSymbolIndex.isDefinitionSelection("Player.java", caller,
                fieldUse, fieldUse + "mSoundVolume".length(), fieldAtUse),
        "لم يُفرَّق بين تعريف الحقل والمرجع إليه");

    String locals = "class Scratch { void work() { int localCount = 0; localCount++; } }";
    ProjectSymbolIndex.registerSource("Scratch.java", "Scratch.java", locals);
    int localDeclaration = locals.indexOf("localCount");
    ProjectSymbolIndex.DefinitionTarget localTarget =
        ProjectSymbolIndex.resolveDefinition("Scratch.java", locals,
            localDeclaration, localDeclaration + "localCount".length());
    check("GoTo: تعريف متغير محلي لا يُعامل كتعريف حقل",
        localTarget != null
            && localTarget.kind == ProjectSymbolIndex.DefinitionTarget.KIND_OTHER
            && !ProjectSymbolIndex.isDefinitionSelection("Scratch.java", locals,
                localDeclaration, localDeclaration + "localCount".length(), localTarget),
        "تغير سلوك متغير محلي خارج نطاق الطلب");

    ProjectSymbolIndex.DefinitionTarget fixtureMethod =
        SystemApiSourceProvider.resolveMember(ApiFixture.class, "setVisibility");
    boolean fixtureMethodColored = false;
    if (fixtureMethod != null && fixtureMethod.source != null) {
      for (CodeLanguageTools.Range range :
          CodeLanguageTools.highlight(fixtureMethod.fileName, fixtureMethod.source))
        if (range.start == fixtureMethod.offset
            && range.end == fixtureMethod.offset + fixtureMethod.symbol.length()
            && range.type == CodeLanguageTools.FUNCTION) fixtureMethodColored = true;
    }
    ProjectSymbolIndex.DefinitionTarget fixtureField =
        SystemApiSourceProvider.resolveMember(ApiFixture.class, "VISIBLE");
    check("كلاسات النظام: توليد مصدر Java ملوّن وإزاحة دقيقة للدالة والحقل",
        fixtureMethod != null && fixtureMethod.system
            && fixtureMethod.fileName.endsWith(".class")
            && fixtureMethod.source.contains("class ApiFixture")
            && fixtureMethod.source.substring(fixtureMethod.offset,
                fixtureMethod.offset + fixtureMethod.symbol.length()).equals("setVisibility")
            && fixtureMethodColored
            && fixtureField != null && fixtureField.kind == ProjectSymbolIndex.DefinitionTarget.KIND_FIELD
            && fixtureField.source.substring(fixtureField.offset,
                fixtureField.offset + fixtureField.symbol.length()).equals("VISIBLE"),
        "مصدر الكلاس الافتراضي أو الموضع/التلوين غير دقيق");

    String systemCaller =
        "class SystemCaller { void paint(View view) { view.setVisibility(0); } }";
    ProjectSymbolIndex.registerSource("SystemCaller.java", "SystemCaller.java", systemCaller);
    int systemUse = systemCaller.indexOf("setVisibility");
    ProjectSymbolIndex.DefinitionTarget systemMethod =
        ProjectSymbolIndex.resolveDefinition("SystemCaller.java", systemCaller,
            systemUse, systemUse + "setVisibility".length());
    check("كلاسات النظام: Go To للدالة يفتح مصدر View ويعطي إزاحة اسمها",
        systemMethod != null && systemMethod.system && "View".equals(systemMethod.className)
            && systemMethod.source != null
            && systemMethod.source.substring(systemMethod.offset,
                systemMethod.offset + systemMethod.symbol.length()).equals("setVisibility"),
        "لم تُحلّ دالة View إلى إعلانها الافتراضي");

    String pager = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    String activity = read("app/src/main/java/com/shima/demo/MainActivity.java");
    int goStart = pager.indexOf("public int goToSymbol(");
    int goEnd = pager.indexOf("private static int resolveLiveSymbolOffset", goStart);
    String goBody = goStart >= 0 && goEnd > goStart ? pager.substring(goStart, goEnd) : "";
    check("GoTo: يبقى اسم الهدف محددًا بعد مهام استعادة التبويب",
        goBody.contains("code.post(") && goBody.contains("request != goToGeneration")
            && goBody.contains("code.setSelection(liveTarget, liveTarget + symbol.length())")
            && goBody.contains("code.bringPointIntoView(liveTarget)"),
        "استعادة موضع التبويب قد تطوي التحديد أو تترك الهدف خارج العرض");
    String lineStyler = read("app/src/main/java/almlk/LineStyler.java");
    check("كلاسات النظام: امتداد class يستخدم أيقونة جافا ومحلل ألوان جافا",
        lineStyler.contains("lower.endsWith(\".class\")")
            && lineStyler.contains("mode = MODE_JAVA;")
            && pager.contains("n.endsWith(\".class\")")
            && pager.contains("ProjectSymbolIndex.systemSourceForFile(name)"),
        "ملف الكلاس الافتراضي لا يُفتح أو يُلوّن مثل مصدر Java");
    check("GoTo: اختيار التعريف يوجّه إلى لوحة الاستخدامات، والمرجع يظل قفزة تعريف",
        count(pager, "ProjectSymbolIndex.isDefinitionSelection(") >= 2
            && pager.contains("usageListener.requested(")
            && activity.contains("ProjectSymbolIndex.isDefinitionSelection(")
            && activity.contains("findUsagesForSelection(fileName, source, selectionStart, selectionEnd)")
            && activity.contains("openDefinition(target)"),
        "فرع العرض لم يُربط بمسار Go To");
  }

  // ═══════════════ تبديل اللغة وترجمة الإعدادات الأساسية ═══════════════
  static void localeAndSettingsResources() throws Exception {
    section("لغة التطبيق وترجمة الإعدادات الأساسية");
    String application = read("app/src/main/java/com/shima/demo/ShimaApplication.java");
    String localizedActivity = read("app/src/main/java/com/shima/demo/LocaleAwareActivity.java");
    String localizedPreferences = read("app/src/main/java/com/shima/demo/LocaleAwarePreferenceActivity.java");
    String fragment = read("app/src/main/java/com/almlkid/ui/preferences/ApplicationPreferencesFragment.java");
    String preferencesHost = read("app/src/main/java/com/almlkid/ui/preferences/AlmlkPreferencesActivity.java");

    check("اللغة: إنشاء سياق موارد جديد من التفضيل المحفوظ",
        application.contains("PreferenceManager.getDefaultSharedPreferences(base)")
            && application.contains("base.createConfigurationContext(localized)")
            && localizedActivity.contains("ShimaApplication.localize(base)")
            && localizedPreferences.contains("ShimaApplication.localize(base)"),
        "سياق النشاط لا يُعاد بناؤه بالاختيار المحفوظ");
    check("اللغة: كل الخيارات معروفة وDefault يتبع لغة الجهاز",
        application.contains("case \"en\":") && application.contains("case \"de\":")
            && application.contains("case \"ru\":") && application.contains("case \"zh\":")
            && application.contains("case \"ar\":") && application.contains("case \"default\":")
            && application.contains("Resources.getSystem().getConfiguration()")
            && application.contains("return systemLocale();"),
        "تعيين locale غير مكتمل أو يعود إلى العربية ضمنيًا");
    String[] localeActivities = {
      "StartupActivity.java", "MainActivity.java", "AboutActivity.java", "DesignerActivity.java",
      "ThemeActivity.java", "RecoveryActivity.java", "CodeStyleActivity.java"
    };
    boolean allActivitiesLocalized = true;
    for (String activity : localeActivities)
      allActivitiesLocalized &=
          read("app/src/main/java/com/shima/demo/" + activity).contains("extends LocaleAwareActivity");
    check("اللغة: الأنشطة وشاشة التفضيلات تستخدم سياقًا محليًا", allActivitiesLocalized
        && preferencesHost.contains("extends LocaleAwarePreferenceActivity")
        && preferencesHost.contains("bar.setTitle(R.string.app_name)"), "نشاط بلا غلاف اللغة أو عنوان محلي");
    check("اللغة: إعادة إنشاء شاشة التفضيلات بعد حفظ الاختيار، بلا تحديث موارد عام",
        fragment.contains("anchor.post(") && fragment.contains("host.recreate()")
            && !fragment.contains("applyLanguage(")
            && !application.contains("updateConfiguration("),
        "التطبيق ما زال يعدّل موارد Application بدل سياق Activity");
    check("اللغة: اتجاه LTR ثابت في سياق الموارد",
        application.contains("localized.setLayoutDirection(Locale.ENGLISH)")
            && read("app/src/main/AndroidManifest.xml").contains("android:supportsRtl=\"false\""),
        "اتجاه التخطيط قد يتبع العربية");
    String uiStrings = read("app/src/main/java/com/shima/demo/UiStrings.java");
    check("اللغة: النصوص المؤجلة عبر Application تستخدم الاختيار الحالي",
        uiStrings.contains("context instanceof ShimaApplication")
            && uiStrings.contains("ShimaApplication.localize(context)"),
        "سياق Application يحتفظ بلغة قديمة في الرسائل المؤجلة");

    Map<String, String> english = stringResources("app/src/main/res/values/strings.xml");
    Map<String, String> arabic = stringResources("app/src/main/res/values-ar/strings.xml");
    int sourcePreferenceCount = 0;
    int missing = 0;
    int degraded = 0;
    String[] badFragments = {"رئيسي عنوان", "وصف رئيسي وصف", "وصف وصف", "قسم قسم", "عنوان "};
    for (Map.Entry<String, String> entry : english.entrySet()) {
      String key = entry.getKey();
      if (!key.startsWith("preference_") && !key.startsWith("proguard_")) continue;
      sourcePreferenceCount++;
      String translation = arabic.get(key);
      if (translation == null) {
        missing++;
      } else {
        for (String bad : badFragments) if (translation.contains(bad)) degraded++;
      }
    }
    String versus = arabic.get("preference_summary_versus");
    boolean placeholdersKept = versus != null && versus.contains("%1$s") && versus.contains("%2$s");
    check("الإعدادات الأساسية: ترجمة كل مفاتيح المصدر الإنجليزي دون عبارات placeholder",
        sourcePreferenceCount == 163 && missing == 0 && degraded == 0 && placeholdersKept,
        "عدد المصدر=" + sourcePreferenceCount + ", مفقود=" + missing + ", رديء=" + degraded);
    String advancedXml = read("app/src/main/res/xml/preferences_advanced_setting.xml");
    check("الإعدادات المتقدمة: مواردها مستقلة ولم تُستبدل بنصوص الإعدادات الأساسية",
        advancedXml.contains("@string/ui_pref_application_title")
            && advancedXml.contains("@string/ui_pref_editor_summary")
            && !advancedXml.contains("@string/preference_"),
        "تداخلت مفاتيح الإعدادات الأساسية مع المتقدمة");
  }

  // ═══════════════ §A السلامة البنيوية لمخرَج المنسّقات ═══════════════
  // العقد المتبنّى من دراسة المرجع (تقرير بند 2 §3): المنسّق لا يُفترَض سليمًا بل
  // **يُتحقَّق** من مخرَجه — google-java-format يرفض المصدر الذي لا يُحلَّل بدل إنتاج
  // مخرَج مكسور صمتًا. لا نسخنا المنسّق؛ تبنّينا العقد.

  static void structuralSoundness() {
    section("أ — السلامة البنيوية لمخرَج المنسّقات (عقد المرجع)");

    String java =
        "class A {\n"
            + "  void f() {\n"
            + "    if (x) { g(1, 2); }\n"
            + "    for (int i = 0; i < n; i++) { }\n"
            + "  }\n"
            + "}\n";
    String xml =
        "<resources>\n"
            + "  <string name=\"a\">1</string>\n"
            + "  <item>\n"
            + "    <sub/>\n"
            + "  </item>\n"
            + "</resources>\n";

    for (int indent : new int[] {0, 2, 4, 8, 16}) {
      String out = CodeLanguageTools.format(java, indent);
      check(
          "جافا: البصمة غير البيضاء محفوظة عند إزاحة " + indent,
          nonWhitespaceSignature(out).equals(nonWhitespaceSignature(java)),
          "اختلفت البصمة");
      check(
          "جافا: توازن { } محفوظ عند إزاحة " + indent,
          count(out, '{') == count(java, '{') && count(out, '}') == count(java, '}'),
          count(out, '{') + "/" + count(out, '}'));
      check(
          "جافا: توازن ( ) محفوظ عند إزاحة " + indent,
          count(out, '(') == count(java, '(') && count(out, ')') == count(java, ')'),
          count(out, '(') + "/" + count(out, ')'));
      check(
          "جافا: التنسيق ثابت (idempotent) عند إزاحة " + indent,
          CodeLanguageTools.format(out, indent).equals(out),
          "تغيّر الناتج عند إعادة التنسيق");
    }

    for (int indent : new int[] {0, 2, 4, 8, 16}) {
      String out = XmlCodeFormatter.format(xml, indent);
      check(
          "XML: البصمة غير البيضاء محفوظة عند إزاحة " + indent,
          nonWhitespaceSignature(out).equals(nonWhitespaceSignature(xml)),
          "اختلفت البصمة");
      check(
          "XML: عدد الوسوم محفوظ عند إزاحة " + indent,
          count(out, '<') == count(xml, '<') && count(out, '>') == count(xml, '>'),
          count(out, '<') + "/" + count(out, '>'));
      check(
          "XML: العمق يعود إلى الصفر بعد التنسيق عند إزاحة " + indent,
          XmlStructureScanner.scan(out).depthBefore[
                  XmlStructureScanner.scan(out).lineCount - 1]
                  + XmlStructureScanner.scan(out)
                          .depthDelta[XmlStructureScanner.scan(out).lineCount - 1]
              == 0,
          "عمق نهائي ≠ 0");
      check(
          "XML: التنسيق ثابت (idempotent) عند إزاحة " + indent,
          XmlCodeFormatter.format(out, indent).equals(out),
          "تغيّر الناتج عند إعادة التنسيق");
    }

    // مدخل مكسور: لا يُسمح للمنسّق أن يزيد الكسر أو يفقد محتوى.
    String brokenJava = "class A {\n  void f() {\n    if (x) { g(1;\n";
    String brokenOut = CodeLanguageTools.format(brokenJava, 4);
    check(
        "جافا: مدخل مكسور لا يفقد محتوى",
        nonWhitespaceSignature(brokenOut).equals(nonWhitespaceSignature(brokenJava)),
        "فُقد محتوى من مدخل مكسور");
    String brokenXml = "<resources>\n  <string name=\"a\">1\n</resources>\n";
    String brokenXmlOut = XmlCodeFormatter.format(brokenXml, 4);
    check(
        "XML: مدخل مكسور لا يفقد محتوى",
        nonWhitespaceSignature(brokenXmlOut).equals(nonWhitespaceSignature(brokenXml)),
        "فُقد محتوى من مدخل مكسور");
    check(
        "XML: وسوم الاقتباس محفوظة في مدخل مكسور",
        count(brokenXmlOut, '"') == count(brokenXml, '"'),
        count(brokenXmlOut, '"') + " مقابل " + count(brokenXml, '"'));

    // نص فارغ وفارغ-أبيض: لا استثناء ولا فقدان.
    check("جافا: نص فارغ آمن", CodeLanguageTools.format("", 4) != null, null);
    check("XML: نص فارغ آمن", XmlCodeFormatter.format("", 4) != null, null);
    check(
        "جافا: نص أبيض فقط يبقى أبيض",
        CodeLanguageTools.format("   \n  \n", 4).trim().isEmpty(),
        "[" + CodeLanguageTools.format("   \n  \n", 4) + "]");
  }

  // ═══════════════ §A2 المرحلتان 3+4: إكمال XML السياقي ═══════════════

  static void xmlCompletion() {
    section("أ2 — إكمال XML السياقي (المراحل 3+4)");

    // قيمة سمة العرض: قوائم مقيدة + أبعاد تقبل الأرقام
    String w = "<Button android:layout_width=\"";
    java.util.List<String> vals = almlk.XmlCompletionEngine.complete(w, w.length());
    check("XML: قيم layout_width تحوي wrap_content", vals.contains("wrap_content"), vals.toString());
    check("XML: قيم layout_width تحوي match_parent", vals.contains("match_parent"), vals.toString());

    // إدخال رقم داخل قيمة العرض لا يُعترض: تُشتق أبعاد تبدأ بالرقم
    String d = "<Button android:layout_width=\"5";
    java.util.List<String> dims = almlk.XmlCompletionEngine.complete(d, d.length());
    check("XML: بادئة رقمية تُنتج 5.0dip", dims.contains("5.0dip"), dims.toString());
    check("XML: بادئة رقمية تُنتج 5dp", dims.contains("5dp"), dims.toString());
    check("XML: بادئة رقمية لا تُسقِط الاقتراحات", !dims.isEmpty(), "فارغة");

    // بداية الرمز داخل القيمة = بعد الاقتباس مباشرة (فيُحفظ الرقم المكتوب)
    check("XML: completionStart داخل القيمة بعد الاقتباس",
        almlk.XmlCompletionEngine.completionStart(d, d.length()) == d.length() - 1,
        "" + almlk.XmlCompletionEngine.completionStart(d, d.length()));

    // اسم سمة بعد وسم
    String a = "<Button ";
    java.util.List<String> attrs = almlk.XmlCompletionEngine.complete(a, a.length());
    check("XML: اقتراح أسماء سمات يحوي android:layout_width",
        attrs.contains("android:layout_width"), attrs.toString());
    check("XML: اقتراح أسماء سمات يحوي android:id", attrs.contains("android:id"), attrs.toString());

    // اسم وسم بعد '<'
    String t = "<But";
    java.util.List<String> tags = almlk.XmlCompletionEngine.complete(t, t.length());
    check("XML: اقتراح وسوم يرشّح Button بالبادئة", tags.contains("Button"), tags.toString());
    check("XML: اقتراح وسوم لا يحوي LinearLayout لبـBut", !tags.contains("LinearLayout"),
        tags.toString());

    // قيمة منطقية
    String b = "<Button android:clickable=\"";
    java.util.List<String> bools = almlk.XmlCompletionEngine.complete(b, b.length());
    check("XML: قيمة منطقية true/false", bools.contains("true") && bools.contains("false"),
        bools.toString());

    // قيمة نص → موارد
    String tx = "<TextView android:text=\"";
    java.util.List<String> texts = almlk.XmlCompletionEngine.complete(tx, tx.length());
    check("XML: قيمة text تقترح @string/", texts.contains("@string/"), texts.toString());

    // خارج أي وسم: لا اقتراح (لا اقتحام على نص عادي)
    String none = "hello world ";
    check("XML: خارج الوسوم لا اقتراح", almlk.XmlCompletionEngine.complete(none, none.length()).isEmpty(),
        "أقحم اقتراحًا");
    check("XML: complete(null-safe) على نص فارغ آمن",
        almlk.XmlCompletionEngine.complete("", 0).isEmpty(), "رمى");
    check("XML: completionStart على نص فارغ آمن",
        almlk.XmlCompletionEngine.completionStart("", 0) == 0, "رمى");
  }

  // ═══════════════════ §B أصناف almlk الأساسية ═══════════════════

  static void coreAlmlk() {
    section("ب — أصناف almlk الأساسية (محرك المحرر)");

    // LineBuffer
    LineBuffer buffer = new LineBuffer();
    buffer.append('a');
    buffer.append('b');
    buffer.append('c');
    check("LineBuffer: الطول بعد الإلحاق", buffer.length() == 3, "" + buffer.length());
    check("LineBuffer: المحتوى", buffer.toString().equals("abc"), buffer.toString());
    buffer.insert(1, 'X');
    check("LineBuffer: الإدراج في المنتصف", buffer.toString().equals("aXbc"), buffer.toString());
    buffer.delete(1, 1);
    check("LineBuffer: الحذف", buffer.toString().equals("abc"), buffer.toString());
    buffer.replace("hello".toCharArray());
    check("LineBuffer: الاستبدال الكامل", buffer.toString().equals("hello"), buffer.toString());
    char[] dest = new char[3];
    buffer.getChars(1, 3, dest, 0);
    check("LineBuffer: getChars", new String(dest).equals("ell"), new String(dest));
    check("LineBuffer: charAt", buffer.charAt(0) == 'h', "" + buffer.charAt(0));
    buffer.insert(5, "!!".toCharArray(), 0, 2);
    check("LineBuffer: إدراج مصفوفة", buffer.toString().equals("hello!!"), buffer.toString());

    // LineDocument
    LineDocument document = new LineDocument();
    check("LineDocument: سطر واحد ابتداءً", document.lineCount() == 1, "" + document.lineCount());
    document.insertLine(1, "second".toCharArray());
    check("LineDocument: الإدراج يضيف سطرًا", document.lineCount() == 2, "" + document.lineCount());
    document.insertLine(2, "third".toCharArray());
    check("LineDocument: ثلاثة أسطر", document.lineCount() == 3, "" + document.lineCount());
    check(
        "LineDocument: lineStartOffset للسطر الثاني",
        document.lineStartOffset(1) == 1,
        "" + document.lineStartOffset(1));
    check(
        "LineDocument: lineLength",
        document.lineLength(1) == 6,
        "" + document.lineLength(1));
    document.insertChar(1, 0, 'S');
    check("LineDocument: insertChar", document.line(1).toString().equals("Ssecond"),
        document.line(1).toString());
    document.delete(1, 0, 1);
    check("LineDocument: delete", document.line(1).toString().equals("second"),
        document.line(1).toString());
    long before = document.version();
    document.setLine(1, "changed".toCharArray());
    check("LineDocument: version تتقدم عند التغيير", document.version() > before,
        before + " → " + document.version());
    document.removeLine(2);
    check("LineDocument: removeLine", document.lineCount() == 2, "" + document.lineCount());
    check("LineDocument: lineChars", new String(document.lineChars(1)).equals("changed"),
        new String(document.lineChars(1)));

    // IdentifierBounds
    String id = "int fooBar = x;";
    int at = id.indexOf('o');
    check("IdentifierBounds: inside على حرف من المعرّف", IdentifierBounds.inside(id, at), "ليست داخلًا");
    check("IdentifierBounds: start", IdentifierBounds.start(id, at) == 4,
        "" + IdentifierBounds.start(id, at));
    // end نهاية حصرية كمديات جافا: fooBar = [4, 10)
    check("IdentifierBounds: end نهاية حصرية", IdentifierBounds.end(id, at) == 10,
        "" + IdentifierBounds.end(id, at));
    // inside تُعرَّف لموضع المؤشر: الموضع المجاور لمعرّف يُعَدّ داخله. موضع خارجي حقًا هو '='.
    check("IdentifierBounds: موضع خارج أي معرّف", !IdentifierBounds.inside(id, 11), "عُدَّت داخلًا");
    check("IdentifierBounds: موضع مجاور لمعرّف يُعَدّ داخله (دلالة المؤشر)",
        IdentifierBounds.inside(id, 10), "لم تُعَدّ");
    check("IdentifierBounds: isPart على رقم", IdentifierBounds.isPart('7'), "ليست جزءًا");
    check("IdentifierBounds: isPart على مسافة", !IdentifierBounds.isPart(' '), "عُدَّت جزءًا");
    check("IdentifierBounds: isStart على رقم", !IdentifierBounds.isStart('7'), "عُدَّت بداية");
    check("IdentifierBounds: isStart على شرطة سفلية", IdentifierBounds.isStart('_'), "ليست بداية");
    check("IdentifierBounds: offset=0 آمن", IdentifierBounds.start(id, 0) == 0, "رمى أو أخطأ");
    check("IdentifierBounds: offset=الطول آمن",
        IdentifierBounds.end(id, id.length()) <= id.length(), "تجاوز الطول");

    // ضغط مطوّل: أي حرف في الاسم يختار المعرّف كاملًا، لا جزءًا يتوقف عند موضع اللمسة.
    String touchLine = "Collections.emptyList()";
    int touchStart = touchLine.indexOf("emptyList");
    int touchEnd = touchStart + "emptyList".length();
    boolean everyCharacterSelectsWholeIdentifier = true;
    for (int column = touchStart; column < touchEnd; column++) {
      int[] touched = IdentifierBounds.rangeAt(touchLine, column);
      if (touched == null || touched[0] != touchStart || touched[1] != touchEnd) {
        everyCharacterSelectsWholeIdentifier = false;
        break;
      }
    }
    check("IdentifierBounds: اللمس على كل حرف يختار emptyList كاملًا",
        everyCharacterSelectsWholeIdentifier, "حدود جزئية أو null");
    String voiceInstalled = "VOICE_INSTALLED";
    boolean everyVoiceCharacterSelectsWholeIdentifier = true;
    for (int column = 0; column < voiceInstalled.length(); column++) {
      int[] touched = IdentifierBounds.rangeAt(voiceInstalled, column);
      if (touched == null || touched[0] != 0 || touched[1] != voiceInstalled.length()) {
        everyVoiceCharacterSelectsWholeIdentifier = false;
        break;
      }
    }
    check("انحدار الصورة: أي حرف في VOICE_INSTALLED يحدد الاسم كاملًا عبر الشرطة السفلية",
        everyVoiceCharacterSelectsWholeIdentifier, "حدود جزئية أو null");
    int[] partialIdentifier = IdentifierBounds.wholeIdentifierForSelection(
        touchLine, touchStart + 1, touchStart + 4);
    check("IdentifierBounds: يوسّع اختيارًا جزئيًا إلى المعرّف الكامل",
        partialIdentifier != null && partialIdentifier[0] == touchStart
            && partialIdentifier[1] == touchEnd,
        partialIdentifier == null ? "null" : partialIdentifier[0] + ".." + partialIdentifier[1]);
    int[] reversedIdentifier = IdentifierBounds.wholeIdentifierForSelection(
        touchLine, touchEnd - 2, touchStart + 2);
    check("IdentifierBounds: ترتيب الطرفين العكسي آمن",
        reversedIdentifier != null && reversedIdentifier[0] == touchStart
            && reversedIdentifier[1] == touchEnd,
        reversedIdentifier == null ? "null" : reversedIdentifier[0] + ".." + reversedIdentifier[1]);
    check("IdentifierBounds: لا يضمّ الفاصل إلى المعرّف",
        IdentifierBounds.wholeIdentifierForSelection(touchLine, touchStart - 1, touchStart + 2) == null,
        "قُبل مدى يعبر النقطة");
    check("IdentifierBounds: لا يلتقط اللمس على النقطة كلمة مجاورة",
        IdentifierBounds.rangeAt(touchLine, touchStart - 1) == null, "أُعيد مدى");
    String numericToken = "value = 12345;";
    int numberStart = numericToken.indexOf("12345");
    int[] numericRange = IdentifierBounds.wholeIdentifierForSelection(
        numericToken, numberStart + 1, numberStart + 3);
    check("IdentifierBounds: المدى الجزئي للأرقام يبقى متصلًا وكاملًا",
        numericRange != null && numericRange[0] == numberStart
            && numericRange[1] == numberStart + 5,
        numericRange == null ? "null" : numericRange[0] + ".." + numericRange[1]);
    check("IdentifierBounds: المدى الفارغ أو الخارج مرفوض بأمان",
        IdentifierBounds.wholeIdentifierForSelection(touchLine, touchStart, touchStart) == null
            && IdentifierBounds.rangeAt(touchLine, -1) == null,
        "قُبل مدى غير صالح");

    // StyleRunBatcher
    int[] styles = {1, 1, 2, 2, 2, 1, 0};
    final int[] runs = {0};
    StyleRunBatcher.batch(styles, 0, styles.length, (styleId, start, end) -> runs[0]++);
    check("StyleRunBatcher: عدد runs = 4", runs[0] == 4, "" + runs[0]);
    check("StyleRunBatcher: countRuns يطابق batch",
        StyleRunBatcher.countRuns(styles, 0, styles.length) == 4,
        "" + StyleRunBatcher.countRuns(styles, 0, styles.length));
    check("StyleRunBatcher: نافذة جزئية", StyleRunBatcher.countRuns(styles, 2, 5) == 1,
        "" + StyleRunBatcher.countRuns(styles, 2, 5));
    check("StyleRunBatcher: مصفوفة null آمنة", StyleRunBatcher.countRuns(null, 0, 5) == 0, "رمى");
    StyleRunBatcher.batch(null, 0, 5, (styleId, start, end) -> runs[0]++);
    check("StyleRunBatcher: batch(null) آمن", true, null);
    // النافذة [0,3) = {1,1,2} ← runان
    check("StyleRunBatcher: نافذة من أول المصفوفة", StyleRunBatcher.countRuns(styles, 0, 3) == 2,
        "" + StyleRunBatcher.countRuns(styles, 0, 3));
    final int[] untouched = {0};
    StyleRunBatcher.batch(styles, 0, 3, null);
    check("StyleRunBatcher: consumer=null آمن", untouched[0] == 0, "رمى");

    // UndoRedoStack
    UndoRedoStack stack = new UndoRedoStack();
    check("UndoRedoStack: فارغ ابتداءً — لا تراجع", !stack.canUndo(), "كان قابلًا للتراجع");
    check("UndoRedoStack: فارغ ابتداءً — لا إعادة", !stack.canRedo(), "كان قابلًا للإعادة");
    stack.record(0, "", "abc");
    check("UndoRedoStack: بعد التسجيل قابل للتراجع", stack.canUndo(), "لم يكن");
    check("UndoRedoStack: قبل التراجع لا إعادة", !stack.canRedo(), "كانت متاحة");
    UndoRedoStack.Applied undone = stack.popUndo();
    check("UndoRedoStack: popUndo يعيد العملية", undone != null && undone.inserted.equals("abc"),
        undone == null ? "null" : undone.inserted);
    check("UndoRedoStack: بعد التراجع صارت الإعادة متاحة", stack.canRedo(), "لم تكن");
    check("UndoRedoStack: بعد التراجع لا تراجع", !stack.canUndo(), "بقي متاحًا");
    UndoRedoStack.Applied redone = stack.popRedo();
    check("UndoRedoStack: popRedo يعيد العملية", redone != null && redone.inserted.equals("abc"),
        redone == null ? "null" : redone.inserted);
    check("UndoRedoStack: بعد الإعادة لا إعادة", !stack.canRedo(), "بقيت متاحة");
    check("UndoRedoStack: بعد الإعادة تراجع متاح", stack.canUndo(), "لم يكن");
    stack.record(5, "x", "y");
    stack.clear();
    check("UndoRedoStack: clear يمسح التراجع", !stack.canUndo(), "بقي متاحًا");
    check("UndoRedoStack: clear يمسح الإعادة", !stack.canRedo(), "بقيت متاحة");
    check("UndoRedoStack: popUndo على فارغ لا يُرمي", stack.popUndo() == null, "رمى أو أعاد");
    check("UndoRedoStack: popRedo على فارغ لا يُرمي", stack.popRedo() == null, "رمى أو أعاد");

    // HexColorCodec
    check("HexColorCodec: RRGGBB صالح", HexColorCodec.isValid("C9A227", true), "رُفض");
    check("HexColorCodec: #RRGGBB صالح", HexColorCodec.isValid("#C9A227", true), "رُفض");
    check("HexColorCodec: AARRGGBB صالح مع ألفا", HexColorCodec.isValid("33C9A227", true), "رُفض");
    check("HexColorCodec: AARRGGBB مرفوض بلا ألفا", !HexColorCodec.isValid("33C9A227", false),
        "قُبل");
    check("HexColorCodec: RRGGBB يُصبح معتمًا",
        HexColorCodec.parse("C9A227", true) == 0xFFC9A227,
        Integer.toHexString(HexColorCodec.parse("C9A227", true)));
    check("HexColorCodec: AARRGGBB يُقرأ حرفيًا",
        HexColorCodec.parse("33C9A227", true) == 0x33C9A227,
        Integer.toHexString(HexColorCodec.parse("33C9A227", true)));
    check("HexColorCodec: الأحرف الصغيرة مقبولة",
        HexColorCodec.parse("c9a227", true) == 0xFFC9A227, "اختلفت");
    check("HexColorCodec: الصيغة القصيرة مرفوضة", !HexColorCodec.isValid("C9A", true), "قُبلت");
    check("HexColorCodec: خانة غير hex تُرفض", !HexColorCodec.isValid("C9A22G", true), "قُبلت");
    check("HexColorCodec: null يُرفض", !HexColorCodec.isValid(null, true), "قُبل");
    check("HexColorCodec: فارغ يُرفض", !HexColorCodec.isValid("", true), "قُبل");
    boolean threw = false;
    try {
      HexColorCodec.parse("XYZ", true);
    } catch (IllegalArgumentException expected) {
      threw = true;
    }
    check("HexColorCodec: parse يرمي IllegalArgumentException لا قيمة خاطئة", threw, "لم يرمِ");

    // XmlColorLiteral
    XmlColorLiteral rgb =
        almlk.ColorLiteralFactory.make(0, 5, 12, 0xFFC9A227, XmlColorLiteral.Format.RGB6);
    check("XmlColorLiteral: containsColumn داخل القيمة", rgb.containsColumn(6), "لم تحتوِ");
    check("XmlColorLiteral: containsColumn خارج القيمة", !rgb.containsColumn(2), "احتوت");
    check("XmlColorLiteral: length", rgb.length() == 7, "" + rgb.length());
    check(
        "XmlColorLiteral: formatReplacement يحفظ صيغة RGB6",
        rgb.formatReplacement(0xFF112233).equals("#112233"),
        rgb.formatReplacement(0xFF112233));
    XmlColorLiteral argb =
        almlk.ColorLiteralFactory.make(0, 5, 14, 0x33C9A227, XmlColorLiteral.Format.ARGB8);
    check(
        "XmlColorLiteral: formatReplacement يحفظ صيغة ARGB8",
        argb.formatReplacement(0x33112233).equals("#33112233"),
        argb.formatReplacement(0x33112233));
    // العقد: RGB6 مع لون معتم ← 6 خانات؛ ومع لون شفّاف ← 8 خانات حتى لا تُفقد الألفا صمتًا.
    check(
        "XmlColorLiteral: RGB6 + لون معتم ← 6 خانات",
        rgb.formatReplacement(0xFF112233).equals("#112233"),
        rgb.formatReplacement(0xFF112233));
    check(
        "XmlColorLiteral: RGB6 + لون شفّاف ← 8 خانات (لا تُفقد الألفا)",
        rgb.formatReplacement(0x33112233).equals("#33112233"),
        rgb.formatReplacement(0x33112233));
    check(
        "XmlColorLiteral: الحروف كبيرة دائمًا",
        argb.formatReplacement(0x33aabbcc).equals("#33AABBCC"),
        argb.formatReplacement(0x33aabbcc));
    XmlColorLiteral[] literals = {rgb};
    check("XmlColorLiteral: atColumn يجد القيمة",
        XmlColorLiteral.atColumn(literals, 7) == rgb, "لم يجد");
    check("XmlColorLiteral: atColumn خارج المدى يعيد null",
        XmlColorLiteral.atColumn(literals, 99) == null, "أعاد قيمة");
    check("XmlColorLiteral: atColumn على null آمن",
        XmlColorLiteral.atColumn(null, 7) == null, "رمى");
    check("XmlColorLiteral: containsRange داخل القيمة", rgb.containsRange(6, 8), "لم تحتوِ");
  }

  // ═══════════════════ §C المرحلة السادسة ═══════════════════

  static void phase6XmlEngine() {
    section("ج — المرحلة 6: ماسح البنية + التعليق + المنسق البنيوي");

    String xml = "<a>\n  <b/>\n  <!-- تعليق -->\n  <![CDATA[x]]>\n</a>\n";
    XmlStructureScanner.Layout layout = XmlStructureScanner.scan(xml);
    // خمسة أسطر نص + سطر سادس فارغ بعد آخر \n
    check("Scanner: عدد الأسطر (مع السطر الفارغ الأخير)", layout.lineCount == 6,
        "" + layout.lineCount);
    check("Scanner: الحالة الابتدائية NORMAL",
        layout.startState[0] == XmlStructureScanner.NORMAL, "" + layout.startState[0]);
    check("Scanner: سطر التعليق يدخل حالة COMMENT",
        layout.startState[2] == XmlStructureScanner.COMMENT
            || layout.endState[2] == XmlStructureScanner.COMMENT
            || XmlStructureScanner.firstCommentSpanInRange(xml,
                   layout.lineStart[2], layout.lineEnd[2]) != null,
        "لم يُلتقط التعليق");
    check("Scanner: سطر CDATA يمسّ حالة CDATA",
        XmlStructureScanner.rangeTouchesState(
            xml, layout.lineStart[3], layout.lineEnd[3], XmlStructureScanner.CDATA),
        "لم يُلتقط CDATA");
    check("Scanner: العمق يعود إلى الصفر في النهاية",
        layout.depthBefore[layout.lineCount - 1] + layout.depthDelta[layout.lineCount - 1] == 0,
        "" + (layout.depthBefore[layout.lineCount - 1] + layout.depthDelta[layout.lineCount - 1]));
    check("Scanner: startsWithClose يلتقط </a>",
        layout.startsWithClose[4], "لم يُلتقط");
    check("Scanner: startsWithClose سالب لسطر فتح",
        !layout.startsWithClose[1], "التُقط خطأً");
    check("Scanner: commentSpanContaining يجد التعليق",
        XmlStructureScanner.commentSpanContaining(xml, xml.indexOf("تعليق")) != null, "لم يجد");
    check("Scanner: نص فارغ آمن", XmlStructureScanner.scan("").lineCount >= 1, "رمى");

    // XmlCommentEditor
    String file =
        "<resources>\n  <string name=\"a\">1</string>\n  <string name=\"b\">2</string>\n</resources>\n";
    int from = file.indexOf("  <string name=\"a\"");
    int to = file.indexOf("  <string name=\"b\"");
    XmlCommentEditor.Outcome commented = XmlCommentEditor.comment(file, from, to);
    check("Comment: ينجح على نطاق صالح", commented.applies(), commented.rejection);
    check("Comment: يستخدم وسوم XML لا //",
        commented.text.contains("<!--") && !commented.text.contains("//"),
        commented.text);
    // تحديد بطول صفر يتوسّع إلى سطره، وسطر 0 فيه محتوى — فالرفض الصحيح يكون على سطر أبيض.
    String blank = "<a>\n\n</a>\n";
    check("Comment: يفشل على سطر أبيض", !XmlCommentEditor.comment(blank, 4, 4).applies(), "نجح");
    check("Comment: يفشل على نص فارغ", !XmlCommentEditor.comment("", 0, 0).applies(), "نجح");
    check("Comment: يرفض CDATA",
        !XmlCommentEditor.comment("<a><![CDATA[x]]></a>", 0, 18).applies(), "قبل CDATA");
    check("Comment: يرفض النطاق المعلّق",
        !XmlCommentEditor.comment("<!-- <a/> -->", 4, 8).applies(), "قبل معلّقًا");
    check("Comment: يرفض ما يحوي --",
        !XmlCommentEditor.comment("<a>\nx--y\n</a>", 0, 12).applies(), "قبل --");
    check("Comment: السطر الواحد يُعلَّق سطريًا",
        XmlCommentEditor.comment(file, from, from + 5).text.trim().startsWith("<!--")
            && !XmlCommentEditor.comment(file, from, from + 5).text.contains("\n"),
        XmlCommentEditor.comment(file, from, from + 5).text);

    // دورات ذهاب/إياب دقيقة بالبايت
    check("Comment: دورة دقيقة في منتصف ملف", exactRoundTrip(file, from, to), "غير دقيقة");
    check("Comment: دورة دقيقة لسطر واحد",
        exactRoundTrip(file, from, file.indexOf("\n  <string name=\"b\"")), "غير دقيقة");
    String tail = "<resources>\n  <string name=\"a\">1</string>\n</resources>\n";
    check("Comment: دورة دقيقة لآخر سطر",
        exactRoundTrip(tail, tail.indexOf("</resources>"), tail.length()), "غير دقيقة");
    String tailNoNl = "<resources>\n  <string name=\"a\">1</string>\n</resources>";
    check("Comment: دورة دقيقة لآخر سطر بلا سطر نهاية",
        exactRoundTrip(tailNoNl, tailNoNl.indexOf("</resources>"), tailNoNl.length()), "غير دقيقة");
    check("Comment: toggle يعلّق ثم يفكّ",
        XmlCommentEditor.toggle(file, from, to).applies(), null);
    check("Comment: lineRegion يرجع مدى",
        XmlCommentEditor.lineRegion(file, from, to)[0] == from, "مدى خاطئ");

    // XmlCodeFormatter
    check("Formatter: isXmlName على .xml", XmlCodeFormatter.isXmlName("a.xml"), "رفض");
    check("Formatter: isXmlName على .XML", XmlCodeFormatter.isXmlName("a.XML"), "رفض");
    check("Formatter: isXmlName بعد لاحقة تبويب مكرر",
        XmlCodeFormatter.isXmlName("res/values/colors.xml (2)"), "رفض");
    check("Formatter: isXmlName لا يقبل لاحقة غير رقمية",
        !XmlCodeFormatter.isXmlName("a.xml (draft)"), "قبل");
    check("Formatter: isXmlName على .java", !XmlCodeFormatter.isXmlName("A.java"), "قبل");
    check("Formatter: isXmlName على null", !XmlCodeFormatter.isXmlName(null), "قبل");
    check("Formatter: الوسوم الذاتية لا تزيد العمق",
        leadingOf(XmlCodeFormatter.format("<a>\n<b/>\n<c/>\n</a>", 2), 2) == 2,
        "" + leadingOf(XmlCodeFormatter.format("<a>\n<b/>\n<c/>\n</a>", 2), 2));
    check("Formatter: <?xml?> عند الصفر",
        leadingOf(XmlCodeFormatter.format("<?xml version=\"1.0\"?>\n<a/>", 2), 0) == 0,
        "أُزيح إعلان XML");
    check("Formatter: <!DOCTYPE> عند الصفر",
        leadingOf(XmlCodeFormatter.format("<!DOCTYPE a>\n<a/>", 2), 0) == 0, "أُزيح DOCTYPE");
    String commentXml = "<a>\n<!--\n<b/>\n-->\n</a>";
    check("Formatter: التعليق لا يُعامل كوسم",
        XmlCodeFormatter.format(commentXml, 2) != null, "رمى");
    check("Formatter: قيم السمات لا تُمس",
        XmlCodeFormatter.format("<a t=\"  x  \"/>", 2).contains("t=\"  x  \""),
        XmlCodeFormatter.format("<a t=\"  x  \"/>", 2));
  }

  static boolean exactRoundTrip(String text, int start, int end) {
    XmlCommentEditor.Outcome commented = XmlCommentEditor.comment(text, start, end);
    if (!commented.applies()) return false;
    String withComment =
        text.substring(0, commented.start) + commented.text + text.substring(commented.end);
    XmlCommentEditor.Outcome back =
        XmlCommentEditor.uncomment(
            withComment, commented.start, commented.start + commented.text.length());
    if (!back.applies()) return false;
    String restored =
        withComment.substring(0, back.start) + back.text + withComment.substring(back.end);
    return restored.equals(text);
  }

  /** يبني فهرسًا فيه @+id داخل تعليق — يجب ألّا يُفهرس الاسم. */
  static String buildCommentedIdIndex() throws Exception {
    File dir = new File("/tmp/shima-qa/commented/res/layout");
    dir.mkdirs();
    try (OutputStreamWriter writer =
        new OutputStreamWriter(
            new FileOutputStream(new File(dir, "c.xml")), StandardCharsets.UTF_8)) {
      writer.write("<LinearLayout>\n  <!-- android:id=\"@+id/hiddenInComment\" -->\n</LinearLayout>\n");
    }
    XmlResourceIndex index = XmlResourceIndex.build(new File("/tmp/shima-qa/commented"));
    XmlResourceIndex.Declaration found = index.lookup("id", "hiddenInComment");
    return found == null ? null : found.file;
  }

  /** يبني فهرسًا فيه @+id داخل CDATA — يجب ألّا يُفهرس الاسم. */
  static String buildCdataIdIndex() throws Exception {
    File dir = new File("/tmp/shima-qa/cdata/res/layout");
    dir.mkdirs();
    try (OutputStreamWriter writer =
        new OutputStreamWriter(
            new FileOutputStream(new File(dir, "d.xml")), StandardCharsets.UTF_8)) {
      writer.write("<LinearLayout>\n  <![CDATA[ android:id=\"@+id/hiddenInCdata\" ]]>\n</LinearLayout>\n");
    }
    XmlResourceIndex index = XmlResourceIndex.build(new File("/tmp/shima-qa/cdata"));
    XmlResourceIndex.Declaration found = index.lookup("id", "hiddenInCdata");
    return found == null ? null : found.file;
  }

  // ═══════════════════ §D المرحلة السابعة ═══════════════════

  static void phase7XmlSemantics() throws Exception {
    section("د — المرحلة 7: دلاليات موارد XML");

    String decl = "<LinearLayout android:id=\"@+id/root\" android:text=\"@string/app_name\" />";
    XmlResourceReference plus = XmlResourceReference.at(decl, decl.indexOf("@+id") + 2);
    check("Ref: @+id/root يُستخرج", plus != null && plus.name.equals("root"),
        plus == null ? "null" : plus.name);
    check("Ref: @+id و@id يُطبَّعان إلى مفتاح واحد",
        plus != null && plus.key().equals("id/root"), plus == null ? "null" : plus.key());
    String use = "<TextView android:id=\"@id/root\" />";
    XmlResourceReference plain = XmlResourceReference.at(use, use.indexOf("@id") + 1);
    check("Ref: @id/root له المفتاح نفسه",
        plain != null && plain.key().equals("id/root"), plain == null ? "null" : plain.key());
    check("Ref: @+id معلَّم إعلانًا", plus != null && plus.declaration, "لم يُعلَّم");
    check("Ref: @id ليس إعلانًا", plain != null && !plain.declaration, "عُلِّم خطأً");

    String framework = "<TextView android:theme=\"@android:style/Theme.Dark\" />";
    XmlResourceReference fw =
        XmlResourceReference.at(framework, framework.indexOf("@android") + 4);
    check("Ref: @android:style/… يُلتقط", fw != null && fw.type.equals("style"),
        fw == null ? "null" : fw.type);
    check("Ref: البادئة android: تفصل موارد الإطار", fw != null && fw.framework, "لم تُفصل");
    check("Ref: display للمورد الإطاري",
        fw != null && fw.display().equals("android:style/Theme.Dark"),
        fw == null ? "null" : fw.display());
    String project = "<TextView android:text=\"@string/app_name\" />";
    XmlResourceReference proj = XmlResourceReference.at(project, project.indexOf("@string") + 3);
    check("Ref: مورد المشروع ليس إطاريًا", proj != null && !proj.framework, "عُدَّ إطاريًا");
    check("Ref: display لمورد المشروع",
        proj != null && proj.display().equals("string/app_name"),
        proj == null ? "null" : proj.display());
    String attr = "<TextView style=\"?attr/colorPrimary\" />";
    XmlResourceReference attrRef = XmlResourceReference.at(attr, attr.indexOf("?attr") + 2);
    check("Ref: ?attr/ يُلتقط", attrRef != null && attrRef.key().equals("attr/colorPrimary"),
        attrRef == null ? "null" : attrRef.key());
    String androidAttr = "<TextView style=\"?android:attr/textColor\" />";
    XmlResourceReference androidAttrRef =
        XmlResourceReference.at(androidAttr, androidAttr.indexOf("?android") + 3);
    check("Ref: ?android:attr/ يُلتقط",
        androidAttrRef != null && androidAttrRef.key().equals("attr/textColor"),
        androidAttrRef == null ? "null" : androidAttrRef.key());
    check("Ref: موضع بلا مرجع يعيد null",
        XmlResourceReference.at("plain text here", 3) == null, "أعاد قيمة");
    check("Ref: نص null آمن", XmlResourceReference.at(null, 0) == null, "رمى");
    check("Ref: nameStart/nameEnd يحددان الاسم لا البادئة",
        proj != null
            && project.substring(proj.nameStart, proj.nameEnd).equals("app_name"),
        proj == null ? "null" : project.substring(proj.nameStart, proj.nameEnd));

    // XmlResourceIndex على مشروع مؤقت
    File root = new File("/tmp/shima-qa/proj/res");
    root.mkdirs();
    File values = new File(root, "values");
    values.mkdirs();
    try (OutputStreamWriter writer =
        new OutputStreamWriter(
            new FileOutputStream(new File(values, "strings.xml")), StandardCharsets.UTF_8)) {
      writer.write(
          "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n"
              + "  <string name=\"app_name\">Shima</string>\n"
              + "  <string name=\"empty\"></string>\n</resources>\n");
    }
    File layouts = new File(root, "layout");
    layouts.mkdirs();
    try (OutputStreamWriter writer =
        new OutputStreamWriter(
            new FileOutputStream(new File(layouts, "main.xml")), StandardCharsets.UTF_8)) {
      writer.write("<LinearLayout android:id=\"@+id/root\" />\n");
    }
    File skipped = new File("/tmp/shima-qa/proj/build/res/values");
    skipped.mkdirs();
    try (OutputStreamWriter writer =
        new OutputStreamWriter(
            new FileOutputStream(new File(skipped, "gen.xml")), StandardCharsets.UTF_8)) {
      writer.write("<resources>\n  <string name=\"generated\">no</string>\n</resources>\n");
    }
    XmlResourceIndex index = XmlResourceIndex.build(new File("/tmp/shima-qa/proj"));
    check("Index: بُني من الجذر", index != null && !index.isEmpty(), "فارغ");
    check("Index: root يعيد الجذر", index != null && index.root() != null, "null");
    check("Index: حجم ≥ 3 إعلانات", index != null && index.size() >= 3,
        index == null ? "null" : "" + index.size());
    XmlResourceIndex.Declaration name = index == null ? null : index.lookup("string", "app_name");
    check("Index: حلّ string/app_name", name != null && "Shima".equals(name.value),
        name == null ? "null" : name.value);
    check("Index: الإعلان يحمل الملف والسطر", name != null && name.line >= 0 && name.file != null,
        name == null ? "null" : name.file + ":" + name.line);
    check("Index: مجلد build/ مستثنى",
        index != null && index.lookup("string", "generated") == null, "فهرس build/");
    check("Index: @+id/root مفهرس",
        index != null && index.lookup("id", "root") != null, "لم يُفهرس");
    check("Index: الحلّ بالمرجع يعمل", index != null && index.lookup(proj) != null, "لم يحلّ");
    check("Index: مفتاح غير موجود يعيد null",
        index != null && index.lookup("string", "nope") == null, "أعاد قيمة");
    check("Index: empty() فارغ", XmlResourceIndex.empty().isEmpty(), "ليس فارغًا");
    check("Index: build(null) لا يُرمي", XmlResourceIndex.build(null) != null, "رمى");

    // المرحلة 9: الإعلانات المكتوبة داخل الملفات (@+id/x في layout) كانت تُفلت من الفهرس
    // رغم أن توثيق lookup يَعِد بحلّها — أُغلقت الفجوة، وهذه بواباتها.
    check("Index: @+id المعلَن داخل layout مفهرس",
        index != null && index.lookup("id", "root") != null, "لم يُفهرس");
    XmlResourceIndex.Declaration inline = index == null ? null : index.lookup("id", "root");
    check("Index: الإعلان الداخلي يشير إلى ملف layout",
        inline != null && inline.file != null && inline.file.endsWith("main.xml"),
        inline == null ? "null" : inline.file);
    check("Index: الإعلان الداخلي يحمل موضع @+",
        inline != null && inline.offset >= 0 && inline.line >= 0,
        inline == null ? "null" : inline.line + ":" + inline.offset);
    check("Index: @+id داخل تعليق لا يُفهرس", buildCommentedIdIndex() == null,
        "فُهرس اسم من داخل تعليق");
    check("Index: @+id في CDATA لا يُفهرس", buildCdataIdIndex() == null, "فُهرس من CDATA");
  }

  // ═══════════════════ §D2 زخارف ألوان XML في كل أنواع الملفات ═══════════════════

  static void xmlColorStyling() throws Exception {
    section("د2 — زخرفة قيم اللون في ملفات XML المتنوعة");

    List<XmlColorLiteral> valuesColors =
        styledXmlColors(
            "app/src/main/res/values/colors.xml",
            read("app/src/main/res/values/colors.xml"));
    check("ألوان XML: ملف الألوان يكسو القيم", valuesColors != null && !valuesColors.isEmpty(),
        valuesColors == null ? "انتهت المهلة" : "عدد=" + valuesColors.size());

    List<XmlColorLiteral> styleColors =
        styledXmlColors(
            "app/src/main/res/values/styles.xml",
            read("app/src/main/res/values/styles.xml"));
    check("ألوان XML: القيم داخل styles.xml تُفهرس أيضًا",
        styleColors != null && !styleColors.isEmpty(),
        styleColors == null ? "انتهت المهلة" : "عدد=" + styleColors.size());

    List<XmlColorLiteral> runtimeColors =
        styledXmlColors(
            "app/src/main/res/values/runtime_styles.xml",
            read("app/src/main/res/values/runtime_styles.xml"));
    check("ألوان XML: ملف قيم آخر لا يعتمد على اسمه colors.xml",
        runtimeColors != null && !runtimeColors.isEmpty(),
        runtimeColors == null ? "انتهت المهلة" : "عدد=" + runtimeColors.size());

    String layout =
        "<TextView android:textColor=\"#FF112233\" android:background=\"#ff000000\" />";
    List<XmlColorLiteral> layoutColors =
        styledXmlColors("app/src/main/res/layout-land/widget.xml", layout);
    check("ألوان XML: android:background=#ff000000 يُفهرس من مجلد layout-land أيضًا",
        layoutColors != null && layoutColors.size() == 2
            && layoutColors.get(0).argb == 0xFF112233
            && layoutColors.get(1).argb == 0xFF000000,
        layoutColors == null ? "انتهت المهلة" : "عدد=" + layoutColors.size());

    String drawable =
        "<selector>\n  <item android:color='#abc' />\n  <!-- #FF0000 is not a value -->\n</selector>";
    List<XmlColorLiteral> drawableColors =
        styledXmlColors("res/drawable/selector.xml", drawable);
    check("ألوان XML: قيمة اقتباس مفرد في drawable تُفهرس والتعليق يُستثنى",
        drawableColors != null && drawableColors.size() == 1
            && drawableColors.get(0).argb == 0xFFAABBCC,
        drawableColors == null ? "انتهت المهلة" : "عدد=" + drawableColors.size());

    String repeatedTabName =
        "<resources><color name=\"accent\">#80445566</color></resources>";
    List<XmlColorLiteral> repeatedTabColors =
        styledXmlColors("res/values-night/colors.xml (2)", repeatedTabName);
    check("ألوان XML: لاحقة التبويب المكرر لا توقف التلوين",
        repeatedTabColors != null && repeatedTabColors.size() == 1
            && repeatedTabColors.get(0).argb == 0x80445566,
        repeatedTabColors == null ? "انتهت المهلة" : "عدد=" + repeatedTabColors.size());

    String canvas = read("app/src/main/java/almlk/CodeCanvasView.java");
    String paintCache = read("app/src/main/java/almlk/StylePaintCache.java");
    check("ألوان XML: كل literal يرسم خطًا تحته في أي مسار XML",
        canvas.contains("drawColorUnderlines(canvas, line, originX, lineTop)")
            && canvas.contains("provider.colorLiterals(document, line)")
            && canvas.contains("canvas.drawLine(left, underlineY, right, underlineY")
            && canvas.contains("paints.colorUnderline(literal.argb, strokeWidth)")
            && paintCache.contains("colorUnderline(int argb, float strokeWidthPx)")
            && paintCache.contains("setStyle(Paint.Style.STROKE)"),
        "مسار رسم خط اللون أسفل النص غير موصول");
    check("ألوان XML: الحد التبايني لا يستبدل لون الخط المحدد",
        canvas.contains("colorDecorationOutlineColor(literal.argb)")
            && canvas.contains("paints.colorUnderline(outline, contrastWidth)")
            && canvas.contains("paints.colorUnderline(literal.argb, strokeWidth)")
            && canvas.contains("colorLuminance - backgroundLuminance"),
        "تعذّر تمييز الخط الداكن أو تغيّر لونه عن قيمة XML");
  }

  static List<XmlColorLiteral> styledXmlColors(String fileName, String source) throws Exception {
    LineDocument document = new LineDocument();
    document.setAll(source);
    LineStyler styler = new LineStyler(document);
    CountDownLatch completed = new CountDownLatch(1);
    int finalLine = document.lineCount() - 1;
    styler.setListener(
        (from, to) -> {
          if (to >= finalLine) completed.countDown();
        });
    try {
      styler.setFileName(fileName);
      if (!completed.await(5, TimeUnit.SECONDS)) return null;
      ArrayList<XmlColorLiteral> literals = new ArrayList<>();
      for (int line = 0; line < document.lineCount(); line++) {
        XmlColorLiteral[] styled = styler.colorLiteralsForLine(line);
        if (styled != null) {
          for (XmlColorLiteral literal : styled) if (literal != null) literals.add(literal);
        }
      }
      return literals;
    } finally {
      styler.shutdown();
    }
  }

  // ═══════════════════ §E المرحلة الثامنة ═══════════════════

  static void phase8CodeStyle() {
    section("هـ — المرحلة 8: نمط الكود والتفويض");

    android.content.Context context = freshPrefs();
    check("CodeStyle: افتراضي .xml = 4", CodeStyle.indentSizeFor(context, "s.xml") == 4,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    check("CodeStyle: افتراضي .java = 4", CodeStyle.indentSizeFor(context, "A.java") == 4,
        "" + CodeStyle.indentSizeFor(context, "A.java"));
    putPref(CodeStyle.XML_INDENT_KEY, "2");
    check("CodeStyle: xml=2 معزول عن جافا",
        CodeStyle.indentSizeFor(context, "s.xml") == 2
            && CodeStyle.indentSizeFor(context, "A.java") == 4,
        CodeStyle.indentSizeFor(context, "s.xml") + "/" + CodeStyle.indentSizeFor(context, "A.java"));
    putPref(CodeStyle.JAVA_INDENT_KEY, "8");
    check("CodeStyle: java=8 معزول عن XML",
        CodeStyle.indentSizeFor(context, "A.java") == 8
            && CodeStyle.indentSizeFor(context, "s.xml") == 2,
        CodeStyle.indentSizeFor(context, "A.java") + "/" + CodeStyle.indentSizeFor(context, "s.xml"));
    for (String bad : new String[] {"abc", "999", "-3", "", "1.5", "  ", "0x10"}) {
      putPref(CodeStyle.XML_INDENT_KEY, bad);
      check("CodeStyle: القيمة الفاسدة «" + bad.trim() + "» ترتدّ إلى 4",
          CodeStyle.indentSizeFor(context, "s.xml") == 4,
          "" + CodeStyle.indentSizeFor(context, "s.xml"));
    }
    putPref(CodeStyle.XML_INDENT_KEY, " 6 ");
    check("CodeStyle: المسافات تُقتطع", CodeStyle.indentSizeFor(context, "s.xml") == 6,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    putPref(CodeStyle.XML_INDENT_KEY, "0");
    check("CodeStyle: الصفر مقبول", CodeStyle.indentSizeFor(context, "s.xml") == 0,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    putPref(CodeStyle.XML_INDENT_KEY, "16");
    check("CodeStyle: الحد الأقصى مقبول", CodeStyle.indentSizeFor(context, "s.xml") == 16,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    check("CodeStyle: context=null آمن", CodeStyle.indentSize(null, CodeStyle.XML_INDENT_KEY) == 4,
        "رمى أو أخطأ");
    check("CodeStyle: indentSizeFor(null,…) آمن", CodeStyle.indentSizeFor(null, "a.xml") == 4, "أخطأ");
    check("CodeStyle: key=null آمن", CodeStyle.indentSize(context, null) == 4, "رمى أو أخطأ");

    freshPrefs();
    CodeStyle.setIndentSize(context, CodeStyle.XML_INDENT_KEY, 3);
    check("CodeStyle: setIndentSize يكتب", CodeStyle.indentSizeFor(context, "s.xml") == 3,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    CodeStyle.setIndentSize(context, CodeStyle.XML_INDENT_KEY, 500);
    check("CodeStyle: الكتابة تُقيَّد بالسقف", CodeStyle.indentSizeFor(context, "s.xml") == 16,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    CodeStyle.setIndentSize(context, CodeStyle.XML_INDENT_KEY, -9);
    check("CodeStyle: الكتابة تُقيَّد بالصفر", CodeStyle.indentSizeFor(context, "s.xml") == 0,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    CodeStyle.setIndentSize(null, CodeStyle.XML_INDENT_KEY, 2);
    check("CodeStyle: setIndentSize(null) آمن", true, null);

    freshPrefs();
    CodeStyle.seedDefaults(context);
    check("CodeStyle: seedDefaults يبذل المفتاحين",
        android.preference.PreferenceManager.store.containsKey(CodeStyle.XML_INDENT_KEY)
            && android.preference.PreferenceManager.store.containsKey(CodeStyle.JAVA_INDENT_KEY),
        android.preference.PreferenceManager.store.toString());
    putPref(CodeStyle.JAVA_INDENT_KEY, "2");
    CodeStyle.seedDefaults(context);
    check("CodeStyle: seedDefaults لا يدهس اختيار المستخدم",
        CodeStyle.indentSizeFor(context, "A.java") == 2,
        "" + CodeStyle.indentSizeFor(context, "A.java"));
    CodeStyle.seedDefaults(null);
    check("CodeStyle: seedDefaults(null) آمن", true, null);

    // التفويض — مصدر حقيقة واحد
    check("XmlCodeFormatter: INDENT_KEY مُعار",
        XmlCodeFormatter.INDENT_KEY.equals(CodeStyle.XML_INDENT_KEY), XmlCodeFormatter.INDENT_KEY);
    check("XmlCodeFormatter: DEFAULT_INDENT مُعار",
        XmlCodeFormatter.DEFAULT_INDENT == CodeStyle.DEFAULT_INDENT,
        "" + XmlCodeFormatter.DEFAULT_INDENT);
    check("XmlCodeFormatter: MAX_INDENT مُعار",
        XmlCodeFormatter.MAX_INDENT == CodeStyle.MAX_INDENT, "" + XmlCodeFormatter.MAX_INDENT);
    freshPrefs();
    check("XmlCodeFormatter: resolveIndentSize(null) = 4",
        XmlCodeFormatter.resolveIndentSize(null) == 4,
        "" + XmlCodeFormatter.resolveIndentSize(null));
    putPref(CodeStyle.XML_INDENT_KEY, "2");
    check("XmlCodeFormatter: resolveIndentSize يقرأ التفضيل",
        XmlCodeFormatter.resolveIndentSize(context) == 2,
        "" + XmlCodeFormatter.resolveIndentSize(context));
    putPref(CodeStyle.XML_INDENT_KEY, "zzz");
    check("XmlCodeFormatter: resolveIndentSize يرتدّ عند الفساد",
        XmlCodeFormatter.resolveIndentSize(context) == 4,
        "" + XmlCodeFormatter.resolveIndentSize(context));

    // منسّق جافا يكرّم الإزاحة
    String java = "class A {\nvoid f() {\nif (x) {\nreturn;\n}\n}\n}";
    check("جافا: مستوى ثانٍ = 8 عند إزاحة 4",
        leadingOf(CodeLanguageTools.format(java, 4), 2) == 8,
        "" + leadingOf(CodeLanguageTools.format(java, 4), 2));
    check("جافا: مستوى ثانٍ = 4 عند إزاحة 2",
        leadingOf(CodeLanguageTools.format(java, 2), 2) == 4,
        "" + leadingOf(CodeLanguageTools.format(java, 2), 2));
    check("جافا: لا إزاحة عند 0",
        leadingOf(CodeLanguageTools.format(java, 0), 2) == 0,
        "" + leadingOf(CodeLanguageTools.format(java, 0), 2));
    check("جافا: المحتوى مطابق تمامًا بلا الإزاحة",
        stripIndent(CodeLanguageTools.format(java, 2)).equals(stripIndent(CodeLanguageTools.format(java, 4))),
        "اختلف المحتوى");
    check("جافا: عدد الأسطر ثابت",
        CodeLanguageTools.format(java, 2).split("\n", -1).length
            == CodeLanguageTools.format(java, 4).split("\n", -1).length,
        "اختلف العدد");
    check("جافا: خطوة سالبة لا تُسقط",
        leadingOf(CodeLanguageTools.format(java, -5), 2) == 0, "رمى أو أخطأ");
  }

  // ═══════════════════ §F سجل القوائم ═══════════════════

  static void menuRegistry() {
    section("و — سجل القوائم: أهلية حية وأمان null");

    EditorMenuRegistry registry = new EditorMenuRegistry();
    String[] pages = {
      EditorMenuRegistry.PAGE_TOOLBAR,
      EditorMenuRegistry.PAGE_ROOT,
      EditorMenuRegistry.PAGE_REFACTOR,
      EditorMenuRegistry.PAGE_CODE,
      EditorMenuRegistry.PAGE_FORMAT,
      EditorMenuRegistry.PAGE_FIND,
      EditorMenuRegistry.PAGE_SMALL,
    };

    check("Registry: entries(page, null) يعيد فارغًا بلا رمي",
        registry.entries(EditorMenuRegistry.PAGE_FORMAT, null).isEmpty(), "رمى أو أعاد");
    check("Registry: صفحة مجهولة تعيد فارغًا",
        registry.entries("no-such-page", new EditorMenuRegistry.Context()).isEmpty(), "أعادت");
    check("Registry: entries(null, ctx) لا تُرمي",
        registry.entries(null, new EditorMenuRegistry.Context()).isEmpty(), "رمت");

    EditorMenuRegistry.Context xmlContext = new EditorMenuRegistry.Context();
    xmlContext.xml = true;
    xmlContext.hasOpenFile = true;
    xmlContext.writable = true;
    xmlContext.hasSelection = true;
    EditorMenuRegistry.Context javaContext = new EditorMenuRegistry.Context();
    javaContext.hasOpenFile = true;
    javaContext.writable = true;
    javaContext.hasSelection = true;
    EditorMenuRegistry.Context readOnly = new EditorMenuRegistry.Context();
    readOnly.hasOpenFile = true;
    readOnly.writable = false;
    readOnly.xml = true;
    EditorMenuRegistry.Context closed = new EditorMenuRegistry.Context();

    check("Registry: XML يفتح التنسيق",
        enabled(registry, EditorMenuRegistry.PAGE_FORMAT, xmlContext, "format_code"), "معطّل");
    check("Registry: XML يفتح التعليق",
        enabled(registry, EditorMenuRegistry.PAGE_CODE, xmlContext, "comment"), "معطّل");
    check("Registry: XML يفتح فكّ التعليق",
        enabled(registry, EditorMenuRegistry.PAGE_CODE, xmlContext, "uncomment"), "معطّل");
    check("Registry: XML يفتح إعداد نمط الكود",
        enabled(registry, EditorMenuRegistry.PAGE_FORMAT, xmlContext, "configure_style"), "معطّل");
    check("Registry: XML يفتح استعراض الاستخدامات",
        enabled(registry, EditorMenuRegistry.PAGE_FIND, xmlContext, "find_usages"), "معطّل");
    check("Registry: XML يفتح الاستخدامات الموسعة",
        enabled(registry, EditorMenuRegistry.PAGE_FIND, xmlContext, "find_extended"), "معطّل");
    check("Registry: XML يفتح الانتقال إلى",
        enabled(registry, EditorMenuRegistry.PAGE_ROOT, xmlContext, "goto"), "معطّل");
    check("Registry: XML يفتح التوثيق",
        enabled(registry, EditorMenuRegistry.PAGE_ROOT, xmlContext, "documentation"), "معطّل");
    check("Registry: تنظيم الاستيرادات جافا فقط",
        !enabled(registry, EditorMenuRegistry.PAGE_CODE, xmlContext, "organize_imports")
            && enabled(registry, EditorMenuRegistry.PAGE_CODE, javaContext, "organize_imports"),
        "خالف العزل");
    check("Registry: try/catch جافا فقط",
        !enabled(registry, EditorMenuRegistry.PAGE_CODE, xmlContext, "surround_try")
            && enabled(registry, EditorMenuRegistry.PAGE_CODE, javaContext, "surround_try"),
        "خالف العزل");
    check("Registry: بلا حقل يعطّل Getters/Setters ولا يعطّل الباني الفارغ",
        !enabled(registry, EditorMenuRegistry.PAGE_CODE, javaContext, "create_setters")
            && enabled(registry, EditorMenuRegistry.PAGE_CODE, javaContext, "create_constructor"),
        "أهلية غير صحيحة");
    javaContext.hasFieldTarget = true;
    check("Registry: الحقل المستهدف يفعّل Getters/Setters",
        enabled(registry, EditorMenuRegistry.PAGE_CODE, javaContext, "create_setters"),
        "بقي معطّلًا");
    check("Registry: ملف للقراءة فقط يعطّل التنسيق", 
        !enabled(registry, EditorMenuRegistry.PAGE_FORMAT, readOnly, "format_code"), "بقي مفعّلًا");
    check("Registry: ملف للقراءة فقط يعطّل التعليق",
        !enabled(registry, EditorMenuRegistry.PAGE_CODE, readOnly, "comment"), "بقي مفعّلًا");
    check("Registry: إعداد النمط لا يحتاج كتابة",
        enabled(registry, EditorMenuRegistry.PAGE_FORMAT, readOnly, "configure_style"), "عُطّل");
    check("Registry: إعداد النمط لا يحتاج ملفًا مفتوحًا",
        enabled(registry, EditorMenuRegistry.PAGE_FORMAT, closed, "configure_style"), "عُطّل");
    check("Registry: بلا تحديد يعطّل الاستبدال",
        !enabled(registry, EditorMenuRegistry.PAGE_CODE, closed, "replace"), "بقي مفعّلًا");
    check("Registry: بالتحديد يفتح الاستبدال",
        enabled(registry, EditorMenuRegistry.PAGE_CODE, javaContext, "replace"), "معطّل");
    check("Registry: بلا ملف مفتوح يعطّل الإغلاق",
        !enabled(registry, EditorMenuRegistry.PAGE_ROOT, closed, "close"), "بقي مفعّلًا");
    check("Registry: بملف مفتوح يفتح الإغلاق",
        enabled(registry, EditorMenuRegistry.PAGE_ROOT, xmlContext, "close"), "معطّل");

    // أسباب التعطيل يجب أن تكون ظاهرة لا فارغة صامتة
    for (String page : pages) {
      EditorMenuRegistry.Entry disabled = firstDisabled(registry, page, closed);
      if (disabled != null) {
        check("Registry: سبب تعطيل ظاهر في «" + page + "»",
            !disabled.disabledReason.isEmpty(), disabled.id + " بلا سبب");
      }
    }

    // لا سبب تعطيل يَعِد بمرحلة قادمة — بوابة انحدار للجولات التالية كلها
    check("Registry: لا سبب تعطيل يَعِد بمرحلة", !containsInRegistryReason("المرحلة"),
        "وُجد وعد بمرحلة غير منفّذة");

    // القائمة المصغرة
    EditorMenuRegistry.Context layoutContext = new EditorMenuRegistry.Context();
    layoutContext.xml = true;
    layoutContext.layoutXml = true;
    layoutContext.writable = true;
    layoutContext.hasOpenFile = true;
    check("Registry: «تصميم» يظهر لملف layout فقط",
        entry(registry, EditorMenuRegistry.PAGE_SMALL, layoutContext, "design") != null
            && entry(registry, EditorMenuRegistry.PAGE_SMALL, xmlContext, "design") == null,
        "خالف شرط layoutXml");
    check("Registry: Fix بلا مساهمين لا يظهر",
        entry(registry, EditorMenuRegistry.PAGE_SMALL, xmlContext, "fix") == null, "ظهر بلا مساهم");
    List<EditorMenuRegistry.DynamicCommand> fixes = new ArrayList<>();
    fixes.add(new EditorMenuRegistry.DynamicCommand(
        "f1", "إنشاء method() في class", true, "", null));
    EditorMenuRegistry.Context withFix = new EditorMenuRegistry.Context();
    withFix.xml = true;
    withFix.hasOpenFile = true;
    withFix.fixes = fixes;
    check("Registry: Fix يظهر بمساهم",
        entry(registry, EditorMenuRegistry.PAGE_SMALL, withFix, "fix") != null, "لم يظهر");

    EditorMenuRegistry.Context toolbarContext = new EditorMenuRegistry.Context();
    toolbarContext.hasSelection = true;
    toolbarContext.hasText = true;
    toolbarContext.canExpand = true;
    toolbarContext.hasClipboardText = true;
    EditorMenuRegistry.Entry toolbarMore =
        entry(registry, EditorMenuRegistry.PAGE_TOOLBAR, toolbarContext, "more");
    check("Registry: شريط التحديد يحافظ على الترتيب ويفتح الجذر عبر المزيد",
        registry.entries(EditorMenuRegistry.PAGE_TOOLBAR, toolbarContext).size() == 5
            && "expand".equals(registry.entries(EditorMenuRegistry.PAGE_TOOLBAR, toolbarContext).get(0).id)
            && toolbarMore != null && toolbarMore.enabled
            && EditorMenuRegistry.PAGE_ROOT.equals(toolbarMore.subpage)
            && entry(registry, EditorMenuRegistry.PAGE_TOOLBAR, toolbarContext, "select_all") == null,
        "مسار more/الترتيب مكسور");
    check("Registry: أزرار القص والنسخ واللصق تتبع تحديدًا حيًا والحافظة",
        enabled(registry, EditorMenuRegistry.PAGE_TOOLBAR, toolbarContext, "cut")
            && enabled(registry, EditorMenuRegistry.PAGE_TOOLBAR, toolbarContext, "copy")
            && enabled(registry, EditorMenuRegistry.PAGE_TOOLBAR, toolbarContext, "paste"),
        "أهلية الشريط لا تطابق السياق");
    EditorMenuRegistry.Context blankToolbarContext = new EditorMenuRegistry.Context();
    blankToolbarContext.hasText = true;
    blankToolbarContext.writable = true;
    blankToolbarContext.hasClipboardText = true;
    List<EditorMenuRegistry.Entry> blankToolbar =
        registry.entries(EditorMenuRegistry.PAGE_TOOLBAR, blankToolbarContext);
    check("Registry: الضغط على الفراغ يعرض اللصق وتحديد الكل والمزيد فقط",
        blankToolbar.size() == 3
            && "paste".equals(blankToolbar.get(0).id)
            && "select_all".equals(blankToolbar.get(1).id)
            && "more".equals(blankToolbar.get(2).id)
            && enabled(registry, EditorMenuRegistry.PAGE_TOOLBAR, blankToolbarContext, "select_all"),
        "شريط الفراغ لا يعرض الإجراء المطلوب");
    blankToolbarContext.hasText = false;
    EditorMenuRegistry.Entry emptySelectAll =
        entry(registry, EditorMenuRegistry.PAGE_TOOLBAR, blankToolbarContext, "select_all");
    check("Registry: تحديد الكل معطّل عندما يكون المستند فارغًا",
        emptySelectAll != null && !emptySelectAll.enabled
            && "ui_reason_empty_document".equals(emptySelectAll.disabledReason),
        emptySelectAll == null ? "اختفى بلا سياق" : emptySelectAll.disabledReason);
  }

  static boolean enabled(
      EditorMenuRegistry registry, String page, EditorMenuRegistry.Context context, String id) {
    EditorMenuRegistry.Entry entry = entry(registry, page, context, id);
    return entry != null && entry.enabled;
  }

  static EditorMenuRegistry.Entry firstDisabled(
      EditorMenuRegistry registry, String page, EditorMenuRegistry.Context context) {
    for (EditorMenuRegistry.Entry entry : registry.entries(page, context)) {
      if (!entry.enabled) return entry;
    }
    return null;
  }

  /** يقرأ مصدر السجل ويبحث عن كلمة في نص سبب تعطيل ({@code c -> "…"}). */
  static boolean containsInRegistryReason(String needle) {
    String source;
    try {
      source = read("app/src/main/java/com/almlkid/ui/EditorMenuRegistry.java");
    } catch (Exception unreadable) {
      System.out.println("      (تعذّرت قراءة مصدر السجل: " + unreadable + ")");
      return false;
    }
    int index = 0;
    while ((index = source.indexOf("c -> \"", index)) >= 0) {
      int end = source.indexOf('"', index + 6);
      if (end < 0) break;
      String reason = source.substring(index + 6, end);
      if (reason.contains(needle)) {
        System.out.println("      (سبب تعطيل: «" + reason + "»)");
        return true;
      }
      index = end;
    }
    return false;
  }

  // ═══════════════════ §G لا مسارات ميتة ═══════════════════

  static void noDeadPaths() throws Exception {
    section("ز — لا مسارات ميتة (بند 4: الإحلال الكامل)");

    String tools = read("app/src/main/java/com/almlkid/kay/ui/CodeLanguageTools.java");
    check("Dead: formatXml محذوف", !tools.contains("formatXml"), "ما زال");
    check("Dead: rtrim اليتيم محذوف", !tools.contains("rtrim"), "ما زال");
    check("Dead: لا تفريع XML في التنسيق", !tools.contains("isXml(fileName) ? format"), "ما زال");
    check("Dead: لا ثابت أربع مسافات مضمّن", !tools.contains("output.append(\"    \")"), "ما زال");
    check("Dead: isXml باقٍ للملوّن والمفتّش", tools.contains("private static boolean isXml("),
        "حُذف خطأً");
    check("Dead: لا نداء .formatXml( في المشروع", !containsInTree(".formatXml(", SRC), "وُجد");
    check("Dead: مسار XML الحي formatXmlSource سليم",
        containsInTree("formatXmlSource", SRC + "/com/almlkid/ui"), "اختفى");
    // المرحلة 1: أُحيي الملف بربط حي — وجوده ومرجعه مطلوبان الآن.
    check("إعدادات: preferences_codestyle.xml موجود",
        new File("/home/user/ShimaProject/app/src/main/res/xml/preferences_codestyle.xml").exists(),
        "الملف مفقود");
    check("إعدادات: مرجع حي لـ preferences_codestyle",
        read("app/src/main/java/com/almlkid/ui/preferences/CodestylePreferencesFragment.java")
            .contains("R.xml.preferences_codestyle"),
        "بلا مرجع");

    String formatter = read("app/src/main/java/almlk/XmlCodeFormatter.java");
    check("Dead: XmlCodeFormatter لا يقرأ التفضيل مباشرة",
        !formatter.contains("getSharedPreferences"), "يقرأ مباشرة");
    check("Dead: مفتاح الإزاحة الحرفي في CodeStyle وحده",
        !formatter.contains("\"xml_indentation_size\""), "مكتوب هنا أيضًا");
    check("Dead: CodeStyle يفوّض عبر indentSize",
        read("app/src/main/java/almlk/CodeStyle.java").contains("indentSize("), "لا يفوّض");

    section("ح — منظومة الاقتراحات: أيقونات الأنواع + الاستيراد التلقائي (المراحل 1-4)");
    String pager = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("اقتراح: النافذة العامة showCompletionPopup موجودة",
        pager.contains("public void showCompletionPopup()"), "مفقودة");
    check("اقتراح: التفويض applyTypedCompletion في الصفحات",
        pager.contains("public void applyTypedCompletion(ProjectSymbolIndex.CompletionItem"), "مفقود");
    check("اقتراح: النقر يلتزم منمطًا لا insertText مجرّد",
        pager.contains("applyTypedCompletion(completionAdapter.getItem(position))"), "ما زال مجرّد");
    check("اقتراح: لا نقر قديم بـ insertText في النافذة الحية",
        !pager.contains("applyCompletion(completionAdapter.getItem(position).insertText)"), "باقٍ");
    String ed = read("app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java");
    check("اقتراح: typedCompletions من فهرس الرموز", ed.contains("typedCompletions()"), "مفقود");
    check("اقتراح: applyTypedCompletion في المحرر",
        ed.contains("public void applyTypedCompletion("), "مفقود");
    check("اقتراح: الدالة تُدرج قوسين والمؤشر بداخلهما",
        ed.contains("isMethod && insert.indexOf('(') < 0")
            && ed.contains("caret = start + insert.length() + 1"), "منقوص");
    check("اقتراح: الكلاس يستورد تلقائيًا عبر addImportIfNeeded",
        ed.contains("private void addImportIfNeeded(String className)")
            && ed.contains("addImportIfNeeded(item.label)"), "منقوص");
    check("اقتراح: الاستيراد يتخطى java.lang", ed.contains("java.lang"), "منقوص");
    check("اقتراح: الاستيراد يتخطى نفس الحزمة", ed.contains("pkg.equals(currentPkg)"), "منقوص");
    check("اقتراح: إدراج سطر الاستيراد", ed.contains("replaceRange(insertAt, insertAt,"), "منقوص");
    check("اقتراح: packageOf يقرأ حزمة الصنف",
        ed.contains("ProjectSymbolIndex.packageOf(simple)"), "منقوص");
    String psi = read("app/src/main/java/com/almlkid/kay/ui/ProjectSymbolIndex.java");
    check("فهرس: packageOf عام ومتزامن",
        psi.contains("public static synchronized String packageOf("), "مفقود");
    String adapter = read("app/src/main/java/com/almlkid/ui/EditorCompletionAdapter.java");
    check("أيقونات: METHOD→box_red", adapter.contains("R.drawable.box_red"), "مفقود");
    check("أيقونات: CLASS→box_blue", adapter.contains("return R.drawable.box_blue"), "مفقود");
    check("أيقونات: VARIABLE→objects", adapter.contains("R.drawable.objects"), "مفقود");
    String icons = "/home/user/ShimaProject/app/src/main/res/drawable-hdpi/";
    check("أيقونات: ملفات المرجع المنسوخة موجودة",
        new File(icons + "box_red.png").exists() && new File(icons + "box_blue.png").exists()
            && new File(icons + "objects.png").exists()
            && new File(icons + "box_light_blue.png").exists()
            && new File(icons + "pakage.png").exists(), "ملف ناقص");
    String mainAct = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("اقتراح: الأمر اليدوي يوحَّد على النافذة الحية",
        mainAct.contains("editor.showCompletionPopup()"), "لا يفوّض");
    check("اقتراح: لا محول مزدوج في MainActivity",
        !mainAct.contains("completionIcon("), "باقٍ");

    section("ط — عزل قوائم المحرر عن الكيبورد (علّة «المزيد»)");
    String pg = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("عزل: لا نافذة حاوية focusable متبقية",
        !pg.contains("ViewGroup.LayoutParams.WRAP_CONTENT, true)"), "ما زالت focusable");
    check("عزل: selectionMenu = INPUT_METHOD_NOT_NEEDED",
        pg.contains("selectionMenu.setInputMethodMode(PopupWindow.INPUT_METHOD_NOT_NEEDED)"), "مفقود");
    check("عزل: selectionMenu = SOFT_INPUT_STATE_UNCHANGED",
        pg.contains("selectionMenu.setSoftInputMode(")
            && pg.contains("SOFT_INPUT_STATE_UNCHANGED"), "مفقود");
    check("عزل: القائمة المصغّرة أُزيلت كليًا (إحلال 1.0.68)",
        !pg.contains("smallContextMenu"), "ما زالت");
    check("عزل: نافذة الإكمال ما زالت غير focusable (حارس انحدار)",
        pg.contains("completionWindow = new PopupWindow(completionList, width, height, false)"), "تغيّرت");
    check("عزل: setOutsideTouchable باقٍ لـselectionMenu",
        pg.contains("selectionMenu.setOutsideTouchable(true)"), "مفقود");
    check("عزل: المانيفست ما زال adjustResize (لم نكسر التحرير)",
        read("app/src/main/AndroidManifest.xml").contains("stateHidden|adjustResize"), "تغيّر");

    section("ي — الضغط المطول على الفراغ يُخرج شريط إجراءات التحديد (لا دايلوق «تحرير»)");
    String canvas = read("app/src/main/java/almlk/CodeCanvasView.java");
    check("مطول/فراغ: يستدعي شريط إجراءات التحديد",
        canvas.contains("interactions.onShowSelectionActionsRequested()"), "مفقود");
    check("مطول/فراغ: يضع المؤشر مكان الضغط أولًا",
        canvas.contains("setCaret(pos[0], pos[1]);"), "مفقود");
    int blankLongPressStart = canvas.indexOf("private void onLongPressTimeout()");
    int blankLongPressEnd = canvas.indexOf("private void selectionFeedback()", blankLongPressStart);
    String longPress = blankLongPressStart >= 0 && blankLongPressEnd > blankLongPressStart
        ? canvas.substring(blankLongPressStart, blankLongPressEnd) : "";
    int blankBranch = longPress.indexOf("else {");
    int blankFeedback = longPress.indexOf("selectionFeedback();", blankBranch);
    int blankActions = longPress.indexOf("interactions.onShowSelectionActionsRequested();", blankBranch);
    check("مطول/فراغ: يهتز قبل فتح شريط الإجراءات",
        blankBranch >= 0 && blankFeedback > blankBranch && blankActions > blankFeedback
            && canvas.contains("performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)"),
        "تغذية لمسية مفقودة أو ترتيب غير صحيح");
    String selectionMenuResource = read("app/src/main/res/menu/editor_selection_toolbar.xml");
    String selectionPager = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("مطول/فراغ: شريط الإجراء يضم اللصق وتحديد الكل من مورد قائمة",
        read("app/src/main/java/almlk/CodeEditorView.java").contains("ID_PASTE")
            && selectionMenuResource.contains("@+id/editor_selection_select_all")
            && selectionMenuResource.contains("@string/keybind_select_all")
            && selectionPager.contains("R.menu.editor_selection_toolbar")
            && selectionPager.contains("EXPAND_SELECTION"),
        "أمر اللصق أو التحديد مفقود");
    check("مطول/فراغ: لا القائمة المصغرة القديمة",
        !canvas.contains("onSmallContextMenuRequested"), "ما زالت");
    String edv = read("app/src/main/java/almlk/CodeEditorView.java");
    check("مطول/فراغ: المحرر يبدأ وضع التحديد",
        edv.contains("onShowSelectionActionsRequested") && edv.contains("startSelectionActionMode();"),
        "مفقود");
    check("مطول/فراغ: hook القائمة المصغرة محذوف",
        !edv.contains("onSmallContextMenuRequestedExternal"), "باقٍ");
    check("مطول/فراغ: SmallContextMenuListener محذوف من AlmlkEditor",
        !read("app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java").contains("SmallContextMenuListener"),
        "باقٍ");
    check("مطول/فراغ: showSmallContextMenu محذوف من الصفحات",
        !read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java").contains("showSmallContextMenu"),
        "باقٍ");
    check("مطول/فراغ: «تصميم» ما زال متاحًا (لا وظيفة مفقودة)",
        read("app/src/main/java/com/shima/demo/MainActivity.java").contains("case \"design\":"), "فُقد");

    section("انتقال الرمز: تحديد الهدف وعرض مواضع الظهور");
    String navPager = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    int goSymbolStart = navPager.indexOf("public int goToSymbol(");
    int goSymbolEnd = navPager.indexOf("private static int resolveLiveSymbolOffset", goSymbolStart);
    String goSymbolBody = goSymbolStart >= 0 && goSymbolEnd > goSymbolStart
        ? navPager.substring(goSymbolStart, goSymbolEnd) : "";
    check("GoTo: يحدد الرمز كاملًا بعد التحقق من حدوده وتثبيت التبويب",
        goSymbolBody.contains("isWholeWordAt(liveText, liveTarget, symbol)")
            && goSymbolBody.contains("code.setSelection(liveTarget, liveTarget + symbol.length())"),
        "القفزة لا تحدد نص الرمز بعد استعادة التبويب");
    String mainNavigation = read("app/src/main/java/com/shima/demo/MainActivity.java");
    int openDefinitionStart = mainNavigation.indexOf("private void openDefinition(");
    int openDefinitionEnd = mainNavigation.indexOf("private boolean isImeVisible()", openDefinitionStart);
    String openDefinitionBody = openDefinitionStart >= 0 && openDefinitionEnd > openDefinitionStart
        ? mainNavigation.substring(openDefinitionStart, openDefinitionEnd) : "";
    check("GoTo: مسار المرجع يقتصر على القفز؛ تعريف الرمز يُحوَّل منفصلًا للاستخدامات",
        openDefinitionBody.contains("editor.goToSymbol(definition.symbol, definition.offset)")
            && openDefinitionBody.contains("editor.goToSymbol(definition.symbol, offset)")
            && !openDefinitionBody.contains("showNavigationUsages")
            && !openDefinitionBody.contains("showSequentialPanels(")
            && !openDefinitionBody.contains("openDrawer(")
            && !mainNavigation.contains("private void showNavigationUsages("),
        "مسار مرجع Go To يعرض النتائج بدل القفز للتعريف");
    String commandCenterNavigation = read("app/src/main/java/com/shima/demo/CommandCenter.java");
    int gotoDispatchStart = mainNavigation.indexOf(
        "case \"goto_element\":", mainNavigation.indexOf("public void execute(String id)"));
    int gotoDispatchEnd = mainNavigation.indexOf("case \"format\":", gotoDispatchStart);
    String gotoDispatch = gotoDispatchStart >= 0 && gotoDispatchEnd > gotoDispatchStart
        ? mainNavigation.substring(gotoDispatchStart, gotoDispatchEnd) : "";
    int gotoRequestStart = navPager.indexOf("public void requestDefinitionForCurrentSelection()");
    int gotoRequestEnd = navPager.indexOf("public void refreshSemanticDiagnostics()", gotoRequestStart);
    String gotoRequest = gotoRequestStart >= 0 && gotoRequestEnd > gotoRequestStart
        ? navPager.substring(gotoRequestStart, gotoRequestEnd) : "";
    check("GoTo: النافذة لا تظهر بلا تحديد أصلي وأمر Go To صريح",
        gotoDispatch.contains("editor.requestDefinitionForCurrentSelection()")
            && !gotoDispatch.contains("promptGotoElement()")
            && gotoRequest.contains("selectionStart == selectionEnd")
            && gotoRequest.contains("ui_error_symbol_selection_required")
            && !gotoRequest.contains("selectionOrIdentifier()")
            && navPager.contains("public boolean hasExplicitEditorSelection()")
            && commandCenterNavigation.contains("Host::hasExplicitEditorSelection"),
        "Go To يقبل موضع المؤشر أو يفتح نافذة البحث دون تحديد");
    int usageRequestStart = navPager.indexOf("private void resolveUsagesOnDemand(ActionMode mode)");
    int usageRequestEnd = navPager.indexOf("public boolean onActionItemClicked(ActionMode mode", usageRequestStart);
    String usageRequestBody = usageRequestStart >= 0 && usageRequestEnd > usageRequestStart
        ? navPager.substring(usageRequestStart, usageRequestEnd) : "";
    int usageResultsStart = mainNavigation.indexOf("private void findUsagesForSelection(");
    int usageResultsEnd = mainNavigation.indexOf("private void showSequentialPanels(", usageResultsStart);
    String usageResultsBody = usageResultsStart >= 0 && usageResultsEnd > usageResultsStart
        ? mainNavigation.substring(usageResultsStart, usageResultsEnd) : "";
    check("Find Usages: الأمر الصريح وحده يفتح لوحة نتائج البحث",
        navPager.contains("case \"find_usages\":")
            && usageRequestBody.contains("usageListener.requested(")
            && usageResultsBody.contains("showSequentialPanels(SequentialPanelHost.Panel.SEARCH)")
            && usageResultsBody.contains("browser.findUsagesAsync("),
        "مسار عرض المواضع غير مربوط بأمر مستقل");

    section("ك — المرحلة 1: اكتمال القائمة الرئيسية (بدون تحديد) بلا عناصر ميتة");
    String cc = read("app/src/main/java/com/shima/demo/CommandCenter.java");
    check("مرحلة1: الأوامر الناقصة مسجلة (exit/close/publish/variant/forward)",
        cc.contains("add(\"exit\"") && cc.contains("add(\"close_project\"")
            && cc.contains("add(\"publish_project\"") && cc.contains("add(\"select_build_variant\"")
            && cc.contains("add(\"forward\""), "ناقصة");
    check("مرحلة1: «للأمام» أهلية حية صريحة لا عنصر ميت",
        cc.contains("add(\"forward\", \"command_forward\", \"ui_group_editor\", false, true, h -> false, null)"), "ميت");
    String ma = read("app/src/main/java/com/shima/demo/MainActivity.java");
    String mainMenuResource = read("app/src/main/res/menu/main_options_menu.xml");
    check("مرحلة1: dispatch ينفّذ الأوامر الجديدة",
        ma.contains("case \"exit\":") && ma.contains("case \"close_project\":")
            && ma.contains("case \"publish_project\":") && ma.contains("case \"select_build_variant\":")
            && ma.contains("case \"forward\":"), "غير منفذة");
    check("مرحلة1: عناصر المشروع معلنة في مورد القائمة ومربوطة بالأوامر",
        mainMenuResource.contains("android:id=\"@id/mainMenuSelectBuildVariant\"")
            && mainMenuResource.contains("android:id=\"@id/mainMenuPublishProject\"")
            && mainMenuResource.contains("android:id=\"@id/mainMenuCloseProject\"")
            && ma.contains("itemId == R.id.mainMenuSelectBuildVariant")
            && ma.contains("case \"select_build_variant\":"),
        "ربط القائمة ناقص");
    check("مرحلة1: إعداد النمط في مورد القائمة وأمر حي",
        mainMenuResource.contains("android:id=\"@id/editorMenuConfigureCodeStyle\"")
            && ma.contains("itemId == R.id.editorMenuConfigureCodeStyle")
            && ma.contains("case \"configure_style\":"),
        "ربط القائمة ناقص");
    check("مرحلة1: الجذر يحوي «للأمام» في مورد القائمة",
        mainMenuResource.contains("android:id=\"@id/mainMenuForward\"")
            && ma.contains("itemId == R.id.mainMenuForward"),
        "مفقود");

    section("ل — المرحلة 2: محرك إعادة التسمية Renamer (وظيفي)");
    String src = "int foo = 1;\nfoo++; // foo\nString s = \"foo\";\n";
    String renamed = almlk.Renamer.renameAll(src, "foo", "bar");
    check("إعادة تسمية: تستبدل التعريف والاستخدام", renamed.contains("int bar = 1;") && renamed.contains("bar++;"),
        renamed);
    check("إعادة تسمية: لا تلمس التعليقات والنصوص", renamed.contains("// foo") && renamed.contains("\"foo\""),
        renamed);
    check("إعادة تسمية: عدّ المواضع = 2", almlk.Renamer.countOccurrences(src, "foo") == 2,
        "" + almlk.Renamer.countOccurrences(src, "foo"));
    check("تحقق: كلمة محجوزة مرفوضة", almlk.Renamer.validate("foo", "class") != null, "قُبلت");
    check("تحقق: اسم مطابق مرفوض", almlk.Renamer.validate("foo", "foo") != null, "قُبل");
    check("تحقق: اسم صالح مقبول", almlk.Renamer.validate("foo", "bar") == null, "رُفض");
    String res = "<Button android:id=\"@+id/oldBtn\"/>\n<Button android:id=\"@id/oldBtn\"/>\n";
    String res2 = almlk.Renamer.renameResource(res, "oldBtn", "newBtn");
    check("مورد XML: @+id و@id يُحدَّثان", res2.contains("@+id/newBtn") && res2.contains("@id/newBtn")
        && !res2.contains("oldBtn"), res2);
    check("مورد XML: R.id يُحدَّث", almlk.Renamer.renameResource("int x = R.id.oldBtn;", "oldBtn", "newBtn")
        .contains("R.id.newBtn"), "لا");

    section("م — المرحلة 2: ربط إعادة التسمية بالقوائم (لا عنصر ميت)");
    String reg = read("app/src/main/java/com/almlkid/ui/EditorMenuRegistry.java");
    check("ربط: rename مفعّلة بتحديد+كتابة",
        reg.contains("add(PAGE_REFACTOR, \"rename\", \"command_rename\", null, ALWAYS,")
            && reg.contains("c -> c.hasSelection && c.writable")
            && !reg.contains("\"rename\", \"command_rename\", null, ALWAYS, c -> false"), "معطلة");
    String pgr = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("ربط: renameCurrentSelection + case rename + Renamer",
        pgr.contains("public void renameCurrentSelection()") && pgr.contains("case \"rename\":")
            && pgr.contains("almlk.Renamer.renameAll") && pgr.contains("almlk.Renamer.renameResource"), "ناقص");
    String mnx = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("ربط: مورد القائمة يعلن rename ويربطه بالمنفّذ",
        mainMenuResource.contains("android:id=\"@id/editorMenuRename\"")
            && mnx.contains("itemId == R.id.editorMenuRename")
            && mnx.contains("case \"rename\":"), "الربط مفقود");
    check("ربط: rename مسجلة + projectJavaFiles متاحة",
        read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"rename\"")
            && read("app/src/main/java/com/almlkid/kay/ui/ProjectSymbolIndex.java").contains("projectJavaFiles()"),
        "ناقصة");

    section("ن — المرحلة 3: محرك إعادة البناء Refactor (وظيفي)");
    String inl = almlk.Refactor.inlineVariable("int a = 5;\nint b = a + 1;\n", "a");
    check("Inline: يحذف الإعلان ويستبدل الاستخدام", inl != null && inl.contains("int b = (5) + 1;")
        && !inl.contains("int a"), String.valueOf(inl));
    check("Inline: null عند غياب الاستخدامات",
        almlk.Refactor.inlineVariable("int a = 5;\n", "a") == null, "ليس null");
    String srcI = "int b = 1 + 2;\n";
    String intro = almlk.Refactor.introduceVariable(srcI, srcI.indexOf("1 + 2"), srcI.indexOf("1 + 2") + 5, "x");
    check("Introduce: يضيف var ويستبدل التعبير", intro != null && intro.contains("var x = 1 + 2;")
        && intro.contains("int b = x;"), String.valueOf(intro));
    check("Introduce: يرفض اسمًا محجوزًا",
        almlk.Refactor.introduceVariable(srcI, 8, 13, "class") == null, "قُبل");
    String srcE = "class C {\n  void m() {\n    foo();\n  }\n}";
    String ext = almlk.Refactor.extractMethod(srcE, srcE.indexOf("foo();"), srcE.indexOf("foo();") + 6, "doFoo");
    check("Extract: يستبدل بنداء ويضيف الدالة", ext != null && ext.contains("doFoo();")
        && ext.contains("private void doFoo() {") && ext.contains("    foo();"), String.valueOf(ext));

    section("س — المرحلة 3: ربط أوامر إعادة البناء بالقوائم (لا ميت)");
    String reg3 = read("app/src/main/java/com/almlkid/ui/EditorMenuRegistry.java");
    check("ربط3: inline/introduce/extract مفعّلة (Java+تحديد+كتابة)",
        reg3.contains("add(PAGE_REFACTOR, \"inline\", \"command_inline_variable\", null, ALWAYS,")
            && reg3.contains("add(PAGE_REFACTOR, \"introduce\", \"command_introduce_variable\", null, ALWAYS,")
            && reg3.contains("add(PAGE_REFACTOR, \"extract_method\", \"command_extract_method\", null, ALWAYS,")
            && reg3.contains("c -> !c.xml && c.hasSelection && c.writable"),
        "معطلة");
    String pg3 = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("ربط3: دوال Refactor موجودة ومربوطة بالحالات",
        pg3.contains("public void refactorInline()") && pg3.contains("public void refactorIntroduce()")
            && pg3.contains("public void refactorExtract()") && pg3.contains("case \"inline\":")
            && pg3.contains("case \"introduce\":") && pg3.contains("case \"extract_method\":"), "ناقص");
    String mn3 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("ربط3: مورد القائمة يعلن أوامر Refactor ويربطها بالمنفّذ",
        mainMenuResource.contains("android:id=\"@id/editorMenuInlineVariable\"")
            && mainMenuResource.contains("android:id=\"@id/editorMenuIntroduceVariable\"")
            && mainMenuResource.contains("android:id=\"@id/editorMenuExtractMethod\"")
            && mn3.contains("itemId == R.id.editorMenuInlineVariable")
            && mn3.contains("itemId == R.id.editorMenuIntroduceVariable")
            && mn3.contains("itemId == R.id.editorMenuExtractMethod")
            && mn3.contains("case \"inline\":"), "الربط مفقود");
    check("ربط3: مسجلة في CommandCenter",
        read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"inline\"")
            && read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"extract_method\""),
        "ناقصة");

    section("ع — أوامر CodeGen: استهداف الحقل، حقول بلا modifiers، والمنشئ الفارغ");
    String cls = "class P {\n  int age;\n  String name;\n}";
    int ageCaret = cls.indexOf("age;") + 1;
    String sg = almlk.CodeGen.createSettersGetters(cls, ageCaret, ageCaret);
    check("CodeGen: يلتقط الحقل بلا modifier ويولّد public له وحده",
        sg != null && sg.contains("public int getAge()")
            && sg.contains("public void setAge(int age)") && !sg.contains("getName()"),
        String.valueOf(sg));
    int nameCaret = cls.indexOf("name;") + 2;
    String nameOnly = almlk.CodeGen.createSettersGetters(cls, nameCaret, nameCaret);
    check("CodeGen: المؤشر على الحقل الثاني لا يولّد الأول",
        nameOnly != null && nameOnly.contains("public String getName()")
            && !nameOnly.contains("getAge()"), String.valueOf(nameOnly));
    int typeCaret = cls.indexOf("int age") + 1;
    String typeTarget = almlk.CodeGen.createSettersGetters(cls, typeCaret, typeCaret);
    check("CodeGen: موضع المؤشر على نوع الحقل يحدد الحقل نفسه",
        typeTarget != null && typeTarget.contains("getAge()") && !typeTarget.contains("getName()"),
        String.valueOf(typeTarget));
    check("CodeGen: لا يولّد accessors عند غياب حقل مستهدف",
        !almlk.CodeGen.hasFieldTarget(cls, cls.indexOf("class P"), cls.indexOf("class P"))
            && almlk.CodeGen.createSettersGetters(cls, cls.indexOf("class P"), cls.indexOf("class P")) == null,
        "قُبل موضع ليس حقلًا");
    String constructor = almlk.CodeGen.createConstructor(cls, ageCaret, ageCaret);
    check("CodeGen: المنشئ يهيّئ الحقل المستهدف فقط",
        constructor != null && constructor.contains("public P(int age)")
            && constructor.contains("this.age = age;") && !constructor.contains("this.name = name;"),
        String.valueOf(constructor));
    int classCaret = cls.indexOf("class P");
    String emptyConstructor = almlk.CodeGen.createConstructor(cls, classCaret, classCaret);
    check("CodeGen: لا حقل عند المؤشر يعني منشئًا فارغًا",
        emptyConstructor != null && emptyConstructor.contains("public P() {")
            && !emptyConstructor.contains("this.age =") && !emptyConstructor.contains("this.name ="),
        String.valueOf(emptyConstructor));
    check("CodeGen: لا يعتبر المتغير المحلي حقلًا",
        !almlk.CodeGen.hasFieldTarget("class P { void m() { String local; } }",
            "class P { void m() { String local; } }".indexOf("local") + 1,
            "class P { void m() { String local; } }".indexOf("local") + 1),
        "اعتُبر المحلي حقلًا");
    String multiple = "class P { int first = 1, second = 2; }";
    String secondOnly = almlk.CodeGen.createSettersGetters(
        multiple, multiple.indexOf("second") + 2, multiple.indexOf("second") + 2);
    check("CodeGen: يفهم أكثر من declarator ويستهدف الاسم المحدد",
        secondOnly != null && secondOnly.contains("getSecond()") && !secondOnly.contains("getFirst()"),
        String.valueOf(secondOnly));
    String finals = "class P { final int serial = 1; }";
    String finalAccessors = almlk.CodeGen.createSettersGetters(
        finals, finals.indexOf("serial") + 2, finals.indexOf("serial") + 2);
    check("CodeGen: حقل final يحصل على getter بلا setter",
        finalAccessors != null && finalAccessors.contains("getSerial()")
            && !finalAccessors.contains("setSerial("), String.valueOf(finalAccessors));
    String noArgumentClass = "class Empty { }";
    String noArgument = almlk.CodeGen.createConstructor(
        noArgumentClass, noArgumentClass.indexOf("Empty") + 1, noArgumentClass.indexOf("Empty") + 1);
    check("CodeGen: يسمح بمنشئ فارغ حتى بلا حقول",
        noArgument != null && noArgument.contains("public Empty()"), String.valueOf(noArgument));
    String existingNoArg = "class Empty { Empty() {} }";
    int existingCaret = existingNoArg.indexOf("Empty") + 1;
    check("CodeGen: يمنع تكرار المنشئ الفارغ المطابق",
        almlk.CodeGen.createConstructor(existingNoArg, existingCaret, existingCaret) == null,
        "تكرر المنشئ");
    String existingDifferent = "class P { int id; P() {} }";
    int idCaret = existingDifferent.indexOf("id;") + 1;
    String overload = almlk.CodeGen.createConstructor(existingDifferent, idCaret, idCaret);
    check("CodeGen: منشئ فارغ موجود لا يمنع overload الحقل",
        overload != null && overload.contains("public P(int id)"), String.valueOf(overload));
    String emptyClass = "class P { int id; }";
    int idPosition = emptyClass.indexOf("id;") + 1;
    String generatedOnce = almlk.CodeGen.createConstructor(emptyClass, idPosition, idPosition);
    check("CodeGen: لا يكرر المنشئ المطابق بعد إنشائه",
        generatedOnce != null && almlk.CodeGen.createConstructor(
            generatedOnce, generatedOnce.indexOf("id;") + 1, generatedOnce.indexOf("id;") + 1) == null,
        String.valueOf(generatedOnce));
    check("CodeGen: null بلا صنف", almlk.CodeGen.createConstructor("int x;", 0, 0) == null, "ليس null");
    String xml = "<TextView android:text=\"Hi\"/>";
    int a = xml.indexOf("Hi");
    String ex = almlk.CodeGen.extractResource(xml, a, a + 2, "greeting");
    check("CodeGen: استخراج مورد يستبدل بـ@string", ex != null && ex.contains("android:text=\"@string/greeting\""),
        String.valueOf(ex));
    check("CodeGen: إدخال string سليم", almlk.CodeGen.stringEntry("greeting", "Hi")
        .contains("<string name=\"greeting\">Hi</string>"), "لا");

    section("ع2 — منظم imports: إزالة آمنة، إضافة للمفقود، وفرز فعلي");
    String importSource = "package demo;\n\nimport java.util.Set;\nimport java.util.List;\n"
        + "import java.util.List;\nimport java.io.File;\n\nclass P { List<String> names; }\n";
    String organizedImports = almlk.JavaImportOrganizer.organize(
        importSource, java.util.Collections.<String>emptyList(), 99);
    check("Imports: يفرز، يزيل التكرار وغير المستخدم، ويحافظ على المستخدم",
        organizedImports.contains("import java.util.List;")
            && !organizedImports.contains("import java.util.Set;")
            && !organizedImports.contains("import java.io.File;")
            && organizedImports.indexOf("import java.util.List;")
                == organizedImports.lastIndexOf("import java.util.List;"),
        String.valueOf(organizedImports));
    String missingImportSource = "package demo;\n\nclass P { List<String> values; }\n";
    String missingImportResult = almlk.JavaImportOrganizer.organize(
        missingImportSource, java.util.Collections.<String>emptyList(), 99);
    check("Imports: يضيف java.util.List رغم عدم وجود import سابق",
        missingImportResult.contains("import java.util.List;")
            && missingImportResult.contains("class P { List<String> values; }"),
        String.valueOf(missingImportResult));
    String commentOnlyUse = "package demo;\nimport java.util.List;\nclass P { // List is only a comment\n int size; }\n";
    String commentOnlyResult = almlk.JavaImportOrganizer.organize(
        commentOnlyUse, java.util.Collections.<String>emptyList(), 99);
    check("Imports: ذكر النوع في تعليق لا يبقي الاستيراد",
        !commentOnlyResult.contains("import java.util.List;"), String.valueOf(commentOnlyResult));
    String candidateSource = "package client;\nclass Use { Widget widget; }\n";
    String candidateResult = almlk.JavaImportOrganizer.organize(candidateSource,
        java.util.Collections.singletonList("model.Widget"), 99);
    check("Imports: يضيف النوع المفقود الوحيد من فهرس المشروع",
        candidateResult.contains("import model.Widget;") && candidateResult.contains("Widget widget"),
        String.valueOf(candidateResult));
    String ambiguous = almlk.JavaImportOrganizer.organize(candidateSource,
        java.util.Arrays.asList("model.Widget", "other.Widget"), 99);
    check("Imports: لا يختار import مبهمًا تلقائيًا",
        !ambiguous.contains("import model.Widget;") && !ambiguous.contains("import other.Widget;"),
        String.valueOf(ambiguous));
    String staticImports = "package demo;\nimport static java.util.Collections.emptyList;\n"
        + "import static java.util.Collections.singletonList;\nclass P { Object v = emptyList(); }\n";
    String staticResult = almlk.JavaImportOrganizer.organize(
        staticImports, java.util.Collections.<String>emptyList(), 99);
    check("Imports: يحافظ على static import المستخدم فقط",
        staticResult.contains("import static java.util.Collections.emptyList;")
            && !staticResult.contains("singletonList"), String.valueOf(staticResult));
    String wildcardResult = almlk.JavaImportOrganizer.organize(
        "package demo;\nimport java.util.Set;\nimport java.util.Map;\nclass P { Set<String> a; Map<String,String> b; }\n",
        java.util.Collections.<String>emptyList(), 1);
    check("Imports: يطبق سقف الاستيرادات المفردة إلى wildcard",
        wildcardResult.contains("import java.util.*;")
            && !wildcardResult.contains("import java.util.Set;")
            && !wildcardResult.contains("import java.util.Map;"), String.valueOf(wildcardResult));
    com.almlkid.kay.ui.ProjectSymbolIndex.clear();
    com.almlkid.kay.ui.ProjectSymbolIndex.registerSource("Widget.java", "ref-widget",
        "package model;\npublic class Widget { int id; }\n");
    java.util.List<com.almlkid.kay.ui.ProjectSymbolIndex.CachedClass> cachedWidget =
        com.almlkid.kay.ui.ProjectSymbolIndex.cachedClassesForFile("Widget.java", "ref-widget");
    com.almlkid.kay.ui.ProjectSymbolIndex.clear();
    if (!cachedWidget.isEmpty()) com.almlkid.kay.ui.ProjectSymbolIndex.registerCachedClass(cachedWidget.get(0));
    check("ProjectSymbols: تُحفظ الحزمة وتُستعاد مع فهرس class cache",
        "model".equals(com.almlkid.kay.ui.ProjectSymbolIndex.packageOf("Widget")),
        String.valueOf(com.almlkid.kay.ui.ProjectSymbolIndex.packageOf("Widget")));
    com.almlkid.kay.ui.ProjectSymbolIndex.clear();

    section("ع3 — أوامر Code النصية: تعليق، إحاطة، واستبدال التحديد");
    String commentSource = "    int a;\n    int b;\n";
    almlk.CodeMenuCommands.Edit commentEdit = almlk.CodeMenuCommands.commentLines(
        commentSource, 0, commentSource.length(), Boolean.TRUE);
    String commentedSource = commentEdit == null ? commentSource
        : commentSource.substring(0, commentEdit.start) + commentEdit.replacement
            + commentSource.substring(commentEdit.end);
    check("Comment: يعلّق الأسطر المحددة مع الاحتفاظ بالإزاحة",
        commentedSource.equals("    // int a;\n    // int b;\n"), commentedSource);
    check("Comment: التعليق الصريح متكرر آمن ولا يضاعف //",
        almlk.CodeMenuCommands.commentLines(commentedSource, 0, commentedSource.length(), Boolean.TRUE) == null,
        "أضاف طبقة تعليق أخرى");
    almlk.CodeMenuCommands.Edit uncommentEdit = almlk.CodeMenuCommands.commentLines(
        commentedSource, 0, commentedSource.length(), Boolean.FALSE);
    String uncommentedSource = uncommentEdit == null ? commentedSource
        : commentedSource.substring(0, uncommentEdit.start) + uncommentEdit.replacement
            + commentedSource.substring(uncommentEdit.end);
    check("Uncomment: يزيل طبقة // دون المساس بالنص",
        uncommentedSource.equals(commentSource), uncommentedSource);
    String partial = "int a;\nint b;\n";
    almlk.CodeMenuCommands.Edit partialEdit = almlk.CodeMenuCommands.commentLines(
        partial, 0, partial.indexOf("int b"), Boolean.TRUE);
    String partialResult = partialEdit == null ? partial
        : partial.substring(0, partialEdit.start) + partialEdit.replacement
            + partial.substring(partialEdit.end);
    check("Comment: نهاية التحديد عند بداية سطر لا تشمل السطر التالي",
        partialResult.equals("// int a;\nint b;\n"), partialResult);
    String wrapSource = "class P {\n    call();\n}\n";
    int callAt = wrapSource.indexOf("call();");
    almlk.CodeMenuCommands.Edit wrapEdit = almlk.CodeMenuCommands.surroundWithTryCatch(
        wrapSource, callAt, callAt + "call();".length(), "  ");
    String wrappedSource = wrapEdit == null ? wrapSource
        : wrapSource.substring(0, wrapEdit.start) + wrapEdit.replacement
            + wrapSource.substring(wrapEdit.end);
    check("Try/catch: يحيط بالسطر ويستعمل وحدة الإزاحة المقدمة",
        wrappedSource.contains("    try {\n      call();\n    } catch (Exception e) {\n      e.printStackTrace();\n    }"),
        wrappedSource);
    check("Try/catch: لا ينشئ كتلة فارغة لتحديد أبيض",
        almlk.CodeMenuCommands.surroundWithTryCatch("  \n", 0, 1, "    ") == null,
        "أنشأ كتلة فارغة");
    check("Replace: يلتقط نص التحديد فقط",
        "needle".equals(almlk.CodeMenuCommands.selectedText("a needle here", 2, 8))
            && "".equals(almlk.CodeMenuCommands.selectedText("a needle here", 4, 4)),
        "نص تحديد خاطئ");
    String codeCommandsPager = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("Code-menu dispatch: comment وtry/catch يستخدمان المحولات المختبرة",
        codeCommandsPager.contains("CodeMenuCommands.commentLines(")
            && codeCommandsPager.contains("CodeMenuCommands.surroundWithTryCatch(")
            && codeCommandsPager.contains("CodeStyle.indentSizeFor(getContext(), activeFile)"),
        "التنفيذ لا يمر عبر محولات الأوامر");
    check("Code-menu replace: يقرأ التحديد قبل finish ويرسله للمضيف بعده",
        codeCommandsPager.contains("CodeMenuCommands.selectedText(")
            && codeCommandsPager.contains("runHostCommand(\"replace\", selectedText)"),
        "مسار الاستبدال فقد التحديد");

    section("ف — المرحلة 4: ربط توليد الكود بالقوائم (لا ميت)");
    String reg4 = read("app/src/main/java/com/almlkid/ui/EditorMenuRegistry.java");
    check("ربط4: setters تتطلب حقلًا مستهدفًا، والمنشئ يسمح بلا حقل، واستخراج XML يتطلب تحديدًا",
        reg4.contains("c -> !c.xml && c.hasFieldTarget && c.writable")
            && reg4.contains("add(PAGE_CODE, \"create_constructor\"")
            && reg4.contains("c -> !c.xml && c.writable")
            && reg4.contains("add(PAGE_CODE, \"extract_resources\", \"command_extract_resources\", null, ALWAYS,")
            && reg4.contains("c -> c.xml && c.hasSelection && c.writable"),
        "أهلية القائمة غير مطابقة للسلوك");
    String pg4 = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("ربط4: دوال CodeGen موجودة ومربوطة",
        pg4.contains("public void codegenSetters()") && pg4.contains("public void codegenConstructor()")
            && pg4.contains("public void codegenExtractResource()") && pg4.contains("case \"create_setters\":")
            && pg4.contains("case \"create_constructor\":") && pg4.contains("case \"extract_resources\":"),
        "ناقصة");
    int settersCase = pg4.indexOf("case \"create_setters\": {");
    int settersCapture = pg4.indexOf("int selectionStart = code.getSelectionStart();", settersCase);
    int settersFinish = pg4.indexOf("mode.finish();", settersCase);
    check("ربط4: تحفظ حدود الحقل قبل إنهاء ActionMode وتمررها للمولّد",
        settersCase >= 0 && settersCapture > settersCase && settersFinish > settersCapture
            && pg4.indexOf("codegenSetters(selectionStart, selectionEnd);", settersFinish) > settersFinish
            && pg4.contains("CodeGen.hasFieldTarget"),
        "فُقد التحديد قبل توليد الدوال");
    check("ربط imports: المنظم يحسب مرشحات المشروع ويستبدل نص المستند",
        pg4.contains("JavaImportOrganizer.organize(")
            && pg4.contains("ProjectSymbolIndex.packageOf(className)")
            && pg4.contains("code.replaceRange(0, text.length(), organized)"),
        "مسار organize_imports لا يطبق التغيير");
    String mn4 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("ربط4: مورد القائمة يعلن أوامر CodeGen ويربطها بالمنفّذ",
        mainMenuResource.contains("android:id=\"@id/editorMenuCreateSetters\"")
            && mainMenuResource.contains("android:id=\"@id/editorMenuCreateConstructor\"")
            && mainMenuResource.contains("android:id=\"@id/editorMenuExtractResources\"")
            && mn4.contains("itemId == R.id.editorMenuCreateSetters")
            && mn4.contains("itemId == R.id.editorMenuCreateConstructor")
            && mn4.contains("itemId == R.id.editorMenuExtractResources")
            && mn4.contains("case \"create_setters\":"), "الربط مفقود");
    check("ربط Replace: يمرر تحديد ActionMode إلى حقل البحث الأولي",
        pg4.contains("CodeMenuCommands.selectedText(")
            && mn4.contains("promptReplace(argument)")
            && mn4.contains("void promptReplace(String initialQuery)")
            && mn4.contains("from.setText(initialQuery == null ? \"\" : initialQuery)"),
        "قيمة التحديد لا تصل إلى حوار الاستبدال");
    check("ربط4: مسجلة في CommandCenter",
        read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"create_setters\"")
            && read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"extract_resources\""),
        "ناقصة");

    section("ص — استكمال قائمة Code: organize/surround حية (لا ميت)");
    String mn5 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("ص: dispatch ينفّذ organize/surround",
        mn5.contains("case \"organize_imports\":") && mn5.contains("case \"surround_try\":"), "غير منفذة");
    check("ص: مورد Code يعلن organize/surround ويربطهما بالمنفّذ",
        mainMenuResource.contains("android:id=\"@id/editorMenuOrganizeImports\"")
            && mainMenuResource.contains("android:id=\"@id/editorMenuSurroundWithTryCatch\"")
            && mn5.contains("itemId == R.id.editorMenuOrganizeImports")
            && mn5.contains("itemId == R.id.editorMenuSurroundWithTryCatch")
            && mn5.contains("case \"organize_imports\":"),
        "الربط مفقود");
    check("ص: مسجلة في CommandCenter بأهلية كتابة",
        read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"organize_imports\"")
            && read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"surround_try\""),
        "ناقصة");

    section("ق — المرحلة 5: نقاط التوقف + تعلّم النمط (وظيفي + ربط)");
    check("نمط: detectIndent يستدل 4", almlk.CodeStyle.detectIndent("    a\n        b\n") == 4,
        "" + almlk.CodeStyle.detectIndent("    a\n        b\n"));
    check("نمط: detectIndent يستدل 2", almlk.CodeStyle.detectIndent("  a\n    b\n") == 2,
        "" + almlk.CodeStyle.detectIndent("  a\n    b\n"));
    String ed5 = read("app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java");
    check("توقف: toggleBreakpointAtCaret + دمج FLAG_BREAKPOINT",
        ed5.contains("public boolean toggleBreakpointAtCaret()") && ed5.contains("breakpoints.contains(line)) flags |= FLAG_BREAKPOINT"),
        "ناقص");
    String rg5 = read("app/src/main/java/com/almlkid/ui/EditorMenuRegistry.java");
    check("توقف/نمط: مفعّلتان (Java / كتابة)",
        rg5.contains("add(PAGE_ROOT, \"breakpoint\", \"command_breakpoint\", null, ALWAYS, c -> !c.xml")
            && rg5.contains("add(PAGE_FORMAT, \"learn_style\", \"command_learn_code_style\", null, ALWAYS, c -> c.writable"),
        "معطلة");
    String pg5 = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("توقف/نمط: معالجان في قائمة التحديد",
        pg5.contains("case \"breakpoint\":") && pg5.contains("code.toggleBreakpointAtCaret()")
            && pg5.contains("case \"learn_style\":"), "ناقص");
    String mn6 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("نمط: مورد القائمة يعلن learn_style ويربطه بالمنفّذ",
        mainMenuResource.contains("android:id=\"@id/editorMenuLearnCodeStyle\"")
            && mn6.contains("itemId == R.id.editorMenuLearnCodeStyle")
            && mn6.contains("case \"learn_style\":" )
            && mn6.contains("void learnCodeStyle()"),
        "الربط مفقود");

    section("ر — المرحلة 1 (الإعدادات): المضيف + المستهلكون");
    check("إعدادات: clampInt/choiceInt نقيان",
        almlk.AppSettings.clampInt("7", 12, 6, 40) == 7
            && almlk.AppSettings.clampInt("99", 12, 6, 40) == 12
            && almlk.AppSettings.clampInt("abc", 12, 6, 40) == 12
            && almlk.AppSettings.choiceInt("2", 4, new int[] {2, 4, 8}) == 2
            && almlk.AppSettings.choiceInt("3", 4, new int[] {2, 4, 8}) == 4,
        "تحليل");
    String host1 = read("app/src/main/java/com/almlkid/ui/preferences/AlmlkPreferencesActivity.java");
    check("مضيف: تبويبان + رؤوس + About + قائمة شظايا",
        host1.contains("NAVIGATION_MODE_TABS") && host1.contains("onBuildHeaders")
            && host1.contains("AboutActivity.class") && host1.contains("isValidFragment")
            && host1.contains("AdvancedSettingsFragment"),
        "ناقص");
    String[] frags1 = {"ApplicationPreferencesFragment", "EditorPreferencesFragment",
        "CodestylePreferencesFragment", "CompilerPreferencesFragment",
        "DropboxPreferencesFragment", "SourceControlPreferencesFragment",
        "KeyBindingsPreferencesFragment", "AdvancedSettingsFragment"};
    boolean fragsOk = true;
    for (String fr : frags1)
      fragsOk &= read("app/src/main/java/com/almlkid/ui/preferences/" + fr + ".java")
          .contains("addPreferencesFromResource") || fr.equals("KeyBindingsPreferencesFragment");
    check("شظايا: الثمان كلها حاضرة", fragsOk
        && read("app/src/main/java/com/almlkid/ui/preferences/KeyBindingsPreferencesFragment.java")
            .contains("createPreferenceScreen"), "ناقص");
    check("xml النمط: 7 مفاتيح",
        read("app/src/main/res/xml/preferences_codestyle.xml").contains("xml_indentation_size")
            && read("app/src/main/res/xml/preferences_codestyle.xml").contains("max_single_imports")
            && read("app/src/main/res/xml/preferences_codestyle.xml").contains("cpp_indentation_size"),
        "ناقص");
    check("مانيفست: نشاطان جديدان",
        read("app/src/main/AndroidManifest.xml")
            .contains("com.almlkid.ui.preferences.AlmlkPreferencesActivity")
            && read("app/src/main/AndroidManifest.xml").contains(".AboutActivity"),
        "غير مسجل");
    String mn7 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("رئيسي: دخول المضيف + حفظ تلقائي + سحب + markSaved",
        mn7.contains("AlmlkPreferencesActivity.class") && mn7.contains("scheduleAutosave()")
            && mn7.contains("attachBrowserSwipe()") && mn7.contains("editor.markSaved()"),
        "ناقص");
    check("تطبيق: لغة من الإعداد",
        read("app/src/main/java/com/shima/demo/ShimaApplication.java").contains("localeFor(")
            && read("app/src/main/java/com/shima/demo/ShimaApplication.java")
                .contains("KEY_LANGUAGE"),
        "ناقص");
    check("محرر: Tab مسافات/\t في الموقعين",
        read("app/src/main/java/almlk/CodeEditorView.java").contains("insertTabOrSpaces()")
            && read("app/src/main/java/almlk/CodeInputConnection.java")
                .contains("editor.insertTabOrSpaces()"),
        "ناقص");
    check("لوحة: عرض تبويب قابل للضبط",
        read("app/src/main/java/almlk/CodeCanvasView.java").contains("setTabSizeChars")
            && read("app/src/main/java/almlk/CodeCanvasView.java")
                .contains("metrics.spaceWidth * tabSizeChars"),
        "ثابت");
    String pg6 = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("pager: تطبيق إعدادات + أهلية الإكمال + لوحة قسرية",
        pg6.contains("applyEditorSettings()") && pg6.contains("completeAfterDot(getContext())")
            && pg6.contains("completeAllTypes(getContext())") && pg6.contains("hasPendingEdits()")
            && pg6.contains("KEYBOARD_NOKEYS"),
        "ناقص");
    check("xml التطبيق: تبويبات المحرر افتراضيًا ظاهرة",
        read("app/src/main/res/xml/preferences_application.xml")
            .contains("android:key=\"editor_tabs\"")
            && read("app/src/main/res/xml/preferences_application.xml")
                .contains("android:defaultValue=\"true\""),
        "رجوع سلوك");

    section("س — المرحلة 2: Code Style متعدد اللغات + Build & Run");
    android.preference.PreferenceManager.reset();
    android.content.Context ctxS = new android.content.Context();
    android.preference.PreferenceManager.store.put("html_indentation_size", "2");
    android.preference.PreferenceManager.store.put("css_indentation_size", "2");
    android.preference.PreferenceManager.store.put("js_indentation_size", "6");
    android.preference.PreferenceManager.store.put("cpp_indentation_size", "8");
    check("نمط: توزّع html/css",
        almlk.CodeStyle.indentSizeFor(ctxS, "a.html") == 2
            && almlk.CodeStyle.indentSizeFor(ctxS, "b.css") == 2,
        almlk.CodeStyle.indentSizeFor(ctxS, "a.html") + "/" + almlk.CodeStyle.indentSizeFor(ctxS, "b.css"));
    check("نمط: توزّع js/cpp",
        almlk.CodeStyle.indentSizeFor(ctxS, "c.js") == 6
            && almlk.CodeStyle.indentSizeFor(ctxS, "d.cpp") == 8,
        almlk.CodeStyle.indentSizeFor(ctxS, "c.js") + "/" + almlk.CodeStyle.indentSizeFor(ctxS, "d.cpp"));
    check("نمط: java/xml كما كانت + سقف الاستيرادات",
        almlk.CodeStyle.indentSizeFor(ctxS, "A.java") == 4
            && almlk.CodeStyle.indentSizeFor(ctxS, "s.xml") == 4
            && almlk.CodeStyle.maxSingleImports(ctxS) == 100,
        "ارتداد");
    android.preference.PreferenceManager.store.put("max_single_imports", "5");
    check("نمط: maxSingleImports يقرأ 5", almlk.CodeStyle.maxSingleImports(ctxS) == 5,
        "" + almlk.CodeStyle.maxSingleImports(ctxS));
    android.preference.PreferenceManager.store.put("max_single_imports", "abc");
    check("نمط: الفاسد يرتدّ 100", almlk.CodeStyle.maxSingleImports(ctxS) == 100,
        "" + almlk.CodeStyle.maxSingleImports(ctxS));
    check("استيرادات: طيّ نجمي حي",
        read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java")
            .contains("almlk.CodeStyle.maxSingleImports(getContext())"),
        "ناقص");
    String cf2 = read("app/src/main/java/com/almlkid/ui/preferences/CompilerPreferencesFragment.java");
    check("بناء: معالجات keystore/maven/ndk",
        cf2.contains("generate_keystore") && cf2.contains("refresh_maven_repository")
            && cf2.contains("install_uninstall_ndksupport") && cf2.contains("PKCS12"),
        "ناقص");
    String mn8 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("بناء: جسر + بيئة + root",
        mn8.contains("BuildActions.delegate") && mn8.contains("buildEnv(root)")
            && mn8.contains("Arrays.asList(\"su\", \"-c\"") && mn8.contains("SHIMA_KEYSTORE"),
        "ناقص");
    check("نمط: بذل المفاتيح الجديدة",
        read("app/src/main/java/almlk/CodeStyle.java").contains("HTML_INDENT_KEY, \"2\"")
            && read("app/src/main/java/almlk/CodeStyle.java").contains("CPP_INDENT_KEY, \"4\""),
        "ناقص");

    section("ش — المرحلة 3: اختصارات + Dropbox/Git");
    android.preference.PreferenceManager.reset();
    android.content.Context ctxK = new android.content.Context();
    check("اختصارات: تحليل نقي",
        almlk.Keybinds.parseMeta("CTRL+SHIFT+F") == 5
            && almlk.Keybinds.keyToken("CTRL+S").equals("S")
            && almlk.Keybinds.tokenForAndroidKeyCode(android.view.KeyEvent.KEYCODE_S).equals("S")
            && almlk.Keybinds.tokenForAndroidKeyCode(android.view.KeyEvent.KEYCODE_F5).equals("F5"),
        "تحليل");
    check("اختصارات: الافتراضيات تُطابق",
        "save".equals(almlk.Keybinds.commandFor(ctxK, true, false, false, android.view.KeyEvent.KEYCODE_S))
            && "run".equals(almlk.Keybinds.commandFor(ctxK, false, false, false, android.view.KeyEvent.KEYCODE_F5))
            && almlk.Keybinds.commandFor(ctxK, false, false, true, android.view.KeyEvent.KEYCODE_S) == null,
        "مطابقة");
    android.preference.PreferenceManager.store.put("keybind_save", "ALT+K");
    check("اختصارات: ربط مخزّن يسبق الافتراضي",
        "save".equals(almlk.Keybinds.commandFor(ctxK, false, true, false, android.view.KeyEvent.KEYCODE_K))
            && almlk.Keybinds.commandFor(ctxK, true, false, false, android.view.KeyEvent.KEYCODE_S) == null,
        "مخزّن");
    String mn9 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("رئيسي: dispatchKeyEvent + مرآة + git",
        mn9.contains("public boolean dispatchKeyEvent(") && mn9.contains("mirrorSync(")
            && mn9.contains("maybeInitGitRepo()") && mn9.contains("SHIMA_GIT_SSH_DIR"),
        "ناقص");
    check("شظية: افتراضات من Keybinds",
        read("app/src/main/java/com/almlkid/ui/preferences/KeyBindingsPreferencesFragment.java")
            .contains("almlk.Keybinds.defaultLabel(id)"),
        "مزدوج");

    section("ت — المرحلة 4: تبويب Advanced كاملًا");
    String adv4 = read("app/src/main/res/xml/preferences_advanced_setting.xml");
    check("متقدم: 8 شاشات كما اللقطة",
        adv4.contains("android:title=\"@string/ui_pref_application_title\"")
            && adv4.contains("android:title=\"@string/ui_group_editor\"")
            && adv4.contains("android:title=\"@string/ui_build_run_title\"")
            && adv4.contains("android:title=\"@string/ui_project_settings_title\"")
            && adv4.contains("android:title=\"@string/ui_shortcut_code\"")
            && adv4.contains("android:title=\"@string/ui_backup_restore_title\"")
            && adv4.contains("android:title=\"@string/ui_experimental_functions\"")
            && adv4.contains("android:title=\"@string/ui_about_category\""),
        "بنية");
    check("متقدم: مفاتيح حية (نسخ/تجارب/رموز)",
        adv4.contains("shima_backup") && adv4.contains("shima_restore")
            && adv4.contains("experimental_crash_report") && adv4.contains("experimental_nav_history")
            && adv4.contains("quick_key_symbol".replace("quick_key_symbol", "preference_quick_key"))
            && adv4.contains("use_adjustPan") && adv4.contains("dark_statusbar"),
        "مفاتيح");
    String af4 = read("app/src/main/java/com/almlkid/ui/preferences/AdvancedSettingsFragment.java");
    check("متقدم: معالجات الشظية",
        af4.contains("ThemeActivity.class") && af4.contains("choose_bg_image")
            && af4.contains("onActivityResult") && af4.contains("shima_backup")
            && af4.contains("shima_restore") && af4.contains("writeProguardConfig")
            && af4.contains("configureGradle"),
        "ناقص");
    String cc4 = read("app/src/main/java/almlk/CodeCanvasView.java");
    check("لوحة: خط مخصص + صورة خلفية",
        cc4.contains("public void setFontPath(") && cc4.contains("setBackgroundImagePath")
            && cc4.contains("backgroundBitmap"),
        "ناقص");
    String pg7 = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("pager: شريط سريع مخصص + علم تجارب",
        pg7.contains("buildQuickKeys()") && pg7.contains("quickBarDisabled()")
            && pg7.contains("experimental_nav_history") && pg7.contains("applyAdvancedSettings()"),
        "ناقص");
    String mn10 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("رئيسي: نافذة/شريط + جسر موسّع",
        mn10.contains("SOFT_INPUT_ADJUST_PAN") && mn10.contains("dark_statusbar")
            && mn10.contains("applyEditorVisual()") && mn10.contains("proguard-rules.pro")
            && mn10.contains("gradle.properties"),
        "ناقص");
    check("تطبيق: علم تقرير الانهيار",
        read("app/src/main/java/com/shima/demo/ShimaApplication.java")
            .contains("experimental_crash_report"),
        "ناقص");

    section("ث — المرحلة 5: الإحلال الشامل");
    check("إحلال: SettingsActivity زالت ملفًا ومرجعًا",
        !new File("/home/user/ShimaProject/app/src/main/java/com/shima/demo/SettingsActivity.java")
            .exists()
            && !read("app/src/main/AndroidManifest.xml").contains("SettingsActivity")
            && !read("app/src/main/java/com/shima/demo/MainActivity.java")
                .contains("SettingsActivity"),
        "بقايا");
    check("قبول: فحوص الأنشطة تحدّثت",
        read("qa/acceptance.sh").contains("AlmlkPreferencesActivity")
            && !read("qa/acceptance.sh").contains("SettingsActivity"),
        "فحوص قديمة");
    check("إحلال: درج وزر رئيسي مستهلَكان",
        read("app/src/main/java/com/shima/demo/MainActivity.java")
            .contains("applyDrawerSettings()")
            && read("app/src/main/java/com/shima/demo/MainActivity.java")
                .contains("LOCK_MODE_LOCKED_CLOSED")
            && read("app/src/main/java/com/shima/demo/MainActivity.java")
                .contains("masterAllowed()"),
        "ناقص");
    check("إحلال: بيت المشاريع من الإعداد",
        read("app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java")
            .contains("projectsHomeDir()")
            && read("app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java")
                .contains("getString(\"project_home\""),
        "ناقص");
    check("إحلال: الزر الرئيسي افتراضي ظاهر",
        read("app/src/main/res/xml/preferences_advanced_setting.xml")
            .contains("android:key=\"enableMainMasterButton\"")
            && read("app/src/main/res/xml/preferences_advanced_setting.xml")
                .contains("android:defaultValue=\"true\""),
        "رجوع سلوك");
    String mainMenuActivity = read("app/src/main/java/com/shima/demo/MainActivity.java");
    String mainMenuXml = read("app/src/main/res/menu/main_options_menu.xml");
    String appLocale = read("app/src/main/java/com/shima/demo/ShimaApplication.java");
    String manifestLocale = read("app/src/main/AndroidManifest.xml");
    check("القائمة الرئيسية: مصدرها res/menu لا صفوف Java مخصصة",
        mainMenuActivity.contains("new PopupMenu(this, anchor, Gravity.END)")
            && mainMenuActivity.contains("getMenuInflater().inflate(R.menu.main_options_menu, menu)")
            && !mainMenuActivity.contains("class IdeMenuEntry")
            && !mainMenuActivity.contains("ideMenuWindow")
            && mainMenuXml.contains("android:title=\"@string/command_go_to_element\"")
            && mainMenuXml.contains("android:title=\"@string/command_forward\"")
            && mainMenuXml.contains("android:title=\"@string/command_save\""),
        "القائمة غير معرفة بموارد XML أو عادت تسميات المفاتيح الخام");
    check("اللغة: LTR ثابت واستعادة النشاط الرئيسي عند تغيير الاختيار",
        !appLocale.contains("updateConfiguration(")
            && manifestLocale.contains("android:supportsRtl=\"false\"")
            && mainMenuActivity.contains("languageAtLastCreate.equals(selectedLanguage)")
            && mainMenuActivity.contains("recreate();"),
        "إعداد الاتجاه أو مسار إعادة الإنشاء غير سليم");
    check("إصدار: 1.0.101", read("VERSION").trim().equals("1.0.101"), read("VERSION").trim());

    section("خ — القائمة المحلية واتجاه التخطيط الثابت");
    check("القائمة: كل العناوين من موارد strings",
        !mainMenuXml.contains("android:title=\"command_")
            && mainMenuXml.contains("@string/ui_selection_mode_edit")
            && mainMenuXml.contains("@string/command_more")
            && mainMenuXml.contains("@string/command_settings"),
        "تسمية خام أو عنوان غير محلي");

    section("ذ — إصلاح «commit already called» في تبويبي الإعدادات");
    String hostZ = read("app/src/main/java/com/almlkid/ui/preferences/AlmlkPreferencesActivity.java");
    int tabSelStart = hostZ.indexOf("public void onTabSelected");
    int tabSelEnd = hostZ.indexOf("public void onTabUnselected");
    check("مضيف: onTabSelected لا يلمس معاملة الإطار",
        tabSelStart >= 0 && tabSelEnd > tabSelStart
            && !hostZ.substring(tabSelStart, tabSelEnd).contains("transaction.")
            && hostZ.substring(tabSelStart, tabSelEnd).contains("commitAllowingStateLoss()"),
        "معاملة الإطار");

    section("ظ — المرحلة 1: الضغط المطوّل وحدود المعرّف");
    String canvasSelection = read("app/src/main/java/almlk/CodeCanvasView.java");
    int selectWordStart = canvasSelection.indexOf("public boolean selectWordAt(");
    int selectWordEnd = canvasSelection.indexOf("public void selectAll(", selectWordStart);
    String selectWordBody = selectWordStart < 0 || selectWordEnd < selectWordStart
        ? "" : canvasSelection.substring(selectWordStart, selectWordEnd);
    check("الضغط المطوّل: الحرف المضغوط يمر عبر rangeAt الموحد",
        selectWordBody.contains("IdentifierBounds.rangeAt(lineText, column)"), "مسار اللمس غير موصول");
    String editorSelection = read("app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java");
    int normalizeStart = editorSelection.indexOf("public void normalizeSelectionToTouchedIdentifier(");
    int normalizeEnd = editorSelection.indexOf("// ---------------- TextWatcher", normalizeStart);
    String normalizeBody = normalizeStart < 0 || normalizeEnd < normalizeStart
        ? "" : editorSelection.substring(normalizeStart, normalizeEnd);
    check("الضغط المطوّل: يوسّع التحديد الجزئي قبل إظهار الإجراءات",
        normalizeBody.contains("IdentifierBounds.wholeIdentifierForSelection")
            && normalizeBody.contains("colorLiteralSelectionRange()"), "التطبيع غير موصول");
    check("الضغط المطوّل: لا يعيد ضبط المدى الكامل المطابق",
        normalizeBody.contains("range[0] != selectionStart")
            && normalizeBody.contains("range[1] != selectionEnd"), "إعادة ضبط غير لازمة");

    section("ش — المرحلة 2: مقبض caret المنفرد");
    String handleController = read("app/src/main/java/almlk/EditorHandleController.java");
    check("مقبض caret: drawable من الثيم ومهلة 3 ثوانٍ",
        handleController.contains("android.R.attr.textSelectHandle")
            && handleController.contains("HIDE_DELAY_MS = 3000L"), "المورد/المهلة ناقصة");
    check("مقبض caret: مؤقت مستقل يتوقف أثناء السحب",
        handleController.contains("host.postDelayed(hideTask, HIDE_DELAY_MS)")
            && handleController.contains("host.removeCallbacks(hideTask)")
            && handleController.contains("public void beginDrag()")
            && handleController.contains("public void endDrag()"), "دورة المؤقت ناقصة");
    String caretCanvas = read("app/src/main/java/almlk/CodeCanvasView.java");
    check("مقبض caret: العرض والالتقاط يستعملان إحداثيات اللوحة نفسها",
        caretCanvas.contains("caretHandleController.draw(canvas, handleX(caretLine, caretColumn), handleY(caretLine))")
            && caretCanvas.contains("caretHandleController.hitTest("), "انفصال قياس الرسم/اللمس");
    check("مقبض caret: السحب يحرك المؤشر مع تعويض نقطة الارتكاز",
        caretCanvas.contains("TOUCH_HANDLE_CARET")
            && caretCanvas.contains("moveCaretFromHandle(event.getX(), event.getY())")
            && caretCanvas.contains("caretHandleDragOffsetY"), "مسار السحب غير مكتمل");
    check("مقبض caret: يظهر بعد نقرة ويختفي عند التحديد وفقدان التركيز والفصل",
        caretCanvas.contains("caretHandleController.show()")
            && caretCanvas.contains("if (selectionMode) caretHandleController.hide()")
            && caretCanvas.contains("if (!gainFocus) {")
            && caretCanvas.contains("cancelActiveHandleGesture();\n      caretHandleController.hide();")
            && caretCanvas.contains("caretHandleController.hide();\n    super.onDetachedFromWindow();"),
        "دورة حياة المقبض غير مكتملة");
    check("مقبض caret: لا يدمج مؤقت العرض مع وميض CaretBlinker",
        !handleController.contains("CaretBlinker")
            && caretCanvas.contains("private final CaretBlinker caretBlinker;")
            && caretCanvas.contains("private final EditorHandleController caretHandleController;"),
        "دمج غير مقصود");

    section("ص — المرحلة 3: مقابض طرفي التحديد");
    int horizontalBoundsStart = caretCanvas.indexOf("private int maxScrollX()");
    int horizontalBoundsEnd = caretCanvas.indexOf("private int maxScrollY()", horizontalBoundsStart);
    String horizontalBounds = horizontalBoundsStart < 0 || horizontalBoundsEnd < horizontalBoundsStart
        ? "" : caretCanvas.substring(horizontalBoundsStart, horizontalBoundsEnd);
    check("مقابض التحديد: حد التمرير الأفقي لا يضيف الجالتر مرتين",
        horizontalBounds.contains("contentWidth - getWidth()")
            && !horizontalBounds.contains("+ gutterWidth"), horizontalBounds);
    check("مقابض التحديد: تحميل رسومي البداية/النهاية من الثيم مع بقاء caret",
        handleController.contains("android.R.attr.textSelectHandleLeft")
            && handleController.contains("android.R.attr.textSelectHandleRight")
            && handleController.contains("public void drawSelectionStart(")
            && handleController.contains("public void drawSelectionEnd(")
            && handleController.contains("public void draw(Canvas canvas, float anchorX, float anchorY)"),
        "رسوم الأطراف أو مقبض caret ناقصة");
    check("مقابض التحديد: استبدال الدائرتين وتطابق نقاط الرسم والالتقاط",
        caretCanvas.contains("caretHandleController.drawSelectionStart(")
            && caretCanvas.contains("caretHandleController.drawSelectionEnd(")
            && caretCanvas.contains("hitTestSelectionStart(")
            && caretCanvas.contains("hitTestSelectionEnd(")
            && !caretCanvas.contains("drawCircle(startX"), "الرسم/الالتقاط غير موحّد");
    check("مقابض التحديد: تثبيت الطرف المقابل وتبديل الطرف المرئي عند العبور",
        caretCanvas.contains("selectionHandleFixedLine = startHandle ? ordered[2] : ordered[0]")
            && caretCanvas.contains("selectionHandleFixedColumn = startHandle ? ordered[3] : ordered[1]")
            && caretCanvas.contains("anchorLine = selectionHandleFixedLine")
            && caretCanvas.contains("int[] sel = orderedSelection();"), "تثبيت/ترتيب الطرف غير مكتمل");
    check("مقابض التحديد: تحويل مشترك للإحداثيات بعد الإزاحة والتمرير والسطر/العمود",
        caretCanvas.contains("positionFromHandlePoint(")
            && caretCanvas.contains("return positionFromPoint(x, y);")
            && caretCanvas.contains("x + getScrollX() - gutterWidth")
            && caretCanvas.contains("y + getScrollY()"), "تحويل الإحداثيات متباين");
    check("مقابض التحديد: أولوية الالتقاط ومنع اعتراض الأب والقرص أثناء السحب",
        caretCanvas.contains("beginSelectionHandleDrag(true, ordered, event)")
            && caretCanvas.contains("beginSelectionHandleDrag(false, ordered, event)")
            && caretCanvas.contains("if (startHit && endHit)")
            && caretCanvas.contains("startIsNearer")
            && caretCanvas.contains("requestParentDisallowIntercept(true)")
            && caretCanvas.contains("touchState != TOUCH_HANDLE_START")
            && caretCanvas.contains("touchState != TOUCH_HANDLE_END"), "أولوية اللمس غير مضمونة");
    check("مقابض التحديد: السحب اللمسي يفعّل سياق الإجراءات عند الحاجة فقط",
        caretCanvas.contains("boolean wasTouchSelection = selectionFromTouch")
            && caretCanvas.contains("selectionFromTouch = true;")
            && caretCanvas.contains("if (!wasTouchSelection && interactions != null) {")
            && caretCanvas.contains("interactions.onSelectionModeChanged(true);"),
        "سياق اللمس غير مفعّل");
    check("مقابض التحديد: تمرير آلي للحافتين وإعادة إسقاط الطرف أثناءه",
        caretCanvas.contains("postOnAnimation(selectionHandleAutoScroll)")
            && caretCanvas.contains("selectionHandleScrollDelta(selectionHandlePointerX, getWidth())")
            && caretCanvas.contains("selectionHandleScrollDelta(selectionHandlePointerY, getHeight())")
            && caretCanvas.contains("scrollTo(oldX + dx, oldY + dy)")
            && caretCanvas.contains("moveSelectionHandle(selectionHandlePointerX, selectionHandlePointerY)"),
        "التمرير الآلي غير مكتمل");
    check("مقابض التحديد: بدء التحديد يخفي caret والطيّ/الخروج يعيدان المقبض",
        caretCanvas.contains("caretHandleController.hide();\n    caretBlinker.holdVisible();")
            && caretCanvas.contains("private void finishSelectionHandleDrag(boolean feedback)")
            && caretCanvas.contains("if (hasFocus() && hasWindowFocus()) caretHandleController.show()")
            && caretCanvas.contains("if (restoreTouchCaret && hasFocus() && hasWindowFocus()) caretHandleController.show()"),
        "تحويل سلوك المقابض غير مكتمل");

    section("ح — المرحلة 4: دورة ActionMode والقوائم دون استبدال السجل");
    String pagerCycle = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    String editorCycle = read("app/src/main/java/almlk/CodeEditorView.java");
    String registrySource = read("app/src/main/java/com/almlkid/ui/EditorMenuRegistry.java");
    int callback = pagerCycle.indexOf("code.setCustomSelectionActionModeCallback(");
    int create = pagerCycle.indexOf("public boolean onCreateActionMode(ActionMode mode, android.view.Menu menu)", callback);
    int prepare = pagerCycle.indexOf("public boolean onPrepareActionMode(ActionMode mode, android.view.Menu menu)", create);
    String createBody = create < 0 || prepare < create ? "" : pagerCycle.substring(create, prepare);
    check("ActionMode: التحديد اللمسي يطبع المدى ويبني التولبار من السجل نفسه",
        callback >= 0 && createBody.contains("code.normalizeSelectionToTouchedIdentifier()")
            && createBody.contains("applySelectionToolbarState(menu)")
            && createBody.contains("styleSelectionIcon(menu, almlk.CodeEditorView.ID_CUT")
            && createBody.contains("menu.add(0, MORE_MENU"), "حلقة التهيئة/التولبار ناقصة");
    check("ActionMode: يعيد إظهار IME فقط إن كان ظاهرًا وبقي الوضع نشطًا",
        createBody.contains("imeWasVisible") && createBody.contains("if (imm != null)")
            && createBody.contains("actionModeActive && code.hasFocus()")
            && createBody.contains("imm.showSoftInput(code, 0)"), "حارس لوحة المفاتيح ناقص");
    int popupStart = pagerCycle.indexOf("private void showSelectionMenu(ActionMode mode, String page)", create);
    int executeStart = pagerCycle.indexOf("private void executeEditorMenuCommand(String id, ActionMode mode)", popupStart);
    String popupBody = popupStart < 0 || executeStart < popupStart
        ? "" : pagerCycle.substring(popupStart, executeStart);
    check("القائمة المتدرجة: تقرأ صفحاتها من EditorMenuRegistry وتنفّذ/تعود بشكل حي",
        popupBody.contains("editorMenuRegistry.entries(page, context)")
            && popupBody.contains("showSelectionMenu(mode, entry.subpage)")
            && popupBody.contains("selectionMenu.dismiss()")
            && popupBody.contains("executeEditorMenuCommand(entry.id, mode)"), "ربط الصفحات أو الأوامر مفقود");
    check("القائمة المتدرجة: نافذة غير مركّزة ولا تغيّر IME وتقبل اللمس الخارجي",
        popupBody.contains("new PopupWindow(container, dp(250), ViewGroup.LayoutParams.WRAP_CONTENT, false)")
            && popupBody.contains("PopupWindow.INPUT_METHOD_NOT_NEEDED")
            && popupBody.contains("SOFT_INPUT_STATE_UNCHANGED")
            && popupBody.contains("selectionMenu.setOutsideTouchable(true)"), "خصائص النافذة تغيّرت");
    int clickStart = pagerCycle.indexOf("public boolean onActionItemClicked(ActionMode mode, android.view.MenuItem item)", executeStart);
    int destroyStart = pagerCycle.indexOf("public void onDestroyActionMode(ActionMode mode)", clickStart);
    String clickBody = clickStart < 0 || destroyStart < clickStart
        ? "" : pagerCycle.substring(clickStart, destroyStart);
    check("⋮: يفتح الجذر عبر more ويبقي التوسيع عبر مداه الحالي",
        clickBody.contains("id == MORE_MENU") && clickBody.contains("probeQuickFixThenShow(mode)")
            && clickBody.contains("id == EXPAND_SELECTION") && clickBody.contains("expandCodeSelection()"),
        "مسار التولبار غير مكتمل");
    int probeStart = pagerCycle.indexOf("private void probeQuickFixThenShow(ActionMode mode)");
    int probeEnd = pagerCycle.indexOf("private void showSelectionMenu(ActionMode mode, String page)", probeStart);
    String probeBody = probeStart < 0 || probeEnd < probeStart
        ? "" : pagerCycle.substring(probeStart, probeEnd);
    check("Quick Fix: يفحص نسخة المستند والمدى قبل العرض والتنفيذ",
        probeBody.contains("documentVersion = code.getDocument().version()")
            && probeBody.contains("request != quickFixGeneration")
            && probeBody.contains("code.getDocument().version() != documentVersion")
            && probeBody.contains("code.getSelectionStart() != selectionStart")
            && pagerCycle.contains("if (!pendingQuickFixContextCurrent())"), "حارس الإصلاح الباهت مفقود");
    check("ActionMode: الإغلاق يلغي العامل ويزيل النافذة دون لمس سجل الأوامر",
        pagerCycle.contains("actionModeActive = false;")
            && pagerCycle.contains("quickFixGeneration++;")
            && pagerCycle.contains("selectionMenu.dismiss();\n              selectionMenu = null;"), "تنظيف الإغلاق ناقص");
    int commandStart = executeStart;
    int commandEnd = pagerCycle.indexOf("private void resolveDefinitionOnDemand(ActionMode mode)", commandStart);
    String commandBody = commandStart < 0 || commandEnd < commandStart
        ? "" : pagerCycle.substring(commandStart, commandEnd);
    check("الأوامر ذات النطاق تُنفّذ قبل finish الذي يمحو التحديد",
        callsBeforeModeFinish(commandBody, "rename", "renameCurrentSelection()")
            && callsBeforeModeFinish(commandBody, "inline", "refactorInline()")
            && callsBeforeModeFinish(commandBody, "introduce", "refactorIntroduce()")
            && callsBeforeModeFinish(commandBody, "extract_method", "refactorExtract()")
            && callsBeforeModeFinish(commandBody, "extract_resources", "codegenExtractResource()")
            && callsBeforeModeFinish(commandBody, "comment", "commentLines()")
            && callsBeforeModeFinish(commandBody, "uncomment", "uncommentLines()")
            && callsBeforeModeFinish(commandBody, "surround_try", "surroundWithTryCatch()"),
        "أُغلق ActionMode قبل التقاط النطاق");
    int introduceStart = pagerCycle.indexOf("public void refactorIntroduce()");
    int extractStart = pagerCycle.indexOf("public void refactorExtract()", introduceStart);
    int promptStart = pagerCycle.indexOf("private void promptRefactorName(", extractStart);
    String introduceBody = introduceStart < 0 || extractStart < introduceStart
        ? "" : pagerCycle.substring(introduceStart, extractStart);
    String extractBody = extractStart < 0 || promptStart < extractStart
        ? "" : pagerCycle.substring(extractStart, promptStart);
    check("Refactor المؤجل: يحفظ النطاق ويتحقق من نسخة الملف بعد إغلاق ActionMode",
        introduceBody.contains("selectionStart = code.getSelectionStart()")
            && introduceBody.contains("selectionEnd = code.getSelectionEnd()")
            && introduceBody.contains("documentVersion")
            && introduceBody.contains("Refactor.introduceVariable(text, selectionStart, selectionEnd, name)")
            && extractBody.contains("selectionStart = code.getSelectionStart()")
            && extractBody.contains("Refactor.extractMethod(text, selectionStart, selectionEnd, name)")
            && extractBody.contains("java.util.Objects.equals(fileAtStart, activeFile)"), "المدى المؤجل قابل للفقد/التقادم");
    String[] executableCommands = {
      "color", "goto", "documentation", "organize_imports", "surround_try", "comment",
      "uncomment", "replace", "format_code", "configure_style", "find_usages", "find_extended",
      "find_text", "rename", "inline", "introduce", "extract_method", "breakpoint",
      "learn_style", "create_setters", "create_constructor", "extract_resources", "close"
    };
    boolean everyCommandRouted = true;
    for (String id : executableCommands) everyCommandRouted &= commandBody.contains("case \"" + id + "\":");
    check("السجل: كل الأوامر الثابتة المعلنة لها مسار تنفيذ في Pager",
        everyCommandRouted, "معرّف سجل بلا case");
    check("PAGE_SMALL: يبقى غير موصول ولا تُحذف تعريفاته في هذه المرحلة",
        registrySource.contains("PAGE_SMALL = \"small\"")
            && registrySource.contains("add(PAGE_SMALL, \"design\"")
            && !pagerCycle.contains("EditorMenuRegistry.PAGE_SMALL"), "تغيير غير مطلوب في الصفحة المصغرة");
    check("التمييز: ActionMode يأتي من اللمس فقط، بينما البحث/التحديد البرمجي لا يفتحه تلقائيًا",
        editorCycle.contains("if (active && hasSelection() && selectionFromTouch) startSelectionActionMode()")
            && editorCycle.contains("onShowSelectionActionsRequested()")
            && editorCycle.contains("startSelectionActionMode();"), "خلط بين مصدرَي التحديد");
    int longPressStart = caretCanvas.indexOf("private void onLongPressTimeout()");
    int longPressEnd = caretCanvas.indexOf("private void selectionFeedback()", longPressStart);
    String longPressBody = longPressStart < 0 || longPressEnd < longPressStart
        ? "" : caretCanvas.substring(longPressStart, longPressEnd);
    check("اللمس: long-press وdouble-tap وبداية/نهاية الرمز تمر إلى range الموحد",
        longPressBody.contains("selectWordAt(pos[0], characterColumnFromPoint(pos[0], downX))")
            && longPressBody.contains("onShowSelectionActionsRequested()")
            && caretCanvas.contains("if (doubleTap)")
            && caretCanvas.contains("selectWordAt(pos[0], characterColumnFromPoint(pos[0], event.getX()))")
            && caretCanvas.contains("IdentifierBounds.rangeAt(lineText, column)"), "تدفق اللمس/المدى ناقص");
    int touchMoveStart = caretCanvas.indexOf("case MotionEvent.ACTION_MOVE:");
    int touchMoveEnd = caretCanvas.indexOf("case MotionEvent.ACTION_POINTER_UP:", touchMoveStart);
    String touchMoveBody = touchMoveStart < 0 || touchMoveEnd < touchMoveStart
        ? "" : caretCanvas.substring(touchMoveStart, touchMoveEnd);
    check("اللمس: حركة الإصبع بعد long-press لا تقصّر تحديد VOICE_INSTALLED",
        touchMoveBody.contains("Deliberately leave TOUCH_SELECTING unchanged")
            && !touchMoveBody.contains("setCaretExtendingSelection(pos[0], pos[1])"),
        "حركة الإصبع أعادت طرف التحديد إلى موضع اللمس");
    check("المقابض: Hotspots وأبعاد drawable وموضع الارتكاز تطابق المرجع",
        handleController.contains("CARET_ANCHOR_X = 0.5f")
            && handleController.contains("SELECTION_START_ANCHOR_X = 0.8f")
            && handleController.contains("SELECTION_END_ANCHOR_X = 0.2f")
            && handleController.contains("anchorX - asset.anchorFractionX * asset.widthPx")
            && handleController.contains("return intrinsic > 0 ? intrinsic : fallback;")
            && caretCanvas.contains(
                "return line * lineStride() + metrics.lineHeight + lineSpacingExtra / 2f - getScrollY();"),
        "اختلاف في مرساة/حجم المقبض أو موضعه العمودي");
  }

  // ═════════════ تشخيصات المشروع والبناء: دقة المدى، المسار، والإصلاح ═════════════
  static void projectDiagnosticsAndBuildOutput() throws Exception {
    section("تشخيصات المشروع والبناء: موضع دقيق، تجميع، وإصلاح آمن");
    ProjectSymbolIndex.clear();
    String helper =
        "package example;\npublic class ClipboardHelper extends SQLiteOpenHelper {\n}\n";
    String callLine = "  void copy() { clibs.getstr(); }";
    String caller =
        "package example;\n"
            + "class ClipboardUser {\n"
            + "  ClipboardHelper clibs = new ClipboardHelper();\n"
            + callLine + "\n"
            + "}\n";
    ProjectSymbolIndex.registerSource("ClipboardHelper.java", "/project/src/ClipboardHelper.java", helper);
    ProjectSymbolIndex.registerSource("ClipboardUser.java", "/project/src/ClipboardUser.java", caller);

    List<CodeLanguageTools.Diagnostic> sourceErrors =
        CodeLanguageTools.inspect("ClipboardUser.java", caller);
    CodeLanguageTools.Diagnostic missing = null;
    int missingCount = 0;
    for (CodeLanguageTools.Diagnostic item : sourceErrors) {
      if ("ui_diagnostic_missing_method".equals(item.messageKey)) {
        missing = item;
        missingCount++;
      }
    }
    check("فحص المشروع يكتشف استدعاء عضو غير موجود في نوع مستقبل مفهرس من ملف آخر",
        missingCount == 1 && missing != null && missing.line == 4
            && missing.offset == caller.indexOf("getstr")
            && ProjectSymbolIndex.canDiagnoseMissingMethod("ClipboardHelper", "getstr")
            && !ProjectSymbolIndex.canDiagnoseMissingMethod("ClipboardHelper", "getReadableDatabase")
            && !ProjectSymbolIndex.canDiagnoseMissingMethod("View"),
        "diagnostics=" + sourceErrors.size() + ", missing=" + missingCount);
    String sqliteApiUse =
        "package example; class SqliteApiUse { ClipboardHelper clibs; "
            + "void open() { clibs.getReadableDatabase(); } }";
    ProjectSymbolIndex.registerSource("SqliteApiUse.java", "/project/src/SqliteApiUse.java", sqliteApiUse);
    check("تحليل subclass من SQLiteOpenHelper يحترم API المعروف ولا يخلطه بعضو مفقود",
        CodeLanguageTools.inspect("SqliteApiUse.java", sqliteApiUse).isEmpty(),
        CodeLanguageTools.inspect("SqliteApiUse.java", sqliteApiUse).toString());
    ProjectSymbolIndex.registerSource(
        "CustomView.java", "/project/src/CustomView.java",
        "class CustomView extends View { void render() { setNotARealSdkMethod(); } }");
    ProjectSymbolIndex.registerSource(
        "Marked.java", "/project/src/Marked.java",
        "class Marked implements Runnable { public void run() {} void call() { unknown(); } }");
    check("فحص الاستدعاء يتجنب APIs المبتورة والآباء/الواجهات الخارجية",
        !ProjectSymbolIndex.canDiagnoseMissingMethod("CustomView")
            && !ProjectSymbolIndex.canDiagnoseMissingMethod("Marked"),
        "تم اعتبار سلسلة وراثة غير مكتملة مرجعًا يقينيًا");
    ProjectSymbolIndex.clear();
    String chainedSource =
        "package example; class Buffer {} class Wrapper { Buffer buffer; } "
            + "class Use { Wrapper wrapper; void run() { wrapper.buffer.missing(); } }";
    ProjectSymbolIndex.registerSource("ChainedUse.java", "/project/src/ChainedUse.java", chainedSource);
    List<CodeLanguageTools.Diagnostic> chainedErrors =
        CodeLanguageTools.inspect("ChainedUse.java", chainedSource);
    int chainedMissing = 0;
    for (CodeLanguageTools.Diagnostic item : chainedErrors)
      if ("ui_diagnostic_missing_method".equals(item.messageKey)
          && item.message.contains("Buffer.missing")) chainedMissing++;
    check("تشخيص السلسلة الموثّقة يستهدف نوع الحقل النهائي فقط",
        chainedMissing == 1,
        "التشخيصات=" + chainedErrors.size() + ", Buffer.missing=" + chainedMissing);
    String cleanJava =
        "package example; class RecordSample { void record(int value) {} "
            + "void use() { record(1); Class<?> type = RecordSample.class; } }";
    ProjectSymbolIndex.clear();
    check("التحليل لا يخلط method باسم record أو .class بإعلانات مكسورة",
        CodeLanguageTools.inspect("RecordSample.java", cleanJava).isEmpty(),
        CodeLanguageTools.inspect("RecordSample.java", cleanJava).toString());
    String textBlockSource =
        "package example; class TextBlockSample { String payload = \"\"\"\n"
            + "  clibs.getstr(); class Phantom { void fake() {} }\n"
            + "\"\"\"; ClipboardHelper clibs = new ClipboardHelper();\n"
            + "  void run() { clibs.getstr(); } }\n";
    ProjectSymbolIndex.clear();
    ProjectSymbolIndex.registerSource("ClipboardHelper.java", "/project/src/ClipboardHelper.java", helper);
    ProjectSymbolIndex.registerSource("TextBlockSample.java", "/project/src/TextBlockSample.java", textBlockSource);
    List<CodeLanguageTools.Diagnostic> textBlockErrors =
        CodeLanguageTools.inspect("TextBlockSample.java", textBlockSource);
    int textBlockMissing = 0;
    for (CodeLanguageTools.Diagnostic item : textBlockErrors)
      if ("ui_diagnostic_missing_method".equals(item.messageKey)) textBlockMissing++;
    check("النص متعدد الأسطر لا يولّد كودًا أو أقواسًا وهمية ويظل التحليل حيًا بعده",
        textBlockErrors.size() == 1 && textBlockMissing == 1,
        textBlockErrors.toString());
    String cascadeSource = "class Broken { void run() { call(] } }\n";
    List<CodeLanguageTools.Diagnostic> cascadeErrors =
        CodeLanguageTools.inspect("Broken.java", cascadeSource);
    check("خطأ القوس الواحد لا يضاعف تشخيصات الإغلاق التابعة له",
        cascadeErrors.size() == 1
            && "ui_diagnostic_illegal_start_of_expression".equals(cascadeErrors.get(0).messageKey),
        cascadeErrors.toString());
    String gradleScript =
        "plugins { id 'com.android.application' }\n"
            + "dependencies { implementation 'androidx.core:core:1.19.1' }\n"
            + "ext.note = '''\n } // delimiters remain inside the Gradle string\n '''\n";
    check("DSL صالح في build.gradle لا يُفحص كمصدر Java فتختفي الخطوط الحمراء الوهمية",
        CodeLanguageTools.inspect("build.gradle", gradleScript).isEmpty(),
        CodeLanguageTools.inspect("build.gradle", gradleScript).toString());
    // ---- فاحص الجمل النحوي (almlk.JavaSyntaxChecker): حالات محددة بمواضع javac ----
    String syntaxSample = read("qa/samples/SyntaxSample.java");
    check("فاحص الجمل: عينة جافا حديثة صحيحة (أنواع وتعبيرات وأنماط) بلا أي تشخيص",
        CodeLanguageTools.inspect("SyntaxSample.java", syntaxSample).isEmpty(),
        CodeLanguageTools.inspect("SyntaxSample.java", syntaxSample).toString());
    List<CodeLanguageTools.Diagnostic> semicolons =
        CodeLanguageTools.inspect("Semi.java", "class Semi {\n  int x = 5\n  void f() { int y = 6 }\n}\n");
    check("فاحص الجمل: كل فاصلة منقوطة مفقودة تُبلَّغ في سطرها ويكمل الفحص بعدها",
        semicolons.size() == 2
            && semicolons.get(0).line == 2
            && semicolons.get(1).line == 3
            && "ui_diagnostic_missing_semicolon".equals(semicolons.get(0).messageKey),
        semicolons.toString());
    List<CodeLanguageTools.Diagnostic> parens =
        CodeLanguageTools.inspect("Paren.java", "class Paren {\n  void f() {\n    foo(a, b;\n    bar();\n  }\n}\n");
    check("فاحص الجمل: القوس المفقود يُبلَّغ في السطر الذي انتهى فيه الاستدعاء لا عند الإغلاق اللاحق",
        parens.size() == 1 && parens.get(0).line == 3
            && "ui_diagnostic_expected_token".equals(parens.get(0).messageKey),
        parens.toString());
    List<CodeLanguageTools.Diagnostic> openBlock =
        CodeLanguageTools.inspect("Open.java", "class Open {\n  void f() {\n    if (x) {\n      y();\n  }\n}\n");
    check("فاحص الجمل: الكتلة غير المغلقة تُبلَّغ بنهاية ملف غير متوقعة عند آخر رمز",
        openBlock.size() == 1 && openBlock.get(0).line == 6
            && "ui_diagnostic_reached_end_of_file".equals(openBlock.get(0).messageKey),
        openBlock.toString());
    List<CodeLanguageTools.Diagnostic> unclosedQuote =
        CodeLanguageTools.inspect("Quote.java", "class Quote {\n  String s = \"abc;\n  int z = 1;\n}\n");
    check("فاحص الجمل: النص غير المغلق خطأ واحد في سطره بلا تبعات على السطور التالية",
        unclosedQuote.size() == 1 && unclosedQuote.get(0).line == 2
            && "ui_diagnostic_unclosed_string".equals(unclosedQuote.get(0).messageKey),
        unclosedQuote.toString());
    List<CodeLanguageTools.Diagnostic> elseOrphan =
        CodeLanguageTools.inspect("Else.java", "class Else {\n  void f() {\n    int a = 1;\n    else { a = 2; }\n  }\n}\n");
    check("فاحص الجمل: else بلا if يُبلَّغ في سطره بالعبارة نفسها التي يعرضها javac",
        elseOrphan.size() == 1 && elseOrphan.get(0).line == 4
            && "ui_diagnostic_else_without_if".equals(elseOrphan.get(0).messageKey),
        elseOrphan.toString());
    List<CodeLanguageTools.Diagnostic> interfaceField =
        CodeLanguageTools.inspect("Api.java", "interface Api {\n  int LIMIT;\n}\n");
    check("فاحص الجمل: حقل الواجهة بلا قيمة ابتدائية خطأ نحوي كما في javac",
        interfaceField.size() == 1 && interfaceField.get(0).line == 2,
        interfaceField.toString());
    List<CodeLanguageTools.Diagnostic> annotationArgs =
        CodeLanguageTools.inspect("Note.java",
            "class Note {\n  @Deprecated(since = \"9\", forRemoval true)\n  void f() {}\n}\n");
    check("فاحص الجمل: وسيطات الإشعار تُفحص بنحو الأزواج name=value",
        annotationArgs.size() == 1 && annotationArgs.get(0).line == 2,
        annotationArgs.toString());
    List<CodeLanguageTools.Diagnostic> scopedNames =
        CodeLanguageTools.inspect("Scopes.java",
            "class Scopes { class X {} void a() { class L {} } void b() { class L {} } }\n"
                + "class Other { class X {} }\n");
    check("فاحص الجمل: الأسماء المكررة تُفحص داخل نطاقها فقط (أصناف متداخلة أو محلية بالاسم نفسه صحيحة)",
        scopedNames.isEmpty(), scopedNames.toString());
    List<CodeLanguageTools.Diagnostic> duplicateNested =
        CodeLanguageTools.inspect("Dup.java", "class Dup { class X {} class X {} }\n");
    check("فاحص الجمل: صنفان متداخلان بالاسم نفسه داخل الصنف ذاته خطأ",
        duplicateNested.size() == 1
            && "ui_diagnostic_duplicate_class".equals(duplicateNested.get(0).messageKey),
        duplicateNested.toString());
    List<CodeLanguageTools.Diagnostic> publicName =
        CodeLanguageTools.inspect("Right.java", "public class Wrong {}\n");
    check("فاحص الجمل: اسم الصنف العام يجب أن يطابق اسم الملف",
        publicName.size() == 1
            && "ui_diagnostic_public_class_name_mismatch".equals(publicName.get(0).messageKey),
        publicName.toString());
    List<CodeLanguageTools.Diagnostic> strayTail =
        CodeLanguageTools.inspect("Tail.java", "class J { int g() { return 0; } }\n}\n");
    check("فاحص الجمل: قوس زائد بعد نهاية الصنف يُبلَّغ بأنه خارج أي صنف",
        strayTail.size() == 1 && strayTail.get(0).line == 2
            && "ui_diagnostic_class_or_interface_expected".equals(strayTail.get(0).messageKey),
        strayTail.toString());
    List<java.nio.file.Path> javaSources = new ArrayList<>();
    Files.walk(Paths.get("app/src/main/java"))
        .filter(p -> p.toString().endsWith(".java"))
        .forEach(javaSources::add);
    List<String> syntaxFailures = new ArrayList<>();
    for (java.nio.file.Path source : javaSources) {
      String text = new String(Files.readAllBytes(source), StandardCharsets.UTF_8);
      List<almlk.JavaSyntaxChecker.Problem> problems =
          almlk.JavaSyntaxChecker.check(source.getFileName().toString(), text);
      if (!problems.isEmpty()) syntaxFailures.add(source + ":" + problems.get(0).line);
    }
    check("كل ملفات جافا في المشروع (" + javaSources.size() + ") صحيحة نحويًا بلا إيجابيات كاذبة",
        javaSources.size() > 100 && syntaxFailures.isEmpty(),
        syntaxFailures.toString());
    String mainActivity = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("الملف الكبير MainActivity (" + mainActivity.length() + " حرفًا) داخل سقف الفحص ويُفحص بلا أخطاء",
        mainActivity.length() <= CodeLanguageTools.MAX_CHECKED_CHARS
            && CodeLanguageTools.inspect("MainActivity.java", mainActivity).isEmpty(),
        CodeLanguageTools.inspect("MainActivity.java", mainActivity).toString());
    String[] syntaxKeys = {
      "ui_diagnostic_expected_token", "ui_diagnostic_missing_semicolon",
      "ui_diagnostic_illegal_start_of_expression", "ui_diagnostic_illegal_start_of_type",
      "ui_diagnostic_not_a_statement", "ui_diagnostic_else_without_if", "ui_diagnostic_orphaned_keyword",
      "ui_diagnostic_reached_end_of_file", "ui_diagnostic_class_or_interface_expected",
      "ui_diagnostic_invalid_method_declaration", "ui_diagnostic_duplicate_class",
      "ui_diagnostic_public_class_name_mismatch", "ui_diagnostic_unclosed_string",
      "ui_diagnostic_unclosed_text_block", "ui_diagnostic_unclosed_block_comment",
      "ui_diagnostic_unclosed_char_literal", "ui_diagnostic_empty_char_literal",
      "ui_diagnostic_illegal_character"
    };
    Map<String, String> syntaxEn = stringResources("app/src/main/res/values/strings.xml");
    Map<String, String> syntaxAr = stringResources("app/src/main/res/values-ar/strings.xml");
    List<String> missingKeys = new ArrayList<>();
    for (String key : syntaxKeys) {
      if (!syntaxEn.containsKey(key) || !syntaxAr.containsKey(key)) missingKeys.add(key);
    }
    check("مفاتيح رسائل فاحص الجمل (18) موجودة في الإنجليزية والعربية", missingKeys.isEmpty(), missingKeys.toString());
    check("ترجمة الفاصلة المنقوطة العربية تعرض الرمز الصحيح (;)",
        syntaxAr.get("ui_diagnostic_missing_semicolon").contains("(;)"),
        syntaxAr.get("ui_diagnostic_missing_semicolon"));
    check("المسار المعجمي القديم للجافا (inspectDeclarations) محذوف بلا بقايا",
        !read("app/src/main/java/com/almlkid/kay/ui/CodeLanguageTools.java").contains("inspectDeclarations"),
        "CodeLanguageTools ما زال يحوي inspectDeclarations");
    check("إعادة المسح الكامل للملف في مفهرس الاستدعاءات محذوفة (diagnosticReceiverType)",
        !read("app/src/main/java/com/almlkid/kay/ui/ProjectSymbolIndex.java").contains("diagnosticReceiverType"),
        "ProjectSymbolIndex ما زال يحوي diagnosticReceiverType");
    ProjectSymbolIndex.clear();
    ProjectSymbolIndex.registerSource("ClipboardHelper.java", "/project/src/ClipboardHelper.java", helper);
    ProjectSymbolIndex.registerSource("ClipboardUser.java", "/project/src/ClipboardUser.java", caller);
    ProjectDiagnostic sourceDiagnostic =
        ProjectDiagnostic.fromSource(
            "ClipboardUser.java", "/project/src/ClipboardUser.java", caller, missing);
    check("مدى التشخيص يُحفظ على اسم الدالة فقط مع بيانات إصلاح للملف المالك",
        sourceDiagnostic != null
            && sourceDiagnostic.diagnostic.offset == caller.indexOf("getstr")
            && sourceDiagnostic.diagnostic.end == caller.indexOf("getstr") + "getstr".length()
            && sourceDiagnostic.endColumn - sourceDiagnostic.diagnostic.column == "getstr".length()
            && sourceDiagnostic.missingMember != null
            && "ClipboardHelper".equals(sourceDiagnostic.missingMember.className)
            && "getstr".equals(sourceDiagnostic.missingMember.methodName),
        sourceDiagnostic == null ? "لم يُنشأ غلاف التشخيص" : sourceDiagnostic.toString());
    check("الإصلاح المقترح ينتج توقيع العضو المستقبِل الصحيح",
        sourceDiagnostic != null
            && sourceDiagnostic.missingMember.methodSource().contains("public void getstr()")
            && sourceDiagnostic.missingMember.methodSource().contains("TODO"),
        sourceDiagnostic == null ? "missingMember=null" : sourceDiagnostic.symbol);

    StringBuilder caret = new StringBuilder();
    for (int i = 0; i < callLine.indexOf("getstr"); i++) caret.append(' ');
    String javacOutput =
        "/project/src/ClipboardUser.java:4: error: cannot find symbol\n"
            + callLine + "\n"
            + caret + "^\n"
            + "  symbol:   method getstr()\n"
            + "  location: variable clibs of type ClipboardHelper\n"
            + "1 error\n";
    ArrayList<BuildDiagnosticsParser.BuildError> compilerErrors =
        BuildDiagnosticsParser.parse(javacOutput + javacOutput);
    check("محوّل javac يستخرج السطر والعمود والرمز ويتخلص من الرسائل المكررة",
        compilerErrors.size() == 1
            && compilerErrors.get(0).line == 4
            && compilerErrors.get(0).column == callLine.indexOf("getstr") + 1
            && "getstr".equals(compilerErrors.get(0).symbol),
        "عدد=" + compilerErrors.size()
            + (compilerErrors.isEmpty() ? "" : "، " + compilerErrors.get(0)));
    ProjectDiagnostic compilerDiagnostic =
        compilerErrors.isEmpty()
            ? null
            : ProjectDiagnostic.fromBuild(
                "ClipboardUser.java",
                "/project/src/ClipboardUser.java",
                caller,
                compilerErrors.get(0));
    check("خطأ البناء يُربط بالمصدر ويحتفظ بخيار Quick Fix عبر الملفات",
        compilerDiagnostic != null
            && compilerDiagnostic.diagnostic.line == 4
            && compilerDiagnostic.preview.equals(callLine.trim())
            && compilerDiagnostic.fromBuild
            && compilerDiagnostic.missingMember != null
            && "ClipboardHelper".equals(compilerDiagnostic.missingMember.className),
        compilerDiagnostic == null ? "لم يُحلّل موضع البناء" : compilerDiagnostic.preview);

    String gradleOutput =
        "Build file '/project/app/build.gradle' line: 17\n"
            + "\n* What went wrong:\n"
            + "> Could not compile build file '/project/app/build.gradle'.\n";
    ArrayList<BuildDiagnosticsParser.BuildError> gradleErrors =
        BuildDiagnosticsParser.parse(gradleOutput);
    check("محوّل Gradle يلتقط build.gradle:line ورسالة التعثر",
        gradleErrors.size() == 1
            && gradleErrors.get(0).fileName.endsWith("app/build.gradle")
            && gradleErrors.get(0).line == 17
            && gradleErrors.get(0).message.contains("Could not compile"),
        "عدد=" + gradleErrors.size()
            + (gradleErrors.isEmpty() ? "" : "، " + gradleErrors.get(0)));
    String preciseGradleOutput =
        "Build file '/project/app/build.gradle' line: 17\n"
            + "* What went wrong:\n"
            + "> startup failed:\n"
            + "  build file '/project/app/build.gradle': 17: Unexpected input: '}' @ line 17, column 9.\n";
    ArrayList<BuildDiagnosticsParser.BuildError> preciseGradleErrors =
        BuildDiagnosticsParser.parse(preciseGradleOutput);
    check("تشخيص Gradle يزيل بادئة build file ويستخدم العمود الدقيق دون نسخة عامة مكررة",
        preciseGradleErrors.size() == 1
            && preciseGradleErrors.get(0).fileName.equals("/project/app/build.gradle")
            && preciseGradleErrors.get(0).line == 17
            && preciseGradleErrors.get(0).column == 9
            && "GRADLE_ERROR".equals(preciseGradleErrors.get(0).code),
        "عدد=" + preciseGradleErrors.size()
            + (preciseGradleErrors.isEmpty() ? "" : "، " + preciseGradleErrors.get(0)));
    DiagnosticUnderline underline = new DiagnosticUnderline(7, 13, false);
    check("مدى الرسم يظل نسبيًا للسطر ويضمن طولًا موجبًا",
        underline.startColumn == 7 && underline.endColumn == 13 && !underline.warning
            && new DiagnosticUnderline(4, 2, true).endColumn == 5,
        underline.startColumn + ".." + underline.endColumn);

    String canvas = read("app/src/main/java/almlk/CodeCanvasView.java");
    String panel = read("app/src/main/java/com/almlkid/ui/SequentialPanelHost.java");
    String pagerSource = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    String main = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("المحرر يرسم مدى تشخيص مستقلًا دون إزالة تسطير ألوان XML",
        canvas.contains("DiagnosticDecorationProvider")
            && canvas.contains("drawDiagnosticUnderlines(canvas, line, originX, lineTop)")
            && canvas.contains("canvas.drawPath(diagnosticPath")
            && canvas.contains("drawColorUnderlines(canvas, line, originX, lineTop)"),
        "مزود/رسم مدى التشخيص أو زخرفة XML مفقود");
    check("لوحة الأخطاء تجمع الصفوف تحت رؤوس الملفات وتدعم Quick Fix بالضغط المطوّل",
        panel.contains("class ErrorFileHeader")
            && panel.contains("setProjectDiagnostics(List<ProjectDiagnostic> values)")
            && panel.contains("errorRows.add(new ErrorFileHeader")
            && panel.contains("row.icon.setImageResource(fileTypeIcon(header.name))")
            && panel.contains("R.drawable.project_errors")
            && panel.contains("setTextIsSelectable(false)")
            && panel.contains("setOnItemLongClickListener")
            && panel.contains("errorQuickFixListener.requested((ProjectDiagnostic) errorRows.get(position))"),
        "التجميع/أيقونات الملف والخطأ/تسليم الضغط المطوّل إلى Quick Fix غير مكتمل");
    check("اختيار الخطأ ينشّط الملف حسب مرجعه ثم يقفز للسطر/العمود ويغلق اللوحة لعرضه",
        main.contains("activateTabByReference(diagnostic.reference, diagnostic.fileName)")
            && main.contains("editor.goToMatch(tab, line, column)")
            && main.contains("browser.openUsageAsync("),
        "مسار التنقل لا يحل هوية الملف");
    int matchStart = pagerSource.indexOf("public boolean goToMatch(String name, int line, int column)");
    int matchEnd = pagerSource.indexOf("private boolean jumpToLineColumn(int line, int column)", matchStart);
    String matchBody = matchStart < 0 || matchEnd < matchStart
        ? "" : pagerSource.substring(matchStart, matchEnd);
    int lazyStart = pagerSource.indexOf("private void loadLazySessionReference(String name, String reference)");
    int lazyEnd = pagerSource.indexOf("public void retryLazySessionReferences()", lazyStart);
    String lazyBody = lazyStart < 0 || lazyEnd < lazyStart
        ? "" : pagerSource.substring(lazyStart, lazyEnd);
    int pendingOpenStart = pagerSource.indexOf("public void openFilePending(String name, String reference)");
    int pendingOpenEnd = pagerSource.indexOf("private static final class PendingOpen", pendingOpenStart);
    String pendingOpenBody = pendingOpenStart < 0 || pendingOpenEnd < pendingOpenStart
        ? "" : pagerSource.substring(pendingOpenStart, pendingOpenEnd);
    check("قفزة التشخيص تنتظر فتح التبويب الكسول ثم تحدد الموضع على النص المحمّل",
        matchBody.contains("name.equals(loadingFile) || openingFiles.contains(name)")
            && matchBody.contains("pendingMatchFile = name")
            && lazyBody.contains("code.setText(")
            && lazyBody.indexOf("code.setText(")
                < lazyBody.indexOf("if (failure == null && name.equals(pendingMatchFile))")
            && lazyBody.contains("if (failure == null && name.equals(pendingMatchFile))")
            && lazyBody.contains("code.post(() -> jumpToLineColumn(line, column))")
            && pendingOpenBody.contains("if (tabName.equals(pendingMatchFile))")
            && pendingOpenBody.contains("code.post(() -> goToMatch(tabName, line, column))"),
        "مسار التحميل الكسول لا يؤجل القفزة إلى ما بعد حقن المحتوى");
    int openDiagnosticStart = main.indexOf("private void openProjectDiagnostic(ProjectDiagnostic diagnostic)");
    int openDiagnosticEnd = main.indexOf("private void showSequentialPanels(", openDiagnosticStart);
    String openDiagnosticBody = openDiagnosticStart < 0 || openDiagnosticEnd < openDiagnosticStart
        ? "" : main.substring(openDiagnosticStart, openDiagnosticEnd);
    int navigation = openDiagnosticBody.indexOf("editor.goToMatch(tab, line, column)");
    int closeAfterNavigation = openDiagnosticBody.indexOf("closeSequentialPanels();", navigation);
    check("القفز إلى التشخيص يغلق لوحة النتائج بعد تحديد موضع المصدر",
        navigation >= 0 && closeAfterNavigation > navigation
            && openDiagnosticBody.contains("browser.openUsageAsync("),
        "لم تُغلق لوحة النتائج بعد التنقل إلى الخطأ");
    int confirmStart = main.indexOf("private void confirmCreateMissingMember(ProjectSymbolIndex.MissingMember member)");
    int confirmEnd = main.indexOf("@Override", confirmStart);
    String confirmationBody = confirmStart < 0 || confirmEnd < confirmStart
        ? "" : main.substring(confirmStart, confirmEnd);
    int confirmPositive = confirmationBody.indexOf(".setPositiveButton(");
    int confirmMutation = confirmationBody.indexOf("browser.createMissingMember(");
    check("إصلاح العضو يتطلب تأكيد Modify files باسم الملف المستهدف قبل أي تعديل",
        confirmationBody.contains("new AlertDialog.Builder(this)")
            && confirmationBody.contains(".setTitle(ui(\"ui_create_missing_member_title\"))")
            && confirmationBody.contains("uiFormat(\"ui_create_missing_member_message\", member.className, signature)")
            && confirmationBody.contains(".setNegativeButton(ui(\"ui_action_no\"), null)")
            && confirmationBody.contains(".setPositiveButton(")
            && confirmPositive >= 0
            && confirmMutation > confirmPositive
            && confirmationBody.contains("editor.goToMatch(active, line, column)")
            && confirmationBody.contains("closeSequentialPanels();")
            && openDiagnosticBody.contains("activateTabByReference(diagnostic.reference, diagnostic.fileName)")
            && openDiagnosticBody.contains("editor.goToMatch(tab, line, column)"),
        "يجب تأكيد التعديل على ملف العضو المستقبِل ثم الانتقال إلى الدالة المنشأة");
    Map<String, String> en = stringResources("app/src/main/res/values/strings.xml");
    Map<String, String> ar = stringResources("app/src/main/res/values-ar/strings.xml");
    check("نصوص التشخيص والتأكيد واسم الملف وأزرار Yes/No مترجمة في الموردين",
        en.containsKey("ui_diagnostic_file_group")
            && en.containsKey("ui_diagnostic_build_error")
            && ar.containsKey("ui_diagnostic_file_group")
            && ar.containsKey("ui_diagnostic_build_error")
            && "Modify files".equals(en.get("ui_create_missing_member_title"))
            && en.get("ui_create_missing_member_message").contains("%1$s.java")
            && en.containsKey("ui_action_yes")
            && en.containsKey("ui_action_no")
            && ar.containsKey("ui_create_missing_member_title")
            && ar.get("ui_create_missing_member_message").contains("%1$s.java")
            && ar.containsKey("ui_action_yes")
            && ar.containsKey("ui_action_no"),
        "موارد ترجمة أو اسم ملف/أزرار التأكيد مفقودة");
    String codeViewSrc = read("app/src/main/java/almlk/CodeEditorView.java");
    String browserSrc = read("app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java");
    String commandSrc = read("app/src/main/java/com/shima/demo/CommandCenter.java");
    check("الضغط المطوّل على خطأ ينقل إلى موقعه ويفتح وضع الإجراءات بقائمة الإصلاح بدل الحوار المباشر",
        main.contains("sequentialPanels.setErrorQuickFixListener(this::requestErrorFixes)")
            && main.contains("private void requestErrorFixes(ProjectDiagnostic diagnostic) {\n    openProjectDiagnostic(diagnostic, true);")
            && !panel.contains("errorQuickFixListener.requested(item.missingMember)")
            && pagerSource.contains("public void startErrorFixActions()")
            && codeViewSrc.contains("public void beginSelectionActionMode()"),
        "مسار الضغط المطوّل لا يمر بالتنقل ثم شريط الإجراءات");
    check("تسليح فتح الإصلاحات يُستهلك داخل القفزة نفسها ولا يبقى عالقًا بعد فشلها",
        pagerSource.contains("boolean openFixes = armedErrorFix;")
            && pagerSource.contains("armedErrorFix = false;")
            && pagerSource.contains("if (openFixes) code.post(this::startErrorFixActions);")
            && pagerSource.contains("pendingMatchFile = null;\n      armedErrorFix = false;")
            && main.contains("if (!editor.goToMatch(tab, line, column)) editor.disarmErrorFixes();"),
        "علم فتح الإصلاحات قد يبقى عالقًا فيغيّر قفزة لاحقة");
    check("أمرا الخطأ التالي/السابق مسجّلان في القائمة ومنفّذان بترتيب اللوحة مع الالتفاف",
        commandSrc.contains("add(\"goto_next_error\", \"keybind_goto_next_error\"")
            && commandSrc.contains("add(\"goto_previous_error\", \"keybind_goto_pre_error\"")
            && main.contains("case \"goto_next_error\":")
            && main.contains("case \"goto_previous_error\":")
            && main.contains("private void gotoAdjacentError(boolean forward)")
            && main.contains("int next = first >= 0 ? last + 1 : after;")
            && main.contains("target = displayedDiagnostics.get(previous >= 0 ? previous : n - 1);")
            && pagerSource.contains("public int[] caretLineColumn()"),
        "أمر التنقل بين الأخطاء غير مكتمل أو لا يلتف");
    check("تقدّم فحص المشروع يظهر في رأس لوحة الأخطاء ثم يعود العدّاد عند الانتهاء",
        panel.contains("public void setScanProgress(int done, int total)")
            && panel.contains("UiStrings.format(getContext(), \"ui_errors_scanning\", scanDone, scanTotal)")
            && browserSrc.contains("default void progress(int done, int total) {}")
            && browserSrc.contains("listener.progress(doneNow, totalFiles)")
            && main.contains("public void progress(int done, int total)")
            && main.contains("sequentialPanels.setScanProgress(0, 0);"),
        "تقدّم الفحص لا يصل إلى رأس اللوحة أو لا يعود للعدّاد");
    check("نصوص التقدم وأمرا التنقل مترجمة في العربية والإنجليزية",
        en.containsKey("ui_errors_scanning")
            && ar.containsKey("ui_errors_scanning")
            && en.containsKey("keybind_goto_next_error")
            && en.containsKey("keybind_goto_pre_error")
            && ar.containsKey("keybind_goto_next_error")
            && ar.containsKey("keybind_goto_pre_error")
            && ar.get("ui_errors_scanning").contains("%1$d"),
        "نص تقدّم الفحص أو أمر التنقل غير مترجم في أحد الموردين");
  }
}
