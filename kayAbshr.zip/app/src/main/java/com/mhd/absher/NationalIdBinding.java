package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.viewpager2.widget.ViewPager2;
import com.a.a.a.a.a;

public final class NationalIdBinding {
    public final ImageView btnClose;
    public final RelativeLayout rootView;
    public final TextView tvUpdateText;
    public final ViewPager2 viewPagerId;

    private NationalIdBinding(RelativeLayout relativeLayout, ViewPager2 viewPager2, TextView textView, ImageView imageView) {
        this.rootView = relativeLayout;
        this.viewPagerId = viewPager2;
        this.tvUpdateText = textView;
        this.btnClose = imageView;
    }

    public static NationalIdBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        ViewPager2 viewPager2FindChildViewById = findChildViewById(view, R.id.viewPagerId);
        TextView textView = (TextView) findChildViewById(view, R.id.tvUpdateText);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnClose);
        if (viewPager2FindChildViewById == null || textView == null || imageView == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new NationalIdBinding(relativeLayout, viewPager2FindChildViewById, textView, imageView);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static NationalIdBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static NationalIdBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.national_id, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
