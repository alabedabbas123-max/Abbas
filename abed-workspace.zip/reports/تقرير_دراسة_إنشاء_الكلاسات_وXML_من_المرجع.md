# تقرير دراسة: إنشاء الكلاسات وملفات XML في المشروع المرجعي (AIDE Pro المفكوك)

**الغرض**: دراسة المرحلة ج من خطة المطابقة — «إنشاء كلاس جديد» و«إنشاء XML جديد» من متصفح الملفات — قبل التنفيذ، وفق البند 2 من اتفاق العمل.
**مصدر الدراسة**: `/tmp/ref/java/java/com/factorialovich/aide/util/CreateClassDialog.java` و`CreateXMLDialog.java` (207 و119 سطرًا).

---

## 1) حوار إنشاء الكلاس في المرجع (CreateClassDialog)

### البنية
- حوار AlertDialog بعنوان «Add New Class» داخل ScrollView، يضم:
  - **Spinner أنواع** بستة عناصر: **Class، Activity، Interface، Enum، Service، BroadcastReceiver**.
  - **حقل اسم** مع TextWatcher (تحقق حي) وsetOnEditorActionListener (إنشاء بزر Done).
  - **خيار «إضافة تلقائية» (autoAdd)** يظهر فقط للأنواع المُعلَّمة بذلك: **Activity وService وBroadcastReceiver** — أي التسجيل التلقائي في AndroidManifest.
  - **قسم Layout** يظهر فقط لـ**Activity**: خيار «إنشاء Layout» + حقل اسم ملف اللاي آوت.
  - (خيارات ثانوية خلف إعداد مخفي: abstract/TAG/ترويسة توثيق — مشروطة بإعدادات sp غير مفعلة افتراضيًا؛ خارج نطاق المطابقة الأساسية.)

### الدلالات الوظيفية
1. **زر الإنشاء لا يغلق الحوار تلقائيًا** — onClick مخصص عبر `getButton(-1).setOnClickListener` حتى يمكن عرض خطأ دون إغلاق (`setError`: «الملف موجود» / «تعذر الكتابة»).
2. **دعم مسار فرعي**: الاسم المُدخل قد يحوي `/` (مثل `sub/MyClass`) — الأجزاء قبل آخر `/` مجلدات تُنشأ (`mkdirs`)، والحزمة تُحسب من المجلد النهائي.
3. **الحزمة** تُشتق من مسار المجلد داخل جذر مصادر المشروع الحالي (عبر gj.DW على مسار src).
4. **إنشاء اللاي آوت** (Activity مع addLayout): يُكتب في `res/layout` الخاص بالمشروع الحالي بقالب LinearLayout عمودي مع `xmlns:android` و`xmlns:app`، ويُرفض إن كان موجودًا (setError على حقل اسم اللاي آوت).
5. **كود الكلاس** يُولَّد من مُولِّد لكل نوع (makeCode على Configuration تضم: packageName، className، layoutName، autoAdd، abstract...).
6. بعد الكتابة يُستدعى callback بمسار الملف → **فتح الملف في المحرر** ومزامنة مجلد المتصفح.

## 2) حوار إنشاء XML في المرجع (CreateXMLDialog)

1. **عنوان ديناميكي**: «Create a %s» حيث %s = اسم مجلد الموارد بعد قطع ما بعد `-` ورفع أول حرف — أي داخل `layout-land` يصبح «Create a Layout»، وداخل `values` «Create a Values».
2. **تحقق حي**: TextWatcher يُعطّل زر الإنشاء عند حقل فارغ؛ الزر لا يغلق الحوار إلا عند النجاح؛ `setError` عند: إدخال فارغ، الملف موجود، تعذر الكتابة.
3. **المحتوى حسب بادئة اسم المجلد**:
   - `layout*`: LinearLayout عمودي match_parent مع `xmlns:android` + `xmlns:app`.
   - `menu*`: عنصر `<menu>` مع **عنصر `<item>` نموذجي** (`@+id/item`، title=Item) و`xmlns:app`.
   - `values*`: `<resources>` فارغ.
   - غير ذلك: ترويسة `<?xml ...?>` فقط.
4. اللاحقة `.xml` تُضاف تلقائيًا إن لم تُكتب، ثم **فتح الملف** عبر الـcallback.

## 3) الوضع الحالي عندنا (ما بعد 1.0.29)

- `BrowserPager.promptCreateClass`: حقل اسم واحد فقط، نوع واحد (class)، تحقق بـToast بعد الضغط (غير حي)، لا أنواع، لا layout، لا تسجيل مانيفست، لا مسار فرعي.
- `BrowserPager.promptCreateXml`: عنوان ثابت، تحقق بـToast، قوالب layout/values/menu بلا `xmlns:app` وبلا item نموذجي، لا تعطيل حي للزر.
- `createTextFile` موجود: كتابة خلفية + invalidate + فتح الملف المنشأ (activate) — يُعاد استخدامه.
- `packageForDir` موجود (اشتقاق الحزمة بعد مقطع `/java/`).
- **ملاحظة تقنية**: `directoryReader` مجمع خيوط بسعة 2 (غير تسلسلي) — عمليات الكلاس متعددة الملفات (layout + manifest + class) يجب أن تُنفذ في مهمة خلفية واحدة لضمان الترتيب.

## 4) خطة التنفيذ بأسلوبنا (إحلال كامل — بلا نسخ كود)

1. **استبدال `promptCreateClass` كليًا**: حوار بأنواع الستة في Spinner، اسم بتحقق حي (زر معطل + setError)، دعم `/`، قسم autoAdd للأنواع الثلاثة المُكوَّنة، قسم layout لـActivity باسم مشتق تلقائيًا من اسم الكلاس (CamelCase → snake_case)، توليد الكود لكل نوع بقوالبنا، تنفيذ خلفي واحد: mkdirs الفرعية → layout (إن طُلب) → إدراج المانيفست (إن طُلب؛ `.Name` إن تطابقت الحزمة مع حزمة المانيفست وإلا الاسم الكامل، قبل `</application>`) → كتابة الكلاس → invalidate + فتح.
2. **إيجاد المانيفست**: صعود من مجلد الإنشاء حتى 10 مستويات بحثًا عن `AndroidManifest.xml` مباشر (يغطي بنية Gradle: `main/` وبنية Eclipse: الجذر)، و`res/layout` شقيق للمانيفست.
3. **استبدال `promptCreateXml` كليًا**: عنوان ديناميكي من اسم المجلد (قطع `-`، رفع أول حرف)، تحقق حي (تعطيل زر + setError للموجود/الاسم غير الصالح)، قوالب مطابقة دلاليًا (layout وmenu مع xmlns:app وitem نموذجي، values)، إعادة استخدام `createTextFile`.
4. البناء + دورة البند 1 بإصدار **1.0.30**.

**خارج النطاق عمدًا** (غير مفعل افتراضيًا في المرجع نفسه): ترويسة التوثيق التاريخية، خيار abstract/TAG خلف إعداد مخفي.
