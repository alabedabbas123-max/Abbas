package almlk;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.view.View;

/**
 * يتحكم بمقابض caret ونهايتي التحديد: drawables من الثيم، أهداف لمس موسّعة، ومؤقت مستقل للـcaret.
 * جميع نقاط الارتكاز تأتي من CodeCanvasView كي يتطابق الرسم والالتقاط مع قياس النص والتمرير.
 */
public final class EditorHandleController {

  public static final long HIDE_DELAY_MS = 3000L;

  private static final float DEFAULT_WIDTH_DP = 32f;
  private static final float DEFAULT_HEIGHT_DP = 40f;
  private static final float MIN_TOUCH_TARGET_DP = 48f;
  private static final int DEFAULT_ACCENT = 0xFF29B6F6;
  // Hotspots used by CodeEditTextScrollView.DragHandle in the reference editor.
  private static final float CARET_ANCHOR_X = 0.5f;
  private static final float SELECTION_START_ANCHOR_X = 0.8f;
  private static final float SELECTION_END_ANCHOR_X = 0.2f;

  private final View host;
  private final float density;
  private final float touchTargetPx;
  private final HandleAsset caretAsset;
  private final HandleAsset selectionStartAsset;
  private final HandleAsset selectionEndAsset;
  private final Paint fallbackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final Rect bounds = new Rect();
  private boolean caretVisible;
  private boolean caretDragging;

  private static final class HandleAsset {
    final Drawable drawable;
    final int widthPx;
    final int heightPx;
    final float anchorFractionX;

    HandleAsset(Drawable drawable, float density, float anchorFractionX) {
      this.drawable = drawable;
      this.anchorFractionX = anchorFractionX;
      // Keep the resource's native dimensions/aspect ratio as DragHandle does in the reference.
      widthPx = resolveDimension(drawable, true, DEFAULT_WIDTH_DP, density);
      heightPx = resolveDimension(drawable, false, DEFAULT_HEIGHT_DP, density);
    }
  }

  private final Runnable hideTask = this::expireAfterDelay;

  private void expireAfterDelay() {
    if (!caretVisible || caretDragging) return;
    caretVisible = false;
    host.invalidate();
  }

  public EditorHandleController(Context context, View host) {
    this.host = host;
    density = context.getResources().getDisplayMetrics().density;
    touchTargetPx = MIN_TOUCH_TARGET_DP * density;
    caretAsset = new HandleAsset(
        loadThemeHandle(context, android.R.attr.textSelectHandle), density, CARET_ANCHOR_X);
    selectionStartAsset = new HandleAsset(
        loadThemeHandle(context, android.R.attr.textSelectHandleLeft),
        density, SELECTION_START_ANCHOR_X);
    selectionEndAsset = new HandleAsset(
        loadThemeHandle(context, android.R.attr.textSelectHandleRight),
        density, SELECTION_END_ANCHOR_X);
    fallbackPaint.setColor(resolveAccent(context));
    fallbackPaint.setStyle(Paint.Style.FILL);
    setCallback(caretAsset);
    setCallback(selectionStartAsset);
    setCallback(selectionEndAsset);
  }

  /** عرض مقبض caret مؤقتًا، وإعادة بدء مهلة الإخفاء. */
  public void show() {
    caretVisible = true;
    caretDragging = false;
    rescheduleHide();
    host.invalidate();
  }

  public boolean isVisible() {
    return caretVisible;
  }

  /** اختبار هدف مقبض caret (48dp على الأقل). */
  public boolean hitTest(float x, float y, float anchorX, float anchorY) {
    return caretVisible && hitTestAsset(caretAsset, x, y, anchorX, anchorY);
  }

  /** اختبار هدفي مقبضي بداية/نهاية التحديد. */
  public boolean hitTestSelectionStart(float x, float y, float anchorX, float anchorY) {
    return hitTestAsset(selectionStartAsset, x, y, anchorX, anchorY);
  }

  public boolean hitTestSelectionEnd(float x, float y, float anchorX, float anchorY) {
    return hitTestAsset(selectionEndAsset, x, y, anchorX, anchorY);
  }

  /** بدء سحب caret يوقف المؤقت كي لا يختفي المقبض تحت الإصبع. */
  public void beginDrag() {
    if (!caretVisible) return;
    caretDragging = true;
    host.removeCallbacks(hideTask);
  }

  /** انتهاء/إلغاء سحب caret يعيد مهلة الإخفاء كاملة. */
  public void endDrag() {
    if (!caretVisible) {
      caretDragging = false;
      return;
    }
    caretDragging = false;
    rescheduleHide();
  }

  /** إخفاء caret وإلغاء callback عند بدء التحديد أو فقدان التركيز أو فصل اللوحة. */
  public void hide() {
    host.removeCallbacks(hideTask);
    boolean changed = caretVisible || caretDragging;
    caretVisible = false;
    caretDragging = false;
    if (changed) host.invalidate();
  }

  /** رسم مقبض caret إذا كان ظاهرًا. */
  public void draw(Canvas canvas, float anchorX, float anchorY) {
    if (caretVisible) drawAsset(canvas, caretAsset, anchorX, anchorY);
  }

  /** رسم مقبض بداية التحديد عند الإحداثي نفسه المستخدم لالتقاطه. */
  public void drawSelectionStart(Canvas canvas, float anchorX, float anchorY) {
    drawAsset(canvas, selectionStartAsset, anchorX, anchorY);
  }

  /** رسم مقبض نهاية التحديد عند الإحداثي نفسه المستخدم لالتقاطه. */
  public void drawSelectionEnd(Canvas canvas, float anchorX, float anchorY) {
    drawAsset(canvas, selectionEndAsset, anchorX, anchorY);
  }

  private boolean hitTestAsset(
      HandleAsset asset, float x, float y, float anchorX, float anchorY) {
    float assetLeft = anchorX - asset.anchorFractionX * asset.widthPx;
    float halfTouchWidth = Math.max(touchTargetPx, asset.widthPx) / 2f;
    float centerX = assetLeft + asset.widthPx / 2f;
    float halfHeight = Math.max(touchTargetPx, asset.heightPx) / 2f;
    float centerY = anchorY + asset.heightPx / 2f;
    return Math.abs(x - centerX) <= halfTouchWidth
        && Math.abs(y - centerY) <= halfHeight;
  }

  private void drawAsset(Canvas canvas, HandleAsset asset, float anchorX, float anchorY) {
    Drawable drawable = asset.drawable;
    if (drawable != null) {
      int left = Math.round(anchorX - asset.anchorFractionX * asset.widthPx);
      int top = Math.round(anchorY);
      bounds.set(left, top, left + asset.widthPx, top + asset.heightPx);
      drawable.setBounds(bounds);
      drawable.setState(host.getDrawableState());
      drawable.draw(canvas);
      return;
    }

    // احتياط عند غياب مورد الثيم، مع إبقاء نقطة الارتكاز على حدّ التحديد نفسه.
    float width = 12f * density;
    float height = 26f * density;
    float left = anchorX - asset.anchorFractionX * width;
    canvas.drawRoundRect(
        left, anchorY, left + width, anchorY + height,
        width / 2f, width / 2f, fallbackPaint);
  }

  private void rescheduleHide() {
    host.removeCallbacks(hideTask);
    if (caretVisible && !caretDragging) host.postDelayed(hideTask, HIDE_DELAY_MS);
  }

  private void setCallback(HandleAsset asset) {
    if (asset.drawable != null) asset.drawable.setCallback(host);
  }

  private static Drawable loadThemeHandle(Context context, int attribute) {
    TypedArray attributes = context.obtainStyledAttributes(new int[] {attribute});
    try {
      Drawable drawable = attributes.getDrawable(0);
      return drawable == null ? null : drawable.mutate();
    } catch (RuntimeException unavailable) {
      return null;
    } finally {
      attributes.recycle();
    }
  }

  private static int resolveDimension(
      Drawable drawable, boolean width, float fallbackDp, float density) {
    int fallback = Math.round(fallbackDp * density);
    if (drawable == null) return fallback;
    int intrinsic = width ? drawable.getIntrinsicWidth() : drawable.getIntrinsicHeight();
    return intrinsic > 0 ? intrinsic : fallback;
  }

  private static int resolveAccent(Context context) {
    TypedArray attributes = context.obtainStyledAttributes(new int[] {android.R.attr.colorAccent});
    try {
      return attributes.getColor(0, DEFAULT_ACCENT);
    } finally {
      attributes.recycle();
    }
  }
}
