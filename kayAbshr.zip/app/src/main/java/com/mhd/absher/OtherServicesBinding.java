package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class OtherServicesBinding {
    public final LinearLayout bottomNavOther;
    public final ImageButton btnChat;
    public final LinearLayout cardCustomize;
    public final LinearLayout contentOther;
    public final GridLayout gridFav;
    public final ImageView imageview106;
    public final ImageView imageview107;
    public final ImageView imageview108;
    public final ImageView imageview109;
    public final ImageView imageview110;
    public final ImageView imageview111;
    public final ImageView imageview112;
    public final ImageView imageview113;
    public final ImageView imageview114;
    public final ImageView imageview115;
    public final ImageView imageview116;
    public final ImageView imageview117;
    public final ImageView imageview118;
    public final ImageView imageview119;
    public final ImageView imageview120;
    public final ImageView imageview121;
    public final ImageView imageview122;
    public final ImageView imageview123;
    public final ImageView imageview124;
    public final LinearLayout itemAbsherTravel;
    public final LinearLayout itemAcceptance;
    public final LinearLayout itemActivateAbsher;
    public final LinearLayout itemAppointments;
    public final LinearLayout itemBirthCert;
    public final LinearLayout itemBorderInquiry;
    public final LinearLayout itemDeathCert;
    public final LinearLayout itemDelegations;
    public final LinearLayout itemDocsDelivery;
    public final LinearLayout itemDonateFarajat;
    public final LinearLayout itemDonateIhsan;
    public final LinearLayout itemGovPayments;
    public final LinearLayout itemResidentIdReq;
    public final LinearLayout itemVisitVisas;
    public final ImageView ivAbsherLogo;
    public final ImageView ivBell;
    public final ImageView ivInfo;
    public final ImageView ivInterior;
    public final ImageView ivSearch;
    public final ImageView ivSettings;
    public final LinearLayout linear16;
    public final LinearLayout linear17;
    public final LinearLayout navFamily;
    public final LinearLayout navHome;
    public final LinearLayout navMyServices;
    public final LinearLayout navOther;
    public final LinearLayout navWorkers;
    public final RelativeLayout relativelayout6;
    public final RelativeLayout rootOther;
    public final ScrollView scrollOther;
    public final RelativeLayout searchContainer;
    public final LinearLayout sectionBg;
    public final Space space18;
    public final TextView textview106;
    public final TextView textview107;
    public final TextView textview108;
    public final TextView textview109;
    public final TextView textview110;
    public final TextView textview111;
    public final TextView textview112;
    public final TextView textview113;
    public final TextView textview114;
    public final TextView textview115;
    public final TextView textview116;
    public final TextView textview117;
    public final TextView textview118;
    public final TextView textview119;
    public final TextView textview120;
    public final TextView textview121;
    public final TextView textview122;
    public final TextView textview123;
    public final TextView textview124;
    public final RelativeLayout topHeader;
    public final TextView tvCardBody;
    public final TextView tvCardTitle;
    public final TextView tvClose;
    public final TextView tvCustomizeAction;
    public final TextView tvFavTitle;
    public final TextView tvSearchHint;
    public final TextView tvTitle;

    private OtherServicesBinding(RelativeLayout relativeLayout, ScrollView scrollView, LinearLayout linearLayout, RelativeLayout relativeLayout2, ImageView imageView, ImageView imageView2, ImageView imageView3, ImageView imageView4, TextView textView, RelativeLayout relativeLayout3, TextView textView2, ImageView imageView5, LinearLayout linearLayout2, RelativeLayout relativeLayout4, ImageView imageView6, TextView textView3, TextView textView4, LinearLayout linearLayout3, TextView textView5, TextView textView6, LinearLayout linearLayout4, LinearLayout linearLayout5, TextView textView7, GridLayout gridLayout, LinearLayout linearLayout6, ImageView imageView7, TextView textView8, LinearLayout linearLayout7, ImageView imageView8, TextView textView9, LinearLayout linearLayout8, ImageView imageView9, TextView textView10, LinearLayout linearLayout9, ImageView imageView10, TextView textView11, LinearLayout linearLayout10, ImageView imageView11, TextView textView12, LinearLayout linearLayout11, ImageView imageView12, TextView textView13, LinearLayout linearLayout12, ImageView imageView13, TextView textView14, LinearLayout linearLayout13, ImageView imageView14, TextView textView15, LinearLayout linearLayout14, ImageView imageView15, TextView textView16, LinearLayout linearLayout15, ImageView imageView16, TextView textView17, LinearLayout linearLayout16, ImageView imageView17, TextView textView18, LinearLayout linearLayout17, ImageView imageView18, TextView textView19, LinearLayout linearLayout18, ImageView imageView19, TextView textView20, LinearLayout linearLayout19, ImageView imageView20, TextView textView21, Space space, ImageButton imageButton, LinearLayout linearLayout20, LinearLayout linearLayout21, ImageView imageView21, TextView textView22, LinearLayout linearLayout22, ImageView imageView22, TextView textView23, LinearLayout linearLayout23, ImageView imageView23, TextView textView24, LinearLayout linearLayout24, ImageView imageView24, TextView textView25, LinearLayout linearLayout25, ImageView imageView25, TextView textView26) {
        this.rootOther = relativeLayout;
        this.scrollOther = scrollView;
        this.contentOther = linearLayout;
        this.topHeader = relativeLayout2;
        this.ivBell = imageView;
        this.ivSettings = imageView2;
        this.ivAbsherLogo = imageView3;
        this.ivInterior = imageView4;
        this.tvTitle = textView;
        this.searchContainer = relativeLayout3;
        this.tvSearchHint = textView2;
        this.ivSearch = imageView5;
        this.cardCustomize = linearLayout2;
        this.relativelayout6 = relativeLayout4;
        this.ivInfo = imageView6;
        this.tvCardTitle = textView3;
        this.tvCardBody = textView4;
        this.linear16 = linearLayout3;
        this.tvCustomizeAction = textView5;
        this.tvClose = textView6;
        this.sectionBg = linearLayout4;
        this.linear17 = linearLayout5;
        this.tvFavTitle = textView7;
        this.gridFav = gridLayout;
        this.itemDocsDelivery = linearLayout6;
        this.imageview106 = imageView7;
        this.textview106 = textView8;
        this.itemAppointments = linearLayout7;
        this.imageview107 = imageView8;
        this.textview107 = textView9;
        this.itemDelegations = linearLayout8;
        this.imageview108 = imageView9;
        this.textview108 = textView10;
        this.itemAbsherTravel = linearLayout9;
        this.imageview109 = imageView10;
        this.textview109 = textView11;
        this.itemDonateIhsan = linearLayout10;
        this.imageview110 = imageView11;
        this.textview110 = textView12;
        this.itemDonateFarajat = linearLayout11;
        this.imageview111 = imageView12;
        this.textview111 = textView13;
        this.itemActivateAbsher = linearLayout12;
        this.imageview112 = imageView13;
        this.textview112 = textView14;
        this.itemVisitVisas = linearLayout13;
        this.imageview113 = imageView14;
        this.textview113 = textView15;
        this.itemBirthCert = linearLayout14;
        this.imageview114 = imageView15;
        this.textview114 = textView16;
        this.itemAcceptance = linearLayout15;
        this.imageview115 = imageView16;
        this.textview115 = textView17;
        this.itemGovPayments = linearLayout16;
        this.imageview116 = imageView17;
        this.textview116 = textView18;
        this.itemDeathCert = linearLayout17;
        this.imageview117 = imageView18;
        this.textview117 = textView19;
        this.itemBorderInquiry = linearLayout18;
        this.imageview118 = imageView19;
        this.textview118 = textView20;
        this.itemResidentIdReq = linearLayout19;
        this.imageview119 = imageView20;
        this.textview119 = textView21;
        this.space18 = space;
        this.btnChat = imageButton;
        this.bottomNavOther = linearLayout20;
        this.navHome = linearLayout21;
        this.imageview120 = imageView21;
        this.textview120 = textView22;
        this.navMyServices = linearLayout22;
        this.imageview121 = imageView22;
        this.textview121 = textView23;
        this.navFamily = linearLayout23;
        this.imageview122 = imageView23;
        this.textview122 = textView24;
        this.navWorkers = linearLayout24;
        this.imageview123 = imageView24;
        this.textview123 = textView25;
        this.navOther = linearLayout25;
        this.imageview124 = imageView25;
        this.textview124 = textView26;
    }

    public static OtherServicesBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.scrollOther);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.contentOther);
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topHeader);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.ivBell);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.ivSettings);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.ivAbsherLogo);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.ivInterior);
        TextView textView = (TextView) findChildViewById(view, R.id.tvTitle);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.searchContainer);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvSearchHint);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.ivSearch);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.cardCustomize);
        RelativeLayout relativeLayout4 = (RelativeLayout) findChildViewById(view, R.id.relativelayout6);
        ImageView imageView6 = (ImageView) findChildViewById(view, R.id.ivInfo);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tvCardTitle);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tvCardBody);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear16);
        TextView textView5 = (TextView) findChildViewById(view, R.id.tvCustomizeAction);
        TextView textView6 = (TextView) findChildViewById(view, R.id.tvClose);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.sectionBg);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.linear17);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tvFavTitle);
        GridLayout gridLayout = (GridLayout) findChildViewById(view, R.id.gridFav);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.itemDocsDelivery);
        ImageView imageView7 = (ImageView) findChildViewById(view, R.id.imageview106);
        TextView textView8 = (TextView) findChildViewById(view, R.id.textview106);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.itemAppointments);
        ImageView imageView8 = (ImageView) findChildViewById(view, R.id.imageview107);
        TextView textView9 = (TextView) findChildViewById(view, R.id.textview107);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.itemDelegations);
        ImageView imageView9 = (ImageView) findChildViewById(view, R.id.imageview108);
        TextView textView10 = (TextView) findChildViewById(view, R.id.textview108);
        LinearLayout linearLayout9 = (LinearLayout) findChildViewById(view, R.id.itemAbsherTravel);
        ImageView imageView10 = (ImageView) findChildViewById(view, R.id.imageview109);
        TextView textView11 = (TextView) findChildViewById(view, R.id.textview109);
        LinearLayout linearLayout10 = (LinearLayout) findChildViewById(view, R.id.itemDonateIhsan);
        ImageView imageView11 = (ImageView) findChildViewById(view, R.id.imageview110);
        TextView textView12 = (TextView) findChildViewById(view, R.id.textview110);
        LinearLayout linearLayout11 = (LinearLayout) findChildViewById(view, R.id.itemDonateFarajat);
        ImageView imageView12 = (ImageView) findChildViewById(view, R.id.imageview111);
        TextView textView13 = (TextView) findChildViewById(view, R.id.textview111);
        LinearLayout linearLayout12 = (LinearLayout) findChildViewById(view, R.id.itemActivateAbsher);
        ImageView imageView13 = (ImageView) findChildViewById(view, R.id.imageview112);
        TextView textView14 = (TextView) findChildViewById(view, R.id.textview112);
        LinearLayout linearLayout13 = (LinearLayout) findChildViewById(view, R.id.itemVisitVisas);
        ImageView imageView14 = (ImageView) findChildViewById(view, R.id.imageview113);
        TextView textView15 = (TextView) findChildViewById(view, R.id.textview113);
        LinearLayout linearLayout14 = (LinearLayout) findChildViewById(view, R.id.itemBirthCert);
        ImageView imageView15 = (ImageView) findChildViewById(view, R.id.imageview114);
        TextView textView16 = (TextView) findChildViewById(view, R.id.textview114);
        LinearLayout linearLayout15 = (LinearLayout) findChildViewById(view, R.id.itemAcceptance);
        ImageView imageView16 = (ImageView) findChildViewById(view, R.id.imageview115);
        TextView textView17 = (TextView) findChildViewById(view, R.id.textview115);
        LinearLayout linearLayout16 = (LinearLayout) findChildViewById(view, R.id.itemGovPayments);
        ImageView imageView17 = (ImageView) findChildViewById(view, R.id.imageview116);
        TextView textView18 = (TextView) findChildViewById(view, R.id.textview116);
        LinearLayout linearLayout17 = (LinearLayout) findChildViewById(view, R.id.itemDeathCert);
        ImageView imageView18 = (ImageView) findChildViewById(view, R.id.imageview117);
        TextView textView19 = (TextView) findChildViewById(view, R.id.textview117);
        LinearLayout linearLayout18 = (LinearLayout) findChildViewById(view, R.id.itemBorderInquiry);
        ImageView imageView19 = (ImageView) findChildViewById(view, R.id.imageview118);
        TextView textView20 = (TextView) findChildViewById(view, R.id.textview118);
        LinearLayout linearLayout19 = (LinearLayout) findChildViewById(view, R.id.itemResidentIdReq);
        ImageView imageView20 = (ImageView) findChildViewById(view, R.id.imageview119);
        TextView textView21 = (TextView) findChildViewById(view, R.id.textview119);
        Space space = (Space) findChildViewById(view, R.id.space18);
        ImageButton imageButton = (ImageButton) findChildViewById(view, R.id.btnChat);
        LinearLayout linearLayout20 = (LinearLayout) findChildViewById(view, R.id.bottomNavOther);
        LinearLayout linearLayout21 = (LinearLayout) findChildViewById(view, R.id.navHome);
        ImageView imageView21 = (ImageView) findChildViewById(view, R.id.imageview120);
        TextView textView22 = (TextView) findChildViewById(view, R.id.textview120);
        LinearLayout linearLayout22 = (LinearLayout) findChildViewById(view, R.id.navMyServices);
        ImageView imageView22 = (ImageView) findChildViewById(view, R.id.imageview121);
        TextView textView23 = (TextView) findChildViewById(view, R.id.textview121);
        LinearLayout linearLayout23 = (LinearLayout) findChildViewById(view, R.id.navFamily);
        ImageView imageView23 = (ImageView) findChildViewById(view, R.id.imageview122);
        TextView textView24 = (TextView) findChildViewById(view, R.id.textview122);
        LinearLayout linearLayout24 = (LinearLayout) findChildViewById(view, R.id.navWorkers);
        ImageView imageView24 = (ImageView) findChildViewById(view, R.id.imageview123);
        TextView textView25 = (TextView) findChildViewById(view, R.id.textview123);
        LinearLayout linearLayout25 = (LinearLayout) findChildViewById(view, R.id.navOther);
        ImageView imageView25 = (ImageView) findChildViewById(view, R.id.imageview124);
        TextView textView26 = (TextView) findChildViewById(view, R.id.textview124);
        if (scrollView == null || linearLayout == null || relativeLayout2 == null || imageView == null || imageView2 == null || imageView3 == null || imageView4 == null || textView == null || relativeLayout3 == null || textView2 == null || imageView5 == null || linearLayout2 == null || relativeLayout4 == null || imageView6 == null || textView3 == null || textView4 == null || linearLayout3 == null || textView5 == null || textView6 == null || linearLayout4 == null || linearLayout5 == null || textView7 == null || gridLayout == null || linearLayout6 == null || imageView7 == null || textView8 == null || linearLayout7 == null || imageView8 == null || textView9 == null || linearLayout8 == null || imageView9 == null || textView10 == null || linearLayout9 == null || imageView10 == null || textView11 == null || linearLayout10 == null || imageView11 == null || textView12 == null || linearLayout11 == null || imageView12 == null || textView13 == null || linearLayout12 == null || imageView13 == null || textView14 == null || linearLayout13 == null || imageView14 == null || textView15 == null || linearLayout14 == null || imageView15 == null || textView16 == null || linearLayout15 == null || imageView16 == null || textView17 == null || linearLayout16 == null || imageView17 == null || textView18 == null || linearLayout17 == null || imageView18 == null || textView19 == null || linearLayout18 == null || imageView19 == null || textView20 == null || linearLayout19 == null || imageView20 == null || textView21 == null || space == null || imageButton == null || linearLayout20 == null || linearLayout21 == null || imageView21 == null || textView22 == null || linearLayout22 == null || imageView22 == null || textView23 == null || linearLayout23 == null || imageView23 == null || textView24 == null || linearLayout24 == null || imageView24 == null || textView25 == null || linearLayout25 == null || imageView25 == null || textView26 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new OtherServicesBinding(relativeLayout, scrollView, linearLayout, relativeLayout2, imageView, imageView2, imageView3, imageView4, textView, relativeLayout3, textView2, imageView5, linearLayout2, relativeLayout4, imageView6, textView3, textView4, linearLayout3, textView5, textView6, linearLayout4, linearLayout5, textView7, gridLayout, linearLayout6, imageView7, textView8, linearLayout7, imageView8, textView9, linearLayout8, imageView9, textView10, linearLayout9, imageView10, textView11, linearLayout10, imageView11, textView12, linearLayout11, imageView12, textView13, linearLayout12, imageView13, textView14, linearLayout13, imageView14, textView15, linearLayout14, imageView15, textView16, linearLayout15, imageView16, textView17, linearLayout16, imageView17, textView18, linearLayout17, imageView18, textView19, linearLayout18, imageView19, textView20, linearLayout19, imageView20, textView21, space, imageButton, linearLayout20, linearLayout21, imageView21, textView22, linearLayout22, imageView22, textView23, linearLayout23, imageView23, textView24, linearLayout24, imageView24, textView25, linearLayout25, imageView25, textView26);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static OtherServicesBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static OtherServicesBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.other_services, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootOther;
    }
}
