package com.almlkid.ui.preferences;

import android.os.Bundle;
import com.shima.demo.R;

/** قسم Code Style — أحجام الإزاحة لكل لغة وحدّ الاستيرادات. */
public class CodestylePreferencesFragment extends BasePreferenceFragment {
  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    addPreferencesFromResource(R.xml.preferences_codestyle);
  }
}
