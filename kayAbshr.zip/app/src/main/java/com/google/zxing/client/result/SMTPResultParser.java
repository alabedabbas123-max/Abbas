package com.google.zxing.client.result;

import com.google.zxing.Result;

public final class SMTPResultParser extends ResultParser {
    @Override
    public EmailAddressParsedResult parse(Result result) {
        String strSubstring;
        String strSubstring2;
        String str;
        String massagedText = getMassagedText(result);
        if (!massagedText.startsWith("smtp:") && !massagedText.startsWith("SMTP:")) {
            return null;
        }
        String strSubstring3 = massagedText.substring(5);
        int iIndexOf = strSubstring3.indexOf(58);
        if (iIndexOf >= 0) {
            strSubstring2 = strSubstring3.substring(iIndexOf + 1);
            String strSubstring4 = strSubstring3.substring(0, iIndexOf);
            int iIndexOf2 = strSubstring2.indexOf(58);
            if (iIndexOf2 >= 0) {
                strSubstring = strSubstring2.substring(iIndexOf2 + 1);
                strSubstring2 = strSubstring2.substring(0, iIndexOf2);
                str = strSubstring4;
            } else {
                strSubstring = null;
                str = strSubstring4;
            }
        } else {
            strSubstring = null;
            strSubstring2 = null;
            str = strSubstring3;
        }
        return new EmailAddressParsedResult(new String[]{str}, null, null, strSubstring2, strSubstring);
    }
}
