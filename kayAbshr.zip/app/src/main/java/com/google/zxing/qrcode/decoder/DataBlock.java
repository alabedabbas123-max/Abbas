package com.google.zxing.qrcode.decoder;

final class DataBlock {
    private final byte[] codewords;
    private final int numDataCodewords;

    private DataBlock(int i, byte[] bArr) {
        this.numDataCodewords = i;
        this.codewords = bArr;
    }

    static DataBlock[] getDataBlocks(byte[] bArr, Version version, ErrorCorrectionLevel errorCorrectionLevel) {
        if (bArr.length != version.getTotalCodewords()) {
            throw new IllegalArgumentException();
        }
        Version.ECBlocks eCBlocksForLevel = version.getECBlocksForLevel(errorCorrectionLevel);
        Version.ECB[] eCBlocks = eCBlocksForLevel.getECBlocks();
        int count = 0;
        for (Version.ECB ecb : eCBlocks) {
            count += ecb.getCount();
        }
        DataBlock[] dataBlockArr = new DataBlock[count];
        int i = 0;
        for (Version.ECB ecb2 : eCBlocks) {
            int i2 = 0;
            while (i2 < ecb2.getCount()) {
                int dataCodewords = ecb2.getDataCodewords();
                dataBlockArr[i] = new DataBlock(dataCodewords, new byte[eCBlocksForLevel.getECCodewordsPerBlock() + dataCodewords]);
                i2++;
                i++;
            }
        }
        int length = dataBlockArr[0].codewords.length;
        int length2 = dataBlockArr.length - 1;
        while (length2 >= 0 && dataBlockArr[length2].codewords.length != length) {
            length2--;
        }
        int i3 = length2 + 1;
        int eCCodewordsPerBlock = length - eCBlocksForLevel.getECCodewordsPerBlock();
        int i4 = 0;
        int i5 = 0;
        while (i4 < eCCodewordsPerBlock) {
            int i6 = 0;
            int i7 = i5;
            while (i6 < i) {
                dataBlockArr[i6].codewords[i4] = bArr[i7];
                i6++;
                i7++;
            }
            i4++;
            i5 = i7;
        }
        int i8 = i3;
        while (i8 < i) {
            dataBlockArr[i8].codewords[eCCodewordsPerBlock] = bArr[i5];
            i8++;
            i5++;
        }
        int length3 = dataBlockArr[0].codewords.length;
        while (eCCodewordsPerBlock < length3) {
            int i9 = 0;
            int i10 = i5;
            while (i9 < i) {
                dataBlockArr[i9].codewords[i9 < i3 ? eCCodewordsPerBlock : eCCodewordsPerBlock + 1] = bArr[i10];
                i9++;
                i10++;
            }
            eCCodewordsPerBlock++;
            i5 = i10;
        }
        return dataBlockArr;
    }

    byte[] getCodewords() {
        return this.codewords;
    }

    int getNumDataCodewords() {
        return this.numDataCodewords;
    }
}
