package almlk;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * مصدر الحقيقة الوحيد لنمط الكود — المرحلة الثامنة.
 *
 * <p>يحلّ حجم الإزاحة **باسم الملف** من التفضيلات المشتركة، فلا يبقى ثابت مضمّن في كل منسّق.
 * هذا منهج المرجع الذي يحلّ الإزاحة بالامتداد من تفضيل مستقل لكل لغة.
 *
 * <p>عقدان ملتزمان:
 *
 * <ul>
 *   <li>قيمة فاسدة أو غائبة أو عبثية **ترتدّ إلى الافتراضي** بصمت بدل إسقاط الميزة.
 *   <li>بذل الافتراضيات **مرة واحدة** ({@link #seedDefaults}) فلا يُدهس اختيار المستخدم
 *       عند كل إقلاع.
 * </ul>
 */
public final class CodeStyle {

  public static final String XML_INDENT_KEY = "xml_indentation_size";
  public static final String JAVA_INDENT_KEY = "java_indentation_size";
  // المرحلة 2: مفاتيح إزاحة بقية اللغات كما في قسم Code Style.
  public static final String HTML_INDENT_KEY = "html_indentation_size";
  public static final String CSS_INDENT_KEY = "css_indentation_size";
  public static final String JS_INDENT_KEY = "js_indentation_size";
  public static final String CPP_INDENT_KEY = "cpp_indentation_size";
  public static final String MAX_IMPORTS_KEY = "max_single_imports";
  public static final int DEFAULT_MAX_IMPORTS = 100;
  public static final int DEFAULT_INDENT = 4;
  /** سقف يمنع إزاحة عبثية من إدخال يدوي. */
  public static final int MAX_INDENT = 16;

  private CodeStyle() {}

  /**
   * حجم الإزاحة المناسب للملف: تفضيل XML لملفات {@code .xml}، وتفضيل Java لغيرها.
   *
   * <p>غير XML يشمل جافا وما يُلوَّن ويُنسَّق كأسلوبها (gradle/js/ts/json/css) — كتصنيف
   * اللغات المعتمد في المحرر، فلا مفتاح لمنسّق غير موجود.
   */
  public static int indentSizeFor(Context context, String fileName) {
    String lower = fileName == null ? "" : fileName.toLowerCase();
    if (XmlCodeFormatter.isXmlName(fileName)) return indentSize(context, XML_INDENT_KEY);
    if (lower.endsWith(".html") || lower.endsWith(".htm")) return indentSize(context, HTML_INDENT_KEY);
    if (lower.endsWith(".css")) return indentSize(context, CSS_INDENT_KEY);
    if (lower.endsWith(".js") || lower.endsWith(".ts")) return indentSize(context, JS_INDENT_KEY);
    if (lower.endsWith(".c") || lower.endsWith(".h") || lower.endsWith(".cpp") || lower.endsWith(".cc"))
      return indentSize(context, CPP_INDENT_KEY);
    return indentSize(context, JAVA_INDENT_KEY);
  }

  /** سقف الاستيرادات المفردة قبل طيّها بنجمية — يرتدّ آمنًا إلى 100. */
  public static int maxSingleImports(Context context) {
    if (context == null) return DEFAULT_MAX_IMPORTS;
    try {
      String raw = preferences(context).getString(MAX_IMPORTS_KEY, null);
      if (raw == null) return DEFAULT_MAX_IMPORTS;
      int value = Integer.parseInt(raw.trim());
      return value >= 1 && value <= 500 ? value : DEFAULT_MAX_IMPORTS;
    } catch (Throwable ignored) {
      return DEFAULT_MAX_IMPORTS;
    }
  }

  /** قراءة مفتاح إزاحة بارتداد آمن إلى {@link #DEFAULT_INDENT}. */
  public static int indentSize(Context context, String key) {
    if (context == null || key == null) return DEFAULT_INDENT;
    try {
      String raw = preferences(context).getString(key, Integer.toString(DEFAULT_INDENT));
      if (raw == null) return DEFAULT_INDENT;
      int value = Integer.parseInt(raw.trim());
      return value >= 0 && value <= MAX_INDENT ? value : DEFAULT_INDENT;
    } catch (Throwable ignored) {
      return DEFAULT_INDENT;
    }
  }

  /** كتابة مفتاح إزاحة بقيمة مضبوطة ضمن الحدود. */
  public static void setIndentSize(Context context, String key, int value) {
    if (context == null || key == null) return;
    int clamped = value < 0 ? 0 : Math.min(value, MAX_INDENT);
    preferences(context).edit().putString(key, Integer.toString(clamped)).apply();
  }

  /**
   * بذل الافتراضيات مرة واحدة — لا يُدهس اختيار المستخدم.
   *
   * <p>مكافئ {@code PreferenceManager.setDefaultValues(context, xml, false)} في المرجع، لكن
   * بلا مورد تفضيلات ميت: يُبذَل فقط ما تُكرّمه الشيفرة فعلًا.
   */
  /**
   * المرحلة 5 (تعلّم النمط): يستدل حجم الإزاحة من أصغر بادئة مسافات موجبة في المستند،
   * مقرَّبًا إلى أقرب قيمة من {2,4,8}. نقي وقابل للاختبار (بلا Context).
   */
  public static int detectIndent(String source) {
    if (source == null) return DEFAULT_INDENT;
    int min = -1;
    for (String line : source.split("\n")) {
      int spaces = 0;
      while (spaces < line.length() && line.charAt(spaces) == ' ') spaces++;
      if (spaces > 0 && spaces < line.length() && !line.trim().isEmpty()) {
        if (min < 0 || spaces < min) min = spaces;
      }
    }
    if (min < 0) return DEFAULT_INDENT;
    int best = DEFAULT_INDENT, bestDiff = Integer.MAX_VALUE;
    for (int cand : new int[] {2, 4, 8}) {
      int d = Math.abs(cand - min);
      if (d < bestDiff) { bestDiff = d; best = cand; }
    }
    return best;
  }

  public static void seedDefaults(Context context) {
    if (context == null) return;
    try {
      SharedPreferences preferences = preferences(context);
      SharedPreferences.Editor editor = preferences.edit();
      boolean changed = false;
      if (!preferences.contains(XML_INDENT_KEY)) {
        editor.putString(XML_INDENT_KEY, Integer.toString(DEFAULT_INDENT));
        changed = true;
      }
      if (!preferences.contains(JAVA_INDENT_KEY)) {
        editor.putString(JAVA_INDENT_KEY, Integer.toString(DEFAULT_INDENT));
        changed = true;
      }
      String[][] seeds = {
        {HTML_INDENT_KEY, "2"}, {CSS_INDENT_KEY, "2"}, {JS_INDENT_KEY, "4"}, {CPP_INDENT_KEY, "4"}
      };
      for (String[] seed : seeds) {
        if (!preferences.contains(seed[0])) {
          editor.putString(seed[0], seed[1]);
          changed = true;
        }
      }
      if (changed) editor.apply();
    } catch (Throwable ignored) {
      // بذل الافتراضيات تحسين لا شرط؛ فشله لا يُسقط الميزة.
    }
  }

  private static SharedPreferences preferences(Context context) {
    return android.preference.PreferenceManager.getDefaultSharedPreferences(
        context.getApplicationContext());
  }
}
