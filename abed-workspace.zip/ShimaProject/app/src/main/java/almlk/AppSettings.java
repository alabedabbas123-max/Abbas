package almlk;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * مصدر الحقيقة الموحّد لقراءة مفاتيح الإعدادات — المرحلة 1 من خطة الإعدادات.
 *
 * <p>على منهج {@link CodeStyle}: قيمة فاسدة أو غائبة ترتدّ إلى الافتراضي بصمت بدل
 * إسقاط الميزة، والدوال النقية (تحليل/تقييد) قابلة للاختبار بلا Context.
 */
public final class AppSettings {
  public static final String KEY_LANGUAGE = "app_language";
  public static final String KEY_EDITOR_TABS = "editor_tabs";
  public static final String KEY_BROWSER_SWIPE = "browser_swipe";
  public static final String KEY_FONT_SIZE = "editor_font_size";
  public static final String KEY_AUTOSAVE = "autosafe_time";
  public static final String KEY_USE_SPACES = "use_spaces_for_tabs";
  public static final String KEY_TAB_SIZE = "tabsize";
  public static final String KEY_FORCE_SOFT_KEYBOARD = "force_soft_keyboard";
  public static final String KEY_COMPLETE_AFTER_DOT = "complete_after_dot";
  public static final String KEY_COMPLETE_AFTER_LETTER = "complete_after_letter";
  public static final String KEY_COMPLETE_ALL_TYPES = "complete_all_types";

  private AppSettings() {}

  public static SharedPreferences prefs(Context context) {
    return PreferenceManager.getDefaultSharedPreferences(context);
  }

  public static String language(Context context) {
    String value = prefs(context).getString(KEY_LANGUAGE, "default");
    return value == null ? "default" : value;
  }

  /** تبويبات المحرر ظاهرة افتراضيًا (سلوكنا القائم) ويمكن إخفاؤها. */
  public static boolean editorTabs(Context context) {
    return prefs(context).getBoolean(KEY_EDITOR_TABS, true);
  }

  public static boolean browserSwipe(Context context) {
    return prefs(context).getBoolean(KEY_BROWSER_SWIPE, true);
  }

  public static int fontSizeSp(Context context) {
    return clampInt(prefs(context).getString(KEY_FONT_SIZE, "12"), 12, 6, 40);
  }

  /** ثوانٍ؛ -1 = معطّل. */
  public static int autosaveSeconds(Context context) {
    return clampInt(prefs(context).getString(KEY_AUTOSAVE, "-1"), -1, -1, 3600);
  }

  public static boolean useSpacesForTabs(Context context) {
    return prefs(context).getBoolean(KEY_USE_SPACES, true);
  }

  public static int tabSize(Context context) {
    return choiceInt(prefs(context).getString(KEY_TAB_SIZE, "4"), 4, new int[] {2, 4, 8});
  }

  public static boolean forceSoftKeyboard(Context context) {
    return prefs(context).getBoolean(KEY_FORCE_SOFT_KEYBOARD, false);
  }

  public static boolean completeAfterDot(Context context) {
    return prefs(context).getBoolean(KEY_COMPLETE_AFTER_DOT, true);
  }

  public static boolean completeAfterLetter(Context context) {
    return prefs(context).getBoolean(KEY_COMPLETE_AFTER_LETTER, true);
  }

  public static boolean completeAllTypes(Context context) {
    return prefs(context).getBoolean(KEY_COMPLETE_ALL_TYPES, true);
  }

  /** نقي: تحليل عدد صحيح مع تقييد بالنطاق، والفاسد يرتدّ للافتراضي. */
  public static int clampInt(String value, int fallback, int min, int max) {
    try {
      int parsed = Integer.parseInt(value == null ? "" : value.trim());
      return parsed < min || parsed > max ? fallback : parsed;
    } catch (NumberFormatException error) {
      return fallback;
    }
  }

  /** نقي: يقبل القيمة إن كانت ضمن مجموعة مسموحة فقط. */
  public static int choiceInt(String value, int fallback, int[] allowed) {
    try {
      int parsed = Integer.parseInt(value == null ? "" : value.trim());
      for (int candidate : allowed) if (candidate == parsed) return parsed;
    } catch (NumberFormatException ignored) {
      // يرتدّ للافتراضي
    }
    return fallback;
  }
}
