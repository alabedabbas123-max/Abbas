package almlk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * المحلل المعجمي لجافا لفاحص الجمل ({@link JavaSyntaxChecker}).
 *
 * <p>يحوّل النص إلى رموز (معرّفات، كلمات مفتاحية، رموز تشكيل، قيم حرفية، رموز غير صالحة) مع
 * إزاحات النص الأصلي. تُترجم تسلسلات الهروب اليونيكودية (backslash-u) أولًا كما تنص JLS 3.3، وتُربط كل إزاحة
 * مترجمة بموضعها الأصلي فتبقى التشخيصات دقيقة. الأخطاء المعجمية تُسجَّل كـ{@link Issue}، ولا توقف
 * التحليل إلا عند تعليق أو نص كتلي غير مغلق لأن ما بعدهما يصبح نصًا لا رموزًا.
 *
 * <p>يعمل بجافا 8 (مستوى مشروعنا)، وكل الرموز في مصفوفات مسطّحة لتجنب تخصيص كائنات لكل رمز.
 */
public final class JavaTokenizer {
  public static final int IDENTIFIER = 1;
  public static final int KEYWORD = 2;
  public static final int SYMBOL = 3;
  public static final int LITERAL = 4;
  public static final int INVALID = 5;
  public static final int END = 6;

  /** خطأ معجمي مع موضعه الأصلي ومفتاح رسالته المترجمة. */
  public static final class Issue {
    public final int offset;
    public final int end;
    public final String key;
    public final String fallback;
    public final Object[] arguments;

    Issue(int offset, int end, String key, String fallback, Object... arguments) {
      this.offset = offset;
      this.end = end;
      this.key = key;
      this.fallback = fallback;
      this.arguments = arguments;
    }
  }

  // الرموز متعددة الأحرف الأطول أولًا. الرمز ">" يُصدر دائمًا منفردًا: صيغ ">>" و">=" و">>="
  // تُركَّب في المحلل النحوي من رموز متلاصقة، فإغلاق الأنواع العامة ">>" يعمل تلقائيًا.
  private static final String[] MULTI_CHAR_SYMBOLS = {
    "<<=", "...", "->", "::", "++", "--", "&&", "||", "==", "!=", "<=", "<<",
    "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^="
  };
  private static final String SINGLE_CHAR_SYMBOLS = "(){}[];,.@=<>!~?:+-*/&|^%";
  private static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList(
      "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
      "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
      "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long",
      "native", "new", "package", "private", "protected", "public", "return", "short", "static",
      "strictfp", "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try",
      "void", "volatile", "while"));
  private static final Set<String> LITERAL_WORDS = new HashSet<>(Arrays.asList("true", "false", "null"));

  private final String text;
  private final int[] originalIndex;
  private final int originalLength;
  private final List<Issue> issues = new ArrayList<>();
  private boolean stoppedEarly;

  private int[] kinds = new int[256];
  private int[] starts = new int[256];
  private int[] ends = new int[256];
  private String[] values = new String[256];
  private boolean[] erroneous = new boolean[256];
  private int count;

  private JavaTokenizer(String source) {
    Translation translated = translateUnicodeEscapes(source);
    this.text = translated.text;
    this.originalIndex = translated.map;
    this.originalLength = source.length();
  }

  /** يحلّل النص كاملًا ويعيد المحلل الجاهز للقراءة. */
  public static JavaTokenizer tokenize(String source) {
    JavaTokenizer tokenizer = new JavaTokenizer(source == null ? "" : source);
    tokenizer.scan();
    return tokenizer;
  }

  public int count() {
    return count;
  }

  public int kind(int index) {
    return kinds[index];
  }

  /** إزاحة بداية الرمز في النص الأصلي. */
  public int start(int index) {
    return starts[index];
  }

  /** إزاحة نهاية الرمز (حصرية) في النص الأصلي. */
  public int end(int index) {
    return ends[index];
  }

  /** نص المعرّف أو الكلمة المفتاحية أو الرمز؛ {@code null} للقيم الحرفية. */
  public String value(int index) {
    return values[index];
  }

  /**
   * {@code true} إن حمل الرمز خطأً معجميًا (نص أو حرف غير مغلق، رمز غير مسموح). javac يكتم
   * الأخطاء النحوية الواقعة عليه لأن الخطأ المعجمي هو السبب، فيكتمها الفاحص بالقاعدة نفسها.
   */
  public boolean isErroneous(int index) {
    return index >= 0 && index < count && erroneous[index];
  }

  public List<Issue> issues() {
    return issues;
  }

  /** {@code true} عند تعليق أو نص كتلي غير مغلق: لا يُكمل التحليل النحوي بعده. */
  public boolean stoppedEarly() {
    return stoppedEarly;
  }

  // ---------------------------------------------------------------------------------------------

  private void scan() {
    final String s = text;
    final int n = s.length();
    int i = 0;
    scanning:
    while (true) {
      i = skipTrivia(s, i, n);
      if (stoppedEarly) break;
      if (i >= n) break;
      char c = s.charAt(i);
      int start = i;
      int issuesBefore = issues.size();
      int tokenIndex = count;
      if (Character.isJavaIdentifierStart(c)) {
        int j = i + 1;
        while (j < n && Character.isJavaIdentifierPart(s.charAt(j))) j++;
        String word = s.substring(i, j);
        if (LITERAL_WORDS.contains(word)) add(LITERAL, start, j, word);
        else if (KEYWORDS.contains(word)) add(KEYWORD, start, j, word);
        else add(IDENTIFIER, start, j, word);
        i = j;
      } else if (isDigit(c) || (c == '.' && i + 1 < n && isDigit(s.charAt(i + 1)))) {
        i = scanNumber(s, i, n);
        add(LITERAL, start, i, null);
      } else if (c == '"') {
        if (s.startsWith("\"\"\"", i)) {
          int close = findTextBlockEnd(s, i + 3, n);
          if (close < 0) {
            issues.add(new Issue(originalOffset(start), originalOffset(start + 3),
                "ui_diagnostic_unclosed_text_block", "Unclosed text block."));
            stoppedEarly = true;
            break scanning;
          }
          i = close;
        } else {
          i = scanQuoted(s, i, n, '"');
        }
        add(LITERAL, start, i, null);
      } else if (c == '\'') {
        i = scanCharLiteral(s, i, n);
        add(LITERAL, start, i, null);
      } else {
        int symbolLength = symbolLengthAt(s, i, n);
        if (symbolLength > 0) {
          i += symbolLength;
          add(SYMBOL, start, i, s.substring(start, i));
        } else {
          issues.add(new Issue(originalOffset(i), originalOffset(i + 1),
              "ui_diagnostic_illegal_character", "illegal character: '%1$s'", String.valueOf(c)));
          i++;
          add(INVALID, start, i, null);
        }
      }
      if (issues.size() > issuesBefore && tokenIndex < count) erroneous[tokenIndex] = true;
    }
    add(END, n, n, null);
  }

  /** يتخطى المسافات والتعليقات؛ يضبط {@link #stoppedEarly} عند تعليق كتلي غير مغلق. */
  private int skipTrivia(String s, int i, int n) {
    while (i < n) {
      char c = s.charAt(i);
      if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\uFEFF'
          || Character.isWhitespace(c)) {
        i++;
      } else if (c == '/' && i + 1 < n && s.charAt(i + 1) == '/') {
        i += 2;
        while (i < n && s.charAt(i) != '\n' && s.charAt(i) != '\r') i++;
      } else if (c == '/' && i + 1 < n && s.charAt(i + 1) == '*') {
        int close = s.indexOf("*/", i + 2);
        if (close < 0) {
          issues.add(new Issue(originalOffset(i), originalOffset(i + 2),
              "ui_diagnostic_unclosed_block_comment", "Unclosed block comment."));
          stoppedEarly = true;
          return n;
        }
        i = close + 2;
      } else {
        break;
      }
    }
    return i;
  }

  private static int scanNumber(String s, int i, int n) {
    boolean hex = s.charAt(i) == '0' && i + 1 < n && (s.charAt(i + 1) == 'x' || s.charAt(i + 1) == 'X');
    int j = i + 1;
    while (j < n) {
      char d = s.charAt(j);
      if (Character.isLetterOrDigit(d) || d == '_' || d == '.') {
        j++;
      } else if ((d == '+' || d == '-') && isExponentMarker(s.charAt(j - 1), hex)) {
        j++;
      } else {
        break;
      }
    }
    return j;
  }

  private static boolean isExponentMarker(char c, boolean hex) {
    return hex ? (c == 'p' || c == 'P') : (c == 'e' || c == 'E');
  }

  /** يعيد موضع الإغلاق بعد ثلاث علامات اقتباس، أو -1 إن لم يُغلق النص. */
  private static int findTextBlockEnd(String s, int from, int n) {
    int j = from;
    while (j < n) {
      char d = s.charAt(j);
      if (d == '\\') {
        j += 2;
      } else if (d == '"' && s.startsWith("\"\"\"", j)) {
        return j + 3;
      } else {
        j++;
      }
    }
    return -1;
  }

  /** نص عادي بين علامتي اقتباس؛ يتوقف عند نهاية السطر (غير مغلق) دون أن يبلعه. */
  private int scanQuoted(String s, int i, int n, char quote) {
    int j = i + 1;
    while (j < n) {
      char d = s.charAt(j);
      if (d == '\n' || d == '\r') {
        issues.add(new Issue(originalOffset(i), originalOffset(i + 1),
            "ui_diagnostic_unclosed_string", "Unclosed string literal."));
        return j;
      }
      if (d == '\\') {
        if (j + 1 < n && (s.charAt(j + 1) == '\n' || s.charAt(j + 1) == '\r')) {
          issues.add(new Issue(originalOffset(i), originalOffset(i + 1),
              "ui_diagnostic_unclosed_string", "Unclosed string literal."));
          return j;
        }
        j += 2;
      } else if (d == quote) {
        return j + 1;
      } else {
        j++;
      }
    }
    issues.add(new Issue(originalOffset(i), originalOffset(i + 1),
        "ui_diagnostic_unclosed_string", "Unclosed string literal."));
    return n;
  }

  /** حرف بين علامتي اقتباس مفردتين: حرف واحد أو تسلسل هروب؛ غير ذلك خطأ معجمي. */
  private int scanCharLiteral(String s, int i, int n) {
    if (i + 1 < n && s.charAt(i + 1) == '\'') {
      issues.add(new Issue(originalOffset(i), originalOffset(i + 2),
          "ui_diagnostic_empty_char_literal", "empty character literal"));
      return i + 2;
    }
    int j = i + 1;
    while (j < n) {
      char d = s.charAt(j);
      if (d == '\n' || d == '\r') break;
      if (d == '\\') {
        if (j + 1 < n && (s.charAt(j + 1) == '\n' || s.charAt(j + 1) == '\r')) break;
        j += 2;
        continue;
      }
      if (d == '\'') {
        int contentLength = j - (i + 1);
        boolean escape = s.charAt(i + 1) == '\\';
        if (contentLength != 1 && !(escape && contentLength >= 2)) {
          issues.add(new Issue(originalOffset(i), originalOffset(j + 1),
              "ui_diagnostic_unclosed_char_literal", "unclosed character literal"));
        }
        return j + 1;
      }
      j++;
    }
    issues.add(new Issue(originalOffset(i), originalOffset(i + 1),
        "ui_diagnostic_unclosed_char_literal", "unclosed character literal"));
    return Math.min(j, n);
  }

  private static int symbolLengthAt(String s, int i, int n) {
    for (String symbol : MULTI_CHAR_SYMBOLS) {
      if (symbol.length() == 3 && i + 3 <= n && s.startsWith(symbol, i)) return 3;
    }
    for (String symbol : MULTI_CHAR_SYMBOLS) {
      if (symbol.length() == 2 && i + 2 <= n && s.startsWith(symbol, i)) return 2;
    }
    return SINGLE_CHAR_SYMBOLS.indexOf(s.charAt(i)) >= 0 ? 1 : 0;
  }

  private static boolean isDigit(char c) {
    return c >= '0' && c <= '9';
  }

  private void add(int kind, int start, int end, String value) {
    if (count == kinds.length) {
      int size = count * 2;
      kinds = Arrays.copyOf(kinds, size);
      starts = Arrays.copyOf(starts, size);
      ends = Arrays.copyOf(ends, size);
      values = Arrays.copyOf(values, size);
      erroneous = Arrays.copyOf(erroneous, size);
    }
    kinds[count] = kind;
    starts[count] = originalOffset(start);
    ends[count] = originalOffset(end);
    values[count] = value;
    count++;
  }

  private int originalOffset(int translatedIndex) {
    if (originalIndex == null) return Math.min(translatedIndex, originalLength);
    return originalIndex[Math.min(translatedIndex, originalIndex.length - 1)];
  }

  // ---------------------------------------------------------------------------------------------

  private static final class Translation {
    final String text;
    final int[] map;

    Translation(String text, int[] map) {
      this.text = text;
      this.map = map;
    }
  }

  /** يترجم \\uXXXX كما تنص JLS 3.3 (الشَّرطة المائلة يجب أن تسبقها عدد زوجي من الشرطات). */
  private static Translation translateUnicodeEscapes(String source) {
    if (source.indexOf("\\u") < 0) return new Translation(source, null);
    int n = source.length();
    StringBuilder out = new StringBuilder(n);
    int[] map = new int[n + 1];
    int i = 0;
    while (i < n) {
      char c = source.charAt(i);
      if (c == '\\' && i + 1 < n && source.charAt(i + 1) == 'u' && precedingBackslashesEven(source, i)) {
        int j = i + 1;
        while (j < n && source.charAt(j) == 'u') j++;
        if (j + 4 <= n && isHexQuad(source, j)) {
          map[out.length()] = i;
          out.append((char) Integer.parseInt(source.substring(j, j + 4), 16));
          i = j + 4;
          continue;
        }
      }
      map[out.length()] = i;
      out.append(c);
      i++;
    }
    map[out.length()] = n;
    return new Translation(out.toString(), Arrays.copyOf(map, out.length() + 1));
  }

  private static boolean precedingBackslashesEven(String source, int index) {
    int backslashes = 0;
    for (int k = index - 1; k >= 0 && source.charAt(k) == '\\'; k--) backslashes++;
    return (backslashes & 1) == 0;
  }

  private static boolean isHexQuad(String source, int from) {
    for (int k = from; k < from + 4; k++) {
      char c = source.charAt(k);
      boolean hex = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
      if (!hex) return false;
    }
    return true;
  }
}
