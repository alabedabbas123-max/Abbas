package com.almlkid.ui.browsers;

import android.app.AlertDialog;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import androidx.documentfile.provider.DocumentFile;
import android.util.AttributeSet;
import android.view.*;
import android.webkit.MimeTypeMap;
import android.widget.*;
import com.almlkid.kay.ui.ProjectSearchEngine;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.ui.UsageSearchEngine;
import com.shima.demo.R;
import com.shima.performance.EncodingManager;
import com.shima.performance.PersistentSymbolIndexStore;
import com.shima.editor.core.DexMetadataReader;
import com.shima.demo.ThemeConfig;
import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Complete project browser. SAF is the primary backend; java.io.File is a fallback. */
public class BrowserPager extends LinearLayout {
  public interface Listener {
    void selected(String name, String content);
  }

  /**
   * تقرير فتح الملفات — «فتح فوري»: يُطلق لحظة نقرة الملف (قبل قراءة المحتوى)
   * ليعرض التبويب فورًا. Default فارغ حتى تبقى بقية الحالات اختيارية.
   */
  public interface FileOpeningCallback {
    void onFileOpening(String name);
  }

  /** حاوية قابلة للإلغاء تخزّن المؤشر، وتتسامح مع عدم الربط. */
  private static final class OpeningCallbackHolder {
    FileOpeningCallback callback;

    void notifyOpening(String name) {
      if (callback != null) callback.onFileOpening(name);
    }
  }

  public interface MutationListener {
    void completed(boolean success, String fileName, String content, String message);
  }

  public interface SaveListener {
    void completed(boolean success, String message);
  }

  public interface DefinitionOpenListener {
    void completed(boolean success, String fileName, String content, int offset, String message);
  }

  public interface UsageListener {
    void completed(List<UsageSearchEngine.Usage> usages);
  }

  public interface ProjectSearchListener {
    void completed(List<UsageSearchEngine.Usage> results, int filesScanned, boolean cancelled);
  }

  public interface DefinitionSearchListener {
    void completed(ProjectSymbolIndex.DefinitionTarget target);
  }

  public interface SymbolSearchListener {
    void completed(List<ProjectSymbolIndex.DefinitionTarget> results, boolean cancelled);
  }

  public interface ActionListener {
    void onCreateProject();

    void onCloneGit();

    void onStoragePermissionRequested();

    void onProjectOpened(String name, String path);

    void onSelectProjectFolder();
  }

  private static final int ACTION_CREATE_PROJECT = 1,
      ACTION_CLONE = 2,
      ACTION_PERMISSION = 3,
      ACTION_UP_DOCUMENT = 4,
      ACTION_SELECT_TREE = 5,
      ACTION_EMPTY = 6,
      ACTION_UP_FILE = 7;
  private Listener listener;
  private final OpeningCallbackHolder openingCallback = new OpeningCallbackHolder();
  private ActionListener actions;
  private TextView pathLabel;
  private View header;
  private ListView list;
  private final ArrayList<Entry> entries = new ArrayList<>();
  /** تقرير AIDE — ThemeConfig واحد مخزّن بدل إنشائه لكل صف في القائمة. */
  private ThemeConfig cachedEntryTheme;
  private final Map<String, Entry> openedEntries = Collections.synchronizedMap(new HashMap<>());
  private ExecutorService fileReader = Executors.newSingleThreadExecutor();
  private ExecutorService directoryReader = Executors.newFixedThreadPool(2);
  private ExecutorService symbolWorker = Executors.newSingleThreadExecutor();
  // Searches have their own short-lived lane so the first project index build never blocks typing.
  private ExecutorService symbolSearchWorker = Executors.newFixedThreadPool(2);
  private final HashMap<String, Entry> symbolFiles = new HashMap<>();
  private PersistentSymbolIndexStore symbolIndexStore;
  private String indexedProjectKey = "";
  private final Object activeSymbolLock = new Object();
  private String activeSymbolFile = "", activeSymbolReference = "", activeSymbolSource = "";
  private int activeSymbolLength, activeSymbolHash;
  private boolean activeSymbolsReady;
  private List<ProjectSymbolIndex.DefinitionTarget> activeSymbols = Collections.emptyList();
  // Metadata-only workspace catalog. Contents stay lazy and are loaded only when a search/open
  // request needs them, following AndroidIDE's separate file/index and document-content model.
  private final LinkedHashMap<String, Entry> searchFileCatalog = new LinkedHashMap<>();
  private volatile boolean searchCatalogReady;
  private final android.os.Handler mainHandler =
      new android.os.Handler(android.os.Looper.getMainLooper());
  private final LinkedHashMap<String, List<Entry>> directoryCache =
      new LinkedHashMap<String, List<Entry>>(64, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, List<BrowserPager.Entry>> eldest) {
          return size() > 40;
        }
      };
  private final HashSet<String> prefetching = new HashSet<>();
  private final com.shima.performance.FileContentCache fileContentCache =
      new com.shima.performance.FileContentCache(4 * 1024 * 1024);
  private int openGeneration, navigationGeneration;
  private Future<?> openTask, projectSearchTask, symbolSearchTask;
  private int projectSearchGeneration;
  private Uri pendingProjectDetection, projectDocumentUri;
  private File currentFile, projectFile;
  private DocumentFile documentRoot, currentDocument;
  private final ArrayDeque<DocumentFile> documentParents = new ArrayDeque<>();
  private boolean usingDocuments;

  private static class Entry {
    String name;
    File file;
    DocumentFile document;
    Uri documentUri;
    long size;
    long modified;
    boolean folder;
    int icon, action, depth;

    Entry(String n, File f, DocumentFile d, boolean dir, int i, int a) {
      this(n, f, d, dir, i, a, 0);
    }

    Entry(String n, File f, DocumentFile d, boolean dir, int i, int a, int level) {
      name = n;
      file = f;
      document = d;
      documentUri = d == null ? null : d.getUri();
      folder = dir;
      icon = i;
      action = a;
      depth = level;
      size = f == null ? -1 : f.isFile() ? f.length() : -1;
      modified = f == null ? 0 : f.lastModified();
    }

    Entry(String n, Uri uri, boolean dir, long length, int drawable) {
      this(n, uri, dir, length, 0, drawable);
    }

    Entry(String n, Uri uri, boolean dir, long length, long lastModified, int drawable) {
      name = n;
      documentUri = uri;
      folder = dir;
      size = length;
      modified = lastModified;
      icon = drawable;
    }
  }

  public BrowserPager(Context c) {
    super(c);
    init();
  }

  public BrowserPager(Context c, AttributeSet a) {
    super(c, a);
    init();
  }

  public BrowserPager(Context c, AttributeSet a, int s) {
    super(c, a, s);
    init();
  }

  public void setOnFileSelectedListener(Listener l) {
    listener = l;
  }

  /** تقرير فتح الملفات — ربط نغمة «الفتح الفوري» (تُستدعى قبل محتوى الملف). */
  public void setOnFileOpeningListener(FileOpeningCallback callback) {
    openingCallback.callback = callback;
  }

  public void setActionListener(ActionListener l) {
    actions = l;
  }

  private void init() {
    symbolIndexStore = new PersistentSymbolIndexStore(getContext());
    setLayoutDirection(LAYOUT_DIRECTION_LTR);
    setTextDirection(TEXT_DIRECTION_LTR);
    setOrientation(VERTICAL);
    setBackgroundColor(Color.rgb(25, 25, 25));
    header = LayoutInflater.from(getContext()).inflate(R.layout.browser_header, this, false);
    header.setLayoutDirection(LAYOUT_DIRECTION_LTR);
    pathLabel = header.findViewById(R.id.browserHeaderLabel);
    pathLabel.setTextDirection(TEXT_DIRECTION_LTR);
    pathLabel.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
    ((ImageView) header.findViewById(R.id.browserHeaderIcon))
        .setImageResource(R.drawable.folder_open);
    header.findViewById(R.id.browserHeaderMenuButton).setOnClickListener(this::showHeaderMenu);
    addView(header, new LayoutParams(-1, -2));
    View body = LayoutInflater.from(getContext()).inflate(R.layout.filebrowser, this, false);
    list = body.findViewById(R.id.filebrowserFileList);
    list.setBackgroundColor(Color.rgb(25, 25, 25));
    list.setCacheColorHint(Color.TRANSPARENT);
    list.setDivider(new ColorDrawable(Color.TRANSPARENT));
    list.setDividerHeight(0);
    list.setAdapter(new FolderAdapter());
    list.setOnItemClickListener((p, v, pos, id) -> activate(entries.get(pos)));
    list.setOnItemLongClickListener(
        (p, v, pos, id) -> {
          Entry e = entries.get(pos);
          if (e.action == 0) showEntryMenu(v, e);
          return true;
        });
    addView(body, new LayoutParams(-1, 0, 1));
    applyTheme();
    pathLabel.setText("جارٍ تحميل المشاريع…");
    restoreProjectRootReference();
    post(
        () -> {
          if (!restoreDocumentTree()) {
            loadFile(new File(Environment.getExternalStorageDirectory(), "AppProjects"));
          }
        });
  }

  public void openTree(Uri treeUri) {
    try {
      getContext()
          .getContentResolver()
          .takePersistableUriPermission(
              treeUri,
              Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
    } catch (Exception writeNotGranted) {
      try {
        getContext()
            .getContentResolver()
            .takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
      } catch (Exception ignored) {
      }
    }
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .putString("tree_uri", treeUri.toString())
        .apply();
    DocumentFile root = DocumentFile.fromTreeUri(getContext(), treeUri);
    if (root == null) {
      toast("تعذر فتح المجلد المحدد");
      return;
    }
    usingDocuments = true;
    documentRoot = root;
    invalidateSearchCatalog();
    documentParents.clear();
    pendingProjectDetection = root.getUri();
    loadDocument(root, false);
  }

  /** يفتح جذر مشروع محدد مباشرة — لاستعادة الجلسة أو التراجع عن تبديل المشروع. */
  public void openProjectRoot(String path) {
    if ((path == null || path.isEmpty()) && projectDocumentUri != null) {
      openTree(projectDocumentUri);
      return;
    }
    if (path == null || path.isEmpty()) return;
    if (path.startsWith("content:")) {
      openTree(Uri.parse(path));
      return;
    }
    File dir = new File(path);
    if (!dir.isDirectory()) return;
    projectFile = dir;
    projectDocumentUri = null;
    rememberProjectRoot();
    loadFile(dir);
  }

  /** التخزين المؤقت للمشروع الحالي فقط: إسقاط كاشات مشروع سابق فورًا وبسرعة. */
  public void suspendProjectCacheFor(String previousReference) {
    if (previousReference != null && !previousReference.isEmpty() && symbolIndexStore != null) {
      String key =
          previousReference.startsWith("/")
              ? "file:" + previousReference
              : previousReference.startsWith("content:") ? "uri:" + previousReference : "";
      // إسقاط قيود المشروع السابق فقط من المخزن الدائم — مشروع المستخدم الحالي لا يُمس.
      if (!key.isEmpty() && !key.equals(symbolProjectKey())) {
        try {
          symbolIndexStore.pruneProject(key, java.util.Collections.<String>emptySet());
        } catch (Throwable ignored) {
        }
      }
    }
    synchronized (definitionLookupCache) {
      definitionLookupCache.clear();
    }
    synchronized (symbolFiles) {
      symbolFiles.clear();
    }
    synchronized (searchFileCatalog) {
      searchFileCatalog.clear();
      searchCatalogReady = false;
    }
    openedEntries.clear();
  }

  private boolean restoreDocumentTree() {
    String saved =
        getContext()
            .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
            .getString("tree_uri", "");
    if (saved.isEmpty()) return false;
    try {
      Uri savedUri = Uri.parse(saved);
      if (!hasPersistedReadPermission(savedUri)) {
        clearSavedTree();
        return false;
      }
      DocumentFile root = DocumentFile.fromTreeUri(getContext(), savedUri);
      if (root != null) {
        usingDocuments = true;
        documentRoot = root;
        documentParents.clear();
        loadDocument(root, false);
        return true;
      }
    } catch (Exception ignored) {
    }
    clearSavedTree();
    return false;
  }

  private boolean hasPersistedReadPermission(Uri treeUri) {
    for (UriPermission permission :
        getContext().getContentResolver().getPersistedUriPermissions()) {
      if (permission.isReadPermission() && permission.getUri().equals(treeUri)) return true;
    }
    return false;
  }

  private void clearSavedTree() {
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .remove("tree_uri")
        .apply();
  }

  private void rememberProjectRoot() {
    getContext()
        .getSharedPreferences("file_browser", Context.MODE_PRIVATE)
        .edit()
        .putString("project_uri", projectDocumentUri == null ? "" : projectDocumentUri.toString())
        .putString("project_file", projectFile == null ? "" : projectFile.getAbsolutePath())
        .apply();
  }

  private void restoreProjectRootReference() {
    android.content.SharedPreferences preferences =
        getContext().getSharedPreferences("file_browser", Context.MODE_PRIVATE);
    String uri = preferences.getString("project_uri", "");
    String file = preferences.getString("project_file", "");
    if (!uri.isEmpty()) {
      projectDocumentUri = Uri.parse(uri);
      projectFile = null;
    } else if (!file.isEmpty()) {
      projectFile = new File(file);
      projectDocumentUri = null;
    }
  }

  public void applyTheme() {
    ThemeConfig theme = new ThemeConfig(getContext());
    int background = theme.isDark() ? Color.rgb(25, 25, 25) : Color.rgb(250, 250, 250);
    int chrome = Color.rgb(31, 31, 31);
    setBackgroundColor(background);
    if (list != null) {
      list.setBackgroundColor(background);
      ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
    }
    if (header != null) header.setBackgroundColor(chrome);
    if (pathLabel != null) pathLabel.setTextColor(Color.WHITE);
  }

  private void invalidateSearchCatalog() {
    synchronized (searchFileCatalog) {
      searchFileCatalog.clear();
      searchCatalogReady = false;
    }
  }

  public void refresh() {
    invalidateSearchCatalog();
    // إن تغيّر الثيم (تبديل داكن/فاتح) نعيد بناء ThemeConfig المخزّن ليتلوّن النص الجديد.
    cachedEntryTheme = null;
    if (usingDocuments && currentDocument != null) {
      invalidateDirectory(documentCacheKey(currentDocument.getUri()));
      loadDocument(currentDocument, true);
    } else if (currentFile != null) {
      invalidateDirectory(fileCacheKey(currentFile));
      loadFile(currentFile);
    }
  }

  public void createFile() {
    promptCreate(false);
  }

  public void createFolder() {
    promptCreate(true);
  }

  public String getCurrentPath() {
    return usingDocuments && currentDocument != null
        ? pathForDocument(currentDocument)
        : currentFile == null ? "" : currentFile.getAbsolutePath();
  }

  /** Returns a stable File path or SAF content URI for metadata-only session restoration. */
  public String fileReference(String name) {
    Entry entry = openedEntries.get(name);
    if (entry == null) return "";
    if (entry.documentUri != null) return entry.documentUri.toString();
    return entry.file == null ? "" : entry.file.getAbsolutePath();
  }

  /** Supplies the visible editor snapshot so Go To Element can answer before the disk index ends. */
  public void setActiveEditorSnapshot(String fileName, String source, String reference) {
    String file = fileName == null ? "" : fileName;
    String text = source == null ? "" : source;
    String stable = reference == null ? "" : reference;
    int length = text.length();
    int hash = text.hashCode();
    synchronized (activeSymbolLock) {
      if (activeSymbolFile.equals(file)
          && activeSymbolReference.equals(stable)
          && activeSymbolLength == length
          && activeSymbolHash == hash) return;
      activeSymbolFile = file;
      activeSymbolReference = stable;
      activeSymbolSource = text;
      activeSymbolLength = length;
      activeSymbolHash = hash;
      activeSymbols = Collections.emptyList();
      activeSymbolsReady = false;
    }
  }

  private List<ProjectSymbolIndex.DefinitionTarget> activeSymbolsSnapshot() {
    String file, reference, source;
    int length, hash;
    synchronized (activeSymbolLock) {
      if (activeSymbolsReady) return activeSymbols;
      file = activeSymbolFile;
      reference = activeSymbolReference;
      source = activeSymbolSource;
      length = activeSymbolLength;
      hash = activeSymbolHash;
    }
    if (source.isEmpty() || file.isEmpty()) return Collections.emptyList();
    List<ProjectSymbolIndex.DefinitionTarget> parsed =
        ProjectSymbolIndex.extractSourceSymbols(file, reference, source);
    synchronized (activeSymbolLock) {
      if (activeSymbolFile.equals(file)
          && activeSymbolReference.equals(reference)
          && activeSymbolLength == length
          && activeSymbolHash == hash) {
        activeSymbols = Collections.unmodifiableList(new ArrayList<>(parsed));
        activeSymbolsReady = true;
        return activeSymbols;
      }
    }
    return parsed;
  }

  private List<ProjectSymbolIndex.DefinitionTarget> searchSymbolsNow(
      String query, boolean includeSystem) {
    ArrayList<ProjectSymbolIndex.DefinitionTarget> combined = new ArrayList<>();
    combined.addAll(ProjectSymbolIndex.searchSymbols(query, 400, includeSystem));
    combined.addAll(ProjectSymbolIndex.filterSymbols(activeSymbolsSnapshot(), query, 200));
    return ProjectSymbolIndex.filterSymbols(combined, query, 400);
  }

  public void saveOpenedFileAsync(String name, String content, SaveListener listener) {
    Entry entry = openedEntries.get(name);
    if (entry == null) {
      if (listener != null) listener.completed(false, "تعذر العثور على الملف المفتوح");
      return;
    }
    fileReader.execute(
        () -> {
          boolean success = false;
          String message;
          try {
            OutputStream output =
                entry.documentUri != null
                    ? getContext().getContentResolver().openOutputStream(entry.documentUri, "wt")
                    : new FileOutputStream(entry.file, false);
            if (output == null) throw new IOException("مزود الملفات لم يسمح بالكتابة");
            output.write(EncodingManager.encodeUtf8(content));
            output.flush();
            output.close();
            cacheFileContent(fileContentKey(entry), content);
            persistJavaIndex(entry, content);
            success = true;
            message = "تم حفظ الملف";
          } catch (Exception error) {
            message = "تعذر الحفظ: " + error.getMessage();
          }
          final boolean result = success;
          final String resultMessage = message;
          mainHandler.post(
              () -> {
                if (listener != null) listener.completed(result, resultMessage);
              });
        });
  }

  private void activate(Entry e) {
    if (e.action == ACTION_CREATE_PROJECT) {
      if (actions != null) actions.onCreateProject();
      return;
    }
    if (e.action == ACTION_CLONE) {
      if (actions != null) actions.onCloneGit();
      return;
    }
    if (e.action == ACTION_PERMISSION) {
      if (actions != null) actions.onStoragePermissionRequested();
      return;
    }
    if (e.action == ACTION_SELECT_TREE) {
      if (actions != null) actions.onSelectProjectFolder();
      return;
    }
    if (e.action == ACTION_UP_DOCUMENT) {
      if (!documentParents.isEmpty()) loadDocument(documentParents.removeLast(), true);
      return;
    }
    // تقرير فتح الملفات — قناة الصعود آمنة دائمًا: «..» لا يمر أبدًا بضغط المجلدات
    // وحيدة الفرع، وإلا ارتدّ المستخدم إلى قاع سلسلة java/com/example بلا مخرج.
    if (e.action == ACTION_UP_FILE) {
      if (e.file != null) loadFileUp(e.file);
      return;
    }
    if (e.action == ACTION_EMPTY) return;
    if (e.folder) {
      if (usingDocuments) {
        // تقرير «إظهار جميع الملفات» — عنصر مدمج من التخزين المباشر (نقطي مثل .gradle)
        // لا documentUri له: تنقّل عبر المسار المباشر بأمان تام.
        if (e.documentUri == null && e.file != null) {
          loadFile(e.file);
          return;
        }
        DocumentFile target =
            e.document != null
                ? e.document
                : DocumentFile.fromSingleUri(getContext(), e.documentUri);
        if (target == null) {
          toast("تعذر فتح المجلد");
          return;
        }
        if (currentDocument == documentRoot && actions != null) {
          projectDocumentUri = e.documentUri;
          projectFile = null;
          rememberProjectRoot();
          actions.onProjectOpened(e.name, pathForUri(e.documentUri));
        }
        documentParents.addLast(currentDocument);
        loadDocument(target, true);
      } else {
        if (currentFile != null && currentFile.getName().equals("AppProjects") && actions != null) {
          projectFile = e.file;
          projectDocumentUri = null;
          rememberProjectRoot();
          actions.onProjectOpened(e.name, e.file.getAbsolutePath());
        }
        loadFile(e.file);
      }
      return;
    }
    openedEntries.put(e.name, e);
    if (listener == null) {
      // دفاع: لا صمت أبدًا — المُستمع يجب أن يكوّن مربوطًا دائمًا في MainActivity.
      toast("تعذر فتح الملف: واجهة الفتح غير مهيأة");
      return;
    }
    // تقرير فتح الملفات — الملكية الصحيحة للقراءة: الخدمة almlk.FileContentService تنشق عن
    // مصير هذا الدرج (الذي يُغلق للحظة ولا يجوز أن يقتل قراءة جارية). هنا نعلن فورًا فقط.
    openGeneration++;
    openingCallback.notifyOpening(e.name);
  }

  private void loadDocument(DocumentFile directory, boolean preserveParents) {
    usingDocuments = true;
    currentDocument = directory;
    currentFile = null;
    pathLabel.setText(pathForDocument(directory));
    final Uri uri = directory.getUri();
    final String key = documentCacheKey(uri);
    final int request = ++navigationGeneration;
    List<Entry> cached = cachedDirectory(key);
    if (cached != null) {
      showDocumentEntries(directory, uri, cached, request);
      return;
    }
    showLoadingEntry();
    directoryReader.execute(
        () -> {
          List<Entry> loaded;
          try {
            loaded = sortedEntries(queryDocumentChildren(uri));
            cacheDirectory(key, loaded);
          } catch (Exception error) {
            loaded = null;
          }
          final List<Entry> result = loaded;
          mainHandler.post(() -> showDocumentEntries(directory, uri, result, request));
        });
  }

  private void showDocumentEntries(
      DocumentFile directory, Uri uri, List<Entry> children, int request) {
    if (request != navigationGeneration
        || currentDocument == null
        || !currentDocument.getUri().equals(uri)) return;
    entries.clear();
    if (!documentParents.isEmpty())
      entries.add(new Entry("..", null, null, true, R.drawable.folder_open, ACTION_UP_DOCUMENT));
    if (directory == documentRoot && nameForUri(uri).equalsIgnoreCase("AppProjects")) {
      entries.add(
          new Entry(
              "إنشاء مشروع جديد...",
              null,
              null,
              false,
              R.drawable.ic_launcher_java,
              ACTION_CREATE_PROJECT));
      entries.add(
          new Entry(
              "استنساخ مستودع Git...", null, null, false, R.drawable.browser_git, ACTION_CLONE));
    }
    if (children == null) {
      entries.add(
          new Entry(
              "⚠ أعد اختيار المجلد لمنح صلاحية القراءة",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
    } else if (children.isEmpty()) {
      entries.add(
          new Entry("المجلد فارغ", null, null, false, R.drawable.folder_open, ACTION_EMPTY));
    } else {
      entries.addAll(children);
    }
    notifyList();
    if (pendingProjectDetection != null && pendingProjectDetection.equals(uri)) {
      pendingProjectDetection = null;
      if (children != null && entriesLookLikeProject() && actions != null) {
        projectDocumentUri = uri;
        projectFile = null;
        rememberProjectRoot();
        actions.onProjectOpened(nameForUri(uri), pathForDocument(directory));
      }
    }
    if (children != null) prefetchDocumentChildren(children);
  }

  private void showLoadingEntry() {
    entries.clear();
    entries.add(
        new Entry("جارٍ فتح المجلد…", null, null, false, R.drawable.folder_open, ACTION_EMPTY));
    notifyList();
  }

  private List<Entry> sortedEntries(Entry[] source) {
    Arrays.sort(
        source,
        (a, b) -> {
          if (a.folder != b.folder) return a.folder ? -1 : 1;
          return a.name.compareToIgnoreCase(b.name);
        });
    return new ArrayList<>(Arrays.asList(source));
  }

  private void prefetchDocumentChildren(List<Entry> children) {
    ArrayList<Entry> folders = new ArrayList<>();
    for (Entry entry : children) {
      if (entry.folder && entry.documentUri != null && folders.size() < 8) folders.add(entry);
    }
    if (folders.isEmpty()) return;
    directoryReader.execute(
        () -> {
          for (Entry folder : folders) {
            String key = documentCacheKey(folder.documentUri);
            synchronized (directoryCache) {
              if (directoryCache.containsKey(key) || !prefetching.add(key)) continue;
            }
            try {
              cacheDirectory(key, sortedEntries(queryDocumentChildren(folder.documentUri)));
            } catch (Exception ignored) {
            } finally {
              synchronized (directoryCache) {
                prefetching.remove(key);
              }
            }
          }
        });
  }

  private Entry[] queryDocumentChildren(Uri directoryUri) throws Exception {
    String parentId = DocumentsContract.getDocumentId(directoryUri);
    Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(directoryUri, parentId);
    String[] projection = {
      DocumentsContract.Document.COLUMN_DOCUMENT_ID,
      DocumentsContract.Document.COLUMN_DISPLAY_NAME,
      DocumentsContract.Document.COLUMN_MIME_TYPE,
      DocumentsContract.Document.COLUMN_SIZE,
      DocumentsContract.Document.COLUMN_LAST_MODIFIED
    };
    ArrayList<Entry> result = new ArrayList<>();
    try (Cursor cursor =
        getContext().getContentResolver().query(childrenUri, projection, null, null, null)) {
      if (cursor == null) throw new IOException("Document provider returned no cursor");
      int idColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
      int nameColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
      int mimeColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE);
      int sizeColumn = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
      int modifiedColumn = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
      while (cursor.moveToNext()) {
        String documentId = cursor.getString(idColumn);
        String name = cursor.isNull(nameColumn) ? "بدون اسم" : cursor.getString(nameColumn);
        String mime = cursor.isNull(mimeColumn) ? "" : cursor.getString(mimeColumn);
        boolean folder = DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);
        long size = sizeColumn < 0 || cursor.isNull(sizeColumn) ? -1 : cursor.getLong(sizeColumn);
        long modified =
            modifiedColumn < 0 || cursor.isNull(modifiedColumn) ? 0 : cursor.getLong(modifiedColumn);
        Uri childUri = DocumentsContract.buildDocumentUriUsingTree(directoryUri, documentId);
        result.add(
            new Entry(
                name,
                childUri,
                folder,
                size,
                modified,
                folder ? folderIconFor(name) : iconFor(name)));
      }
    }
    // تقرير «إظهار جميع الملفات» — مزوّد SAF يُقصي كل ملف يبدأ بنقطة (.gitignore/.gradle…)
    // وقد يُقصي عناصر أخرى بحسب الـ ROM. ندمج قائمة File المباشرة (حين يسمح الوصول المباشر)
    // كي تظهر كل محتويات المجلد دون إخفاء، مع إزالة التكرار بالاسم.
    mergeDirectChildren(directoryUri, result);
    return result.toArray(new Entry[0]);
  }

  /** يدمج ما يخفيه المزوّد (عادة الملفات النقطية) من قائمة File المباشرة. بلا ضجيج عند غياب الوصول. */
  private void mergeDirectChildren(Uri directoryUri, ArrayList<Entry> into) {
    if (!canReadDirectStorage()) return;
    File direct = fileForDocumentUri(directoryUri);
    if (direct == null) return;
    File[] files;
    try {
      files = direct.listFiles();
    } catch (Throwable failure) {
      return;
    }
    if (files == null) return;
    java.util.HashSet<String> seen = new java.util.HashSet<>();
    for (Entry entry : into)
      if (entry.name != null) seen.add(entry.name);
    boolean added = false;
    for (File file : files) {
      String name = file.getName();
      if (seen.contains(name)) continue;
      boolean folder = file.isDirectory();
      into.add(
          new Entry(name, file, null, folder, folder ? folderIconFor(name) : iconFor(name), 0, 0));
      seen.add(name);
      added = true;
    }
    if (added) {
      // إعادة الفرز: مجلدات أولًا ثم أبجدي — يحافظ على ترتيب موحّد بعد الدمج.
      into.sort(
          (a, b) -> {
            if (a.folder != b.folder) return a.folder ? -1 : 1;
            return a.name.compareToIgnoreCase(b.name);
          });
    }
  }

  /** هندسة المسار لتحويل SAF URI لوحدة التخزين الأساسية إلى ملف مباشر (عندما يمكن ذلك). */
  private File fileForDocumentUri(Uri uri) {
    if (uri == null) return null;
    try {
      String id = DocumentsContract.getDocumentId(uri);
      if (id == null) return null;
      int colon = id.indexOf(':');
      String volume = colon < 0 ? id : id.substring(0, colon);
      String rel = colon < 0 ? "" : id.substring(colon + 1);
      if ("primary".equalsIgnoreCase(volume) || "home".equalsIgnoreCase(volume)) {
        return new File(android.os.Environment.getExternalStorageDirectory(), rel);
      }
    } catch (Throwable ignored) {
    }
    return null;
  }

  private String fileContentKey(Entry entry) {
    if (entry == null) return "";
    if (entry.documentUri != null)
      return "content:" + entry.documentUri + ":" + entry.size;
    if (entry.file == null) return "";
    return "content:" + entry.file.getAbsolutePath() + ":" + entry.file.lastModified() + ":" + entry.file.length();
  }

  private String cachedFileContent(String key) {
    return fileContentCache.get(key);
  }

  private void cacheFileContent(String key, String content) {
    fileContentCache.put(key, content);
  }

  private String documentCacheKey(Uri uri) {
    return "document:" + uri;
  }

  private String fileCacheKey(File directory) {
    return "file:" + directory.getAbsolutePath();
  }

  private List<Entry> cachedDirectory(String key) {
    synchronized (directoryCache) {
      List<Entry> value = directoryCache.get(key);
      return value == null ? null : new ArrayList<>(value);
    }
  }

  private void cacheDirectory(String key, List<Entry> value) {
    synchronized (directoryCache) {
      directoryCache.put(key, new ArrayList<>(value));
    }
  }

  private void invalidateDirectory(String key) {
    synchronized (directoryCache) {
      directoryCache.remove(key);
    }
  }

  public void indexProjectSymbols(Runnable completed) {
    symbolWorker.execute(
        () -> {
          buildSymbolIndex();
          if (completed != null) mainHandler.post(completed);
        });
  }

  // تقرير 05 — كاش LRU صغير لآخر عمليات التنقل الدقيقة (exact lookup شبه فوري عند التكرار).
  private final java.util.LinkedHashMap<String, ProjectSymbolIndex.DefinitionTarget>
      definitionLookupCache =
          new java.util.LinkedHashMap<String, ProjectSymbolIndex.DefinitionTarget>(
              16, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(
                java.util.Map.Entry<String, ProjectSymbolIndex.DefinitionTarget> eldest) {
              return size() > 8;
            }
          };

  /** Resolves a definition after the complete project index is available. */
  public void findDefinitionAsync(
      String fileName,
      String source,
      int selectionStart,
      int selectionEnd,
      DefinitionSearchListener listener) {
    final String cacheKey =
        fileName + "@" + selectionStart + ":" + selectionEnd + "#" + (source == null ? 0 : source.hashCode());
    synchronized (definitionLookupCache) {
      ProjectSymbolIndex.DefinitionTarget cached = definitionLookupCache.get(cacheKey);
      if (cached != null) {
        mainHandler.post(() -> {
          if (listener != null) listener.completed(cached);
        });
        return;
      }
    }
    symbolWorker.execute(
        () -> {
          if (symbolFiles.isEmpty()) buildSymbolIndex();
          ProjectSymbolIndex.DefinitionTarget target =
              ProjectSymbolIndex.resolveDefinition(fileName, source, selectionStart, selectionEnd);
          if (target != null) {
            synchronized (definitionLookupCache) {
              definitionLookupCache.put(cacheKey, target);
            }
          }
          if (target == null) {
            String symbol = UsageSearchEngine.identifierAt(source, selectionStart, selectionEnd);
            int offset = UsageSearchEngine.findDeclarationOffset(source, symbol);
            if (offset >= 0)
              target = new ProjectSymbolIndex.DefinitionTarget(fileName, "", symbol, null, offset, false);
            if (target == null) {
              synchronized (symbolFiles) {
                for (Entry entry : symbolFiles.values()) {
                  if (entry == null || entry.name == null) continue;
                  String lower = entry.name.toLowerCase(Locale.US);
                  if (!(lower.endsWith(".java") || lower.endsWith(".kt"))) continue;
                  String candidate = readEntryText(entry);
                  int candidateOffset = UsageSearchEngine.findDeclarationOffset(candidate, symbol);
                  if (candidateOffset >= 0) {
                    target =
                        new ProjectSymbolIndex.DefinitionTarget(
                            entry.name, symbol, symbol, null, candidateOffset, false);
                    break;
                  }
                }
              }
            }
          }
          final ProjectSymbolIndex.DefinitionTarget result = target;
          mainHandler.post(() -> {
            if (listener != null) listener.completed(result);
          });
        });
  }

  /** Searches indexed project symbols without rescanning source files for every query. */
  public void searchSymbolsAsync(String query, SymbolSearchListener listener) {
    searchSymbolsAsync(query, true, listener);
  }

  public void searchSymbolsAsync(
      String query, boolean includeSystem, SymbolSearchListener listener) {
    final String wanted = query == null ? "" : query.trim();
    final int request = ++projectSearchGeneration;
    if (symbolSearchTask != null) symbolSearchTask.cancel(true);
    symbolSearchTask = symbolSearchWorker.submit(() -> {
      boolean cancelled = request != projectSearchGeneration || Thread.currentThread().isInterrupted();
      final List<ProjectSymbolIndex.DefinitionTarget> immediate =
          cancelled || wanted.isEmpty()
              ? Collections.emptyList()
              : searchSymbolsNow(wanted, includeSystem);
      mainHandler.post(() -> {
        if (request == projectSearchGeneration && listener != null)
          listener.completed(immediate, cancelled);
      });
      // Return the active-file suggestions immediately, then refresh the same query as soon as
      // the background project index becomes ready. No keystroke waits for a full disk traversal.
      if (!cancelled && !searchCatalogReady) {
        long deadline = android.os.SystemClock.uptimeMillis() + 4000;
        while (request == projectSearchGeneration
            && !Thread.currentThread().isInterrupted()
            && !searchCatalogReady
            && android.os.SystemClock.uptimeMillis() < deadline) {
          try {
            Thread.sleep(16);
          } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            break;
          }
        }
      }
      boolean ready = request == projectSearchGeneration
          && !Thread.currentThread().isInterrupted()
          && searchCatalogReady
          && !wanted.isEmpty();
      if (ready) {
        final List<ProjectSymbolIndex.DefinitionTarget> refreshed =
            searchSymbolsNow(wanted, includeSystem);
        mainHandler.post(() -> {
          if (request == projectSearchGeneration && listener != null)
            listener.completed(refreshed, false);
        });
      }
    });
  }

  /**
   * Searches the metadata catalog built during project indexing. File contents remain lazy, while
   * repeated searches skip directory traversal and open each candidate through the bounded cache.
   */
  public void searchProjectAsync(
      ProjectSearchEngine.Query query, ProjectSearchListener listener) {
    if (query == null || query.isEmpty()) {
      if (listener != null) mainHandler.post(() -> listener.completed(Collections.emptyList(), 0, false));
      return;
    }
    final int request = ++projectSearchGeneration;
    if (projectSearchTask != null) projectSearchTask.cancel(true);
    projectSearchTask = symbolWorker.submit(() -> {
      if (!searchCatalogReady) buildSymbolIndex();
      LinkedHashMap<String, Entry> candidates = new LinkedHashMap<>();
      synchronized (searchFileCatalog) {
        candidates.putAll(searchFileCatalog);
      }
      synchronized (openedEntries) {
        for (Entry entry : openedEntries.values()) {
          if (entry != null && isSearchableTextFile(entry))
            candidates.put(referenceForEntry(entry), entry);
        }
      }
      ArrayList<UsageSearchEngine.Usage> results = new ArrayList<>();
      int filesScanned = 0;
      for (Entry item : candidates.values()) {
        if (filesScanned >= 5000
            || results.size() >= query.maxResults
            || request != projectSearchGeneration
            || Thread.currentThread().isInterrupted()) break;
        if (item == null || !isSearchableTextFile(item)) continue;
        filesScanned++;
        String cacheKey = fileContentKey(item);
        String source = cachedFileContent(cacheKey);
        if (source == null) {
          source = readEntryText(item);
          cacheFileContent(cacheKey, source);
        }
        int remaining = Math.max(1, query.maxResults - results.size());
        ProjectSearchEngine.Query fileQuery =
            remaining == query.maxResults
                ? query
                : new ProjectSearchEngine.Query(
                    query.text,
                    query.caseSensitive,
                    query.wholeWord,
                    query.regularExpression,
                    remaining);
        results.addAll(
            ProjectSearchEngine.search(
                item.name,
                referenceForEntry(item),
                source,
                fileQuery,
                () -> request != projectSearchGeneration || Thread.currentThread().isInterrupted()));
      }
      boolean cancelled = request != projectSearchGeneration || Thread.currentThread().isInterrupted();
      final int scanned = filesScanned;
      final ArrayList<UsageSearchEngine.Usage> found = results;
      mainHandler.post(() -> {
        if (request == projectSearchGeneration && listener != null)
          listener.completed(found, scanned, cancelled);
      });
    });
  }

  public void cancelProjectSearch() {
    projectSearchGeneration++;
    if (projectSearchTask != null) projectSearchTask.cancel(true);
    if (symbolSearchTask != null) symbolSearchTask.cancel(true);
  }

  private boolean isSearchableTextFile(Entry entry) {
    if (entry == null || entry.folder || entry.name == null) return false;
    if (entry.size > ProjectSearchEngine.DEFAULT_MAX_FILE_BYTES) return false;
    String lower = entry.name.toLowerCase(Locale.US);
    int dot = lower.lastIndexOf('.');
    if (dot < 0) return lower.equals("readme") || lower.equals("license") || lower.equals("makefile");
    String extension = lower.substring(dot);
    return extension.equals(".java")
        || extension.equals(".smali")
        || extension.equals(".kt")
        || extension.equals(".kts")
        || extension.equals(".xml")
        || extension.equals(".gradle")
        || extension.equals(".properties")
        || extension.equals(".json")
        || extension.equals(".csv")
        || extension.equals(".txt")
        || extension.equals(".md")
        || extension.equals(".yaml")
        || extension.equals(".yml")
        || extension.equals(".html")
        || extension.equals(".css")
        || extension.equals(".js")
        || extension.equals(".ts")
        || extension.equals(".c")
        || extension.equals(".cc")
        || extension.equals(".cpp")
        || extension.equals(".h")
        || extension.equals(".hpp")
        || extension.equals(".sh")
        || extension.equals(".sql")
        || extension.equals(".toml")
        || extension.equals(".pro");
  }

  private boolean skipSearchFolder(String name) {
    if (name == null) return true;
    String lower = name.toLowerCase(Locale.US);
    return lower.equals(".git")
        || lower.equals(".gradle")
        || lower.equals("build")
        || lower.equals("out")
        || lower.equals("target")
        || lower.equals("node_modules")
        || lower.equals(".idea")
        || lower.equals(".cxx")
        || lower.equals("captures");
  }

  /** Scans project source files off the UI thread and returns bounded usage results. */
  public void findUsagesAsync(
      String fileName,
      String source,
      int selectionStart,
      int selectionEnd,
      UsageListener listener) {
    final String symbol = UsageSearchEngine.identifierAt(source, selectionStart, selectionEnd);
    if (symbol.isEmpty()) {
      if (listener != null) mainHandler.post(() -> listener.completed(Collections.emptyList()));
      return;
    }
    symbolWorker.execute(
        () -> {
          if (!searchCatalogReady) buildSymbolIndex();
          // مفتاح موحّد بالمرجع القانوني: نفس الملف الفيزيائي يُفحص مرة واحدة فقط،
          // وإلا ظهرت النتائج مكررة عند وجوده في أكثر من سجل (الكتالوج/الرموز/المفتوحة).
          LinkedHashMap<String, Entry> files = new LinkedHashMap<>();
          synchronized (searchFileCatalog) {
            for (Entry entry : searchFileCatalog.values()) {
              if (entry != null && !entry.folder) files.put(referenceForEntry(entry), entry);
            }
          }
          synchronized (symbolFiles) {
            for (Entry entry : symbolFiles.values()) {
              if (entry != null && !entry.folder) files.put(referenceForEntry(entry), entry);
            }
          }
          synchronized (openedEntries) {
            for (Entry entry : openedEntries.values()) {
              if (entry != null && !entry.folder) files.put(referenceForEntry(entry), entry);
            }
          }
          ArrayList<UsageSearchEngine.Usage> result = new ArrayList<>();
          java.util.HashSet<String> seen = new java.util.HashSet<>();
          for (Entry entry : files.values()) {
            if (Thread.currentThread().isInterrupted()) break;
            String lower = entry.name.toLowerCase(Locale.US);
            if (!(lower.endsWith(".java") || lower.endsWith(".kt"))) continue;
            String cacheKey = fileContentKey(entry);
            String text = cachedFileContent(cacheKey);
            if (text == null) {
              text = readEntryText(entry);
              cacheFileContent(cacheKey, text);
            }
            String reference = referenceForEntry(entry);
            for (UsageSearchEngine.Usage usage :
                UsageSearchEngine.findUsages(
                    entry.name, reference, text, symbol,
                    entry.name.equals(fileName) ? selectionStart : -1)) {
              // صمّام أخير ضد التكرار: نفس الملف والإزاحة لا يظهران مرتين أبدًا.
              if (usage != null && seen.add(usage.fileName + "@" + usage.offset)) result.add(usage);
            }
            if (result.size() >= 1000) break;
          }
          mainHandler.post(
              () -> {
                if (listener != null) listener.completed(result);
              });
        });
  }

  /** Opens a usage result lazily and returns its source plus the exact offset. */
  public void openUsageAsync(
      UsageSearchEngine.Usage usage, DefinitionOpenListener listener) {
    if (usage == null) return;
    symbolWorker.execute(
        () -> {
          Entry target = null;
          synchronized (openedEntries) {
            target = openedEntries.get(usage.fileName);
          }
          if (target == null) {
            synchronized (searchFileCatalog) {
              if (!usage.reference.isEmpty()) target = searchFileCatalog.get(usage.reference);
              if (target == null)
                for (Entry candidate : searchFileCatalog.values()) {
                  if (candidate != null
                      && usage.fileName.equals(candidate.name)
                      && (usage.reference.isEmpty() || usage.reference.equals(referenceForEntry(candidate)))) {
                    target = candidate;
                    break;
                  }
                }
            }
          }
          if (target == null) {
            synchronized (symbolFiles) {
              for (Entry candidate : symbolFiles.values()) {
                if (candidate != null
                    && usage.fileName.equals(candidate.name)
                    && (usage.reference.isEmpty() || usage.reference.equals(referenceForEntry(candidate)))) {
                  target = candidate;
                  break;
                }
              }
            }
          }
          if (target == null) {
            mainHandler.post(
                () -> {
                  if (listener != null)
                    listener.completed(false, usage.fileName, null, 0, "تعذر فتح موضع الاستخدام");
                });
            return;
          }
          String text = readEntryText(target);
          openedEntries.put(target.name, target);
          final Entry opened = target;
          mainHandler.post(
              () -> {
                if (listener != null)
                  listener.completed(
                      true,
                      opened.name,
                      text,
                      Math.min(usage.offset, text.length()),
                      "تم فتح الاستخدام عند السطر " + usage.line);
              });
        });
  }

  private String referenceForEntry(Entry entry) {
    if (entry == null) return "";
    return entry.documentUri != null
        ? entry.documentUri.toString()
        : entry.file == null ? "" : entry.file.getAbsolutePath();
  }

  private String symbolProjectKey() {
    if (projectDocumentUri != null) return "uri:" + projectDocumentUri;
    if (projectFile != null) return "file:" + projectFile.getAbsolutePath();
    return "";
  }

  private Entry findDefinitionEntry(ProjectSymbolIndex.DefinitionTarget definition) {
    if (definition == null) return null;
    synchronized (searchFileCatalog) {
      if (definition.reference != null && !definition.reference.isEmpty()) {
        Entry exact = searchFileCatalog.get(definition.reference);
        if (exact != null) return exact;
        for (Entry candidate : searchFileCatalog.values())
          if (candidate != null && definition.reference.equals(referenceForEntry(candidate))) return candidate;
      }
    }
    synchronized (symbolFiles) {
      Entry byClass = symbolFiles.get(definition.className);
      if (byClass != null) return byClass;
      if (definition.fileName != null)
        for (Entry candidate : symbolFiles.values())
          if (candidate != null && definition.fileName.equals(candidate.name)) return candidate;
    }
    if (definition.fileName != null) {
      synchronized (searchFileCatalog) {
        for (Entry candidate : searchFileCatalog.values())
          if (candidate != null && definition.fileName.equals(candidate.name)) return candidate;
      }
    }
    return null;
  }

  public void openDefinition(
      ProjectSymbolIndex.DefinitionTarget definition, DefinitionOpenListener listener) {
    if (definition == null) {
      if (listener != null) listener.completed(false, null, null, 0, "تعذر تحديد تعريف العنصر");
      return;
    }
    if (definition.source != null) {
      if (listener != null)
        listener.completed(
            true,
            definition.fileName,
            definition.source,
            definition.offset,
            "تم فتح تعريف النظام للقراءة فقط");
      return;
    }
    symbolWorker.execute(
        () -> {
          Entry target = findDefinitionEntry(definition);
          if (target == null) {
            buildSymbolIndex();
            target = findDefinitionEntry(definition);
          }
          if (target == null) {
            mainHandler.post(
                () -> {
                  if (listener != null)
                    listener.completed(
                        false,
                        definition.fileName,
                        null,
                        0,
                        "تعذر العثور على ملف تعريف " + definition.symbol);
                });
            return;
          }
          String source = readEntryText(target);
          openedEntries.put(target.name, target);
          final Entry opened = target;
          mainHandler.post(
              () -> {
                if (listener != null)
                  listener.completed(
                      true,
                      opened.name,
                      source,
                      Math.min(definition.offset, source.length()),
                      "تم الانتقال إلى " + definition.symbol);
              });
        });
  }

  public void createMissingMember(
      ProjectSymbolIndex.MissingMember member, MutationListener listener) {
    symbolWorker.execute(
        () -> {
          Entry target;
          synchronized (symbolFiles) {
            target = symbolFiles.get(member.className);
          }
          if (target == null) {
            buildSymbolIndex();
            synchronized (symbolFiles) {
              target = symbolFiles.get(member.className);
            }
          }
          if (target == null) {
            postMutation(
                listener, false, null, null, "تعذر العثور على " + member.className + ".java");
            return;
          }
          String source = readEntryText(target);
          int closing = source.lastIndexOf('}');
          if (closing < 0) {
            postMutation(listener, false, target.name, null, "ملف الكلاس لا يحتوي قوس إغلاق");
            return;
          }
          if (ProjectSymbolIndex.hasMethod(member.className, member.methodName)) {
            postMutation(listener, false, target.name, source, "الدالة موجودة بالفعل");
            return;
          }
          String updated =
              source.substring(0, closing).replaceFirst("\\s+$", "")
                  + "\n"
                  + member.methodSource()
                  + source.substring(closing);
          if (!writeEntryText(target, updated)) {
            postMutation(listener, false, target.name, null, "تعذر تعديل ملف الكلاس");
            return;
          }
          persistJavaIndex(target, updated);
          cacheFileContent(fileContentKey(target), updated);
          openedEntries.put(target.name, target);
          postMutation(
              listener, true, target.name, updated, "تم إنشاء الدالة " + member.methodName);
        });
  }

  private void persistJavaIndex(Entry entry, String source) {
    if (entry == null || entry.folder || entry.name == null
        || !entry.name.toLowerCase(Locale.US).endsWith(".java")) return;
    String reference = referenceForEntry(entry);
    ProjectSymbolIndex.registerSource(entry.name, reference, source == null ? "" : source);
    List<ProjectSymbolIndex.CachedClass> parsed =
        ProjectSymbolIndex.cachedClassesForFile(entry.name, reference);
    long size = entry.file != null ? entry.file.length() : EncodingManager.encodeUtf8(source == null ? "" : source).length;
    long modified = entry.file != null ? entry.file.lastModified() : System.currentTimeMillis();
    entry.size = size;
    entry.modified = modified;
    if (symbolIndexStore != null) {
      try {
        symbolIndexStore.save(
            symbolProjectKey(), reference, entry.name, reference, size, modified, parsed);
      } catch (Throwable ignored) {
      }
    }
    synchronized (symbolFiles) {
      for (ProjectSymbolIndex.CachedClass owner : parsed) symbolFiles.put(owner.name, entry);
    }
  }

  private void buildSymbolIndex() {
    ProjectSymbolIndex.clear();
    synchronized (symbolFiles) {
      symbolFiles.clear();
    }
    synchronized (searchFileCatalog) {
      searchFileCatalog.clear();
      searchCatalogReady = false;
    }
    final String projectKey = symbolProjectKey();
    indexedProjectKey = projectKey;
    HashSet<String> visitedSymbolFiles = new HashSet<>();
    ArrayDeque<Entry> queue = new ArrayDeque<>();
    Entry root = null;
    if (projectDocumentUri != null)
      root = new Entry(nameForUri(projectDocumentUri), projectDocumentUri, true, -1, R.drawable.folder);
    else if (projectFile != null)
      root = new Entry(projectFile.getName(), projectFile, null, true, R.drawable.folder, 0);
    if (root == null) return;
    queue.add(root);
    int visited = 0;
    while (!queue.isEmpty() && visited < 10000 && !Thread.currentThread().isInterrupted()) {
      Entry item = queue.removeFirst();
      visited++;
      if (item.folder) {
        if (item != root && skipSearchFolder(item.name)) continue;
        if (item.documentUri != null) {
          try {
            for (Entry child : queryDocumentChildren(item.documentUri)) queue.addLast(child);
          } catch (Exception ignored) {
          }
        } else {
          List<Entry> children = queryFileChildren(item.file);
          if (children != null) queue.addAll(children);
        }
        continue;
      }
      if (isSearchableTextFile(item)) {
        synchronized (searchFileCatalog) {
          searchFileCatalog.put(referenceForEntry(item), item);
        }
      }
      if (!item.name.toLowerCase(Locale.US).endsWith(".java")) continue;

      String reference = referenceForEntry(item);
      String fileKey = reference;
      visitedSymbolFiles.add(fileKey);
      List<ProjectSymbolIndex.CachedClass> cached = null;
      if (symbolIndexStore != null) {
        try {
          cached =
              symbolIndexStore.loadIfFresh(
                  projectKey, fileKey, item.name, reference, item.size, item.modified);
        } catch (Throwable ignored) {
          cached = null;
        }
      }
      // Last-resort bulkhead: indexing is best-effort, so a single pathological file (or a
      // low-memory moment) must never be able to crash the app with an escaping Error.
      try {
        if (cached != null) {
          for (ProjectSymbolIndex.CachedClass owner : cached)
            ProjectSymbolIndex.registerCachedClass(owner);
        } else {
          String source = readEntryText(item);
          ProjectSymbolIndex.registerSource(item.name, reference, source);
          List<ProjectSymbolIndex.CachedClass> parsed =
              ProjectSymbolIndex.cachedClassesForFile(item.name, reference);
          if (symbolIndexStore != null) {
            try {
              symbolIndexStore.save(
                  projectKey, fileKey, item.name, reference, item.size, item.modified, parsed);
            } catch (Throwable ignored) {
              // A cache failure must never prevent the source index from being available in RAM.
            }
          }
          cached = parsed;
        }
      } catch (Throwable indexFailure) {
        cached = null;
      }
      if (cached != null) {
        synchronized (symbolFiles) {
          for (ProjectSymbolIndex.CachedClass owner : cached)
            symbolFiles.put(owner.name, item);
        }
      }
      if (visited % 20 == 0 && Thread.currentThread().isInterrupted()) break;
    }
    if (symbolIndexStore != null && !projectKey.isEmpty()) {
      try {
        symbolIndexStore.pruneProject(projectKey, visitedSymbolFiles);
      } catch (Throwable ignored) {
      }
    }
    if (!Thread.currentThread().isInterrupted()) {
      synchronized (searchFileCatalog) {
        searchCatalogReady = true;
      }
    }
  }

  private String readEntryText(Entry entry) {
    try {
      InputStream input =
          entry.documentUri != null
              ? getContext().getContentResolver().openInputStream(entry.documentUri)
              : new FileInputStream(entry.file);
      return input == null ? "" : EncodingManager.readUtf8(input, EncodingManager.DEFAULT_MAX_BYTES);
    } catch (Exception error) {
      return "";
    }
  }

  private boolean writeEntryText(Entry entry, String content) {
    try {
      OutputStream output =
          entry.documentUri != null
              ? getContext().getContentResolver().openOutputStream(entry.documentUri, "wt")
              : new FileOutputStream(entry.file, false);
      if (output == null) return false;
      output.write(EncodingManager.encodeUtf8(content));
      output.flush();
      output.close();
      return true;
    } catch (Exception error) {
      return false;
    }
  }

  private void postMutation(
      MutationListener listener, boolean success, String name, String content, String message) {
    if (listener != null)
      mainHandler.post(() -> listener.completed(success, name, content, message));
  }

  private boolean canReadDirectStorage() {
    return android.os.Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager();
  }

  public boolean needsProjectFolderSelection() {
    return !usingDocuments && !canReadDirectStorage();
  }

  private void loadFile(File directory) {
    loadFile(directory, 0);
  }

  /** صعود «..»: إعادة الضغط معطّلة عبر تمرير عدّاد القفزات ممتلئًا سلفًا. */
  private void loadFileUp(File directory) {
    loadFile(directory, COMPACT_HOP_LIMIT);
  }

  /**
   * تقرير AIDE — بناء الشجرة (بند 4): «ضغط المجلدات وحيدة الفرع».
   * إن كان المجلد يحوي ابنًا واحدًا فقط وهو مجلد، ننزل داخله تلقائيًا (بحد أقصى 4 قفزات)
   * فيُقفز مسار مثل com/example/app دفعة واحدة بدل ثلاث نقرات. سلسلة النزول كلها في خيط
   * الخلفية بلا قفزات للرئيسي، وزر «..» النهائي يشير إلى ما فوق السلسلة ككل.
   */
  /** حدّ أقصى للنزول المتسلسل — يمنع الحلقات ويكبح التمريرات العميقة المريبة. */
  private static final int COMPACT_HOP_LIMIT = 4;

  private void loadFile(File directory, int compactHops) {
    usingDocuments = false;
    currentFile = directory;
    currentDocument = null;
    pathLabel.setText(shortPath(directory));
    if (!canReadDirectStorage()) {
      entries.clear();
      entries.add(
          new Entry(
              "اختيار مجلد المشروع لإظهار جميع ملفاته...",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
      entries.add(
          new Entry(
              "أو منح صلاحية جميع الملفات...",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_PERMISSION));
      notifyList();
      return;
    }
    final int request = ++navigationGeneration;
    final List<Entry> cached = cachedDirectory(fileCacheKey(directory));
    if (cached != null) {
      Entry single = compactHops < COMPACT_HOP_LIMIT ? singleChildFolder(cached) : null;
      if (single != null) {
        loadFile(single.file, compactHops + 1);
        return;
      }
      showFileEntries(directory, cached, request);
      return;
    }
    showLoadingEntry();
    directoryReader.execute(
        () -> {
          File dir = directory;
          int hops = compactHops;
          List<Entry> loaded = queryFileChildren(dir);
          if (loaded != null) cacheDirectory(fileCacheKey(dir), loaded);
          while (hops < COMPACT_HOP_LIMIT) {
            Entry single = singleChildFolder(loaded);
            if (single == null) break;
            dir = single.file;
            List<Entry> next = cachedDirectory(fileCacheKey(dir));
            if (next == null) {
              next = queryFileChildren(dir);
              if (next != null) cacheDirectory(fileCacheKey(dir), next);
            }
            loaded = next;
            hops++;
          }
          final File finalDir = dir;
          final List<Entry> finalLoaded = loaded;
          mainHandler.post(() -> showCompactedFileEntries(finalDir, finalLoaded, request));
        });
  }

  /** عتبة الضغط: ابن وحيد وهو مجلد (لا ملفات، لا صفوف أوامر). */
  private Entry singleChildFolder(List<Entry> children) {
    if (children == null || children.size() != 1) return null;
    Entry only = children.get(0);
    if (only == null || !only.folder || only.action != 0 || only.file == null) return null;
    return only.file.isDirectory() ? only : null;
  }

  /** عرض نتيجة سلسلة النزول: ضبط الحالة للمجلد العميق ثم الرسم المعتاد. */
  private void showCompactedFileEntries(File directory, List<Entry> children, int request) {
    if (request != navigationGeneration) return;
    currentFile = directory;
    currentDocument = null;
    pathLabel.setText(shortPath(directory));
    showFileEntries(directory, children, request);
  }

  private List<Entry> queryFileChildren(File directory) {
    File[] files;
    try {
      files = directory.listFiles();
    } catch (SecurityException error) {
      return null;
    }
    if (files == null) return null;
    Arrays.sort(
        files,
        (a, b) -> {
          if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
          return a.getName().compareToIgnoreCase(b.getName());
        });
    ArrayList<Entry> result = new ArrayList<>(files.length);
    for (File file : files) {
      String name = file.getName();
      boolean folder = file.isDirectory();
      result.add(
          new Entry(name, file, null, folder, folder ? folderIconFor(name) : iconFor(name), 0, 0));
    }
    return result;
  }

  private void showFileEntries(File directory, List<Entry> children, int request) {
    if (request != navigationGeneration || currentFile == null || !currentFile.equals(directory))
      return;
    entries.clear();
    if (directory.getParentFile() != null)
      entries.add(
          new Entry(
              "..", directory.getParentFile(), null, true, R.drawable.folder_open, ACTION_UP_FILE));
    if (directory.getName().equals("AppProjects")) {
      entries.add(
          new Entry(
              "اختيار مجلد المشاريع...",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
      entries.add(
          new Entry(
              "إنشاء مشروع جديد...",
              null,
              null,
              false,
              R.drawable.ic_launcher_java,
              ACTION_CREATE_PROJECT));
      entries.add(
          new Entry(
              "استنساخ مستودع Git...", null, null, false, R.drawable.browser_git, ACTION_CLONE));
    }
    if (children == null) {
      entries.add(
          new Entry(
              "اختيار المجلد لعرض جميع ملفاته...",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_SELECT_TREE));
      entries.add(
          new Entry(
              "منح صلاحية جميع الملفات...",
              null,
              null,
              false,
              R.drawable.folder_open,
              ACTION_PERMISSION));
    } else if (children.isEmpty()) {
      entries.add(
          new Entry("المجلد فارغ", null, null, false, R.drawable.folder_open, ACTION_EMPTY));
    } else {
      entries.addAll(children);
    }
    notifyList();
    if (children != null) prefetchFileChildren(children);
  }

  private void prefetchFileChildren(List<Entry> children) {
    ArrayList<File> folders = new ArrayList<>();
    for (Entry entry : children) {
      if (entry.folder && entry.file != null && folders.size() < 8) folders.add(entry.file);
    }
    if (folders.isEmpty()) return;
    directoryReader.execute(
        () -> {
          for (File folder : folders) {
            String key = fileCacheKey(folder);
            synchronized (directoryCache) {
              if (directoryCache.containsKey(key) || !prefetching.add(key)) continue;
            }
            try {
              List<Entry> result = queryFileChildren(folder);
              if (result != null) cacheDirectory(key, result);
            } finally {
              synchronized (directoryCache) {
                prefetching.remove(key);
              }
            }
          }
        });
  }

  private void notifyList() {
    ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
  }

  private void showHeaderMenu(View anchor) {
    PopupMenu m = new PopupMenu(getContext(), anchor);
    String[] items = {
      "ملف جديد",
      "مجلد جديد",
      "تحديث",
      "اختيار مجلد المشاريع",
      "نسخ مسار المجلد",
      "منح صلاحية الملفات"
    };
    for (String x : items) m.getMenu().add(x);
    m.setOnMenuItemClickListener(
        i -> {
          String x = i.getTitle().toString();
          if (x.equals("ملف جديد")) promptCreate(false);
          else if (x.equals("مجلد جديد")) promptCreate(true);
          else if (x.equals("تحديث")) refresh();
          else if (x.equals("اختيار مجلد المشاريع")) {
            if (actions != null) actions.onSelectProjectFolder();
          } else if (x.startsWith("نسخ")) copyCurrentPath();
          else if (actions != null) actions.onStoragePermissionRequested();
          return true;
        });
    m.show();
  }

  private void showEntryMenu(View anchor, Entry e) {
    PopupMenu m = new PopupMenu(getContext(), anchor);
    for (String x : new String[] {"فتح", "إعادة تسمية", "حذف", "نسخ المسار"}) m.getMenu().add(x);
    m.setOnMenuItemClickListener(
        i -> {
          String x = i.getTitle().toString();
          if (x.equals("فتح")) activate(e);
          else if (x.equals("إعادة تسمية")) promptRename(e);
          else if (x.equals("حذف")) confirmDelete(e);
          else copyEntryPath(e);
          return true;
        });
    m.show();
  }

  private void promptCreate(boolean folder) {
    EditText input = new EditText(getContext());
    input.setHint(folder ? "اسم المجلد" : "اسم الملف مع الامتداد");
    input.setSingleLine(true);
    new AlertDialog.Builder(getContext())
        .setTitle(folder ? "إنشاء مجلد" : "إنشاء ملف")
        .setView(input)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "إنشاء",
            (d, w) -> {
              String name = input.getText().toString().trim();
              if (!validName(name)) return;
              final boolean documents = usingDocuments;
              final DocumentFile documentParent = currentDocument;
              final File fileParent = currentFile;
              directoryReader.execute(
                  () -> {
                    boolean success = false;
                    String error = "تعذر الإنشاء أو أن الاسم موجود";
                    try {
                      if (documents) success = createDocumentChild(documentParent, folder, name);
                      else {
                        if (!fileParent.exists()) fileParent.mkdirs();
                        File target = new File(fileParent, name);
                        success = folder ? target.mkdirs() : target.createNewFile();
                      }
                    } catch (Exception exception) {
                      error = "تعذر الإنشاء: " + exception.getMessage();
                    }
                    final boolean result = success;
                    final String message = error;
                    mainHandler.post(
                        () -> {
                          if (result) refresh();
                          else toast(message);
                        });
                  });
            })
        .show();
  }

  private boolean createDocumentChild(DocumentFile parent, boolean folder, String name) {
    try {
      String mime = folder ? DocumentsContract.Document.MIME_TYPE_DIR : mimeFor(name);
      Uri created =
          DocumentsContract.createDocument(
              getContext().getContentResolver(), parent.getUri(), mime, name);
      return created != null;
    } catch (Exception directCreateFailed) {
      DocumentFile created =
          folder ? parent.createDirectory(name) : parent.createFile(mimeFor(name), name);
      return created != null;
    }
  }

  private void promptRename(Entry e) {
    EditText input = new EditText(getContext());
    input.setText(e.name);
    input.setSelectAllOnFocus(true);
    new AlertDialog.Builder(getContext())
        .setTitle("إعادة تسمية")
        .setView(input)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "حفظ",
            (d, w) -> {
              String name = input.getText().toString().trim();
              if (!validName(name)) return;
              final boolean documents = usingDocuments;
              directoryReader.execute(
                  () -> {
                    boolean success =
                        documents
                            ? renameDocument(e.documentUri, name)
                            : e.file.renameTo(new File(e.file.getParentFile(), name));
                    mainHandler.post(
                        () -> {
                          if (success) refresh();
                          else toast("تعذر تغيير الاسم");
                        });
                  });
            })
        .show();
  }

  private void confirmDelete(Entry e) {
    new AlertDialog.Builder(getContext())
        .setTitle("حذف")
        .setMessage("هل تريد حذف " + e.name + "؟")
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "حذف",
            (d, w) -> {
              final boolean documents = usingDocuments;
              directoryReader.execute(
                  () -> {
                    boolean success =
                        documents ? deleteDocument(e.documentUri) : deleteRecursively(e.file);
                    mainHandler.post(
                        () -> {
                          if (success) refresh();
                          else toast("تعذر الحذف");
                        });
                  });
            })
        .show();
  }

  private boolean renameDocument(Uri uri, String name) {
    try {
      return uri != null
          && DocumentsContract.renameDocument(getContext().getContentResolver(), uri, name) != null;
    } catch (Exception error) {
      return false;
    }
  }

  private boolean deleteDocument(Uri uri) {
    try {
      return uri != null
          && DocumentsContract.deleteDocument(getContext().getContentResolver(), uri);
    } catch (Exception error) {
      return false;
    }
  }

  private boolean deleteRecursively(File f) {
    if (f.isDirectory()) {
      File[] c = f.listFiles();
      if (c != null) for (File x : c) if (!deleteRecursively(x)) return false;
    }
    return f.delete();
  }

  private String readDocument(Uri uri, String name, long size) {
    try {
      InputStream in = getContext().getContentResolver().openInputStream(uri);
      if (in == null) return "تعذر فتح الملف";
      byte[] data = readBytes(in);
      if (isTextFile(name, data)) return EncodingManager.decodeUtf8(data);
      return binaryPreview(pathForUri(uri), size, data);
    } catch (Exception e) {
      return "تعذر فتح الملف:\n" + e;
    }
  }

  private String readFile(File file, String name) {
    try {
      FileInputStream in = new FileInputStream(file);
      byte[] data = readBytes(in);
      if (isTextFile(name, data)) return EncodingManager.decodeUtf8(data);
      return binaryPreview(file.getAbsolutePath(), file.length(), data);
    } catch (Exception e) {
      return "تعذر فتح الملف:\n" + e;
    }
  }

  private byte[] readBytes(InputStream in) throws IOException {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    byte[] b = new byte[8192];
    int n;
    while (!Thread.currentThread().isInterrupted()
        && (n = in.read(b)) > 0
        && out.size() < 8 * 1024 * 1024) out.write(b, 0, n);
    in.close();
    return out.toByteArray();
  }

  private boolean isTextFile(String name, byte[] data) {
    String n = name.toLowerCase();
    if (n.matches(
        ".*\\.(java|smali|kt|xml|gradle|properties|json|md|txt|html|htm|css|js|ts|c|cpp|cc|h|hpp|py|sh|yaml|yml|pro|cfg|ini|csv)$"))
      return true;
    for (int i = 0; i < Math.min(512, data.length); i++) if (data[i] == 0) return false;
    return true;
  }

  private String binaryPreview(String path, long size, byte[] data) {
    if (path != null && path.toLowerCase(Locale.US).endsWith(".dex"))
      return DexMetadataReader.describe(path, size, data);
    StringBuilder s =
        new StringBuilder("عارض ملف ثنائي\n\nالمسار: ")
            .append(path)
            .append("\nالحجم: ")
            .append(size)
            .append(" بايت\n\nHEX:\n");
    for (int i = 0; i < Math.min(4096, data.length); i++) {
      if (i % 16 == 0) s.append(String.format("%n%08X  ", i));
      s.append(String.format("%02X ", data[i] & 255));
    }
    return s.toString();
  }

  private boolean entriesLookLikeProject() {
    for (Entry entry : entries) {
      String name = entry.name;
      if (name.equals("settings.gradle")
          || name.equals("settings.gradle.kts")
          || name.equals("AndroidManifest.xml")) return true;
    }
    return false;
  }

  private String pathForDocument(DocumentFile doc) {
    return pathForUri(doc.getUri());
  }

  private String pathForUri(Uri uri) {
    try {
      String id = DocumentsContract.getDocumentId(uri);
      if (id.startsWith("primary:")) return "/storage/emulated/0/" + id.substring(8);
      return id;
    } catch (Exception e) {
      return uri == null ? "" : uri.toString();
    }
  }

  private String shortPath(File d) {
    String p = d.getAbsolutePath(),
        base = Environment.getExternalStorageDirectory().getAbsolutePath();
    return p.startsWith(base) ? "…ulated/0" + p.substring(base.length()) : p;
  }

  private String nameForUri(Uri uri) {
    try {
      String id = DocumentsContract.getDocumentId(uri);
      int slash = id.lastIndexOf('/');
      int colon = id.lastIndexOf(':');
      int separator = Math.max(slash, colon);
      String name = separator >= 0 ? id.substring(separator + 1) : id;
      return name.isEmpty() ? "بدون اسم" : name;
    } catch (Exception error) {
      String name = uri == null ? null : uri.getLastPathSegment();
      return name == null || name.isEmpty() ? "بدون اسم" : name;
    }
  }

  private String mimeFor(String name) {
    String ext = MimeTypeMap.getFileExtensionFromUrl(name);
    String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
    return mime == null ? "application/octet-stream" : mime;
  }

  private int folderIconFor(String name) {
    String n = name.toLowerCase(Locale.US);
    if (n.equals("build") || n.equals("bin") || n.equals("obj") || n.startsWith(".")) {
      return R.drawable.folder_hidden;
    }
    return R.drawable.folder;
  }

  private int iconFor(String name) {
    String n = name.toLowerCase(Locale.US);
    if (n.endsWith(".java") || n.endsWith(".kt")) return R.drawable.file_type_java;
    if (n.endsWith(".xml")) return R.drawable.file_type_xml;
    if (n.endsWith(".gradle") || n.endsWith(".gradle.kts")) {
      return R.drawable.project_properties;
    }
    if (n.endsWith(".html") || n.endsWith(".htm")) return R.drawable.file_type_html;
    if (n.endsWith(".js") || n.endsWith(".ts")) return R.drawable.file_type_js;
    if (n.endsWith(".css")) return R.drawable.file_type_css;
    if (n.endsWith(".c")) return R.drawable.file_type_c;
    if (n.endsWith(".cpp") || n.endsWith(".cc") || n.endsWith(".cxx")) {
      return R.drawable.file_type_cpp;
    }
    if (n.endsWith(".h") || n.endsWith(".hpp")) return R.drawable.file_type_h;
    if (n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".aar") || n.endsWith(".apk") || n.endsWith(".dex")) {
      return R.drawable.file_type_zip;
    }
    if (n.endsWith(".txt")
        || n.endsWith(".md")
        || n.endsWith(".markdown")
        || n.endsWith(".properties")
        || n.endsWith(".json")
        || n.endsWith(".yaml")
        || n.endsWith(".yml")
        || n.endsWith(".toml")
        || n.endsWith(".ini")
        || n.endsWith(".cfg")
        || n.endsWith(".sh")
        || n.endsWith(".py")
        || n.endsWith(".smali")) return R.drawable.file_type_txt;
    return R.drawable.file_type_unknown;
  }

  private void copyCurrentPath() {
    copy(usingDocuments ? pathForDocument(currentDocument) : currentFile.getAbsolutePath());
  }

  private void copyEntryPath(Entry e) {
    copy(usingDocuments ? pathForUri(e.documentUri) : e.file.getAbsolutePath());
  }

  private void copy(String value) {
    ClipboardManager c =
        (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
    c.setPrimaryClip(ClipData.newPlainText("path", value));
    toast("تم نسخ المسار");
  }

  private boolean validName(String n) {
    if (n.isEmpty() || n.equals(".") || n.equals("..") || n.contains("/") || n.contains("\\")) {
      toast("اسم غير صالح");
      return false;
    }
    return true;
  }

  private void toast(String s) {
    Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show();
  }

  private class FolderAdapter extends BaseAdapter {
    public int getCount() {
      return entries.size();
    }

    public Object getItem(int p) {
      return entries.get(p);
    }

    public long getItemId(int p) {
      return p;
    }

    /** تقرير AIDE — المحوّل الاحترافي: ViewHolder يخزّن المراجع، فصفر findViewById بعد الإنشاء. */
    private final class EntryHolder {
      final ImageView icon;
      final TextView name;

      EntryHolder(View v) {
        icon = v.findViewById(R.id.filebrowserEntryFileImage);
        name = v.findViewById(R.id.filebrowserEntryName);
      }
    }

    public View getView(int p, View v, ViewGroup parent) {
      EntryHolder holder;
      if (v == null) {
        v = LayoutInflater.from(getContext()).inflate(R.layout.filebrowser_entry, parent, false);
        holder = new EntryHolder(v);
        v.setTag(holder);
        v.setLayoutDirection(LAYOUT_DIRECTION_LTR);
        v.setMinimumHeight(dp(57));
        v.setBackgroundColor(Color.TRANSPARENT);
        holder.name.setTextDirection(TEXT_DIRECTION_LTR);
        holder.name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        holder.name.setSingleLine(false);
        holder.name.setMaxLines(2);
        holder.name.setEllipsize(android.text.TextUtils.TruncateAt.END);
      } else {
        holder = (EntryHolder) v.getTag();
        if (holder == null) {
          holder = new EntryHolder(v);
          v.setTag(holder);
        }
      }
      Entry e = entries.get(p);
      v.setPadding(dp(20 + e.depth * 18), dp(4), dp(10), dp(4));
      holder.icon.setImageResource(e.icon);
      holder.name.setText(e.name);
      holder.name.setTextColor(entryTheme().color(ThemeConfig.PLAIN));
      // تقرير «إظهار جميع الملفات» — لا خفوت ولا إخفاء: كل الصفوف بظهور كامل 100%؛
      // العلامة الوحيدة للمجلدات المبنية/النقطية هي أيقونة folder_hidden فقط.
      v.setAlpha(1.0f);
      return v;
    }
  }

  /** ThemeConfig واحد للمحوّل كله بدل إنشائه لكل صف (كان أثقل تكلفة عرض الصف). */
  private ThemeConfig entryTheme() {
    if (cachedEntryTheme == null) cachedEntryTheme = new ThemeConfig(getContext());
    return cachedEntryTheme;
  }

  @Override
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (fileReader.isShutdown()) fileReader = Executors.newSingleThreadExecutor();
    if (directoryReader.isShutdown()) directoryReader = Executors.newFixedThreadPool(2);
    if (symbolWorker.isShutdown()) symbolWorker = Executors.newSingleThreadExecutor();
    if (symbolSearchWorker.isShutdown()) symbolSearchWorker = Executors.newFixedThreadPool(2);
    if (symbolIndexStore == null) symbolIndexStore = new PersistentSymbolIndexStore(getContext());
  }

  @Override
  protected void onDetachedFromWindow() {
    // تقرير فتح الملفات — جذر العطل: إغلاق الدرج يفصل هذه الواجهة لحظياً؛ كان القتل الجماعي
    // للخيوط ومسح الردود يضيع قراءة الملف معها فيعلق «جارٍ الفتح…» للأبد. الآن: التوليدات
    // تقدّم لتجاهل النتائج البالية فقط، والخدمة/الخيوط تعيش — ما يشبه خدمة المحرك في AIDE.
    openGeneration++;
    navigationGeneration++;
    if (symbolIndexStore != null) {
      symbolIndexStore.close();
      symbolIndexStore = null;
    }
    super.onDetachedFromWindow();
  }

  private int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }
}
