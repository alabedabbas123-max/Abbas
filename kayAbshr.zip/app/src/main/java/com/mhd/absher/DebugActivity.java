package com.mhd.absher;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.TextView;
import com.a.a.a.a.a;
import java.util.HashMap;
import java.util.Map;

public class DebugActivity extends Activity {
    private static final Map exceptionMap = new HashMap() {
        {
            put(a.a("BiA0RFYyHShJXS0bM1l3MxYpWFYxJwNVWzAkMkRXOw=="), a.a("HDowTFQ8MGZeTCc9KEoYOiQjX1khPSlDMg=="));
            put(a.a("HDoiSEAaITJiXhc7M0NcJhE+Tl0lIC9CVg=="), a.a("HDowTFQ8MGZBUSYgZkJIMCYnWVE6Okw="));
            put(a.a("FCYvWVA4MTJEWxAsJUhIIT0pQw=="), a.a("HDowTFQ8MGZMSjwgLkBdIT0lTFR1OzZISjQgL0JWXw=="));
            put(a.a("GyErT10nEilfVTQgA1VbMCQyRFc7"), a.a("HDowTFQ8MGZZVxshK09dJ3QkQVc2P2ZCSDAmJ1lROjpM"));
            put(a.a("FDcyRE48ID9jVyESKVhWMRE+Tl0lIC9CVg=="), a.a("HDowTFQ8MGZEViExKFkYOiQjX1khPSlDMg=="));
        }
    };

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        Intent intent = getIntent();
        String stringExtra = intent != null ? intent.getStringExtra(a.a("MCY0Qko=")) : "";
        if (stringExtra.isEmpty()) {
            spannableStringBuilder.append((CharSequence) a.a("GztmSEonOzQNVTAnNUxfMHQnW1k8OCdPVDB6"));
        } else {
            String[] strArrSplit = stringExtra.split("\n");
            String str = strArrSplit[0];
            String str2 = exceptionMap.containsKey(str) ? (String) exceptionMap.get(str) : "";
            if (!str2.isEmpty()) {
                spannableStringBuilder.append((CharSequence) str2);
            }
            for (int i = 1; i < strArrSplit.length; i++) {
                spannableStringBuilder.append((CharSequence) strArrSplit[i]);
                spannableStringBuilder.append((CharSequence) "\n");
            }
        }
        setTitle(((Object) getTitle()) + a.a("dRc0TEs9MSI="));
        TextView textView = new TextView(this);
        textView.setText(spannableStringBuilder);
        textView.setTextIsSelectable(true);
        HorizontalScrollView horizontalScrollView = new HorizontalScrollView(this);
        ScrollView scrollView = new ScrollView(this);
        horizontalScrollView.addView(scrollView);
        scrollView.addView(textView);
        setContentView(horizontalScrollView);
    }
}
