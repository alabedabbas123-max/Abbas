package com.almlkid.ui;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.shima.demo.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Reusable completion list adapter; changing the prefix updates rows instead of rebuilding them. */
public final class EditorCompletionAdapter extends BaseAdapter {
  private final LayoutInflater inflater;
  private final ArrayList<ProjectSymbolIndex.CompletionItem> items = new ArrayList<>();

  public EditorCompletionAdapter(Context context) {
    inflater = LayoutInflater.from(context);
  }

  public void setItems(List<ProjectSymbolIndex.CompletionItem> values) {
    items.clear();
    if (values != null) items.addAll(values);
    notifyDataSetChanged();
  }

  public List<ProjectSymbolIndex.CompletionItem> snapshot() {
    return Collections.unmodifiableList(new ArrayList<>(items));
  }

  @Override
  public int getCount() {
    return items.size();
  }

  @Override
  public ProjectSymbolIndex.CompletionItem getItem(int position) {
    return items.get(position);
  }

  @Override
  public long getItemId(int position) {
    return position;
  }

  @Override
  public View getView(int position, View reusable, ViewGroup parent) {
    View row = reusable == null
        ? inflater.inflate(R.layout.code_completion_entry, parent, false)
        : reusable;
    ProjectSymbolIndex.CompletionItem item = getItem(position);
    ImageView icon = row.findViewById(R.id.codeCompletionIcon);
    TextView name = row.findViewById(R.id.codeCompletionName);
    TextView detail = row.findViewById(R.id.codeCompletionDetail);
    icon.setImageResource(iconFor(item.kind));
    name.setText(item.label);
    name.setTextColor(item.kind == ProjectSymbolIndex.CompletionItem.CLASS
        ? Color.rgb(35, 187, 255)
        : item.kind == ProjectSymbolIndex.CompletionItem.VARIABLE
            ? Color.rgb(0, 174, 226) : Color.WHITE);
    detail.setText(" : " + item.detail);
    return row;
  }

  /** أيقونات الأنواع مطابقة للمرجع (C0053j:173-198): دالة=أحمر، كلاس=أزرق، متغير=objects… */
  private int iconFor(int kind) {
    if (kind == ProjectSymbolIndex.CompletionItem.METHOD) return R.drawable.box_red;
    if (kind == ProjectSymbolIndex.CompletionItem.VARIABLE) return R.drawable.objects;
    if (kind == ProjectSymbolIndex.CompletionItem.XML) return R.drawable.box_light_blue;
    if (kind == ProjectSymbolIndex.CompletionItem.BUILD) return R.drawable.pakage;
    return R.drawable.box_blue; // CLASS
  }
}
