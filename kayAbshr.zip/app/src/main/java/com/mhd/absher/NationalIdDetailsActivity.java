package com.mhd.absher;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class NationalIdDetailsActivity extends AppCompatActivity {
    private DatabaseReference dbRef;
    private TextView tvCardTitle;
    private TextView tvExpiryDate;
    private TextView tvIdNumber;
    private TextView tvIdVersion;
    private TextView tvIssueDate;
    private TextView tvIssuePlace;
    private TextView tvTitle;
    private ValueEventListener userDataListener;

    public String getSafeString(DataSnapshot dataSnapshot, String... strArr) {
        for (String str : strArr) {
            if (dataSnapshot.hasChild(str) && dataSnapshot.child(str).getValue() != null) {
                return String.valueOf(dataSnapshot.child(str).getValue());
            }
        }
        return null;
    }

    private void loadDataFromSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        String string = sharedPreferences.getString(a.a("PDAIWFU3MTQ="), a.a("ZGZ1GQ1jY34UCA=="));
        String string2 = sharedPreferences.getString(a.a("PCc1WF0RNTJI"), a.a("Z2R0HxdlYmkdAA=="));
        String string3 = sharedPreferences.getString(a.a("PCc1WF0FOCdOXQ=="), a.a("jfifpeDyjPT1n43+ZvWfjNCeg+DkjOj0so3l"));
        String string4 = sharedPreferences.getString(a.a("MCw2REosECdZXQ=="), a.a("Z2R0GhdlYmkdAA=="));
        String string5 = sharedPreferences.getString(a.a("Njs2VHYgOSRISg=="), a.a("YQ=="));
        updateTitlesDynamically(sharedPreferences.getBoolean(a.a("JjwpWns8IC9XXTsdIg=="), true), sharedPreferences.getBoolean(a.a("JjwpWmowJy9JXTsgD0k="), true), sharedPreferences.getBoolean(a.a("JjwpWm48Jy9ZVycdIg=="), false));
        if (this.tvIdNumber != null) {
            this.tvIdNumber.setText(string);
        }
        if (this.tvIssueDate != null) {
            this.tvIssueDate.setText(string2);
        }
        if (this.tvIssuePlace != null) {
            this.tvIssuePlace.setText(string3);
        }
        if (this.tvExpiryDate != null) {
            this.tvExpiryDate.setText(string4);
        }
        if (this.tvIdVersion != null) {
            this.tvIdVersion.setText(string5);
        }
    }

    public boolean parseBoolean(DataSnapshot dataSnapshot, String str, boolean z) {
        if (!dataSnapshot.hasChild(str)) {
            return z;
        }
        Object value = dataSnapshot.child(str).getValue();
        if (value instanceof Boolean) {
            return ((Boolean) value).booleanValue();
        }
        return value != null ? a.a("ISYzSA==").equalsIgnoreCase(String.valueOf(value)) : z;
    }

    private void syncDataWithFirebase() {
        SharedPreferences sharedPreferences = getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0);
        SharedPreferences sharedPreferences2 = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        SharedPreferences sharedPreferences3 = getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
        String string = sharedPreferences.getString(a.a("ICcjX2swNzRITBww"), "");
        if (string.isEmpty()) {
            string = sharedPreferences3.getString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), "");
        }
        if (string.isEmpty()) {
            string = sharedPreferences2.getString(a.a("JjElX10hHyNU"), "");
        }
        if (string.isEmpty()) {
            string = sharedPreferences2.getString(a.a("ICcjX3MwLQ=="), "");
        }
        if (string.isEmpty()) {
            return;
        }
        try {
            this.dbRef = FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(string);
            this.userDataListener = new ValueEventListener() {
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }

                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        SharedPreferences.Editor editorEdit = NationalIdDetailsActivity.this.getSharedPreferences(a.a("ICcjX3w0ICc="), 0).edit();
                        String safeString = NationalIdDetailsActivity.this.getSafeString(dataSnapshot, a.a("PDAIWFU3MTQ="), a.a("HDAIWFU3MTQ="));
                        if (safeString != null) {
                            editorEdit.putString(a.a("PDAIWFU3MTQ="), safeString);
                            if (NationalIdDetailsActivity.this.tvIdNumber != null) {
                                NationalIdDetailsActivity.this.tvIdNumber.setText(safeString);
                            }
                        }
                        String safeString2 = NationalIdDetailsActivity.this.getSafeString(dataSnapshot, a.a("PCc1WF0RNTJI"), a.a("HCc1WF0RNTJI"));
                        if (safeString2 != null) {
                            editorEdit.putString(a.a("PCc1WF0RNTJI"), safeString2);
                            if (NationalIdDetailsActivity.this.tvIssueDate != null) {
                                NationalIdDetailsActivity.this.tvIssueDate.setText(safeString2);
                            }
                        }
                        String safeString3 = NationalIdDetailsActivity.this.getSafeString(dataSnapshot, a.a("PCc1WF0FOCdOXQ=="), a.a("HCc1WF0FOCdOXQ=="));
                        if (safeString3 != null) {
                            editorEdit.putString(a.a("PCc1WF0FOCdOXQ=="), safeString3);
                            if (NationalIdDetailsActivity.this.tvIssuePlace != null) {
                                NationalIdDetailsActivity.this.tvIssuePlace.setText(safeString3);
                            }
                        }
                        String safeString4 = NationalIdDetailsActivity.this.getSafeString(dataSnapshot, a.a("MCw2REosECdZXQ=="), a.a("ECw2REosECdZXQ=="));
                        if (safeString4 != null) {
                            editorEdit.putString(a.a("MCw2REosECdZXQ=="), safeString4);
                            if (NationalIdDetailsActivity.this.tvExpiryDate != null) {
                                NationalIdDetailsActivity.this.tvExpiryDate.setText(safeString4);
                            }
                        }
                        String safeString5 = NationalIdDetailsActivity.this.getSafeString(dataSnapshot, a.a("Njs2VHYgOSRISg=="), a.a("Fjs2VHYgOSRISg=="));
                        if (safeString5 != null) {
                            editorEdit.putString(a.a("Njs2VHYgOSRISg=="), safeString5);
                            if (NationalIdDetailsActivity.this.tvIdVersion != null) {
                                NationalIdDetailsActivity.this.tvIdVersion.setText(safeString5);
                            }
                        }
                        boolean z = NationalIdDetailsActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWns8IC9XXTsdIg=="), true);
                        boolean z2 = NationalIdDetailsActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWmowJy9JXTsgD0k="), true);
                        boolean z3 = NationalIdDetailsActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWm48Jy9ZVycdIg=="), false);
                        editorEdit.putBoolean(a.a("JjwpWns8IC9XXTsdIg=="), z);
                        editorEdit.putBoolean(a.a("JjwpWmowJy9JXTsgD0k="), z2);
                        editorEdit.putBoolean(a.a("JjwpWm48Jy9ZVycdIg=="), z3);
                        NationalIdDetailsActivity.this.updateTitlesDynamically(z, z2, z3);
                        editorEdit.apply();
                    }
                }
            };
            this.dbRef.addValueEventListener(this.userDataListener);
        } catch (Exception e) {
        }
    }

    public void updateTitlesDynamically(boolean z, boolean z2, boolean z3) {
        String strA = a.a("jNGelOHRjc70vY3znocYjNOfpeHfjO8N4dCNxPSyjNE=");
        if (z) {
            strA = a.a("jNGelOHRjc70vY3znocYjfOfqeHSjc70so39ZvWfjNCfpeDijcD0so39");
        } else if (z2) {
            strA = a.a("jNGelOHRjc70vY3znocYjNOfpeHfjO8N4dCNxPSyjNE=");
        } else if (z3) {
            strA = a.a("jNGelOHRjc70vY3znocYjNOfpeHfjO8N4OeM4fWejeU=");
        }
        if (this.tvTitle != null) {
            this.tvTitle.setText(strA);
        }
        if (this.tvCardTitle != null) {
            this.tvCardTitle.setText(strA);
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.national_id_details);
        getWindow().getDecorView().setLayoutDirection(1);
        this.tvIdNumber = (TextView) findViewById(R.id.tvIdNumber);
        this.tvIssueDate = (TextView) findViewById(R.id.tvIssueDate);
        this.tvIssuePlace = (TextView) findViewById(R.id.tvIssuePlace);
        this.tvExpiryDate = (TextView) findViewById(R.id.tvExpiryDate);
        this.tvIdVersion = (TextView) findViewById(R.id.tvIdVersion);
        this.tvTitle = (TextView) findViewById(R.id.tvTitle);
        this.tvCardTitle = (TextView) findViewById(R.id.tvCardTitle);
        ImageView imageView = (ImageView) findViewById(R.id.btnBack);
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    NationalIdDetailsActivity.this.finish();
                }
            });
        }
        loadDataFromSharedPreferences();
        syncDataWithFirebase();
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.dbRef == null || this.userDataListener == null) {
            return;
        }
        this.dbRef.removeEventListener(this.userDataListener);
    }
}
