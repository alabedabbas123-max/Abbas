package com.shima.demo;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.LocaleList;
import android.os.Process;
import android.preference.PreferenceManager;
import java.util.Locale;

/** Global last-resort crash handler. Errors are saved and opened in RecoveryActivity. */
public class ShimaApplication extends Application {
  @Override
  protected void attachBaseContext(Context base) {
    super.attachBaseContext(localize(base));
  }

  /**
   * Wraps a context with the locale saved in app preferences.
   *
   * <p>Locale resources belong to each Context, not just to Application. Every Activity therefore
   * uses this wrapper from attachBaseContext; changing Application Resources alone left recreated
   * Activities bound to their old (Arabic) configuration.
   */
  public static Context localize(Context base) {
    String language =
        PreferenceManager.getDefaultSharedPreferences(base)
            .getString(almlk.AppSettings.KEY_LANGUAGE, "default");
    Locale selected = localeFor(language);
    Locale.setDefault(selected);
    Configuration localized = new Configuration(base.getResources().getConfiguration());
    localized.setLocale(selected);
    // The chosen locale controls text lookup only; keep all app geometry and navigation LTR.
    localized.setLayoutDirection(Locale.ENGLISH);
    return base.createConfigurationContext(localized);
  }

  /** Resolves the explicit app choice; Default follows the device locale, never an implicit Arabic. */
  private static Locale localeFor(String language) {
    String code = language == null ? "default" : language.trim().toLowerCase(Locale.ROOT);
    switch (code) {
      case "en":
        return Locale.ENGLISH;
      case "de":
        return Locale.GERMAN;
      case "ru":
        return new Locale("ru");
      case "zh":
        return new Locale("zh", "CN");
      case "ar":
        return new Locale("ar");
      case "default":
      default:
        return systemLocale();
    }
  }

  private static Locale systemLocale() {
    Configuration system = Resources.getSystem().getConfiguration();
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
      LocaleList locales = system.getLocales();
      if (locales != null && !locales.isEmpty()) return locales.get(0);
    }
    Locale legacy = system.locale;
    return legacy == null ? Locale.ENGLISH : legacy;
  }

  @Override
  public void onCreate() {
    super.onCreate();
    Thread.UncaughtExceptionHandler fallback = Thread.getDefaultUncaughtExceptionHandler();
    Thread.setDefaultUncaughtExceptionHandler(
        (thread, error) -> {
          if (isDeadSystem(error)) {
            Process.killProcess(Process.myPid());
            return;
          }
          try {
            if (PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("experimental_crash_report", true)) CrashStore.save(this, error);
            Intent intent =
                new Intent(this, RecoveryActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            Thread.sleep(250);
          } catch (Throwable ignored) {
            if (fallback != null) fallback.uncaughtException(thread, error);
          }
          Process.killProcess(Process.myPid());
          System.exit(10);
        });
  }

  private boolean isDeadSystem(Throwable error) {
    for (Throwable current = error; current != null; current = current.getCause()) {
      String name = current.getClass().getName();
      if (name.endsWith("DeadSystemException") || name.endsWith("DeadSystemRuntimeException"))
        return true;
    }
    return false;
  }
}
