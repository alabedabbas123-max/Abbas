package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class BlockedBinding {
    public final Button btnContactWhatsApp;
    public final ImageView imageview16;
    public final LinearLayout rootView;
    public final TextView textview14;
    public final TextView textview15;
    public final TextView textview16;

    private BlockedBinding(LinearLayout linearLayout, ImageView imageView, TextView textView, TextView textView2, TextView textView3, Button button) {
        this.rootView = linearLayout;
        this.imageview16 = imageView;
        this.textview14 = textView;
        this.textview15 = textView2;
        this.textview16 = textView3;
        this.btnContactWhatsApp = button;
    }

    public static BlockedBinding bind(View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        ImageView imageView = (ImageView) findChildViewById(view, R.id.imageview16);
        TextView textView = (TextView) findChildViewById(view, R.id.textview14);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview15);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview16);
        Button button = (Button) findChildViewById(view, R.id.btnContactWhatsApp);
        if (imageView == null || textView == null || textView2 == null || textView3 == null || button == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new BlockedBinding(linearLayout, imageView, textView, textView2, textView3, button);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static BlockedBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static BlockedBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.blocked, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}
