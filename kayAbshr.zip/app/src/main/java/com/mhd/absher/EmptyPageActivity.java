package com.mhd.absher;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;

public class EmptyPageActivity extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.empty_page);
        View viewFindViewById = findViewById(R.id.btnBackEmpty);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    EmptyPageActivity.this.finish();
                }
            });
        }
        TextView textView = (TextView) findViewById(R.id.tvTitleEmpty);
        if (textView != null) {
            textView.setText(getIntent().getStringExtra(a.a("IT0yQV0=")));
        }
        ImageView imageView = (ImageView) findViewById(R.id.ivEmptyIcon);
        int intExtra = getIntent().getIntExtra(a.a("PDcpQ2owJw=="), 0);
        if (imageView == null || intExtra == 0) {
            return;
        }
        imageView.setImageResource(intExtra);
    }
}
