# تقرير ميزة المحرر

## الهدف
محرر نصوص احترافي لملفات Java وKotlin وXML وManifest وSmali وGradle، سريع في الفتح والتمرير والتحرير، ولا يجمّد الواجهة أثناء التحليل أو الحفظ.

## البنية
```text
EditorHost
├── TabController
├── CodeViewport
├── Gutter
├── BreadcrumbBar
├── CompletionPopup
├── DiagnosticsOverlay
└── StatusBar
```

يفصل المحرر عن خدمات الفهرسة والبناء. الواجهة تستقبل الأحداث فقط، بينما القراءة والتحليل والحفظ تعمل في workers.

## فتح الملفات بسرعة
```text
metadata فقط
→ إنشاء tab
→ قراءة chunk أولي
→ بناء LineIndex
→ رسم الأسطر المرئية
→ tokenization في الخلفية
→ فهرسة الملف لاحقًا
```

لا يتم تحميل كل الملفات عند فتح المشروع، ولا ينتظر المحرر اكتمال الفهرسة لعرض أول شاشة.

## بنية النص
لا تستخدم String واحدًا يعاد بناؤه عند كل حرف. استخدم Piece Table أو Rope:

```java
interface DocumentBuffer {
    CharSequence read(long start, long end);
    void insert(long offset, CharSequence text);
    void delete(long start, long end);
    int lineOf(long offset);
    long offsetOfLine(int line);
}
```

يحتفظ Piece Table بالمصدر الأصلي وإضافات المستخدم كمقاطع، مما يقلل النسخ والضغط على الذاكرة.

## التنقل والرسم
يستخدم LineIndex مواقع بدايات الأسطر. يرسم CodeViewport الأسطر الظاهرة فقط مع overscan صغير، ولا ينشئ View لكل سطر. يتم تخزين TextLayout للأسطر المتكررة في LRU cache.

```text
scroll → احسب visible range → ارسم range فقط → invalidate للمنطقة المتغيرة
```

أثناء التمرير السريع يمكن تخفيف التمييز مؤقتًا، ثم إكماله عند توقف التمرير.

## التمييز اللغوي
Tokenizer منفصل لكل لغة، يعمل تدريجيًا حسب السطر والـ block المتأثر. يرتبط cache بـ `fileId + line + documentVersion`؛ لذلك لا يعاد تحليل الملف كاملًا بعد تعديل سطر واحد.

## الخصائص
- أرقام الأسطر.
- تمييز السطر النشط.
- folding.
- brackets/tags matching.
- multi-tab.
- read-only للبائنري.
- word wrap اختياري.
- horizontal scrolling.
- bookmarks.
- selection وmulti-selection.
- Go to line/symbol.
- حفظ موضع كل ملف.
- Undo/Redo بمعاملات.

## الحفظ
```text
edit → debounce 750ms → recovery snapshot → temp file → flush → atomic rename
```

لا يكتب فوق المصدر مباشرة. عند الفشل يعاد الملف السابق. تحفظ line endings وencoding.

## الأداء
- لا I/O على Main Thread.
- Executor منفصل للتوكنز.
- cache محدود بـ LRU.
- إلغاء تحليل الطلب القديم.
- تحرير layouts عند `onTrimMemory`.
- وضع Large File للملفات الضخمة.
- benchmark للـ input latency وFPS ووقت أول viewport.

## أدوات التنفيذ
AndroidX، Material Components، Custom View/Canvas، RecyclerView للشجرة فقط، ViewModel، Room للـ metadata، WorkManager للمهام الطويلة، ExecutorService للمهام القصيرة.
