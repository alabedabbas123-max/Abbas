package com.shima.demo;

import android.app.*;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import androidx.drawerlayout.widget.DrawerLayout;
import android.view.*;
import android.widget.*;
import com.almlkid.kay.ui.BuildDiagnosticsParser;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.ProjectDiagnostic;
import com.almlkid.kay.ui.ProjectSearchEngine;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.ui.UsageSearchEngine;
import com.almlkid.kay.view.VPDrawerLayout;
import com.almlkid.ui.SequentialPanelHost;
import com.almlkid.ui.AIDEEditorPager;
import com.almlkid.ui.browsers.BrowserPager;
import com.shima.projects.ProjectWizard;
import java.io.File;
import java.util.*;

/** Java controller for the original res/layout/main_drawer.xml screen. */
public class MainActivity extends LocaleAwareActivity
    implements BrowserPager.ActionListener, CommandCenter.Host {
  VPDrawerLayout drawer;
  AIDEEditorPager editor;
  BrowserPager browser;
  ImageButton masterButton;
  View moreActionView;
  View empty;
  boolean projectOpen = false;
  private String languageAtLastCreate;
  final CommandCenter commands = new CommandCenter();
  ShellCommandRunner shell;
  ProjectSession session;
  // شريط وضع التحرير (دلالة المرجع): يتحول مع ظهور كيبورد المحرر ويعود مع إخفائه.
  boolean editingToolbar;
  boolean lastCanUndo, lastCanRedo;
  AlertDialog requiredStorageDialog;
  FrameLayout sequentialPanelsDrawer;
  View sequentialPanelsScrim;
  SequentialPanelHost sequentialPanels;
  private final ArrayList<ProjectDiagnostic> sourceDiagnostics = new ArrayList<>();
  private final ArrayList<ProjectDiagnostic> buildDiagnostics = new ArrayList<>();
  private final ArrayList<ProjectDiagnostic> displayedDiagnostics = new ArrayList<>();

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    shell = new ShellCommandRunner(this);
    languageAtLastCreate = almlk.AppSettings.language(this);
    getWindow().setStatusBarColor(Color.BLACK);
    getWindow().setNavigationBarColor(Color.rgb(35, 35, 35));
    if (getIntent().getBooleanExtra("safe_mode", false)) {
      showSafeMode();
      return;
    }
    try {
      session = new ProjectSession(this);
      setContentView(R.layout.main_drawer);
      configureActionBar();
      drawer = findViewById(R.id.mainDrawerLayout);
      editor = findViewById(R.id.mainCodePageView);
      // Fix: create the panel host in code instead of inflating <com.almlkid.ui.SequentialPanelHost>
      // from XML. LayoutInflater resolves custom views via reflection, and any build pipeline that
      // strips "unreferenced" constructors makes inflation crash with NoSuchMethodException.
      FrameLayout panelSlot = findViewById(R.id.mainSequentialPanelHost);
      sequentialPanels = panelSlot == null ? null : new SequentialPanelHost(this);
      if (panelSlot != null) {
        panelSlot.addView(
            sequentialPanels,
            new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
      }
      browser = sequentialPanels == null ? findViewById(R.id.mainBrowserPager) : sequentialPanels.browser();
      attachBrowserSwipe();
      empty = findViewById(R.id.mainCodeEmptyView);
      if (drawer == null || editor == null || browser == null || sequentialPanels == null || empty == null)
        throw new IllegalStateException("main_drawer.xml is missing a required view");
      browser.setOnFileSelectedListener(
          (name, content) -> {
            // Keep only the stable path/SAF URI in the session; the text is still loaded lazily.
            openFile(name, content, browser.fileReference(name));
          });
      // تقرير فتح الملفات — الفتح الفوري: التبويب يظهر لحظة النقرة («جارٍ فتح الملف…»)،
      // وحوار تبديل المشروع يُطلق هنا عند النقرة وليس عند وصول المحتوى.
      browser.setOnFileOpeningListener(
          name -> {
            drawer.closeDrawers();
            String reference = browser.fileReference(name);
            maybeSwitchProjectForFile(reference);
            projectOpen = true;
            empty.setVisibility(View.GONE);
            editor.openFilePending(name, reference);
            if (masterButton != null)
              masterButton.setVisibility(masterAllowed() ? View.VISIBLE : View.GONE);
            getActionBar().setTitle(name);
            getActionBar().setSubtitle(ui("ui_open_project_subtitle"));
          });
      browser.setActionListener(this);
      sequentialPanels.setProjectDiagnostics(displayedDiagnostics);
      sequentialPanels.setErrorClickListener(this::openProjectDiagnostic);
      sequentialPanels.setErrorQuickFixListener(this::requestErrorFixes);
      sequentialPanels.setBuildOutput(ui("ui_build_not_started"));
      sequentialPanels.setUsageClickListener(
          usage -> {
            if (usage == null || editor == null) return;
            // كالمرجع: الانتقال بالسطر/العمود على النص الحي وقت النقر — لا إزاحات بائتة،
            // والقفزة تُؤجل تلقائيًا داخل المحرر إن كان محتوى التبويب قيد التحميل الكسول.
            // التفعيل بالمرجع الثابت يحترم أسماء التبويبات المفردة ولا يفتح تبويبًا مكررًا.
            String openTab = editor.selectIfOpenLive(usage.reference, usage.fileName);
            if (openTab == null && editor.activateTabIfOpen(usage.fileName))
              openTab = usage.fileName;
            if (openTab != null) {
              editor.goToMatch(openTab, usage.line, usage.column);
              // الدخول المباشر كما في المرجع: اللوحة تُغلق فورًا ويظهر المحرر على الموقع.
              closeSequentialPanels();
              return;
            }
            browser.openUsageAsync(
                usage,
                (success, fileName, content, offset, message) -> {
                  if (!success || fileName == null || content == null) {
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                    return;
                  }
                  // ترتيب المرجع: الفتح (حقن متزامن) يسبق القفزة دائمًا — والقفزة تستهدف
                  // اسم التبويب الفعلي بعد الفتح (قد يكون مفردًا).
                  openFile(fileName, content, browser.fileReference(fileName));
                  editor.goToMatch(editor.getActiveFile(), usage.line, usage.column);
                  closeSequentialPanels();
                });
          });
      sequentialPanels.setCloseListener(this::closeSequentialPanels);
      editor.setProjectDiagnostics(displayedDiagnostics);
      editor.setDiagnosticsListener(this::onEditorDiagnostics);
      editor.setFileChangedListener(this::onEditorFileChanged);
      // المرحلة الثامنة: بذل افتراضيات نمط الكود مرة واحدة، بلا دهم اختيار المستخدم.
      almlk.CodeStyle.seedDefaults(this);
      com.almlkid.ui.preferences.BuildActions.delegate =
          new com.almlkid.ui.preferences.BuildActions.Delegate() {
            @Override
            public void refreshMaven() {
              if (browser == null) {
                Toast.makeText(MainActivity.this, ui("ui_error_open_project_first"), Toast.LENGTH_SHORT).show();
                return;
              }
              browser.indexProjectSymbols(
                  () -> {
                    if (editor != null) editor.refreshSemanticDiagnostics();
                    scanProjectDiagnostics();
                    Toast.makeText(
                            MainActivity.this, ui("ui_maven_index_updated"), Toast.LENGTH_SHORT)
                        .show();
                  });
            }

            @Override
            public void applyEditorVisual() {
              runOnUiThread(() -> { if (editor != null) editor.applyAdvancedSettings(); });
            }

            @Override
            public void writeProguardConfig() {
              java.io.File root = session == null ? null : session.directory();
              if (root == null) {
                Toast.makeText(MainActivity.this, ui("ui_error_open_project_first"), Toast.LENGTH_SHORT).show();
                return;
              }
              java.io.File target = new java.io.File(root, "proguard-rules.pro");
              try {
                if (!target.exists()) {
                  java.io.FileOutputStream out = new java.io.FileOutputStream(target);
                  out.write(("# قواعد حماية شيميا الافتراضية\n-keep class ** { *; }\n")
                      .getBytes("UTF-8"));
                  out.close();
                }
                Toast.makeText(MainActivity.this, uiFormat("ui_protection_file_path", target.getAbsolutePath()),
                    Toast.LENGTH_LONG).show();
              } catch (Exception e) {
                Toast.makeText(MainActivity.this, ui("ui_error_write_protection_file"),
                    Toast.LENGTH_SHORT).show();
              }
            }

            @Override
            public void configureGradle() {
              java.io.File root = session == null ? null : session.directory();
              if (root == null) {
                Toast.makeText(MainActivity.this, ui("ui_error_open_project_first"), Toast.LENGTH_SHORT).show();
                return;
              }
              java.io.File target = new java.io.File(root, "gradle.properties");
              try {
                if (!target.exists()) {
                  java.io.FileOutputStream out = new java.io.FileOutputStream(target);
                  out.write(("org.gradle.jvmargs=-Xmx1536m\n").getBytes("UTF-8"));
                  out.close();
                  Toast.makeText(MainActivity.this, ui("ui_gradle_properties_created"),
                      Toast.LENGTH_SHORT).show();
                } else {
                  Toast.makeText(MainActivity.this, ui("ui_gradle_properties_exists"),
                      Toast.LENGTH_SHORT).show();
                }
              } catch (Exception e) {
                Toast.makeText(MainActivity.this, ui("ui_error_create_gradle_properties"),
                    Toast.LENGTH_SHORT).show();
              }
            }

            @Override
            public void ndkToggle() {
              android.content.SharedPreferences sp = almlk.AppSettings.prefs(MainActivity.this);
              boolean now = !sp.getBoolean("ndk_support_installed", false);
              sp.edit().putBoolean("ndk_support_installed", now).apply();
              Toast.makeText(MainActivity.this, ui(now ? "ui_ndk_support_installed" : "ui_ndk_support_removed"),
                  Toast.LENGTH_SHORT).show();
            }
          };
      editor.setHostCommandListener(new AIDEEditorPager.HostCommandListener() {
        @Override public void run(String commandId) { dispatch(commandId); }
        @Override public void run(String commandId, String argument) {
          if ("replace".equals(commandId)) promptReplace(argument);
          else dispatch(commandId);
        }
      });
      // قائمة التبويب: عند إغلاق كل التبويبات منها تُعرض الواجهة الفارغة كما في بقية المسارات.
      editor.setTabsClosedListener(
          () -> {
            empty.setVisibility(View.VISIBLE);
            editor.setVisibility(View.GONE);
            if (masterButton != null) masterButton.setVisibility(View.GONE);
          });
      editor.setQuickFixListener(this::confirmCreateMissingMember);
      editor.setDefinitionListener(this::openDefinition);
      editor.setDefinitionRequestListener(this::findDefinitionForSelection);
      editor.setUsageListener(this::findUsagesForSelection);
      editor.setHistoryStateListener(this::refreshEditingToolbarState);
      masterButton = findViewById(R.id.mainMasterButton);
      if (masterButton != null) {
        masterButton.setOnClickListener(v -> showCommands());
        hideMasterButtonWithKeyboard(masterButton);
      }
      ProgressBar progress = findViewById(R.id.mainErrorProgress);
      if (progress != null) progress.setVisibility(View.GONE);
      configureDrawer();
      applySelectedTheme();
      showNoProject();
      editor.restoreSessionAsync(
          restored -> {
            if (!restored) return;
            projectOpen = true;
            empty.setVisibility(View.GONE);
            editor.setVisibility(View.VISIBLE);
            if (masterButton != null)
              masterButton.setVisibility(masterAllowed() ? View.VISIBLE : View.GONE);
            indexAndScanProject();
          });
      // حفظ المشروع المفتوح عبر إعادة التشغيل: استرجاع عنوانه وفتح جذره مباشرة.
      if (session != null && session.isOpen()) {
        projectOpen = true;
        getActionBar().setTitle(session.name());
        getActionBar().setSubtitle(ui("ui_android_project_subtitle"));
        if (browser != null) {
          // تقرير AIDE — بروتوكول الاستعادة = إعادة تنفيذ بروتوكول الفتح ذاته (جذر + فهرسة + إعلام).
          browser.openProjectRoot(session.path());
          Toast.makeText(this, uiFormat("ui_project_opened", session.name()), Toast.LENGTH_SHORT).show();
        }
      }
      browser.postDelayed(this::showPermissionsCenterOnFirstRun, 500);
    } catch (Throwable error) {
      CrashStore.save(this, error);
      showStartupError(error);
    }
  }

  void configureActionBar() {
    ActionBar b = getActionBar();
    if (b == null) return;
    b.setTitle(ui("ui_current_project"));
    b.setSubtitle(getString(R.string.app_name));
    b.setBackgroundDrawable(new ColorDrawable(Color.rgb(34, 34, 34)));
    b.setDisplayHomeAsUpEnabled(true);
    b.setHomeButtonEnabled(true);
    b.setHomeAsUpIndicator(R.drawable.ic_navigation_menu);
  }

  void applySelectedTheme() {
    ThemeConfig theme = new ThemeConfig(this);
    int background = theme.color(ThemeConfig.BACKGROUND);
    int chrome = Color.rgb(34, 34, 34);
    getWindow().setStatusBarColor(theme.isDark() ? Color.BLACK : Color.rgb(224, 224, 224));
    // المرحلة 4: نافذة/شريط حالة من الإعدادات المتقدمة.
    if (almlk.AppSettings.prefs(this).getBoolean("use_adjustPan", false))
      getWindow()
          .setSoftInputMode(
              android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
                  | android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
    else
      getWindow()
          .setSoftInputMode(
              android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
                  | android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    if (almlk.AppSettings.prefs(this).getBoolean("dark_statusbar", false))
      getWindow().setStatusBarColor(Color.BLACK);
    getWindow()
        .setNavigationBarColor(theme.isDark() ? Color.rgb(35, 35, 35) : Color.rgb(224, 224, 224));
    ActionBar bar = getActionBar();
    if (bar != null) bar.setBackgroundDrawable(new ColorDrawable(chrome));
    if (empty != null) empty.setBackgroundColor(background);
    if (editor != null) editor.applyTheme();
    if (browser != null) browser.applyTheme();
  }

  /** المرحلة 5: الدرج والزر الرئيسي يحترمان مفاتيح التطبيق المتقدمة عند كل استئناف. */
  private void applyDrawerSettings() {
    android.content.SharedPreferences sp = almlk.AppSettings.prefs(this);
    if (drawer != null) {
      boolean drawerOn = sp.getBoolean("advanced_setting_enable_drawer", true);
      boolean toggleOn = sp.getBoolean("enableDrawerToggle", true);
      drawer.setDrawerLockMode(
          drawerOn && toggleOn
              ? androidx.drawerlayout.widget.DrawerLayout.LOCK_MODE_UNLOCKED
              : androidx.drawerlayout.widget.DrawerLayout.LOCK_MODE_LOCKED_CLOSED,
          android.view.Gravity.START);
    }
    if (masterButton != null && !masterAllowed()) masterButton.setVisibility(View.GONE);
  }

  private boolean masterAllowed() {
    return almlk.AppSettings.prefs(this).getBoolean("enableMainMasterButton", true);
  }

  void configureDrawer() {
    drawer.setScrimColor(Color.BLACK);
    drawer.setHorizontalSwipeListener(
        new VPDrawerLayout.HorizontalSwipeListener() {
          @Override
          public void onDrawerSwipeLeft() {
            // The file browser and tool panes are one continuous pager.
            if (sequentialPanels != null) sequentialPanels.nextPage();
          }

          @Override
          public boolean onDrawerSwipeRight() {
            // At the file page return false so DrawerLayout can close normally.
            return sequentialPanels != null && sequentialPanels.previousPageIfPossible();
          }
        });
    drawer.addDrawerListener(
        new DrawerLayout.SimpleDrawerListener() {
          @Override
          public void onDrawerOpened(View v) {
            getActionBar().setHomeAsUpIndicator(R.drawable.ic_navigation_back);
            invalidateOptionsMenu();
          }

          @Override
          public void onDrawerClosed(View v) {
            getActionBar().setHomeAsUpIndicator(R.drawable.ic_navigation_menu);
            invalidateOptionsMenu();
          }
        });
  }

  void showNoProject() {
    projectOpen = false;
    sourceDiagnostics.clear();
    buildDiagnostics.clear();
    publishProjectDiagnostics();
    empty.setVisibility(View.VISIBLE);
    editor.setVisibility(View.GONE);
    if (masterButton != null) masterButton.setVisibility(View.GONE);
    getActionBar().setTitle(ui("ui_current_project"));
    getActionBar().setSubtitle(getString(R.string.app_name));
  }

  void openFile(String file) {
    openFile(file, null);
  }

  void openFile(String file, String content) {
    openFile(file, content, "");
  }

  void openFile(String file, String content, String reference) {
    // تقرير فتح الملفات — تقرير التبديل بين المشاريع يسبق القراءة الآن (setOnFileOpeningListener)
    // أي وصول openFile هنا يعني أن المحتوى جاهز للحقن فقط.
    projectOpen = true;
    empty.setVisibility(View.GONE);
    editor.openFile(file, content, reference);
    if (browser != null)
      browser.setActiveEditorSnapshot(editor.getActiveFile(), editor.getTextContent(), reference);
    if (masterButton != null) masterButton.setVisibility(View.VISIBLE);
    getActionBar().setTitle(file);
    getActionBar().setSubtitle(ui("ui_open_project_subtitle"));
  }

  @Override
  public void onProjectOpened(String name, String path) {
    // فتح مشروع مختلف عمّا هو مفتوح: تأكيد أولًا مع إيقاف تخزين المشروع السابق بسرعة.
    if (projectOpen
        && session != null
        && session.isOpen()
        && path != null
        && !path.isEmpty()
        && !session.path().equals(path)) {
      confirmProjectSwitch(name, path);
      return;
    }
    applyProjectOpen(name, path);
  }

  /** حوار تأكيد أنيق قبل استبدال المشروع الحالي بآخر جديد. */
  private void confirmProjectSwitch(final String name, final String path) {
    final String previousName = session.name();
    final String previousPath = session.path();
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_project_wizard_title"))
        .setMessage(uiFormat("ui_project_switch_message", name, previousName))
        .setPositiveButton(
            ui("ui_open_project_entry"),
            (dialog, which) -> {
              suspendProjectCaches(previousPath);
              applyProjectOpen(name, path);
            })
        .setNegativeButton(
            ui("dialog_cancel"),
            (dialog, which) -> {
              // تراجع أنيق: إبقاء المشروع السابق مفتوحًا وإعادة المتصفح إلى جذره.
              if (browser != null) browser.openProjectRoot(previousPath);
            })
        .show();
  }

  /** التخزين المؤقت للمشروع الحالي فقط: إسقاط فهرس/كاش المشروع السابق فورًا. */
  private void suspendProjectCaches(String previousPath) {
    ProjectSymbolIndex.clear();
    if (editor != null) editor.closeAll();
    if (browser != null) browser.suspendProjectCacheFor(previousPath);
  }

  /** إن كان الملف المفتوح داخل مشروع آخر غير المفتوح: طلب فتح مشروع جديد (نفس حوار التأكيد). */
  /** مسار مشروعٍ طلبنا تبديله لملفٍ منه — يمنع ظهور الحوار مرتين لنفس المشروع. */
  private String pendingFileSwitchPath;

  private void maybeSwitchProjectForFile(String reference) {
    if (reference == null || !reference.startsWith("/")) return;
    final String base = "/storage/emulated/0/AppProjects/";
    if (!reference.startsWith(base)) return;
    int slash = reference.indexOf('/', base.length());
    if (slash < 0) return;
    String projectPath = reference.substring(0, slash);
    String projectName = projectPath.substring(projectPath.lastIndexOf('/') + 1);
    if (projectName.isEmpty()
        || session == null
        || !session.isOpen()
        || session.path().equals(projectPath)) return;
    // تقرير فتح الملفات — الحوار مرة واحدة لكل مشروع مقترن حتى لو نقر المستخدم عدة ملفات.
    if (projectPath.equals(pendingFileSwitchPath)) return;
    pendingFileSwitchPath = projectPath;
    getWindow()
        .getDecorView()
        .postDelayed(
            () -> {
              if (projectPath.equals(pendingFileSwitchPath)) pendingFileSwitchPath = null;
            },
            4000);
    onProjectOpened(projectName, projectPath);
  }

  private void applyProjectOpen(String name, String path) {
    maybeInitGitRepo();
    projectOpen = true;
    session.open(name, path);
    boolean hasOpenFile = editor.hasOpenFile();
    empty.setVisibility(hasOpenFile ? View.GONE : View.VISIBLE);
    editor.setVisibility(hasOpenFile ? View.VISIBLE : View.GONE);
    if (masterButton != null)
      masterButton.setVisibility(
          (hasOpenFile && masterAllowed()) ? View.VISIBLE : View.GONE);
    getActionBar().setTitle(name);
    getActionBar().setSubtitle(ui("ui_android_project_subtitle"));
    sourceDiagnostics.clear();
    buildDiagnostics.clear();
    publishProjectDiagnostics();
    indexAndScanProject();
    // تقرير 04 — فحص dependencies في الخلفية وعرض الخطة في لوحة Build دون تعطيل المحرر.
    com.shima.dependencies.GradleDependencyScanner.scanAsync(
        this,
        new File(path),
        lines -> {
          if (sequentialPanels != null)
            for (String line : lines) sequentialPanels.appendBuildOutput(line);
        });
  }

  private void openDefinition(ProjectSymbolIndex.DefinitionTarget definition) {
    if (definition == null) return;
    // بند 3 — وضع لوحة المفاتيح لا يتغير بسبب الانتقال أو القوائم.
    final boolean imeWasVisible = isImeVisible();
    // المقارنة بالاسم القصير + مرجع الجلسة الدقيق — أسماء التبويبات قد تكون مفردة (app/X.java).
    String activeName = editor == null ? null : editor.getActiveFile();
    String activeShort =
        activeName == null ? "" : activeName.substring(activeName.lastIndexOf('/') + 1);
    String activeReference = editor == null ? "" : editor.activeFileReference();
    boolean sameOpenFile = definition.fileName != null
        && (definition.fileName.equals(activeName) || definition.fileName.equals(activeShort))
        && (definition.reference == null || definition.reference.isEmpty()
            || activeReference.isEmpty() || definition.reference.equals(activeReference));
    if (definition.source == null && sameOpenFile) {
      // هذا المسار لمرجع محدد؛ تحديد التعريف نفسه يُحوَّل قبل الوصول هنا إلى قائمة الاستخدامات.
      editor.goToSymbol(definition.symbol, definition.offset);
      restoreKeyboardIfVisible(imeWasVisible);
      return;
    }
    // تبويب مفتوح آخر محتواه حي: تفعيل مباشر وقفزة على نصه — لا إعادة حقن من القرص
    // تدمّر تعديلات غير محفوظة.
    if (definition.source == null && editor != null) {
      String openTab = editor.selectIfOpenLive(definition.reference, definition.fileName);
      if (openTab != null) {
        editor.goToSymbol(definition.symbol, definition.offset);
        restoreKeyboardIfVisible(imeWasVisible);
        return;
      }
    }
    final String targetReference = definition.reference;
    browser.openDefinition(
        definition,
        (success, fileName, content, offset, message) -> {
          if (!success || fileName == null || content == null) {
            // المرجع يتنقل بصمت — التنبيه عند الفشل فقط.
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            return;
          }
          String reference = targetReference == null || targetReference.isEmpty()
              ? browser.fileReference(fileName) : targetReference;
          openFile(fileName, content, reference);
          // عند تحديد مرجع، افتح التعريف وحدد الرمز؛ أما تحديد التعريف فيُحوَّل لقائمة الاستخدامات.
          editor.goToSymbol(definition.symbol, offset);
          restoreKeyboardIfVisible(imeWasVisible);
        });
  }

  private boolean isImeVisible() {
    android.graphics.Rect frame = new android.graphics.Rect();
    android.view.View decor = getWindow().getDecorView();
    decor.getWindowVisibleDisplayFrame(frame);
    int heightDiff = decor.getRootView().getHeight() - frame.bottom;
    return heightDiff > getResources().getDisplayMetrics().density * 100;
  }

  private void restoreKeyboardIfVisible(boolean wasVisible) {
    if (wasVisible && editor != null) editor.postDelayed(editor::ensureKeyboardVisible, 150);
  }

  private void findDefinitionForSelection(
      String fileName, String source, int selectionStart, int selectionEnd) {
    // المرحلة السابعة: مراجع XML تُحل من فهرس موارد المشروع، لا من محلل رموز Java.
    if (almlk.XmlCodeFormatter.isXmlName(fileName)) {
      resolveXmlResourceDefinition(source, selectionStart);
      return;
    }
    browser.findDefinitionAsync(
        fileName,
        source,
        selectionStart,
        selectionEnd,
        target -> {
          if (target == null) {
            Toast.makeText(this, ui("ui_error_definition_not_found"), Toast.LENGTH_SHORT).show();
          } else if (ProjectSymbolIndex.isDefinitionSelection(
              fileName, source, selectionStart, selectionEnd, target)) {
            findUsagesForSelection(fileName, source, selectionStart, selectionEnd);
          } else {
            openDefinition(target);
          }
        });
  }

  /** حلّ {@code @type/name} إلى ملف القيم الذي يعرّفه — فهرسة على خيط خلفي وقفزة على الرئيسي. */
  private void resolveXmlResourceDefinition(String source, int offset) {
    if (browser == null) return;
    browser.resolveXmlResourceAsync(
        source,
        offset,
        (reference, declaration) -> {
          if (reference == null) {
            Toast.makeText(this, ui("ui_xml_cursor_resource_reference"), Toast.LENGTH_SHORT)
                .show();
            return;
          }
          if (declaration == null) {
            Toast.makeText(
                    this,
                    reference.framework
                        ? uiFormat("ui_xml_framework_resource", reference.display())
                        : uiFormat("ui_xml_resource_not_found", reference.display()),
                    Toast.LENGTH_SHORT)
                .show();
            return;
          }
          openDefinition(
              new ProjectSymbolIndex.DefinitionTarget(
                  declaration.file,
                  "@" + declaration.type,
                  declaration.name,
                  null,
                  declaration.offset,
                  false,
                  declaration.file,
                  ProjectSymbolIndex.DefinitionTarget.KIND_FIELD));
        });
  }

  private void findUsagesForSelection(
      String fileName, String source, int selectionStart, int selectionEnd) {
    final String symbol = UsageSearchEngine.identifierAt(source, selectionStart, selectionEnd);
    if (symbol.isEmpty()) {
      Toast.makeText(this, ui("ui_error_symbol_selection_required"), Toast.LENGTH_SHORT).show();
      return;
    }
    showSequentialPanels(SequentialPanelHost.Panel.SEARCH);
    sequentialPanels.setSearchStatus(uiFormat("ui_search_usages_start", symbol));
    sequentialPanels.setSearchResults(Collections.emptyList(), symbol);
    browser.findUsagesAsync(
        fileName,
        source,
        selectionStart,
        selectionEnd,
        (usages, done) -> {
          if (sequentialPanels != null) {
            sequentialPanels.setSearchResults(usages, symbol);
            int count = usages == null ? 0 : usages.size();
            sequentialPanels.setSearchStatus(
                !done
                    ? uiFormat("ui_search_usages_in_progress", symbol, count)
                    : count == 0
                        ? uiFormat("ui_search_no_usages", symbol)
                        : uiFormat("ui_search_usages_found", count));
          }
        });
  }

  private void indexAndScanProject() {
    if (browser == null) return;
    browser.indexProjectSymbols(
        () -> {
          if (editor != null) editor.refreshSemanticDiagnostics();
          scanProjectDiagnostics();
        });
  }

  private void scanProjectDiagnostics() {
    if (browser == null) return;
    browser.scanProjectDiagnosticsAsync(
        new BrowserPager.ProjectDiagnosticsListener() {
          @Override
          public void progress(int done, int total) {
            if (sequentialPanels != null) sequentialPanels.setScanProgress(done, total);
          }

          @Override
          public void completed(List<ProjectDiagnostic> found) {
            if (sequentialPanels != null) sequentialPanels.setScanProgress(0, 0);
            sourceDiagnostics.clear();
            if (found != null) sourceDiagnostics.addAll(found);
            publishProjectDiagnostics();
            if (editor != null) editor.refreshSemanticDiagnostics();
          }
        });
  }

  private void onEditorFileChanged(String fileName, String reference) {
    boolean removed = removeDiagnosticsForFile(sourceDiagnostics, fileName, reference);
    removed |= removeDiagnosticsForFile(buildDiagnostics, fileName, reference);
    if (removed) publishProjectDiagnostics();
  }

  private void onEditorDiagnostics(
      String fileName,
      String reference,
      String source,
      List<CodeLanguageTools.Diagnostic> found) {
    removeDiagnosticsForFile(sourceDiagnostics, fileName, reference);
    if (found != null) {
      for (CodeLanguageTools.Diagnostic diagnostic : found) {
        ProjectDiagnostic item =
            ProjectDiagnostic.fromSource(fileName, reference, source, diagnostic);
        if (item != null) sourceDiagnostics.add(item);
      }
    }
    publishProjectDiagnostics();
  }

  private boolean removeDiagnosticsForFile(
      ArrayList<ProjectDiagnostic> values, String fileName, String reference) {
    String shortName = fileName == null ? "" : fileName.substring(fileName.lastIndexOf('/') + 1);
    boolean removed = false;
    for (int i = values.size() - 1; i >= 0; i--) {
      ProjectDiagnostic item = values.get(i);
      if (item == null) {
        values.remove(i);
        removed = true;
        continue;
      }
      boolean sameReference =
          reference != null && !reference.isEmpty() && reference.equals(item.reference);
      boolean sameName =
          (item.fileName.equals(fileName) || item.fileName.equals(shortName))
              && (reference == null || reference.isEmpty() || item.reference.isEmpty());
      if (sameReference || sameName) {
        values.remove(i);
        removed = true;
      }
    }
    return removed;
  }

  private void publishProjectDiagnostics() {
    LinkedHashMap<String, ProjectDiagnostic> unique = new LinkedHashMap<>();
    for (ProjectDiagnostic item : sourceDiagnostics) {
      if (item == null) continue;
      String key = diagnosticMergeKey(item);
      if (!unique.containsKey(key)) unique.put(key, item);
    }
    for (ProjectDiagnostic item : buildDiagnostics) {
      if (item == null) continue;
      String key = diagnosticMergeKey(item);
      if (!unique.containsKey(key)) unique.put(key, item);
    }
    displayedDiagnostics.clear();
    displayedDiagnostics.addAll(unique.values());
    displayedDiagnostics.sort(
        (a, b) -> {
          int file = a.groupKey().compareToIgnoreCase(b.groupKey());
          if (file != 0) return file;
          int line = Integer.compare(a.diagnostic.line, b.diagnostic.line);
          return line != 0 ? line : Integer.compare(a.diagnostic.column, b.diagnostic.column);
        });
    if (editor != null) editor.setProjectDiagnostics(displayedDiagnostics);
    if (sequentialPanels != null) sequentialPanels.setProjectDiagnostics(displayedDiagnostics);
  }

  private String diagnosticMergeKey(ProjectDiagnostic item) {
    String owner = item.reference.isEmpty() ? item.fileName : item.reference;
    String point = item.symbol.isEmpty()
        ? item.diagnostic.code + "|" + String.valueOf(item.diagnostic.message)
        : item.symbol;
    return owner + "|" + item.diagnostic.line + "|" + item.diagnostic.column + "|" + point;
  }

  private void openProjectDiagnostic(ProjectDiagnostic diagnostic) {
    openProjectDiagnostic(diagnostic, false);
  }

  /**
   * ينقل إلى موقع التشخيص ويحدده. مع openFixes (الضغط المطوّل كالمرجع) يُسلَّح فتح شريط
   * الإجراءات بعد تحديد الخطأ مباشرة، ويُلغى التسليح إن لم تتم القفزة.
   */
  private void openProjectDiagnostic(ProjectDiagnostic diagnostic, boolean openFixes) {
    if (diagnostic == null || diagnostic.diagnostic == null || editor == null) return;
    int line = Math.max(1, diagnostic.diagnostic.line);
    int column = Math.max(1, diagnostic.diagnostic.column);
    String tab = editor.activateTabByReference(diagnostic.reference, diagnostic.fileName);
    if (tab != null) {
      if (openFixes) editor.armErrorFixes();
      if (!editor.goToMatch(tab, line, column)) editor.disarmErrorFixes();
      closeSequentialPanels();
      return;
    }
    if (browser == null) return;
    UsageSearchEngine.Usage target =
        new UsageSearchEngine.Usage(
            diagnostic.fileName,
            diagnostic.reference,
            Math.max(0, diagnostic.diagnostic.offset),
            line,
            column,
            diagnostic.preview,
            "diagnostic");
    browser.openUsageAsync(
        target,
        (success, fileName, content, offset, message) -> {
          if (!success || fileName == null || content == null) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            return;
          }
          openFile(fileName, content, browser.fileReference(fileName));
          String active = editor.getActiveFile();
          if (active != null) {
            if (openFixes) editor.armErrorFixes();
            if (!editor.goToMatch(active, line, column)) editor.disarmErrorFixes();
          }
          closeSequentialPanels();
        });
  }

  /** الضغط المطوّل على خطأ (كالمرجع): انتقال إلى موقعه ثم وضع الإجراءات بقائمة الإصلاح. */
  private void requestErrorFixes(ProjectDiagnostic diagnostic) {
    openProjectDiagnostic(diagnostic, true);
  }

  /**
   * الخطأ التالي/السابق بترتيب لوحة الأخطاء (الملف ثم السطر ثم العمود) مع الالتفاف، ويبدأ
   * من موضع المؤشر في الملف النشط. الترتيب مضمون لأن publishProjectDiagnostics يفرز القائمة.
   */
  private void gotoAdjacentError(boolean forward) {
    if (editor == null) return;
    int n = displayedDiagnostics.size();
    if (n == 0) {
      Toast.makeText(this, ui("ui_errors_title"), Toast.LENGTH_SHORT).show();
      return;
    }
    String activeReference = editor.getActiveFileReference();
    String activeName = editor.getActiveFile();
    String activeKey = activeReference.isEmpty() ? (activeName == null ? "" : activeName) : activeReference;
    int[] caret = editor.caretLineColumn();
    int first = -1, last = -1, after = n;
    for (int i = 0; i < n; i++) {
      String key = displayedDiagnostics.get(i).groupKey();
      if (first < 0 && key.equals(activeKey)) first = i;
      if (key.equals(activeKey)) last = i;
      if (after == n && key.compareToIgnoreCase(activeKey) > 0) after = i;
    }
    ProjectDiagnostic target = null;
    if (forward) {
      for (int i = Math.max(first, 0); first >= 0 && i <= last && target == null; i++) {
        ProjectDiagnostic item = displayedDiagnostics.get(i);
        if (item.diagnostic.line > caret[0]
            || (item.diagnostic.line == caret[0] && item.diagnostic.column > caret[1])) target = item;
      }
      if (target == null) {
        int next = first >= 0 ? last + 1 : after;
        target = displayedDiagnostics.get(next < n ? next : 0);
      }
    } else {
      for (int i = last; first >= 0 && i >= first && target == null; i--) {
        ProjectDiagnostic item = displayedDiagnostics.get(i);
        if (item.diagnostic.line < caret[0]
            || (item.diagnostic.line == caret[0] && item.diagnostic.column < caret[1])) target = item;
      }
      if (target == null) {
        int previous = (first >= 0 ? first : after) - 1;
        target = displayedDiagnostics.get(previous >= 0 ? previous : n - 1);
      }
    }
    openProjectDiagnostic(target, false);
  }

  private void showSequentialPanels(SequentialPanelHost.Panel initial) {
    if (sequentialPanels == null) return;
    sequentialPanels.setProjectDiagnostics(displayedDiagnostics);
    sequentialPanels.showPage(initial == null ? SequentialPanelHost.Panel.ERRORS : initial);
    if (drawer != null && !drawer.isDrawerOpen(Gravity.START)) drawer.openDrawer(Gravity.START);
  }

  private void closeSequentialPanels() {
    if (drawer != null && drawer.isDrawerOpen(Gravity.START)) drawer.closeDrawer(Gravity.START);
  }

  private void showPanel(SequentialPanelHost.Panel panel) {
    showSequentialPanels(panel);
  }

  private void confirmCreateMissingMember(ProjectSymbolIndex.MissingMember member) {
    StringBuilder signature = new StringBuilder();
    signature.append(member.returnType).append(' ').append(member.methodName).append('(');
    for (int i = 0; i < member.parameters.size(); i++) {
      if (i > 0) signature.append(", ");
      ProjectSymbolIndex.Parameter parameter = member.parameters.get(i);
      signature.append(parameter.type).append(' ').append(parameter.name);
    }
    signature.append(')');
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_create_missing_member_title"))
        .setMessage(uiFormat("ui_create_missing_member_message", member.className, signature))
        .setNegativeButton(ui("ui_action_no"), null)
        .setPositiveButton(
            ui("ui_action_yes"),
            (dialog, which) ->
                browser.createMissingMember(
                    member,
                    (success, fileName, content, message) -> {
                      Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                      if (success) {
                        openFile(fileName, content, browser.fileReference(fileName));
                        int methodOffset =
                            content == null || member.methodName == null
                                ? -1
                                : content.lastIndexOf(member.methodName + "(");
                        if (methodOffset >= 0 && editor != null) {
                          int line = 1, column = 1;
                          for (int i = 0; i < methodOffset; i++) {
                            if (content.charAt(i) == '\n') {
                              line++;
                              column = 1;
                            } else column++;
                          }
                          String active = editor.getActiveFile();
                          if (active != null) editor.goToMatch(active, line, column);
                        }
                        if (editor != null) editor.refreshSemanticDiagnostics();
                        scanProjectDiagnostics();
                        closeSequentialPanels();
                      }
                    }))
        .show();
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    menu.clear();
    menu.add(0, 1, 0, getString(R.string.command_run))
        .setIcon(R.drawable.ic_vectoric_run)
        .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    // دلالة المرجع: أثناء الكتابة يحل زوج التراجع/الإعادة محل القلم، بأهلية حية
    // (المتاح أبيض والمعطل باهت) — وخارج التحرير يعود القلم كما كان.
    boolean editingNow =
        editingToolbar && (drawer == null || !drawer.isDrawerOpen(Gravity.START));
    if (editingNow && editor != null) {
      lastCanUndo = editor.canUndoEdit();
      lastCanRedo = editor.canRedoEdit();
      MenuItem undoItem =
          menu.add(0, 4, 1, getString(R.string.command_undo)).setIcon(R.drawable.ic_vectoric_undo);
      undoItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
      undoItem.setEnabled(lastCanUndo);
      if (undoItem.getIcon() != null)
        undoItem.getIcon().mutate().setAlpha(lastCanUndo ? 255 : 95);
      MenuItem redoItem =
          menu.add(0, 5, 2, getString(R.string.command_redo)).setIcon(R.drawable.ic_vectoric_redo);
      redoItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
      redoItem.setEnabled(lastCanRedo);
      if (redoItem.getIcon() != null)
        redoItem.getIcon().mutate().setAlpha(lastCanRedo ? 255 : 95);
    } else if (activeLayoutXml()) {
      // دلالة المرجع: ملف تخطيط XML بلا كيبورد → أيقونة معاينة التصميم محل القلم.
      menu.add(0, 6, 1, ui("command_design"))
          .setIcon(R.drawable.ic_vectoric_design)
          .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    } else
      menu.add(0, 2, 1, getString(R.string.command_edit))
          .setIcon(R.drawable.ic_vectoric_edit)
          .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    MenuItem more = menu.add(0, 3, 3, getString(R.string.menu_more));
    ImageButton button = new ImageButton(this);
    button.setImageResource(R.drawable.ic_vectoric_more);
    button.setContentDescription(getString(R.string.menu_more));
    button.setBackgroundColor(Color.TRANSPARENT);
    button.setPadding(dp(12), dp(12), dp(12), dp(12));
    button.setOnClickListener(v -> showIdeRootMenu(v));
    moreActionView = button;
    more.setActionView(button);
    more.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    return true;
  }

  /** اختصارات العتاد على مستوى الـIDE — ترسل معرفات الأوامر للفهرس كما كل نقاط الواجهة. */
  @Override
  public boolean onKeyShortcut(int keyCode, android.view.KeyEvent event) {
    if (event.isCtrlPressed()) {
      switch (keyCode) {
        case android.view.KeyEvent.KEYCODE_S:
          dispatch("save");
          return true;
        case android.view.KeyEvent.KEYCODE_F:
          dispatch(event.isShiftPressed() ? "replace" : "find");
          return true;
        case android.view.KeyEvent.KEYCODE_H:
          dispatch("replace");
          return true;
        case android.view.KeyEvent.KEYCODE_G:
          dispatch("goto_line");
          return true;
        case android.view.KeyEvent.KEYCODE_SLASH:
          dispatch("comment");
          return true;
        case android.view.KeyEvent.KEYCODE_L:
          dispatch("format");
          return true;
        case android.view.KeyEvent.KEYCODE_SPACE:
          dispatch("complete");
          return true;
        default:
          break;
      }
    }
    return super.onKeyShortcut(keyCode, event);
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      if (drawer.isDrawerOpen(Gravity.START)) drawer.closeDrawers();
      else openBrowser();
      return true;
    }
    if (item.getItemId() == 1) {
      // نمط المرجع: الأيقونة ترسل معرف الأمر للفهرس فيفحص الأهلية ثم ينفذ.
      dispatch("run");
      return true;
    }
    if (item.getItemId() == 2) {
      // أيقونة القلم كما في المرجع: دخول التحرير مباشرة، وإن لا ملف مفتوحًا نفتح المتصفح.
      if (editor == null || !editor.beginEditingSession()) openFilesBrowser();
      return true;
    }
    if (item.getItemId() == 6) {
      openDesigner();
      return true;
    }
    if (item.getItemId() == 4) {
      dispatch("undo");
      return true;
    }
    if (item.getItemId() == 5) {
      dispatch("redo");
      return true;
    }
    if (item.getItemId() == 3) {
      showIdeRootMenu(moreActionView != null ? moreActionView : masterButton);
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  @Override
  public void onCreateProject() {
    drawer.closeDrawers();
    // بنية المرجع: معالج قوالب حقيقي — فئات من JSON، اسم/حزمة بتحقق حي، نسخ واستبدالات،
    // ثم فتح المشروع وملفات البداية. لا ستب ولا وهم (بند الإحلال الكامل).
    ProjectWizard.show(
        this,
        browser != null ? browser.projectsTargetDirectory() : null,
        new ProjectWizard.Host() {
          @Override
          public void onProjectCreated(
              File projectRoot, File mainModule, java.util.List<File> starterFiles) {
            if (browser != null) browser.openCreatedProject(projectRoot);
            openStarterFiles(starterFiles);
          }

          @Override
          public void onProjectImported(File targetDirectory) {
            if (browser != null) browser.refreshListing();
          }
        });
  }

  /** فتح ملفات بداية المشروع في التبويبات بالترتيب — القراءة خلفية والحقن على الواجهة. */
  private void openStarterFiles(java.util.List<File> starters) {
    if (starters == null || starters.isEmpty()) return;
    new Thread(
            () -> {
              for (File starter : starters) {
                String content;
                try (java.io.FileInputStream in = new java.io.FileInputStream(starter)) {
                  java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                  byte[] buffer = new byte[8192];
                  int read;
                  while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
                  content = out.toString("UTF-8");
                } catch (Exception unreadable) {
                  continue;
                }
                final String name = starter.getName();
                final String text = content;
                final String reference = starter.getAbsolutePath();
                runOnUiThread(() -> openFile(name, text, reference));
              }
            })
        .start();
  }

  @Override
  public void onCloneGit() {
    drawer.closeDrawers();
    View v = getLayoutInflater().inflate(R.layout.gitclonerepository, null);
    ((TextView) v.findViewById(R.id.gitclonerepositoryLocation))
        .setText("/storage/emulated/0/AppProjects");
    ((EditText) v.findViewById(R.id.gitclonerepositoryUrl)).setText("");
    ((EditText) v.findViewById(R.id.gitclonerepositoryDirectoryName)).setText("");
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_clone_git_entry"))
        .setView(v)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("ui_clone_git_entry"),
            (d, w) -> Toast.makeText(this, ui("ui_clone_git_entry"), Toast.LENGTH_SHORT).show())
        .show();
  }

  /** فتح الدرج على القسم المثبت — زر القائمة لا يُسقط المستخدم من الأخطاء/البحث للملفات. */
  void openBrowser() {
    if (drawer != null) drawer.openDrawer(Gravity.START);
  }

  /** فتح الدرج على صفحة الملفات تحديدًا — للأوامر التي تقصد الملفات صراحة. */
  void openFilesBrowser() {
    if (sequentialPanels != null) sequentialPanels.showFilesPage();
    if (drawer != null) drawer.openDrawer(Gravity.START);
  }

  @Override
  public void onStoragePermissionRequested() {
    showPermissionsCenter();
  }

  private void showPermissionsCenterOnFirstRun() {
    ensureRequiredStorageAccess();
  }

  private void ensureRequiredStorageAccess() {
    if (browser == null || !browser.needsProjectFolderSelection()) {
      if (requiredStorageDialog != null && requiredStorageDialog.isShowing()) {
        requiredStorageDialog.dismiss();
      }
      return;
    }
    if (isFinishing() || (requiredStorageDialog != null && requiredStorageDialog.isShowing()))
      return;

    requiredStorageDialog =
        new AlertDialog.Builder(this)
            .setTitle(ui("ui_permission_first_run_title"))
            .setMessage(ui("ui_permission_first_run_message"))
            .setPositiveButton(ui("ui_permission_select_project_folder"), (dialog, which) -> onSelectProjectFolder())
            .setNeutralButton(ui("ui_permission_all_files"), (dialog, which) -> openAllFilesSettings())
            .create();
    requiredStorageDialog.setCancelable(false);
    requiredStorageDialog.setCanceledOnTouchOutside(false);
    requiredStorageDialog.show();
  }

  private void showPermissionsCenter() {
    String files =
        (android.os.Build.VERSION.SDK_INT < 30 || android.os.Environment.isExternalStorageManager()
                ? "✓ "
                : "")
            + ui("ui_permission_all_files");
    String installs =
        (android.os.Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls()
                ? "✓ "
                : "")
            + ui("ui_permission_install_apks");
    String overlay =
        (android.os.Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this)
                ? "✓ "
                : "")
            + ui("ui_permission_overlay");
    android.os.PowerManager power =
        (android.os.PowerManager) getSystemService(android.content.Context.POWER_SERVICE);
    String battery =
        (android.os.Build.VERSION.SDK_INT < 23
                || (power != null && power.isIgnoringBatteryOptimizations(getPackageName()))
            ? "✓ "
            : "")
            + ui("ui_permission_battery_exemption");
    String[] options = {
      ui("ui_permission_choose_project_recommended"),
      files,
      installs,
      overlay,
      battery,
      ui("ui_permission_legacy_storage"),
      ui("ui_permission_advanced_info")
    };
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_permission_title"))
        .setItems(
            options,
            (dialog, which) -> {
              switch (which) {
                case 0:
                  onSelectProjectFolder();
                  break;
                case 1:
                  openAllFilesSettings();
                  break;
                case 2:
                  openInstallPackagesSettings();
                  break;
                case 3:
                  openOverlaySettings();
                  break;
                case 4:
                  requestBatteryExemption();
                  break;
                case 5:
                  requestLegacyStoragePermissions();
                  break;
                default:
                  showMessage(ui("ui_permission_explanation_title"), ui("ui_permission_explanation"));
              }
            })
        .setNegativeButton(ui("ui_action_close"), null)
        .show();
  }

  private void openAllFilesSettings() {
    if (android.os.Build.VERSION.SDK_INT < 30) {
      requestLegacyStoragePermissions();
      return;
    }
    try {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
              android.net.Uri.parse("package:" + getPackageName())));
    } catch (Exception error) {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
    }
  }

  private void openInstallPackagesSettings() {
    if (android.os.Build.VERSION.SDK_INT < 26) return;
    startActivity(
        new android.content.Intent(
            android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            android.net.Uri.parse("package:" + getPackageName())));
  }

  private void openOverlaySettings() {
    if (android.os.Build.VERSION.SDK_INT < 23) return;
    startActivity(
        new android.content.Intent(
            android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            android.net.Uri.parse("package:" + getPackageName())));
  }

  private void requestBatteryExemption() {
    if (android.os.Build.VERSION.SDK_INT < 23) return;
    try {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
              android.net.Uri.parse("package:" + getPackageName())));
    } catch (Exception error) {
      startActivity(
          new android.content.Intent(
              android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
    }
  }

  private void requestLegacyStoragePermissions() {
    if (android.os.Build.VERSION.SDK_INT < 23) return;
    if (android.os.Build.VERSION.SDK_INT >= 33) {
      showMessage(ui("ui_storage_permission_title"), ui("ui_storage_permission_message"));
      return;
    }
    String[] permissions =
        android.os.Build.VERSION.SDK_INT <= 29
            ? new String[] {
              android.Manifest.permission.READ_EXTERNAL_STORAGE,
              android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            }
            : new String[] {android.Manifest.permission.READ_EXTERNAL_STORAGE};
    requestPermissions(permissions, 40);
  }

  @Override
  public void onSelectProjectFolder() {
    android.content.Intent intent =
        new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT_TREE);
    intent.addFlags(
        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            | android.content.Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
    startActivityForResult(intent, 77);
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == 88) {
      applySelectedTheme();
      return;
    }
    if (requestCode == 7801) {
      if (resultCode != RESULT_OK || data == null || editor == null) return;
      // تعديلات المصمم تعود نصًا كاملًا — تُحقن عبر موديل المحرك (قابلة للتراجع + حفظ تلقائي).
      String updated = data.getStringExtra("xml");
      if (updated != null) editor.replaceActiveContent(updated);
      int designerOffset = data.getIntExtra("goto", -1);
      if (designerOffset >= 0) editor.goToOffset(designerOffset);
      return;
    }
    if (requestCode == 77) {
      if (resultCode == RESULT_OK && data != null && data.getData() != null) {
        android.net.Uri uri = data.getData();
        int flags =
            data.getFlags()
                & (android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
          getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) {
        }
        if (browser != null) browser.openTree(uri);
      }
      getWindow().getDecorView().postDelayed(this::ensureRequiredStorageAccess, 350);
    }
  }

  @Override
  protected void onPause() {
    if (editor != null) editor.saveSession();
    super.onPause();
    stopAutosave();
  }

  @Override
  protected void onStop() {
    // تقرير 03 — حفظ الجلسة والملفات المتسخة عند مغادرة الواجهة، وليس فقط عند الإغلاق.
    if (editor != null) editor.saveSession();
    super.onStop();
  }

  @Override
  public void onTrimMemory(int level) {
    super.onTrimMemory(level);
    // تقارير 01/03 — تحرير كاشات التوكنز/النتائج عند ضغط الذاكرة بدل الانتظار حتى OOM.
    if (editor != null) editor.trimMemoryCaches();
  }

  @Override
  protected void onResume() {
    super.onResume();
    String selectedLanguage = almlk.AppSettings.language(this);
    if (languageAtLastCreate != null && !languageAtLastCreate.equals(selectedLanguage)) {
      languageAtLastCreate = selectedLanguage;
      recreate();
      return;
    }
    if (editor != null) editor.applyEditorSettings();
    if (editor != null) editor.applyAdvancedSettings();
    applyDrawerSettings();
    scheduleAutosave();
    applySelectedTheme();
    if (browser != null) browser.refresh();
    getWindow()
        .getDecorView()
        .postDelayed(
            () -> {
              ensureRequiredStorageAccess();
              // تقرير AIDE — بعد منح صلاحية التخزين نسترد التبويبات التي فشل فتحها عند الإقلاع.
              if (browser != null && !browser.needsProjectFolderSelection() && editor != null) {
                editor.retryLazySessionReferences();
              }
            },
            450);
  }

  /** Displays the localized hierarchical menu declared in res/menu/main_options_menu.xml. */
  void showIdeRootMenu(View anchor) {
    if (anchor == null) return;
    PopupMenu popup = new PopupMenu(this, anchor, Gravity.END);
    Menu menu = popup.getMenu();
    getMenuInflater().inflate(R.menu.main_options_menu, menu);

    MenuItem editMode = menu.findItem(R.id.mainMenuEditMode);
    MenuItem navigateMode = menu.findItem(R.id.mainMenuNavigateMode);
    if (editMode != null) editMode.setVisible(!editingToolbar);
    if (navigateMode != null) navigateMode.setVisible(editingToolbar);
    updateIdeMenuState(menu);

    popup.setOnMenuItemClickListener(this::onIdeMenuItemClick);
    popup.show();
  }

  /** Applies live command eligibility without creating menu rows or titles in Java. */
  private void updateIdeMenuState(Menu menu) {
    for (int index = 0; index < menu.size(); index++) {
      MenuItem item = menu.getItem(index);
      int itemId = item.getItemId();
      if (itemId == R.id.editorMenuComment || itemId == R.id.editorMenuUnComment) {
        item.setEnabled(isEditorWritable());
      } else {
        String commandId = ideCommandForMenuItem(itemId);
        if (commandId != null) {
          CommandCenter.Command command = commands.get(commandId);
          item.setEnabled(command != null && command.enabled(this));
        }
      }
      if (item.hasSubMenu()) updateIdeMenuState(item.getSubMenu());
    }
  }

  /** Routes resource menu ids to the shared command catalogue. */
  private String ideCommandForMenuItem(int itemId) {
    if (itemId == R.id.mainMenuOpenFileBrowser) return "files";
    if (itemId == R.id.mainMenuOpenErrorBrowser) return "show_errors";
    if (itemId == R.id.mainMenuOpenSearchBrowser || itemId == R.id.mainMenuSearchInProject)
      return "show_search_results";
    if (itemId == R.id.mainMenuOpenDebugBrowser) return "show_debugger";
    if (itemId == R.id.mainMenuOpenLogCatBrowser) return "show_logcat";
    if (itemId == R.id.mainMenuGoto) return "goto_element";
    if (itemId == R.id.mainMenuForward) return "forward";
    if (itemId == R.id.mainMenuSave) return "save";
    if (itemId == R.id.editorMenuFindUsage) return "find_usages";
    if (itemId == R.id.mainMenuSearch) return "find";
    if (itemId == R.id.mainMenuReplace || itemId == R.id.editorMenuReplace) return "replace";
    if (itemId == R.id.mainMenuGotoLine) return "goto_line";
    if (itemId == R.id.editorMenuRename) return "rename";
    if (itemId == R.id.editorMenuInlineVariable) return "inline";
    if (itemId == R.id.editorMenuIntroduceVariable) return "introduce";
    if (itemId == R.id.editorMenuExtractMethod) return "extract_method";
    if (itemId == R.id.editorMenuOrganizeImports) return "organize_imports";
    if (itemId == R.id.editorMenuSurroundWithTryCatch) return "surround_try";
    if (itemId == R.id.editorMenuCreateSetters) return "create_setters";
    if (itemId == R.id.editorMenuCreateConstructor) return "create_constructor";
    if (itemId == R.id.editorMenuExtractResources) return "extract_resources";
    if (itemId == R.id.editorMenuFormatCode) return "format";
    if (itemId == R.id.editorMenuLearnCodeStyle) return "learn_style";
    if (itemId == R.id.editorMenuConfigureCodeStyle) return "configure_style";
    if (itemId == R.id.mainMenuRebuild) return "build_debug";
    if (itemId == R.id.mainMenuBuildRelease) return "build_release";
    if (itemId == R.id.mainMenuSelectBuildVariant) return "select_build_variant";
    if (itemId == R.id.mainMenuPublishProject) return "publish_project";
    if (itemId == R.id.mainMenuCloseProject) return "close_project";
    if (itemId == R.id.mainMenuTerminal) return "terminal";
    if (itemId == R.id.mainMenuPermissions) return "permissions";
    if (itemId == R.id.mainMenuTheme) return "theme";
    if (itemId == R.id.mainMenuAbout) return "about";
    if (itemId == R.id.mainMenuGitStatus) return "git_status";
    if (itemId == R.id.mainMenuGitLog) return "git_log";
    if (itemId == R.id.mainMenuGitAdd) return "git_add";
    if (itemId == R.id.mainMenuGitCommit) return "git_commit";
    if (itemId == R.id.mainMenuGitPull) return "git_pull";
    if (itemId == R.id.mainMenuGitPush) return "git_push";
    if (itemId == R.id.mainMenuSettings) return "settings";
    if (itemId == R.id.mainMenuExit) return "exit";
    return null;
  }

  private boolean onIdeMenuItemClick(MenuItem item) {
    int itemId = item.getItemId();
    if (itemId == R.id.mainMenuEditMode || itemId == R.id.mainMenuNavigateMode) {
      toggleEditNavigateMode();
      return true;
    }
    if (itemId == R.id.mainMenuShowOpenFiles) {
      showOpenFilesDialog();
      return true;
    }
    if (itemId == R.id.editorMenuHelp) {
      openDocumentation();
      return true;
    }
    if (itemId == R.id.editorMenuComment) {
      if (editor != null) editor.commentLines();
      return true;
    }
    if (itemId == R.id.editorMenuUnComment) {
      if (editor != null) editor.uncommentLines();
      return true;
    }
    String commandId = ideCommandForMenuItem(itemId);
    if (commandId == null) return false;
    dispatch(commandId);
    return true;
  }

  /** بند المرجع المتبدل: وضع التحرير يفتح كيبورد المحرر، ووضع التنقل يخفيه. */
  private void toggleEditNavigateMode() {
    if (editor == null) return;
    if (editingToolbar) {
      View focused = getCurrentFocus();
      android.view.inputmethod.InputMethodManager imm =
          (android.view.inputmethod.InputMethodManager)
              getSystemService(INPUT_METHOD_SERVICE);
      if (imm != null && focused != null)
        imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
    } else if (!editor.beginEditingSession()) {
      openFilesBrowser();
    }
  }

  /** «قائمة الملفات المفتوحة» المرجعية: اختيار تبويب يفعّله مباشرة. */
  private void showOpenFilesDialog() {
    if (editor == null) return;
    final List<String> names = editor.openFileNames();
    if (names.isEmpty()) {
      Toast.makeText(this, ui("view_no_open_files"), Toast.LENGTH_SHORT).show();
      return;
    }
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_open_files_title"))
        .setItems(names.toArray(new String[0]), (d, w) -> editor.showOpenFile(names.get(w)))
        .setNegativeButton(ui("ui_action_close"), null)
        .show();
  }

  /** التوثيق: فتح وثائق أندرويد للرمز تحت المؤشر (أو الصفحة المرجعية عامة). */
  private void openDocumentation() {
    String symbol = editor == null ? "" : editor.documentationQuery();
    String url =
        symbol == null || symbol.isEmpty()
            ? "https://developer.android.com/reference"
            : "https://developer.android.com/s/results?q=" + android.net.Uri.encode(symbol);
    try {
      startActivity(
          new android.content.Intent(
              android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)));
    } catch (Exception noBrowser) {
      Toast.makeText(this, ui("ui_no_browser_for_docs"), Toast.LENGTH_SHORT).show();
    }
  }

  /** إغلاق المشروع كما في المرجع: إغلاق التبويبات ومسح الجلسة والعودة لمجلد المشاريع. */
  private void closeCurrentProject() {
    if (editor != null) editor.closeAll();
    if (session != null) session.clear();
    showNoProject();
    if (browser != null) browser.showProjectsHome();
    if (drawer != null) drawer.openDrawer(Gravity.START);
  }

  private void confirmExit() {
    new AlertDialog.Builder(this)
        .setTitle(R.string.menu_exit_title)
        .setMessage(R.string.menu_exit_message)
        .setNegativeButton(R.string.action_no, null)
        .setPositiveButton(R.string.action_yes, (dialog, which) -> finish())
        .show();
  }

  void showCommands() {
    final List<String> groups = commands.groups();
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_commands_title"))
        .setItems(groups.toArray(new String[0]), (d, w) -> showCommandGroup(groups.get(w)))
        .show();
  }

  void showCommandGroup(String group) {
    final List<CommandCenter.Command> list = commands.inGroup(group);
    String[] labels = new String[list.size()];
    for (int i = 0; i < list.size(); i++) {
      CommandCenter.Command c = list.get(i);
      labels[i] = (c.enabled(this) ? "" : "🔒  ") + c.titleFor(this);
    }
    new AlertDialog.Builder(this)
        .setTitle(group)
        .setItems(labels, (d, w) -> dispatch(list.get(w).id))
        .setNegativeButton(ui("ui_action_back"), (d, w) -> showCommands())
        .show();
  }

  /** المرحلة 3: اختصارات المفاتيح المخزّنة تسبق أي معالجة إدخال أخرى. */
  @Override
  public boolean dispatchKeyEvent(android.view.KeyEvent event) {
    if (event.getAction() == android.view.KeyEvent.ACTION_DOWN) {
      String command =
          almlk.Keybinds.commandFor(
              this,
              event.isCtrlPressed(),
              event.isAltPressed(),
              event.isShiftPressed(),
              event.getKeyCode());
      if (command != null) {
        dispatch(command);
        return true;
      }
    }
    return super.dispatchKeyEvent(event);
  }

  void dispatch(String id) {
    CommandCenter.Command c = commands.get(id);
    if (!commands.dispatch(id, this)) {
      String reason;
      if (c == null) reason = ui("ui_command_unknown");
      else if (c.needsProject && !hasProject()) reason = ui("ui_error_open_project_first");
      else if (c.needsEditor && !hasEditor()) reason = ui("ui_open_file_first");
      else if (("goto_definition".equals(id) || "goto_element".equals(id))
          && !hasExplicitEditorSelection())
        reason = ui("ui_error_symbol_selection_required");
      else if (!isEditorWritable()
          && ("format".equals(id) || "comment".equals(id) || "replace".equals(id)
              || "save".equals(id)))
        reason = ui("ui_file_read_only");
      else reason = ui("ui_command_unavailable");
      Toast.makeText(this, reason, Toast.LENGTH_SHORT).show();
    }
  }

  /** Opens a bounded, debounced project-symbol search without doing source I/O on the UI thread. */
  /** آخر استعلام GoTo — يُحفظ بين الفتحات ويُستعاد محددًا بالكامل كما في المرجع. */
  private static String lastGotoQuery = "";

  /** حد عرض نتائج GoTo كما في المرجع: فوق الحد تُعرض رسالة «اكتب المزيد» بدل القائمة. */
  private static final int GOTO_RESULT_LIMIT = 50;

  void promptGotoElement() {
    View view = getLayoutInflater().inflate(R.layout.gotobrowser, null);
    EditText queryBox = view.findViewById(R.id.gotobrowserSearchBox);
    Switch includeSystem = view.findViewById(R.id.gotobrowserSwitch);
    ListView resultList = view.findViewById(R.id.gotobrowserSymbolList);
    TextView message = view.findViewById(R.id.gotobrowserMessage);
    ProgressBar progress = view.findViewById(R.id.gotobrowserProgress);
    if (queryBox == null || resultList == null || message == null || progress == null) return;
    if (browser != null && editor != null && editor.hasOpenFile())
      browser.setActiveEditorSnapshot(
          editor.getActiveFile(), editor.getTextContent(), editor.activeFileReference());
    includeSystem.setTextOn(ui("ui_include_all_symbols"));
    includeSystem.setTextOff(ui("ui_include_project_symbols"));
    includeSystem.setChecked(false);
    final ArrayList<ProjectSymbolIndex.DefinitionTarget> targets = new ArrayList<>();
    // صف النتيجة كما في المرجع: أيقونة النوع + الاسم (مع «()» للدوال) + الحاوية كسطر ثانٍ.
    ArrayAdapter<ProjectSymbolIndex.DefinitionTarget> adapter =
        new ArrayAdapter<ProjectSymbolIndex.DefinitionTarget>(this, 0, targets) {
          @Override
          public View getView(int position, View convertView, android.view.ViewGroup parent) {
            View row = convertView != null
                ? convertView
                : getLayoutInflater().inflate(R.layout.gotobrowser_entry, parent, false);
            ProjectSymbolIndex.DefinitionTarget target =
                position < targets.size() ? targets.get(position) : null;
            android.widget.ImageView icon = row.findViewById(R.id.gotobrowserEntryImage);
            TextView name = row.findViewById(R.id.gotobrowserEntryName);
            TextView container = row.findViewById(R.id.gotobrowserEntryContainerName);
            View help = row.findViewById(R.id.gotobrowserHelpButton);
            if (help != null) help.setVisibility(View.GONE);
            if (target == null) return row;
            if (icon != null) icon.setImageResource(gotoEntryIcon(target));
            if (name != null)
              name.setText(
                  target.kind == ProjectSymbolIndex.DefinitionTarget.KIND_METHOD
                      ? target.symbol + "()"
                      : target.symbol);
            if (container != null) container.setText(resultLocation(target));
            return row;
          }
        };
    resultList.setAdapter(adapter);
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle(ui("ui_goto_element_title"))
            .setView(view)
            .setNegativeButton(ui("ui_action_close"), null)
            .create();
    final int[] generation = {0};
    final Runnable[] pending = {null};
    android.text.TextWatcher watcher = new android.text.TextWatcher() {
      @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
      @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
        final int request = ++generation[0];
        if (pending[0] != null) queryBox.removeCallbacks(pending[0]);
        targets.clear();
        adapter.notifyDataSetChanged();
        String text = s == null ? "" : s.toString().trim();
        message.setText(text.isEmpty() ? ui("ui_goto_element_prompt") : ui("ui_searching"));
        progress.setVisibility(text.isEmpty() ? View.GONE : View.VISIBLE);
        if (text.isEmpty()) return;
        final boolean showSystem = includeSystem.isChecked();
        pending[0] = () -> browser.searchSymbolsAsync(text, showSystem, (found, cancelled) -> {
          if (request != generation[0] || !dialog.isShowing()) return;
          progress.setVisibility(View.GONE);
          targets.clear();
          if (found != null && found.size() > GOTO_RESULT_LIMIT) {
            // سلوك المرجع عند تجاوز الحد: رسالة «أكثر من N مطابقة» بلا قائمة.
            message.setText(uiFormat("ui_goto_more_than_limit", GOTO_RESULT_LIMIT));
          } else {
            if (found != null) targets.addAll(found);
            message.setText(
                targets.isEmpty() ? ui("ui_no_matching_symbols") : ui("ui_choose_symbol_to_open"));
          }
          adapter.notifyDataSetChanged();
        });
        // Keep only a tiny frame budget: the search worker is cancellable and the in-memory
        // snapshot makes results appear while the user is still typing.
        queryBox.postDelayed(pending[0], 35);
      }
      @Override public void afterTextChanged(android.text.Editable s) {}
    };
    queryBox.addTextChangedListener(watcher);
    includeSystem.setOnCheckedChangeListener((button, checked) -> {
      if (queryBox.getText().length() > 0) queryBox.setText(queryBox.getText());
    });
    resultList.setOnItemClickListener((parent, row, position, id) -> {
      if (position < 0 || position >= targets.size()) return;
      ProjectSymbolIndex.DefinitionTarget target = targets.get(position);
      dialog.dismiss();
      openDefinition(target);
    });
    dialog.setOnDismissListener(d -> {
      // حفظ الاستعلام بين الفتحات — نفس حقل المرجع الساكن المحفوظ عند الإغلاق.
      lastGotoQuery = queryBox.getText() == null ? "" : queryBox.getText().toString();
      generation[0]++;
      if (pending[0] != null) queryBox.removeCallbacks(pending[0]);
      browser.cancelProjectSearch();
    });
    dialog.setOnShowListener(d -> {
      queryBox.requestFocus();
      dialog.getWindow().setSoftInputMode(
          android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    });
    // استعادة آخر استعلام + تحديد كامل + بحث فوري عند الفتح — كما يفعل المرجع في onCreate.
    if (!lastGotoQuery.isEmpty()) queryBox.setText(lastGotoQuery);
    queryBox.selectAll();
    dialog.show();
  }

  /** أيقونة صف GoTo حسب نوع الرمز — كتمييز المرجع بين كلاس/دالة/حقل. */
  private int gotoEntryIcon(ProjectSymbolIndex.DefinitionTarget target) {
    if (target == null) return R.drawable.completion_variable;
    switch (target.kind) {
      case ProjectSymbolIndex.DefinitionTarget.KIND_CLASS:
        return R.drawable.completion_class;
      case ProjectSymbolIndex.DefinitionTarget.KIND_METHOD:
        return R.drawable.completion_method;
      case ProjectSymbolIndex.DefinitionTarget.KIND_FIELD:
        return R.drawable.completion_variable;
      default:
        return target.symbol != null && target.symbol.equals(target.className)
            ? R.drawable.completion_class
            : R.drawable.completion_variable;
    }
  }

  /** السطر الثاني لصف GoTo: الحاوية (الكلاس) ثم الملف — كما يعرض المرجع اسم الحاوية. */
  private String resultLocation(ProjectSymbolIndex.DefinitionTarget target) {
    if (target == null) return "";
    String file = target.fileName == null ? "" : target.fileName;
    boolean ownClass = target.className == null
        || target.className.isEmpty()
        || target.className.equals(target.symbol);
    return ownClass ? file : target.className + " — " + file;
  }

  void showDesigner() {
    View v = getLayoutInflater().inflate(R.layout.designer, null);
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_designer_title"))
        .setView(v)
        .setNegativeButton(ui("ui_action_close"), null)
        .show();
  }

  void runProject() {
    runBuild("assembleDebug", ui("command_run"));
  }

  /** المرحلة 5: يتعلم نمط الإزاحة من المستند ويحفظه في CodeStyle. */
  void learnCodeStyle() {
    if (editor == null || !editor.hasOpenFile()) {
      Toast.makeText(this, ui("ui_open_file_first_short"), Toast.LENGTH_SHORT).show();
      return;
    }
    String text = editor.getTextContent();
    int size = almlk.CodeStyle.detectIndent(text);
    String file = editor.getActiveFile();
    String key = almlk.XmlCodeFormatter.isXmlName(file)
        ? almlk.CodeStyle.XML_INDENT_KEY
        : almlk.CodeStyle.JAVA_INDENT_KEY;
    almlk.CodeStyle.setIndentSize(this, key, size);
    Toast.makeText(this, uiFormat("ui_detected_indent_size", size), Toast.LENGTH_LONG).show();
  }

  // ===== المرحلة 1 (الإعدادات): حفظ تلقائي + سحب المتصفح =====
  private final android.os.Handler autosaveHandler =
      new android.os.Handler(android.os.Looper.getMainLooper());

  private void scheduleAutosave() {
    autosaveHandler.removeCallbacksAndMessages(null);
    int seconds = almlk.AppSettings.autosaveSeconds(this);
    if (seconds <= 0) return;
    autosaveHandler.postDelayed(this::autosaveTick, seconds * 1000L);
  }

  private void stopAutosave() {
    autosaveHandler.removeCallbacksAndMessages(null);
  }

  private void autosaveTick() {
    if (editor != null && browser != null && editor.hasOpenFile() && editor.hasPendingEdits()) {
      browser.saveOpenedFileAsync(
          editor.getActiveFile(),
          editor.getTextContent(),
          (saved, message) -> {
            if (saved && editor != null) {
              editor.markSaved();
              mirrorSync(editor.getActiveFile(), editor.getTextContent());
            }
            scheduleAutosave();
          });
    } else {
      scheduleAutosave();
    }
  }

  /** سحب أفقي يمينًا في المتصفح = صعود مستوى (يُحترم مفتاح browser_swipe). */
  private void attachBrowserSwipe() {
    if (browser == null) return;
    final android.view.GestureDetector detector =
        new android.view.GestureDetector(
            this,
            new android.view.GestureDetector.SimpleOnGestureListener() {
              @Override
              public boolean onFling(
                  android.view.MotionEvent e1,
                  android.view.MotionEvent e2,
                  float velocityX,
                  float velocityY) {
                if (!almlk.AppSettings.browserSwipe(MainActivity.this)) return false;
                if (e1 == null || e2 == null) return false;
                float dx = e2.getX() - e1.getX();
                if (dx <= 0 || Math.abs(dx) < 120 || Math.abs(velocityX) < 200) return false;
                java.io.File root = browser.projectRootFile();
                java.io.File parent = root == null ? null : root.getParentFile();
                if (parent != null && parent.canRead()) {
                  browser.openProjectRoot(parent.getAbsolutePath());
                  return true;
                }
                return false;
              }
            });
    browser.setOnTouchListener(
        (view, event) -> {
          detector.onTouchEvent(event);
          return false;
        });
  }

  private String selectedBuildVariant = "debug";

  /** متغيرات البناء كما في المرجع: اختيار debug/release يُحفظ ويوجّه البناء. */
  void promptBuildVariant() {
    final String[] variants = {"debug", "release"};
    new android.app.AlertDialog.Builder(this)
        .setTitle(ui("command_build_variants"))
        .setItems(variants, (d, which) -> {
          selectedBuildVariant = variants[which];
          Toast.makeText(this, uiFormat("ui_build_current_variant", selectedBuildVariant), Toast.LENGTH_SHORT)
              .show();
        })
        .show();
  }

  void runBuild(String task, String title) {
    File root = session == null ? null : session.directory();
    if (root == null || !root.isDirectory()) {
      showMessage(
          ui("ui_build_title"), ui("ui_build_local_path_required"));
      return;
    }
    File wrapper = new File(root, "gradlew");
    if (!wrapper.isFile()) {
      showMessage(ui("ui_build_title"), uiFormat("ui_gradle_wrapper_not_found", root.getAbsolutePath()));
      return;
    }
    buildDiagnostics.clear();
    publishProjectDiagnostics();
    showPanel(SequentialPanelHost.Panel.BUILD);
    final StringBuilder collectedBuildOutput = new StringBuilder(8192);
    if (sequentialPanels != null)
      sequentialPanels.setBuildOutput("$ sh gradlew " + task + " --no-daemon\n");
    View view = getLayoutInflater().inflate(R.layout.outputconsole, null);
    TextView output = view.findViewById(R.id.outputConsole);
    output.setTextColor(Color.LTGRAY);
    output.setTextSize(13);
    output.setPadding(dp(12), dp(10), dp(12), dp(10));
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton(ui("ui_action_stop"), null)
            .create();
    dialog.setOnShowListener(
        x -> {
          dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> shell.cancel());
          Map<String, String> env = buildEnv(root);
          shell.run(
              root,
              buildCommand(Arrays.asList("sh", "gradlew", task, "--no-daemon")),
              env,
              new ShellCommandRunner.Listener() {
                public void onStart(String c) {
                  collectedBuildOutput.setLength(0);
                  output.setText("$ " + c + "\n\n");
                }

                public void onLine(String line) {
                  if (line != null) collectedBuildOutput.append(line).append('\n');
                  output.append(line + "\n");
                  if (sequentialPanels != null) sequentialPanels.appendBuildOutput(line);
                }

                public void onFinish(int code, boolean cancelled) {
                  String summary = cancelled ? ui("ui_process_stopped") : uiFormat("ui_process_finished_code", code);
                  output.append("\n" + summary);
                  if (sequentialPanels != null) sequentialPanels.appendBuildOutput(summary);
                  if (!cancelled && browser != null) {
                    ArrayList<BuildDiagnosticsParser.BuildError> parsed =
                        BuildDiagnosticsParser.parse(collectedBuildOutput.toString());
                    if (!parsed.isEmpty())
                      browser.resolveBuildDiagnosticsAsync(
                          parsed,
                          found -> {
                            buildDiagnostics.clear();
                            if (found != null) buildDiagnostics.addAll(found);
                            publishProjectDiagnostics();
                            if (!buildDiagnostics.isEmpty()) showPanel(SequentialPanelHost.Panel.ERRORS);
                          });
                  }
                  dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setText(ui("ui_action_close"));
                  dialog
                      .getButton(AlertDialog.BUTTON_NEGATIVE)
                      .setOnClickListener(v -> dialog.dismiss());
                }
              });
        });
    dialog.setOnDismissListener(x -> shell.cancel());
    dialog.show();
  }

  /** المرحلة 2: بيئة البناء تحمل مفاتيح Build & Run المختارة (قناة SHIMA_* القائمة). */
  private Map<String, String> buildEnv(File root) {
    Map<String, String> env = new HashMap<>();
    env.put("SHIMA_CURRENT_PROJECT", root.getAbsolutePath());
    android.content.SharedPreferences sp = almlk.AppSettings.prefs(this);
    String jar = sp.getString("user_androidjar", "");
    if (!jar.isEmpty()) env.put("SHIMA_ANDROID_JAR", jar);
    String m2 = sp.getString("user_m2repositories", "");
    if (!m2.isEmpty()) env.put("SHIMA_M2_REPOSITORIES", m2);
    if (sp.getBoolean("optimze_dex", false)) env.put("SHIMA_OPTIMIZE_DEX", "1");
    if (sp.getBoolean("use_proguard", false)) env.put("SHIMA_USE_PROGUARD", "1");
    if (sp.getBoolean("native_build_parallel", false)) env.put("SHIMA_NATIVE_PARALLEL", "1");
    if (sp.getBoolean("ndk_support_installed", false)) env.put("SHIMA_NDK_SUPPORT", "1");
    if (sp.getBoolean("use_user_keystore", false)) {
      String keystore = sp.getString("user_keystore", "");
      if (!keystore.isEmpty()) env.put("SHIMA_KEYSTORE", keystore);
    }
    String sshDir = sp.getString("git_dot_ssh_dir", "");
    if (!sshDir.isEmpty()) env.put("SHIMA_GIT_SSH_DIR", sshDir);
    if (sp.getBoolean("git_keep_ssh_session_info", false)) env.put("SHIMA_GIT_KEEP_SSH", "1");
    return env;
  }

  /** المرحلة 3: مرآة محلية للمزامنة التلقائية (auto_sync_dropbox) بلا خادم خارجي. */
  private void mirrorSync(String name, String content) {
    if (name == null || content == null) return;
    if (!almlk.AppSettings.prefs(this).getBoolean("auto_sync_dropbox", true)) return;
    try {
      java.io.File dir = new java.io.File(getFilesDir(), "dropbox_mirror");
      dir.mkdirs();
      java.io.File target = new java.io.File(dir, new java.io.File(name).getName());
      java.io.FileOutputStream out = new java.io.FileOutputStream(target);
      out.write(content.getBytes("UTF-8"));
      out.close();
    } catch (Exception ignored) {
      // المرآة تحسين لا شرط؛ فشلها لا يُسقط الحفظ.
    }
  }

  /** المرحلة 3: إنشاء مستودع git عند الفتح وفق git_create_for_projects مع الهوية المحفوظة. */
  private void maybeInitGitRepo() {
    android.content.SharedPreferences sp = almlk.AppSettings.prefs(this);
    if (!sp.getBoolean("git_create_for_projects", false)) return;
    final java.io.File root = session == null ? null : session.directory();
    if (root == null || new java.io.File(root, ".git").exists()) return;
    String userName = sp.getString("git_user_name", "Shima");
    String userEmail = sp.getString("git_user_email", "shima@local");
    String script =
        "git init && git config user.name \"" + userName + "\" && git config user.email \""
            + userEmail + "\"";
    shell.run(
        root,
        java.util.Arrays.asList("sh", "-c", script),
        new java.util.HashMap<>(),
        new ShellCommandRunner.Listener() {
          public void onStart(String c) {}

          public void onLine(String line) {}

          public void onFinish(int code, boolean cancelled) {
            runOnUiThread(
                () -> android.widget.Toast.makeText(
                        MainActivity.this,
                        code == 0 ? ui("ui_git_repository_created") : ui("ui_git_repository_create_failed"),
                        android.widget.Toast.LENGTH_SHORT)
                    .show());
          }
        });
  }

  /** run_as_root: لفّ الأمر بـ su عند تفعيل المفتاح. */
  private java.util.List<String> buildCommand(java.util.List<String> cmd) {
    if (!almlk.AppSettings.prefs(this).getBoolean("run_as_root", false)) return cmd;
    StringBuilder joined = new StringBuilder();
    for (String part : cmd) {
      if (joined.length() > 0) joined.append(' ');
      joined.append(part);
    }
    return Arrays.asList("su", "-c", joined.toString());
  }

  void runShell(String command, String title) {
    File root = session == null ? null : session.directory();
    if (root == null) {
      showMessage(title, ui("ui_shell_needs_local_project"));
      return;
    }
    View view = getLayoutInflater().inflate(R.layout.outputconsole, null);
    TextView output = view.findViewById(R.id.outputConsole);
    output.setTextColor(Color.LTGRAY);
    output.setTextSize(13);
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton(ui("ui_action_stop"), null)
            .create();
    dialog.setOnShowListener(
        x -> {
          dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> shell.cancel());
          Map<String, String> env = buildEnv(root);
          shell.run(
              root,
              buildCommand(Arrays.asList("sh", "-c", command)),
              env,
              new ShellCommandRunner.Listener() {
                public void onStart(String c) {
                  output.setText("$ " + command + "\n\n");
                }

                public void onLine(String line) {
                  output.append(line + "\n");
                }

                public void onFinish(int code, boolean stopped) {
                  output.append(stopped ? "\n" + ui("ui_process_stopped_short") : "\n" + uiFormat("ui_exit_code", code));
                  dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setText(ui("ui_action_close"));
                  dialog
                      .getButton(AlertDialog.BUTTON_NEGATIVE)
                      .setOnClickListener(v -> dialog.dismiss());
                }
              });
        });
    dialog.setOnDismissListener(x -> shell.cancel());
    dialog.show();
  }

  void promptTerminal() {
    final EditText input = new EditText(this);
    input.setHint(uiFormat("ui_terminal_example_hint", "./gradlew tasks"));
    input.setSingleLine(true);
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_terminal_title"))
        .setView(input)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("ui_terminal_run"),
            (d, w) -> {
              String c = input.getText().toString().trim();
              if (!c.isEmpty()) runShell(c, ui("ui_terminal_title"));
            })
        .show();
  }

  void promptCommit() {
    final EditText input = new EditText(this);
    input.setHint(ui("ui_commit_message_hint"));
    input.setSingleLine(true);
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_git_commit_title"))
        .setView(input)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("ui_action_commit"),
            (d, w) -> {
              String m = input.getText().toString().trim();
              if (!m.isEmpty()) runShell("git commit -m " + shellQuote(m), "Git");
            })
        .show();
  }

  String shellQuote(String value) {
    return "'" + value.replace("'", "'\\''") + "'";
  }

  void showMessage(String title, String text) {
    new AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(text)
        .setPositiveButton(ui("ui_action_ok"), null)
        .show();
  }

  @Override
  public boolean hasProject() {
    return projectOpen && session != null && session.isOpen();
  }

  @Override
  public boolean hasEditor() {
    return editor != null && editor.hasOpenFile();
  }

  @Override
  public boolean hasExplicitEditorSelection() {
    return hasEditor() && editor.hasExplicitEditorSelection();
  }

  @Override
  public boolean canUndo() {
    return hasEditor() && editor.canUndoEdit();
  }

  @Override
  public boolean canRedo() {
    return hasEditor() && editor.canRedoEdit();
  }

  @Override
  public boolean isXmlEditor() {
    if (!hasEditor()) return false;
    return almlk.XmlCodeFormatter.isXmlName(editor.getActiveFile());
  }

  @Override
  public boolean isEditorWritable() {
    return hasEditor() && editor.isActiveFileWritableNow();
  }

  @Override
  public boolean isLayoutXmlEditor() {
    return activeLayoutXml();
  }

  @Override
  public boolean panelsShowing() {
    return drawer != null && drawer.isDrawerOpen(Gravity.START);
  }

  @Override
  public void execute(String id) {
    switch (id) {
      case "run":
      case "build_debug":
        runBuild("assembleDebug", ui(id.equals("run") ? "command_run" : "menu_build_debug"));
        break;
      case "build_release":
        runBuild("assembleRelease", ui("menu_build_release"));
        break;
      case "clean":
        runBuild("clean", ui("menu_clean"));
        break;
      case "terminal":
        promptTerminal();
        break;
      case "save":
        browser.saveOpenedFileAsync(
            editor.getActiveFile(),
            editor.getTextContent(),
            (saved, message) -> {
              if (saved) {
                editor.markSaved();
                mirrorSync(editor.getActiveFile(), editor.getTextContent());
              }
              Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            });
        break;
      case "undo":
        editor.undoEdit();
        break;
      case "redo":
        editor.redoEdit();
        break;
      case "find":
        promptFind();
        break;
      case "replace":
        promptReplace();
        break;
      case "goto_line":
        promptGotoLine();
        break;
      case "goto_element":
      case "goto_definition":
        // يلزم تحديد صريح: التعريف يفتح استخدامات الدالة/الحقل، والمرجع يقفز إلى تعريفه.
        editor.requestDefinitionForCurrentSelection();
        break;
      case "format":
        editor.formatSource();
        Toast.makeText(this, ui("ui_format_source_complete"), Toast.LENGTH_SHORT).show();
        break;
      case "comment":
        editor.toggleLineComment();
        break;
      case "select_all":
        editor.selectAllText();
        break;
      case "analyze":
        showDiagnostics();
        break;
      case "complete":
        showCompletions();
        break;
      case "find_usages":
        editor.requestUsageForCurrentSelection();
        break;
      case "design":
        openDesigner();
        break;
      case "panels":
        // سلوك المرجع: عنصر اللوحات يتبدّل بين الإظهار والإخفاء حسب الحالة الراهنة.
        if (panelsShowing()) closeSequentialPanels();
        else showPanel(SequentialPanelHost.Panel.ERRORS);
        break;
      case "show_errors":
        showPanel(SequentialPanelHost.Panel.ERRORS);
        break;
      case "goto_next_error":
        gotoAdjacentError(true);
        break;
      case "goto_previous_error":
        gotoAdjacentError(false);
        break;
      case "show_search_results":
        showPanel(SequentialPanelHost.Panel.SEARCH);
        break;
      case "show_build_output":
        showPanel(SequentialPanelHost.Panel.BUILD);
        break;
      case "show_debugger":
        showPanel(SequentialPanelHost.Panel.DEBUGGER);
        break;
      case "show_logcat":
        showPanel(SequentialPanelHost.Panel.LOGCAT);
        break;
      case "close_file":
        editor.closeCurrent();
        if (!editor.hasOpenFile()) {
          empty.setVisibility(View.VISIBLE);
          editor.setVisibility(View.GONE);
          if (masterButton != null) masterButton.setVisibility(View.GONE);
        }
        break;
      case "close_all":
        editor.closeAll();
        empty.setVisibility(View.VISIBLE);
        editor.setVisibility(View.GONE);
        if (masterButton != null) masterButton.setVisibility(View.GONE);
        break;
      case "files":
        openFilesBrowser();
        break;
      case "new_file":
        openFilesBrowser();
        browser.createFile();
        break;
      case "new_folder":
        openFilesBrowser();
        browser.createFolder();
        break;
      case "refresh":
        browser.refresh();
        break;
      case "git_status":
        runShell("git status --short --branch", ui("ui_command_git_status"));
        break;
      case "git_log":
        runShell("git log --oneline -n 20", ui("ui_command_git_log"));
        break;
      case "git_add":
        runShell("git add -A && git status --short", ui("ui_command_git_add"));
        break;
      case "git_commit":
        promptCommit();
        break;
      case "git_pull":
        runShell("git pull --ff-only", ui("command_git_pull"));
        break;
      case "git_push":
        runShell("git push", ui("command_git_push"));
        break;
      case "theme":
        startActivityForResult(new android.content.Intent(this, ThemeActivity.class), 88);
        break;
      case "permissions":
        showPermissionsCenter();
        break;
      case "documentation":
        openDocumentation();
        break;
      case "settings":
        startActivity(new Intent(this, com.almlkid.ui.preferences.AlmlkPreferencesActivity.class));
        break;
      case "exit":
        confirmExit();
        break;
      case "close_project":
        closeCurrentProject();
        break;
      case "publish_project":
        runBuild("assembleRelease", ui("command_publish_project"));
        break;
      case "select_build_variant":
        promptBuildVariant();
        break;
      case "forward":
        Toast.makeText(this, ui("ui_forward_history_empty"), Toast.LENGTH_SHORT).show();
        break;
      case "rename":
        editor.renameCurrentSelection();
        break;
      case "inline":
        editor.refactorInline();
        break;
      case "introduce":
        editor.refactorIntroduce();
        break;
      case "extract_method":
        editor.refactorExtract();
        break;
      case "create_setters":
        editor.codegenSetters();
        break;
      case "create_constructor":
        editor.codegenConstructor();
        break;
      case "extract_resources":
        editor.codegenExtractResource();
        break;
      case "organize_imports":
        editor.organizeImports();
        break;
      case "surround_try":
        editor.surroundWithTryCatch();
        break;
      case "learn_style":
        learnCodeStyle();
        break;
      case "configure_style":
        startActivity(new Intent(this, CodeStyleActivity.class));
        break;
      case "about":
        showMessage(
            ui("ui_about_title"), ui("ui_about_message"));
        break;
    }
  }

  void showDiagnostics() {
    showSequentialPanels(SequentialPanelHost.Panel.ERRORS);
    if (editor != null) editor.refreshSemanticDiagnostics();
    if (sequentialPanels != null) sequentialPanels.setProjectDiagnostics(displayedDiagnostics);
  }

  void showCompletions() {
    // المراحل 1-4: نفس النافذة الحية المنمطة (أيقونات+توقيع) مع الالتزام الذكي والاستيراد.
    editor.showCompletionPopup();
  }

  void promptFind() {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    final EditText input = new EditText(this);
    input.setHint(ui("ui_find_text_hint"));
    input.setSingleLine(true);
    final CheckBox project = new CheckBox(this);
    final CheckBox caseSensitive = new CheckBox(this);
    final CheckBox wholeWord = new CheckBox(this);
    final CheckBox regex = new CheckBox(this);
    project.setText(ui("ui_search_project_checkbox"));
    caseSensitive.setText(ui("ui_match_case_checkbox"));
    wholeWord.setText(ui("ui_whole_word_checkbox"));
    regex.setText(ui("ui_regex_checkbox"));
    box.addView(input);
    box.addView(project);
    box.addView(caseSensitive);
    box.addView(wholeWord);
    box.addView(regex);
    regex.setOnCheckedChangeListener((button, checked) -> {
      wholeWord.setEnabled(!checked);
      if (checked) wholeWord.setChecked(false);
    });
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_find_title"))
        .setMessage(ui("ui_find_description"))
        .setView(box)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("ui_action_search"),
            (d, w) -> {
              String text = input.getText().toString().trim();
              if (text.isEmpty()) {
                Toast.makeText(this, ui("ui_enter_search_text"), Toast.LENGTH_SHORT).show();
                return;
              }
              ProjectSearchEngine.Query query =
                  new ProjectSearchEngine.Query(
                      text,
                      caseSensitive.isChecked(),
                      wholeWord.isChecked(),
                      regex.isChecked(),
                      ProjectSearchEngine.DEFAULT_MAX_RESULTS);
              if (project.isChecked()) {
                showSequentialPanels(SequentialPanelHost.Panel.SEARCH);
                sequentialPanels.setSearchStatus(ui("ui_searching_project_files"));
                sequentialPanels.setSearchResults(Collections.emptyList(), text);
                browser.searchProjectAsync(
                    query,
                    (results, filesScanned, cancelled) -> {
                      if (sequentialPanels == null) return;
                      sequentialPanels.setSearchResults(results, text);
                      sequentialPanels.setSearchStatus(
                          cancelled
                              ? uiFormat("ui_search_cancelled_count", filesScanned)
                              : uiFormat("ui_search_completed_count", filesScanned, results.size()));
                    });
              } else {
                boolean found = editor.findText(
                    text,
                    caseSensitive.isChecked(),
                    wholeWord.isChecked(),
                    regex.isChecked(),
                    true);
                Toast.makeText(
                        this,
                        ui(found ? "ui_next_match" : "ui_text_not_found"),
                        Toast.LENGTH_SHORT)
                    .show();
              }
            })
        .show();
  }

  void promptReplace() {
    promptReplace("");
  }

  void promptReplace(String initialQuery) {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    final EditText from = new EditText(this), to = new EditText(this);
    from.setHint(ui("ui_find_replace_from_hint"));
    from.setText(initialQuery == null ? "" : initialQuery);
    if (from.length() > 0) from.setSelection(from.length());
    to.setHint(ui("ui_find_replace_to_hint"));
    final CheckBox caseSensitive = new CheckBox(this);
    final CheckBox wholeWord = new CheckBox(this);
    final CheckBox regex = new CheckBox(this);
    caseSensitive.setText(ui("ui_match_case_checkbox"));
    wholeWord.setText(ui("ui_whole_word_checkbox"));
    regex.setText(ui("ui_regex_checkbox"));
    regex.setOnCheckedChangeListener((button, checked) -> {
      wholeWord.setEnabled(!checked);
      if (checked) wholeWord.setChecked(false);
    });
    box.addView(from);
    box.addView(to);
    box.addView(caseSensitive);
    box.addView(wholeWord);
    box.addView(regex);
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_find_replace_title"))
        .setView(box)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("ui_action_replace_all"),
            (d, w) -> editor.replaceAllAsync(
                from.getText().toString(),
                to.getText().toString(),
                caseSensitive.isChecked(),
                wholeWord.isChecked(),
                regex.isChecked(),
                count -> Toast.makeText(
                    this, uiFormat("ui_replace_count", count), Toast.LENGTH_SHORT).show()))
        .show();
  }

  void promptGotoLine() {
    final EditText input = new EditText(this);
    input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
    input.setHint(ui("ui_line_number_hint"));
    new AlertDialog.Builder(this)
        .setTitle(ui("ui_go_to_line_title"))
        .setView(input)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(
            ui("command_goto_line"),
            (d, w) -> {
              try {
                if (!editor.goToLine(Integer.parseInt(input.getText().toString())))
                  Toast.makeText(this, ui("ui_line_out_of_range"), Toast.LENGTH_SHORT).show();
              } catch (Exception e) {
                Toast.makeText(this, ui("ui_enter_valid_number"), Toast.LENGTH_SHORT).show();
              }
            })
        .show();
  }

  /** ملف التبويب النشط تخطيط XML (داخل res/layout*) — شرط ظهور زر معاينة التصميم. */
  boolean activeLayoutXml() {
    if (editor == null || !projectOpen) return false;
    // اسم التبويب قصير — الموقع الحقيقي في المرجع المستقر (مسار كامل أو SAF URI مرمّز).
    String candidate = editor.getActiveFileReference();
    if (candidate == null || candidate.isEmpty()) candidate = editor.getActiveFile();
    if (candidate == null) return false;
    if (candidate.startsWith("content:")) candidate = android.net.Uri.decode(candidate);
    String normalized = candidate.replace('\\', '/').toLowerCase(java.util.Locale.US);
    if (!normalized.endsWith(".xml")) return false;
    int slash = normalized.lastIndexOf('/');
    if (slash <= 0) return false;
    int parentSlash = normalized.lastIndexOf('/', slash - 1);
    String parent = normalized.substring(parentSlash + 1, slash);
    return "layout".equals(parent) || parent.startsWith("layout-");
  }

  /** فتح المصمم على النص الحي للتبويب النشط — المعاينة تعكس آخر ما كتبته ولو غير محفوظ. */
  void openDesigner() {
    if (editor == null || !activeLayoutXml()) return;
    if (!editor.isActiveFileWritableNow()) {
      Toast.makeText(this, ui("ui_file_read_only"), Toast.LENGTH_SHORT).show();
      return;
    }
    android.content.Intent intent = new android.content.Intent(this, DesignerActivity.class);
    intent.putExtra("xml", editor.getTextContent());
    String reference = editor.getActiveFileReference();
    intent.putExtra("file", reference.isEmpty() ? editor.getActiveFile() : reference);
    startActivityForResult(intent, 7801);
  }


  /** إعادة بناء الشريط فقط عند انقلاب أهلية التراجع/الإعادة فعلًا — لا عمل زائدًا بكل حرف. */
  void refreshEditingToolbarState() {
    if (editor == null) return;
    if (!editingToolbar) {
      // خارج وضع الكتابة: تبديل التبويب قد يبدّل زر القلم/معاينة التصميم.
      invalidateOptionsMenu();
      return;
    }
    boolean canUndo = editor.canUndoEdit();
    boolean canRedo = editor.canRedoEdit();
    if (canUndo != lastCanUndo || canRedo != lastCanRedo) invalidateOptionsMenu();
  }

  void hideMasterButtonWithKeyboard(final View masterButton) {
    final View root = getWindow().getDecorView();
    final int[] largestVisibleHeight = {0};
    root.getViewTreeObserver()
        .addOnGlobalLayoutListener(
            () -> {
              android.graphics.Rect frame = new android.graphics.Rect();
              root.getWindowVisibleDisplayFrame(frame);
              int currentHeight = frame.height();
              if (currentHeight > largestVisibleHeight[0]) largestVisibleHeight[0] = currentHeight;
              int difference = largestVisibleHeight[0] - currentHeight;
              boolean keyboardShown = difference > Math.max(dp(170), largestVisibleHeight[0] / 6);
              boolean editorActive =
                  editor != null && editor.hasOpenFile() && editor.getVisibility() == View.VISIBLE;
              int expected = keyboardShown || !editorActive ? View.GONE : View.VISIBLE;
              if (masterButton.getVisibility() != expected) masterButton.setVisibility(expected);
              // شريط وضع التحرير (دلالة المرجع): يتبدل مع ظهور كيبورد المحرر وإخفائه.
              boolean editingNow = keyboardShown && editorActive;
              if (editingNow != editingToolbar) {
                editingToolbar = editingNow;
                invalidateOptionsMenu();
              }
            });
  }

  void showStartupError(Throwable error) {
    ActionBar bar = getActionBar();
    if (bar != null) bar.hide();
    LinearLayout page = new LinearLayout(this);
    page.setOrientation(LinearLayout.VERTICAL);
    page.setPadding(dp(20), dp(24), dp(20), dp(16));
    page.setBackgroundColor(Color.rgb(25, 25, 25));
    TextView title = new TextView(this);
    title.setText(ui("ui_safe_startup_error_title"));
    title.setTextColor(Color.WHITE);
    title.setTextSize(22);
    page.addView(title);
    TextView message = new TextView(this);
    message.setText(
        ui("ui_safe_startup_error_body"));
    message.setTextColor(Color.LTGRAY);
    message.setPadding(0, dp(10), 0, dp(12));
    page.addView(message);
    TextView log = new TextView(this);
    log.setText(CrashStore.read(this));
    log.setTextColor(Color.rgb(255, 180, 180));
    log.setTextSize(11);
    log.setTypeface(android.graphics.Typeface.MONOSPACE);
    log.setTextIsSelectable(true);
    ScrollView scroll = new ScrollView(this);
    scroll.addView(log);
    page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    Button safe = new Button(this);
    safe.setText(ui("ui_open_safe_mode"));
    safe.setOnClickListener(v -> showSafeMode());
    page.addView(safe);
    Button retry = new Button(this);
    retry.setText(ui("ui_retry"));
    retry.setOnClickListener(v -> recreate());
    page.addView(retry);
    setContentView(page);
  }

  void showSafeMode() {
    ActionBar bar = getActionBar();
    if (bar != null) bar.hide();
    LinearLayout page = new LinearLayout(this);
    page.setOrientation(LinearLayout.VERTICAL);
    page.setGravity(Gravity.CENTER_HORIZONTAL);
    page.setPadding(dp(24), dp(42), dp(24), dp(20));
    page.setBackgroundColor(Color.rgb(25, 25, 25));
    ImageView logo = new ImageView(this);
    logo.setImageResource(R.drawable.ic_launcher);
    page.addView(logo, new LinearLayout.LayoutParams(dp(80), dp(80)));
    TextView title = new TextView(this);
    title.setText(ui("ui_safe_mode_title"));
    title.setTextColor(Color.WHITE);
    title.setTextSize(22);
    title.setGravity(Gravity.CENTER);
    title.setPadding(0, dp(18), 0, dp(8));
    page.addView(title);
    TextView note = new TextView(this);
    note.setText(
        ui("ui_safe_mode_body"));
    note.setTextColor(Color.LTGRAY);
    note.setTextSize(15);
    note.setGravity(Gravity.CENTER);
    page.addView(note, new LinearLayout.LayoutParams(-1, 0, 1));
    Button retry = new Button(this);
    retry.setText(ui("ui_open_full_interface"));
    retry.setOnClickListener(
        v -> {
          getIntent().removeExtra("safe_mode");
          recreate();
        });
    page.addView(retry, new LinearLayout.LayoutParams(-1, dp(52)));
    Button report = new Button(this);
    report.setText(ui("ui_show_last_error"));
    report.setOnClickListener(
        v -> startActivity(new android.content.Intent(this, RecoveryActivity.class)));
    page.addView(report, new LinearLayout.LayoutParams(-1, dp(52)));
    setContentView(page);
  }

  private String ui(String key) {
    return UiStrings.get(this, key);
  }

  private String uiFormat(String key, Object... values) {
    return UiStrings.format(this, key, values);
  }

  int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }

  @Override
  public void onBackPressed() {
    if (drawer != null && drawer.isDrawerOpen(Gravity.START)) {
      drawer.closeDrawers();
      return;
    }
    // الانتقال لعنصر ثم «عودة» يعيد للكلاس/الموضع السابق عبر سجل التنقل.
    if (editor != null && editor.navigateBack()) return;
    // مع مشروع مفتوح: «عودة» تعرض قائمة الملفات/الكلاسات ولا تُخرج المشروع لشاشة الفراغ.
    if (projectOpen) {
      if (drawer != null) drawer.openDrawer(Gravity.START);
      return;
    }
    super.onBackPressed();
  }
}
