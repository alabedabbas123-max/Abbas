# مراجع دراسة البنية والميزات

هذه الروابط محفوظة كمرجع دائم عند ضبط أي ميزة جديدة في مشروع Shima:

## مرجع Java/بنية التطبيق القديم

- صفحة الملف:
  https://github.com/alabedabbas123-max/shima/blob/main/kay_id.zip
- الرابط الخام:
  https://github.com/alabedabbas123-max/shima/raw/refs/heads/main/kay_id.zip

## مرجع ملفات DEX القديمة

- صفحة الملف:
  https://github.com/alabedabbas123-max/shima/blob/main/dex.zip
- الرابط الخام:
  https://github.com/alabedabbas123-max/shima/raw/refs/heads/main/dex.zip

## مستودع GitHub

- https://github.com/alabedabbas123-max/shima

## مواصفات محرر Almlk_AR

- https://github.com/alabedabbas123-max/kingid/blob/main/Almlk_AR.md
- https://github.com/alabedabbas123-max/kingid/raw/refs/heads/main/Almlk_AR.md

يستخدم هذا المستند كمواصفات سلوكية ومعمارية فقط؛ لا يتم نسخ كود أو bytecode منه.

## منهج الاستخدام

- الرجوع إلى الملفات القديمة لفهم سلوك الميزة، تقسيم المسؤوليات، وتسلسل الاتصال بين المحرر والفهرسة والواجهات والـ runtime.
- بناء التنفيذ داخل Shima من Java واضحة ومقروءة ومقسمة إلى وحدات صغيرة مترابطة، دون نسخ DEX أو bytecode خارجي.
- استخدام DEX الناتج من كود Shima الحديث عبر AGP/D8، مع إبقاء التوافق مع الإصدارات القديمة المطلوبة ودعم API 37.
- تحسين الأداء باستخدام الفهرسة المسبقة، cache، lazy loading، workers، وإلغاء المهام القديمة لمنع ANR وفقدان الحالة.
- عند طلب أي ميزة جديدة، تتم مراجعة المرجع القديم أولاً ثم تنفيذ نسخة حديثة مستقلة بنفس السلوك المقصود وبأسماء وكود قابلين للصيانة.
- لا يتم تعطيل أو إزالة آليات حماية أو ترخيص أو تشفير لطرف ثالث؛ أي تعديل أمني يقتصر على كود Shima المملوك والمصرح به.
