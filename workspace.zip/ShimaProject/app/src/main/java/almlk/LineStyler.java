package almlk;

import com.almlkid.kay.ui.CodeLanguageTools;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * بند almlk ← الملوّن التزايدي «C0032va» بروحه الحرفية:
 *
 * <ul>
 *   <li>حالة معجمية لكل سطر (LINE_END_STATE): عادي / داخل تعليق كتلي — تعيد الإعراب من أول
 *       سطر متّسخ فقط وتتوقف عند أول سطر لم تتغير حالته (تقارب مبكر).
 *   <li>يعمل على خيط خلفي واحد بعيدًا عن الواجهة؛ أول تنفيذ يكسو الشاشة فورًا دون انتظار أي
 *       معالجة أخرى (الملفات الضخمة تُلوَّن نافذةً نافذةً بصمت).
 *   <li>إلغاء المهام الباهتة: أي تغيّر جديد يلغي الجولة السابقة (جيل متقدّم).
 *   <li>أنماط الإخراج تعيد استعمال ثوابت {@link CodeLanguageTools} — نفس لوحة ألوان التطبيق.
 * </ul>
 */
public final class LineStyler {

  /** يُستدعى على خيط الواجهة بعد كل جولة لإعادة رسم النطاق المتأثر. */
  public interface StylesListener {
    void onStylesUpdated(int fromLine, int toLine);
  }

  private static final int MODE_PLAIN = 0;
  private static final int MODE_JAVA = 1;
  private static final int MODE_XML = 2;
  private static final int MODE_SMALI = 3;

  private static final int STATE_NORMAL = 0;
  private static final int STATE_BLOCK_COMMENT = 1; // /* ... */ أو <!-- ... -->

  private final LineDocument document;
  private final ExecutorService worker = Executors.newSingleThreadExecutor();
  private StylesListener listener;

  private volatile int[][] stylesByLine = new int[0][];
  private int[] endStates = new int[0];
  private int generation;
  private Future<?> running;
  private int mode = MODE_PLAIN;
  private String fileName = "";
  private boolean paused;

  public LineStyler(LineDocument document) {
    this.document = document;
    document.addChangeListener((from, to) -> request(from, to));
  }

  public void setListener(StylesListener listener) {
    this.listener = listener;
  }

  public void setPaused(boolean paused) {
    this.paused = paused;
  }

  /** تغيّر الملف/المحتوى كاملًا: تصفير كامل وجولة جديدة. */
  public void setFileName(String name) {
    fileName = name == null ? "" : name;
    String lower = fileName.toLowerCase(java.util.Locale.US);
    if (lower.endsWith(".java") || lower.endsWith(".kt") || lower.endsWith(".c")
        || lower.endsWith(".cpp") || lower.endsWith(".h") || lower.endsWith(".cs")) {
      mode = MODE_JAVA;
    } else if (lower.endsWith(".xml") || lower.endsWith(".html") || lower.endsWith(".htm")) {
      mode = MODE_XML;
    } else if (lower.endsWith(".smali")) {
      mode = MODE_SMALI;
    } else {
      mode = MODE_PLAIN;
    }
    synchronized (this) {
      stylesByLine = new int[Math.max(0, document.lineCount())][];
      endStates = new int[Math.max(0, document.lineCount())];
      for (int i = 0; i < endStates.length; i++) endStates[i] = -1; // يجبر إكساء كل سطر
    }
    request(0, Integer.MAX_VALUE);
  }

  /** طلب إكساء من سطر إلى سطر (تغيّر تزايدي أو تحديث شامل). */
  public void request(int fromLine, int toLine) {
    if (paused) return;
    final int generationAtRequest;
    synchronized (this) {
      generationAtRequest = ++generation;
      if (running != null) running.cancel(false);
    }
    final int from = Math.max(0, fromLine);
    running =
        worker.submit(
            () -> runStylingPass(generationAtRequest, from, toLine));
  }

  /** جولة واحدة: من السطر الأول المتّسخ حتى التقارب. */
  private void runStylingPass(int generationAtRun, int from, int to) {
    int lineCount = document.lineCount();
    if (lineCount == 0) return;
    synchronized (this) {
      if (stylesByLine.length < lineCount) {
        int[][] bigger = new int[lineCount][];
        System.arraycopy(stylesByLine, 0, bigger, 0, stylesByLine.length);
        stylesByLine = bigger;
        int[] biggerState = new int[lineCount];
        System.arraycopy(endStates, 0, biggerState, 0, endStates.length);
        for (int i = endStates.length; i < lineCount; i++) biggerState[i] = -1;
        endStates = biggerState;
      }
    }
    ensureCapacity(lineCount);
    int firstLine = Math.min(from, lineCount - 1);
    int lastTouched = firstLine;
    // حالة الدخول عند أول سطر = حالة نهاية السطر السابق.
    int state = firstLine > 0 && endStates[firstLine - 1] >= 0
        ? endStates[firstLine - 1]
        : STATE_NORMAL;
    for (int line = firstLine; line < lineCount; line++) {
      if (generationAtRun != generation || paused) return; // مهمة باهتة — تُلغى فورًا.
      if (line > to && endStates[line] == state && stylesByLine[line] != null) {
        break; // تقارب مبكر: سطر تجاوز المتّسخ وحالته لم تتغير — بقية المستند صالحة.
      }
      char[] chars;
      synchronized (document) {
        chars = document.lineChars(line);
      }
      int[] styles = lexLine(chars, state);
      stylesByLine[line] = styles;
      state = lexLineEndState;
      endStates[line] = lexLineEndState;
      lastTouched = line;
      // دفعات 512 سطرًا: الألوان تظهر على الشاشة تدريجيًا أثناء جولة الملفات الضخمة
      // (نفس إحساس نافذة المرجع — لا انتظار اكتمال المستند كله).
      if (line - firstLine > 0 && (line - firstLine) % 512 == 0) {
        postStylesUpdated(generationAtRun, firstLine + lastBatchOffset, line);
        lastBatchOffset = line - firstLine;
      }
    }
    postStylesUpdated(generationAtRun, firstLine + lastBatchOffset, lastTouched);
    lastBatchOffset = 0;
  }

  private int lastBatchOffset;

  private void postStylesUpdated(int generationAtRun, int from, int to) {
    if (to < from) return;
    new android.os.Handler(android.os.Looper.getMainLooper())
        .post(
            () -> {
              StylesListener target = listener;
              if (target != null && generationAtRun == generation)
                target.onStylesUpdated(from, to);
            });
  }

  private int lexLineEndState = STATE_NORMAL;

  private void ensureCapacity(int lineCount) {
    if (endStates.length < lineCount) {
      int[] bigger = new int[lineCount + 64];
      System.arraycopy(endStates, 0, bigger, 0, endStates.length);
      for (int i = Math.max(0, endStates.length - 1); i < bigger.length; i++)
        if (i >= endStates.length) bigger[i] = -1;
      endStates = bigger;
    }
  }

  /** أنماط سطر (كما طوله) أو null إن لم يُكسَ بعد — قراءة الواجهة بلا حجب. */
  public int[] stylesForLine(int line) {
    int[][] snapshot = stylesByLine;
    if (line < 0 || line >= snapshot.length) return null;
    return snapshot[line];
  }

  public void shutdown() {
    worker.shutdownNow();
  }

  // ---------------- اللكسير السطري (حالات: عادي/كتلي) ----------------

  private int[] lexLine(char[] chars, int entryState) {
    int length = chars.length;
    int[] styles = new int[length];
    lexLineEndState = STATE_NORMAL;
    int i = 0;
    if (entryState == STATE_BLOCK_COMMENT) {
      i = consumeBlockComment(chars, 0, styles);
      // consumeBlockComment يضبط نهاية الحالة بنفسه عند عدم الإنهاء فقط — لا فرض هنا.
      if (i >= length) return styles;
    }
    while (i < length) {
      char c = chars[i];
      if (c == ' ' || c == '\t') {
        i++;
        continue;
      }
      if (c == '/' && i + 1 < length && chars[i + 1] == '/') {
        fill(styles, i, length, CodeLanguageTools.COMMENT);
        i = length;
      } else if (c == '/' && i + 1 < length && chars[i + 1] == '*' && mode == MODE_JAVA) {
        i = consumeBlockComment(chars, i, styles);
      } else if (c == '<' && matches(chars, i, "<!--") && mode == MODE_XML) {
        i = consumeBlockComment(chars, i, styles);
      } else if (c == '#' && mode == MODE_SMALI) {
        fill(styles, i, length, CodeLanguageTools.COMMENT);
        i = length;
      } else if (c == '"') {
        i = consumeQuoted(chars, i, styles, '"');
      } else if (c == '\'') {
        i = consumeQuoted(chars, i, styles, '\'');
      } else if (c == '@' && mode != MODE_XML && i + 1 < length
          && Character.isJavaIdentifierStart(chars[i + 1])) {
        int end = i + 1;
        while (end < length && Character.isJavaIdentifierPart(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.ANNOTATION);
        i = end;
      } else if (Character.isDigit(c)) {
        int end = i + 1;
        while (end < length
            && (Character.isLetterOrDigit(chars[end]) || chars[end] == '.' || chars[end] == '_'))
          end++;
        fill(styles, i, end, CodeLanguageTools.NUMBER);
        i = end;
      } else if (c == '.' && mode == MODE_SMALI && i + 1 < length
          && Character.isJavaIdentifierStart(chars[i + 1])) {
        // تعليمة smali (.method .field .registers ...) — كلمات مفتاحية.
        int end = i + 1;
        while (end < length && Character.isJavaIdentifierPart(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.KEYWORD);
        i = end;
      } else if ((c == 'L' || c == '[') && mode == MODE_SMALI
          && i + 1 < length && isSmaliTypeStart(chars, i)) {
        int end = i;
        while (end < length && chars[end] != ';') end++;
        fill(styles, i, Math.min(end + 1, length), CodeLanguageTools.FUNCTION);
        i = Math.min(end + 1, length);
      } else if (c == 'v' && mode == MODE_SMALI && i + 1 < length
          && Character.isDigit(chars[i + 1])) {
        int end = i + 1;
        while (end < length && Character.isDigit(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.NUMBER);
        i = end;
      } else if (mode == MODE_XML && (c == '<' || c == '>' || c == '?')) {
        styles[i] = CodeLanguageTools.KEYWORD;
        i++;
      } else if (Character.isJavaIdentifierStart(c) || (mode == MODE_XML && c == ':')) {
        int end = i + 1;
        while (end < length
            && (Character.isJavaIdentifierPart(chars[end])
                || (mode == MODE_XML && (chars[end] == '-' || chars[end] == ':')))) end++;
        String word = new String(chars, i, end - i);
        if (isKeyword(word)) fill(styles, i, end, CodeLanguageTools.KEYWORD);
        else if (mode == MODE_XML && inTag(chars, i)) fill(styles, i, end, CodeLanguageTools.ANNOTATION);
        i = end;
      } else if ("(){}[];,=+-*/%&|!<>~^?:".indexOf(c) >= 0) {
        styles[i] = CodeLanguageTools.OPERATOR;
        i++;
      } else if (c == '.') {
        styles[i] = CodeLanguageTools.SEPARATOR;
        i++;
      } else {
        i++;
      }
    }
    return styles;
  }

  private boolean matches(char[] chars, int at, String token) {
    if (at + token.length() > chars.length) return false;
    for (int i = 0; i < token.length(); i++)
      if (chars[at + i] != token.charAt(i)) return false;
    return true;
  }

  private boolean isSmaliTypeStart(char[] chars, int at) {
    if (chars[at] == '[') return true;
    if (at + 1 >= chars.length) return false;
    char next = chars[at + 1];
    return Character.isUpperCase(next) || next == 'a' || next == 'b' || next == 'c';
  }

  private boolean inTag(char[] chars, int at) {
    for (int i = at - 1; i >= 0; i--) {
      if (chars[i] == '<') return true;
      if (chars[i] == '>' || chars[i] == '\n') return false;
    }
    return false;
  }

  private int consumeQuoted(char[] chars, int start, int[] styles, char quote) {
    int i = start + 1;
    boolean escaped = false;
    while (i < chars.length) {
      char c = chars[i];
      if (escaped) escaped = false;
      else if (c == '\\') escaped = true;
      else if (c == quote) {
        i++;
        break;
      }
      i++;
    }
    fill(styles, start, Math.min(i, chars.length), CodeLanguageTools.STRING);
    return Math.min(i, chars.length);
  }

  private int consumeBlockComment(char[] chars, int start, int[] styles) {
    String terminator = mode == MODE_XML ? "-->" : "*/";
    int i = start;
    int from = start;
    while (i < chars.length) {
      if (matches(chars, i, terminator)) {
        i += terminator.length();
        fill(styles, from, Math.min(i, chars.length), CodeLanguageTools.COMMENT);
        return i;
      }
      i++;
    }

    fill(styles, from, chars.length, CodeLanguageTools.COMMENT);
    lexLineEndState = STATE_BLOCK_COMMENT;
    return chars.length;
  }

  private static void fill(int[] styles, int from, int to, int id) {
    for (int i = Math.max(0, from); i < Math.min(to, styles.length); i++) styles[i] = id;
  }

  /** كلمات Java الشائعة (تغطي أيضًا C/C++/smali بشكل معقول كما في المصدر). */
  private static final HashSet<String> JAVA_KEYWORDS = new HashSet<>();

  static {
    String[] words = {
      "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class",
      "const", "continue", "default", "do", "double", "else", "enum", "extends", "final",
      "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int",
      "interface", "long", "native", "new", "package", "private", "protected", "public",
      "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
      "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false",
      "null", "record", "sealed", "permits", "var", "yield", "synchronized", "String",
      "int32_t", "int64_t", "struct", "typedef", "union", "unsigned", "register", "sizeof",
      "override", "virtual", "template", "namespace", "using", "inline", "explicit"
    };
    for (String word : words) JAVA_KEYWORDS.add(word);
  }

  private boolean isKeyword(String word) {
    if (mode == MODE_JAVA) return JAVA_KEYWORDS.contains(word);
    if (mode == MODE_XML) return false;
    if (mode == MODE_SMALI)
      return "move".equals(word) || "invoke-virtual".equals(word) || "invoke-static".equals(word)
          || "invoke-direct".equals(word) || "return-void".equals(word);
    return false;
  }
}
