package com.shima.demo;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.drawerlayout.widget.DrawerLayout;
import almlk.design.LayoutSourceMap;
import almlk.design.ResourceResolver;
import almlk.design.XmlLayoutRenderer;
import java.io.File;
import java.util.ArrayList;

/**
 * مصمم واجهات XML بدلالات المرجع: معاينة حقيقية + حوار خصائص العنصر الوظيفي —
 * التعديلات والإضافة والحذف والإحاطة تُكتب في نص XML نفسه وتعود للمحرر.
 */
public class DesignerActivity extends LocaleAwareActivity {

  private DrawerLayout drawer;
  private FrameLayout content;
  private ListView viewList;
  private XmlLayoutRenderer.Result rendering;
  private XmlLayoutRenderer.BorderOverlay overlay;
  private ResourceResolver resolver;
  private String xml = "", fileName = "layout.xml";
  private int themeIndex;
  private boolean previewMode;
  private final ArrayList<String> undoStack = new ArrayList<>();
  private final ArrayList<String> redoStack = new ArrayList<>();
  private boolean dirty;

  private String ui(String key) {
    return UiStrings.get(this, key);
  }

  private String uiFormat(String key, Object... values) {
    return UiStrings.format(this, key, values);
  }

  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    xml = getIntent().getStringExtra("xml") == null ? "" : getIntent().getStringExtra("xml");
    String path = getIntent().getStringExtra("file");
    if (path != null && !path.isEmpty())
      fileName = new File(android.net.Uri.decode(path)).getName();
    resolver = ResourceResolver.forLayoutFile(path);
    themeIndex = getSharedPreferences("designer", MODE_PRIVATE).getInt("theme", 2);

    drawer = new DrawerLayout(this);
    content = new FrameLayout(this);
    drawer.addView(
        content,
        new DrawerLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    viewList = new ListView(this);
    viewList.setDivider(null);
    viewList.setDividerHeight(0);
    DrawerLayout.LayoutParams listParams =
        new DrawerLayout.LayoutParams(dp(240), ViewGroup.LayoutParams.MATCH_PARENT);
    listParams.gravity = Gravity.START;
    drawer.addView(viewList, listParams);
    setContentView(drawer);

    configureActionBar();
    renderLayout();
  }

  private void configureActionBar() {
    ActionBar bar = getActionBar();
    if (bar == null) return;
    bar.setDisplayHomeAsUpEnabled(true);
    bar.setHomeButtonEnabled(true);
    android.graphics.drawable.Drawable menuIcon =
        getDrawable(R.drawable.ic_navigation_menu);
    if (menuIcon != null) {
      menuIcon = menuIcon.mutate();
      menuIcon.setTint(0xFF333333);
    }
    bar.setHomeAsUpIndicator(menuIcon);
    bar.setDisplayShowTitleEnabled(false);
    bar.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
    bar.setListNavigationCallbacks(
        new ArrayAdapter<>(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            new String[] {
              ui("ui_designer_theme_light_small"),
              ui("ui_designer_theme_dark_small"),
              ui("ui_designer_theme_light"),
              ui("ui_designer_theme_dark")
            }),
        (position, id) -> {
          if (position != themeIndex) {
            themeIndex = position;
            getSharedPreferences("designer", MODE_PRIVATE).edit().putInt("theme", position).apply();
            renderLayout();
          }
          return true;
        });
    bar.setSelectedNavigationItem(themeIndex);
    applyChrome();
  }

  private boolean darkTheme() {
    return themeIndex == 1 || themeIndex == 3;
  }

  private boolean smallTheme() {
    return themeIndex == 0 || themeIndex == 1;
  }

  private void applyChrome() {
    ActionBar bar = getActionBar();
    boolean dark = darkTheme();
    // شريط المصمم فاتح دائمًا كما في لقطات المرجع — أيقوناته داكنة من ثيم النشاط الفاتح،
    // وثيم السبنر المختار يطبق على سطح المعاينة والدرج فقط.
    if (bar != null) bar.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
    getWindow().setStatusBarColor(Color.rgb(224, 224, 224));
    drawer.setBackgroundColor(dark ? Color.rgb(18, 18, 18) : Color.rgb(250, 250, 250));
    viewList.setBackgroundColor(dark ? Color.rgb(28, 28, 28) : Color.WHITE);
  }

  private void renderLayout() {
    applyChrome();
    boolean dark = darkTheme();
    content.removeAllViews();
    rendering = XmlLayoutRenderer.render(this, xml, dark, resolver);
    viewList.setAdapter(new TreeAdapter());
    viewList.setOnItemClickListener(
        (parent, view, position, id) -> {
          if (position == 0) return;
          drawer.closeDrawers();
          showElementDialog(position - 1);
        });
    if (rendering.root == null) {
      TextView problem = new TextView(this);
      problem.setText(
          rendering.error == null
              ? ui("ui_designer_no_root_element")
              : uiFormat("ui_designer_render_error", rendering.error));
      problem.setTextColor(dark ? Color.WHITE : Color.BLACK);
      problem.setPadding(dp(24), dp(24), dp(24), dp(24));
      content.addView(problem);
      return;
    }
    overlay = new XmlLayoutRenderer.BorderOverlay(this, rendering.nodes);
    overlay.setBordersVisible(!previewMode);
    overlay.setBackgroundColor(dark ? Color.rgb(18, 18, 18) : Color.WHITE);
    overlay.addView(
        rendering.root,
        new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    content.addView(
        overlay,
        new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    if (smallTheme()) {
      overlay.setScaleX(0.72f);
      overlay.setScaleY(0.72f);
    }
    // وضع التحرير كالمرجع: النقر على عنصر في المعاينة يفتح حوار خصائصه.
    overlay.setOnTouchListener(
        new View.OnTouchListener() {
          float downX, downY;

          @Override
          public boolean onTouch(View v, android.view.MotionEvent event) {
            if (previewMode) return false;
            if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
              downX = event.getRawX();
              downY = event.getRawY();
              return true;
            }
            if (event.getAction() == android.view.MotionEvent.ACTION_UP
                && Math.abs(event.getRawX() - downX) < dp(8)
                && Math.abs(event.getRawY() - downY) < dp(8)) {
              int index = deepestNodeAt(event.getRawX(), event.getRawY());
              if (index >= 0) {
                overlay.select(rendering.nodes.get(index).view);
                showElementDialog(index);
              }
            }
            return true;
          }
        });
  }

  /** أعمق عنصر تحت نقطة اللمس — الأخير توثيقيًا بين الحاويين للنقطة. */
  private int deepestNodeAt(float rawX, float rawY) {
    int found = -1;
    for (int i = 0; i < rendering.nodes.size(); i++) {
      View view = rendering.nodes.get(i).view;
      if (view == null || !view.isAttachedToWindow()) continue;
      int[] at = new int[2];
      view.getLocationOnScreen(at);
      float scale = smallTheme() ? 1f : 1f; // الإحداثيات الشاشية تشمل التصغير بالفعل.
      if (rawX >= at[0] && rawX <= at[0] + view.getWidth() * view.getScaleX() / scale
          && rawY >= at[1] && rawY <= at[1] + view.getHeight() * view.getScaleY() / scale)
        found = i;
    }
    return found;
  }

  // ===================== حوار خصائص العنصر (دلالة المرجع بكاملها) =====================

  private static final int KIND_JUMP = 0, KIND_ADD = 1, KIND_DELETE = 2, KIND_PROP = 3;

  private static final class Row {
    final int kind;
    final CharSequence label;
    final Runnable action;

    Row(int kind, CharSequence label, Runnable action) {
      this.kind = kind;
      this.label = label;
      this.action = action;
    }
  }

  private void showElementDialog(int index) {
    LayoutSourceMap map = new LayoutSourceMap(xml);
    if (index >= map.count() || index >= rendering.nodes.size()) return;
    LayoutSourceMap.Element element = map.element(index);
    String shortTag = shortName(element.tag);
    String title =
        element.parentIndex >= 0
            ? shortName(map.element(element.parentIndex).tag) + " > " + shortTag
            : fileName + " > " + shortTag;

    ArrayList<Row> rows = new ArrayList<>();
    if (element.parentIndex >= 0) {
      final int parent = element.parentIndex;
      rows.add(new Row(KIND_JUMP, ui("ui_designer_parent_element"), () -> showElementDialog(parent)));
    }
    rows.add(
        new Row(
            KIND_JUMP,
            ui("ui_designer_source_code"),
            () -> {
              prepareResult().putExtra("goto", element.start);
              finish();
            }));
    boolean container = isContainerTag(shortTag);
    if (container)
      rows.add(
          new Row(KIND_ADD, ui("ui_designer_add_inside"),
              () -> pickWidget(uiFormat("ui_designer_add_inside_tag", shortTag), false,
                  snippet -> apply(new LayoutSourceMap(xml).insertInside(index, snippet)))));
    rows.add(
        new Row(KIND_ADD, ui("ui_designer_add_before"),
            () -> pickWidget(uiFormat("ui_designer_add_before_tag", shortTag), false,
                snippet -> apply(new LayoutSourceMap(xml).insertBefore(index, snippet)))));
    rows.add(
        new Row(KIND_ADD, ui("ui_designer_add_after"),
            () -> pickWidget(uiFormat("ui_designer_add_after_tag", shortTag), false,
                snippet -> apply(new LayoutSourceMap(xml).insertAfter(index, snippet)))));
    rows.add(
        new Row(KIND_ADD, ui("ui_designer_wrap_container"),
            () -> pickWidget(uiFormat("ui_designer_wrap_tag", shortTag), true,
                snippet -> {
                  int cut = snippet.indexOf('\u0000');
                  apply(new LayoutSourceMap(xml)
                      .surround(index, snippet.substring(0, cut), snippet.substring(cut + 1)));
                })));
    rows.add(new Row(KIND_DELETE, ui("ui_action_delete"),
        () -> apply(new LayoutSourceMap(xml).deleteElement(index))));

    // الخصائص — Label = value بالقيمة الحالية بخط عريض كما في المرجع.
    addProp(rows, map, index, ui("ui_designer_prop_id"), "android:id");
    addProp(rows, map, index, ui("ui_designer_prop_style"), "style");
    addProp(rows, map, index, ui("ui_designer_prop_background"), "android:background");
    addProp(rows, map, index, ui("ui_designer_prop_layout_height"), "android:layout_height");
    addProp(rows, map, index, ui("ui_designer_prop_layout_width"), "android:layout_width");
    addProp(rows, map, index, ui("ui_designer_prop_alpha"), "android:alpha");
    addProp(rows, map, index, ui("ui_designer_prop_elevation"), "android:elevation");
    addProp(rows, map, index, ui("ui_designer_prop_layout_gravity"), "android:layout_gravity");
    addProp(rows, map, index, ui("ui_designer_prop_layout_margin"), "android:layout_margin");
    addProp(rows, map, index, ui("ui_designer_prop_layout_weight"), "android:layout_weight");
    addProp(rows, map, index, ui("ui_designer_prop_padding"), "android:padding");
    addProp(rows, map, index, ui("ui_designer_prop_visibility"), "android:visibility");
    if (container) {
      addProp(rows, map, index, ui("ui_designer_prop_gravity"), "android:gravity");
      if ("LinearLayout".equals(shortTag) || "RadioGroup".equals(shortTag))
        addProp(rows, map, index, ui("ui_designer_prop_orientation"), "android:orientation");
    }
    if (isTextTag(shortTag)) {
      addProp(rows, map, index, ui("ui_designer_prop_text"), "android:text");
      addProp(rows, map, index, ui("ui_designer_prop_text_size"), "android:textSize");
      addProp(rows, map, index, ui("ui_designer_prop_text_color"), "android:textColor");
      addProp(rows, map, index, ui("ui_designer_prop_text_style"), "android:textStyle");
      addProp(rows, map, index, ui("ui_designer_prop_hint"), "android:hint");
      addProp(rows, map, index, ui("ui_designer_prop_gravity"), "android:gravity");
    }

    AlertDialog.Builder builder = new AlertDialog.Builder(this).setTitle(title);
    builder.setAdapter(new RowAdapter(rows), (d, which) -> rows.get(which).action.run());
    builder.show();
  }

  private void addProp(
      ArrayList<Row> rows, LayoutSourceMap map, int index, String label, String attribute) {
    String value = map.attribute(index, attribute);
    SpannableStringBuilder text = new SpannableStringBuilder(label);
    if (value != null && !value.isEmpty()) {
      String shown = displayValue(value);
      int at = text.length();
      text.append(" = ").append(shown);
      text.setSpan(new StyleSpan(Typeface.BOLD), at + 3, text.length(), 0);
    }
    rows.add(new Row(KIND_PROP, text, () -> editProperty(index, label, attribute, value)));
  }

  private String displayValue(String value) {
    if ("match_parent".equals(value) || "fill_parent".equals(value))
      return ui("ui_designer_match_parent");
    if ("wrap_content".equals(value)) return ui("ui_designer_wrap_content");
    return value;
  }

  private final class RowAdapter extends BaseAdapter {
    private final ArrayList<Row> rows;

    RowAdapter(ArrayList<Row> rows) {
      this.rows = rows;
    }

    @Override
    public int getCount() {
      return rows.size();
    }

    @Override
    public Object getItem(int i) {
      return rows.get(i);
    }

    @Override
    public long getItemId(int i) {
      return i;
    }

    @Override
    public View getView(int position, View convert, ViewGroup parent) {
      LinearLayout row;
      if (convert instanceof LinearLayout) row = (LinearLayout) convert;
      else {
        row = new LinearLayout(DesignerActivity.this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(10), dp(20), dp(10));
        ImageView icon = new ImageView(DesignerActivity.this);
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(26), dp(26)));
        TextView label = new TextView(DesignerActivity.this);
        label.setTextSize(17);
        label.setTextColor(0xFF424242);
        label.setPaddingRelative(dp(18), 0, 0, 0);
        row.addView(icon);
        row.addView(label);
      }
      Row item = rows.get(position);
      ImageView icon = (ImageView) row.getChildAt(0);
      switch (item.kind) {
        case KIND_JUMP:
          icon.setImageResource(R.drawable.ic_l_goto_light);
          break;
        case KIND_ADD:
          icon.setImageResource(R.drawable.ic_l_add_light);
          break;
        case KIND_DELETE:
          icon.setImageResource(R.drawable.ic_l_delete_light);
          break;
        default:
          icon.setImageResource(R.drawable.ic_l_fix_light);
          break;
      }
      ((TextView) row.getChildAt(1)).setText(item.label);
      return row;
    }
  }

  // ===================== محررات الخصائص =====================

  private interface SnippetListener {
    void picked(String snippet);
  }

  private void editProperty(int index, String label, String attribute, String current) {
    switch (attribute) {
      case "android:layout_height":
      case "android:layout_width":
      case "android:textSize":
      case "android:elevation":
      case "android:layout_margin":
      case "android:padding":
        showSizeDialog(label, current, value -> writeAttribute(index, attribute, value));
        return;
      case "android:visibility":
        showChoiceDialog(label, new String[] {"visible", "invisible", "gone"}, current,
            value -> writeAttribute(index, attribute, value));
        return;
      case "android:orientation":
        showChoiceDialog(label, new String[] {"vertical", "horizontal"}, current,
            value -> writeAttribute(index, attribute, value));
        return;
      case "android:textStyle":
        showChoiceDialog(label, new String[] {"normal", "bold", "italic", "bold|italic"}, current,
            value -> writeAttribute(index, attribute, value));
        return;
      case "android:gravity":
      case "android:layout_gravity":
        showChoiceDialog(
            label,
            new String[] {
              "center", "center_vertical", "center_horizontal", "left", "right", "top", "bottom",
              "center_vertical|left", "center_vertical|right", "bottom|center_horizontal"
            },
            current,
            value -> writeAttribute(index, attribute, value));
        return;
      case "android:background":
      case "android:textColor":
        showColorDialog(label, current, value -> writeAttribute(index, attribute, value));
        return;
      default:
        showTextDialog(label, current, value -> writeAttribute(index, attribute, value));
    }
  }

  private void writeAttribute(int index, String attribute, String value) {
    apply(new LayoutSourceMap(xml).setAttribute(index, attribute, value));
  }

  /** حوار المقاس المرجعي: حقل قيمة + صف (− / شريط / +) يحرر الرقم بوحدة dp. */
  private void showSizeDialog(String title, String current, SnippetListener listener) {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setPadding(dp(24), dp(10), dp(24), 0);
    EditText field = new EditText(this);
    field.setSingleLine(true);
    field.setText(current == null ? "" : current);
    box.addView(field,
        new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT));
    LinearLayout controls = new LinearLayout(this);
    controls.setOrientation(LinearLayout.HORIZONTAL);
    controls.setGravity(Gravity.CENTER_VERTICAL);
    Button minus = new Button(this);
    minus.setText("−");
    SeekBar seek = new SeekBar(this);
    seek.setMax(512);
    Button plus = new Button(this);
    plus.setText("+");
    controls.addView(minus);
    controls.addView(seek,
        new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
    controls.addView(plus);
    LinearLayout.LayoutParams controlsParams =
        new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT);
    controlsParams.topMargin = dp(10);
    box.addView(controls, controlsParams);
    seek.setProgress(numberOf(current, 0));
    seek.setOnSeekBarChangeListener(
        new SeekBar.OnSeekBarChangeListener() {
          @Override
          public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
            if (fromUser) field.setText(progress + "dp");
          }

          @Override
          public void onStartTrackingTouch(SeekBar bar) {}

          @Override
          public void onStopTrackingTouch(SeekBar bar) {}
        });
    minus.setOnClickListener(v -> field.setText(Math.max(0, numberOf(field.getText().toString(), 0) - 1) + "dp"));
    plus.setOnClickListener(v -> field.setText((numberOf(field.getText().toString(), 0) + 1) + "dp"));
    new AlertDialog.Builder(this)
        .setTitle(title)
        .setView(box)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(ui("ui_action_ok"), (d, w) -> listener.picked(field.getText().toString().trim()))
        .show();
  }

  private static int numberOf(String value, int fallback) {
    if (value == null) return fallback;
    try {
      return (int) Float.parseFloat(value.replaceAll("[^0-9.]", ""));
    } catch (NumberFormatException wrong) {
      return fallback;
    }
  }

  private void showChoiceDialog(
      String title, String[] options, String current, SnippetListener listener) {
    int checked = -1;
    for (int i = 0; i < options.length; i++) if (options[i].equals(current)) checked = i;
    new AlertDialog.Builder(this)
        .setTitle(title)
        .setSingleChoiceItems(options, checked,
            (d, which) -> {
              listener.picked(options[which]);
              d.dismiss();
            })
        .setNegativeButton(ui("dialog_cancel"), null)
        .setNeutralButton(ui("ui_action_delete_property"), (d, w) -> listener.picked(""))
        .show();
  }

  private void showColorDialog(String title, String current, SnippetListener listener) {
    Integer parsed = null;
    if (current != null && current.startsWith("#")) {
      try {
        parsed = Color.parseColor(current);
      } catch (IllegalArgumentException ignored) {
      }
    }
    if (current == null || current.isEmpty() || parsed != null) {
      // منتقي الألوان المرجعي نفسه (net.margaritov) — كما في شاشة نظام الألوان.
      net.margaritov.preference.colorpicker.ColorPickerDialog picker =
          new net.margaritov.preference.colorpicker.ColorPickerDialog(
              this, parsed == null ? Color.WHITE : parsed);
      picker.setTitle(title);
      picker.setAlphaSliderVisible(true);
      picker.setHexValueEnabled(true);
      picker.setOnColorChangedListener(
          color -> listener.picked(String.format("#%08X", color)));
      picker.show();
    } else {
      // قيمة مرجعية (@color/@drawable) — تحرير نصي حر.
      showTextDialog(title, current, listener);
    }
  }

  private void showTextDialog(String title, String current, SnippetListener listener) {
    EditText field = new EditText(this);
    field.setInputType(InputType.TYPE_CLASS_TEXT);
    field.setText(current == null ? "" : current);
    FrameLayout wrapper = new FrameLayout(this);
    wrapper.setPadding(dp(24), dp(8), dp(24), 0);
    wrapper.addView(field);
    new AlertDialog.Builder(this)
        .setTitle(title)
        .setView(wrapper)
        .setNegativeButton(ui("dialog_cancel"), null)
        .setPositiveButton(ui("ui_action_ok"), (d, w) -> listener.picked(field.getText().toString().trim()))
        .show();
  }

  // ===================== كتالوج الودجتس للإضافة والإحاطة =====================

  private static final String[][] CONTAINERS = {
    {"ui_designer_vertical_container",
      "<LinearLayout\n    android:layout_width=\"match_parent\"\n    android:layout_height=\"wrap_content\"\n    android:orientation=\"vertical\">\n</LinearLayout>"},
    {"ui_designer_horizontal_container",
      "<LinearLayout\n    android:layout_width=\"match_parent\"\n    android:layout_height=\"wrap_content\"\n    android:orientation=\"horizontal\">\n</LinearLayout>"},
    {"FrameLayout",
      "<FrameLayout\n    android:layout_width=\"match_parent\"\n    android:layout_height=\"wrap_content\">\n</FrameLayout>"},
    {"RelativeLayout",
      "<RelativeLayout\n    android:layout_width=\"match_parent\"\n    android:layout_height=\"wrap_content\">\n</RelativeLayout>"},
    {"ScrollView",
      "<ScrollView\n    android:layout_width=\"match_parent\"\n    android:layout_height=\"match_parent\">\n</ScrollView>"},
  };

  private static final String[][] WIDGETS = {
    {"TextView",
      "<TextView\n    android:layout_width=\"wrap_content\"\n    android:layout_height=\"wrap_content\"\n    android:text=\"TextView\" />"},
    {"Button",
      "<Button\n    android:layout_width=\"wrap_content\"\n    android:layout_height=\"wrap_content\"\n    android:text=\"Button\" />"},
    {"EditText",
      "<EditText\n    android:layout_width=\"match_parent\"\n    android:layout_height=\"wrap_content\"\n    android:hint=\"EditText\" />"},
    {"ImageView",
      "<ImageView\n    android:layout_width=\"wrap_content\"\n    android:layout_height=\"wrap_content\"\n    android:src=\"@android:drawable/ic_menu_gallery\" />"},
    {"ImageButton",
      "<ImageButton\n    android:layout_width=\"wrap_content\"\n    android:layout_height=\"wrap_content\"\n    android:src=\"@android:drawable/ic_menu_gallery\" />"},
    {"CheckBox",
      "<CheckBox\n    android:layout_width=\"wrap_content\"\n    android:layout_height=\"wrap_content\"\n    android:text=\"CheckBox\" />"},
    {"RadioButton",
      "<RadioButton\n    android:layout_width=\"wrap_content\"\n    android:layout_height=\"wrap_content\"\n    android:text=\"RadioButton\" />"},
    {"Switch",
      "<Switch\n    android:layout_width=\"wrap_content\"\n    android:layout_height=\"wrap_content\" />"},
    {"SeekBar",
      "<SeekBar\n    android:layout_width=\"match_parent\"\n    android:layout_height=\"wrap_content\" />"},
    {"ProgressBar",
      "<ProgressBar\n    android:layout_width=\"wrap_content\"\n    android:layout_height=\"wrap_content\" />"},
    {"Spinner",
      "<Spinner\n    android:layout_width=\"match_parent\"\n    android:layout_height=\"wrap_content\" />"},
    {"ui_designer_divider_widget",
      "<View\n    android:layout_width=\"match_parent\"\n    android:layout_height=\"1dp\"\n    android:background=\"#33000000\" />"},
  };

  private void pickWidget(String title, boolean containersOnly, SnippetListener listener) {
    ArrayList<String> names = new ArrayList<>();
    ArrayList<String> snippets = new ArrayList<>();
    for (String[] entry : CONTAINERS) {
      names.add(entry[0].startsWith("ui_") ? ui(entry[0]) : entry[0]);
      snippets.add(entry[1]);
    }
    if (!containersOnly)
      for (String[] entry : WIDGETS) {
        names.add(entry[0].startsWith("ui_") ? ui(entry[0]) : entry[0]);
        snippets.add(entry[1]);
      }
    new AlertDialog.Builder(this)
        .setTitle(title)
        .setItems(names.toArray(new String[0]),
            (d, which) -> {
              String snippet = snippets.get(which);
              if (containersOnly) {
                // للإحاطة: فصل وسم الفتح عن الإغلاق حول المحتوى.
                int close = snippet.lastIndexOf("</");
                String open = snippet.substring(0, close).trim();
                listener.picked(open + "\u0000" + snippet.substring(close).trim());
              } else listener.picked(snippet);
            })
        .setNegativeButton(ui("dialog_cancel"), null)
        .show();
  }

  // ===================== تطبيق التعديل والتراجع والنتيجة =====================

  private void apply(String newXml) {
    if (newXml == null || newXml.equals(xml)) return;
    undoStack.add(xml);
    redoStack.clear();
    xml = newXml;
    dirty = true;
    renderLayout();
    invalidateOptionsMenu();
  }

  private Intent prepareResult() {
    Intent result = new Intent();
    if (dirty) result.putExtra("xml", xml);
    setResult(RESULT_OK, result);
    return result;
  }

  @Override
  public void onBackPressed() {
    if (drawer.isDrawerOpen(Gravity.START)) {
      drawer.closeDrawers();
      return;
    }
    prepareResult();
    super.onBackPressed();
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    menu.clear();
    MenuItem eye =
        menu.add(0, 1, 0, ui(previewMode ? "ui_designer_edit_mode" : "ui_designer_preview_mode"))
            .setIcon(R.drawable.ic_vectoric_view);
    eye.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    if (eye.getIcon() != null) eye.getIcon().mutate().setTint(0xFF333333);
    MenuItem undo = menu.add(0, 2, 1, getString(R.string.command_undo)).setIcon(R.drawable.ic_vectoric_undo);
    undo.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    undo.setEnabled(!undoStack.isEmpty());
    if (undo.getIcon() != null) {
      undo.getIcon().mutate().setTint(0xFF333333);
      undo.getIcon().setAlpha(undoStack.isEmpty() ? 95 : 255);
    }
    menu.add(0, 4, 2, getString(R.string.command_redo)).setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
    menu.add(0, 3, 3, ui("ui_action_refresh")).setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      if (drawer.isDrawerOpen(Gravity.START)) drawer.closeDrawers();
      else drawer.openDrawer(Gravity.START);
      return true;
    }
    if (item.getItemId() == 1) {
      previewMode = !previewMode;
      if (overlay != null) overlay.setBordersVisible(!previewMode);
      invalidateOptionsMenu();
      return true;
    }
    if (item.getItemId() == 2) {
      if (!undoStack.isEmpty()) {
        redoStack.add(xml);
        xml = undoStack.remove(undoStack.size() - 1);
        dirty = true;
        renderLayout();
        invalidateOptionsMenu();
      }
      return true;
    }
    if (item.getItemId() == 4) {
      if (!redoStack.isEmpty()) {
        undoStack.add(xml);
        xml = redoStack.remove(redoStack.size() - 1);
        dirty = true;
        renderLayout();
        invalidateOptionsMenu();
      }
      return true;
    }
    if (item.getItemId() == 3) {
      renderLayout();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  private static String shortName(String tag) {
    int dot = tag.lastIndexOf('.');
    return dot >= 0 ? tag.substring(dot + 1) : tag;
  }

  private static boolean isContainerTag(String shortTag) {
    switch (shortTag) {
      case "LinearLayout":
      case "FrameLayout":
      case "RelativeLayout":
      case "ScrollView":
      case "HorizontalScrollView":
      case "RadioGroup":
      case "TableLayout":
      case "TableRow":
        return true;
      default:
        return false;
    }
  }

  private static boolean isTextTag(String shortTag) {
    switch (shortTag) {
      case "TextView":
      case "EditText":
      case "Button":
      case "CheckBox":
      case "RadioButton":
      case "Switch":
      case "AppCompatTextView":
      case "AppCompatEditText":
      case "AppCompatButton":
        return true;
      default:
        return false;
    }
  }

  /** شجرة عناصر المرجع: صف رأس الملف ثم العناصر بأيقونة objects وإزاحة العمق. */
  private final class TreeAdapter extends BaseAdapter {
    @Override
    public int getCount() {
      return 1 + (rendering == null ? 0 : rendering.nodes.size());
    }

    @Override
    public Object getItem(int position) {
      return position;
    }

    @Override
    public long getItemId(int position) {
      return position;
    }

    @Override
    public View getView(int position, View convert, ViewGroup parent) {
      LinearLayout row;
      if (convert instanceof LinearLayout) row = (LinearLayout) convert;
      else {
        row = new LinearLayout(DesignerActivity.this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(45));
        ImageView icon = new ImageView(DesignerActivity.this);
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView name = new TextView(DesignerActivity.this);
        name.setTextSize(16);
        name.setPaddingRelative(dp(10), 0, dp(5), 0);
        row.addView(icon);
        row.addView(name);
      }
      ImageView icon = (ImageView) row.getChildAt(0);
      TextView name = (TextView) row.getChildAt(1);
      boolean dark = darkTheme();
      name.setTextColor(dark ? Color.WHITE : 0xFF212121);
      if (position == 0) {
        row.setPaddingRelative(dp(24), dp(4), dp(24), dp(4));
        icon.setImageResource(R.drawable.file_type_xml);
        name.setText(fileName);
        name.setTypeface(null, Typeface.BOLD);
      } else {
        XmlLayoutRenderer.Node node = rendering.nodes.get(position - 1);
        row.setPaddingRelative(dp(24 + node.depth * 16), dp(4), dp(24), dp(4));
        icon.setImageResource(R.drawable.objects);
        name.setText(node.name);
        name.setTypeface(null, Typeface.NORMAL);
      }
      return row;
    }
  }

  private int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
  }
}
