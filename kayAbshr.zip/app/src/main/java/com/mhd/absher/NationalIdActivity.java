package com.mhd.absher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import com.a.a.a.a.a;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class NationalIdActivity extends AppCompatActivity {
    private IdentityPagerAdapter adapter;
    private String cardType = a.a("PDA=");
    private DatabaseReference dbRef;
    private CountDownTimer qrCountDownTimer;
    private SharedPreferences sp;
    private TextView tvUpdateText;
    private ValueEventListener userDataListener;

    class IdentityPagerAdapter extends RecyclerView.Adapter {
        private final String cardType;
        private final Context context;
        private final List pages;
        private final SharedPreferences sp;

        class BarcodeViewHolder extends RecyclerView.ViewHolder {
            ImageView ivLargeBarcode;

            BarcodeViewHolder(View view) {
                super(view);
                this.ivLargeBarcode = (ImageView) view.findViewById(R.id.imageview12);
            }
        }

        class CardViewHolder extends RecyclerView.ViewHolder {
            ImageView ivBg;
            ImageView ivQrCode;
            ImageView ivUserPhoto;
            TextView tvBirth;
            TextView tvBirthPlace;
            TextView tvCopyNumber;
            TextView tvEmployerId;
            TextView tvEmployerName;
            TextView tvExpiryDate;
            TextView tvId;
            TextView tvIssuePlace;
            TextView tvName;
            TextView tvNameEn;
            TextView tvNationality;
            TextView tvProfession;
            TextView tvReligion;

            CardViewHolder(View view) {
                super(view);
                this.tvName = (TextView) view.findViewById(R.id.tvCardNameHome);
                this.tvNameEn = (TextView) view.findViewById(R.id.tvCardNameEn);
                this.tvId = (TextView) view.findViewById(R.id.tvCardIdHome);
                this.tvBirth = (TextView) view.findViewById(R.id.tvCardBirthDate);
                this.tvNationality = (TextView) view.findViewById(R.id.tvCardNationality);
                this.tvProfession = (TextView) view.findViewById(R.id.tvCardProfession);
                this.tvReligion = (TextView) view.findViewById(R.id.tvCardReligion);
                this.tvBirthPlace = (TextView) view.findViewById(R.id.tvCardBirthPlace);
                this.tvExpiryDate = (TextView) view.findViewById(R.id.tvCardExpiryDate);
                this.tvCopyNumber = (TextView) view.findViewById(R.id.tvCardCopyNumber);
                this.tvIssuePlace = (TextView) view.findViewById(R.id.tvCardIssuePlace);
                this.tvEmployerId = (TextView) view.findViewById(R.id.tvCardEmployerId);
                this.tvEmployerName = (TextView) view.findViewById(R.id.tvCardEmployerName);
                this.ivQrCode = (ImageView) view.findViewById(R.id.imageview_qrcode);
                this.ivUserPhoto = (ImageView) view.findViewById(R.id.imageview_id_photo);
                this.ivBg = (ImageView) view.findViewById(R.id.ivDocument1Background);
                if (this.ivBg == null) {
                    this.ivBg = (ImageView) view.findViewById(R.id.img_card_bg);
                }
            }
        }

        class CitizenViewHolder extends RecyclerView.ViewHolder {
            ImageView ivBg;
            ImageView ivQrCode;
            ImageView ivUserPhoto;
            TextView tvCitizenBirthAr;
            TextView tvCitizenBirthEn;
            TextView tvCitizenBirthPlace;
            TextView tvCitizenCopyNumber;
            TextView tvCitizenExpiryAr;
            TextView tvCitizenExpiryEn;
            TextView tvCitizenIdAr;
            TextView tvCitizenIdEn;
            TextView tvCitizenNameAr;
            TextView tvCitizenNameEn;

            CitizenViewHolder(View view, Context context) {
                super(view);
                this.tvCitizenNameAr = (TextView) view.findViewById(R.id.tv_citizen_name_ar);
                this.tvCitizenNameEn = (TextView) view.findViewById(R.id.tv_citizen_name_en);
                this.tvCitizenIdAr = (TextView) view.findViewById(R.id.tv_citizen_id_number);
                this.tvCitizenIdEn = (TextView) view.findViewById(R.id.tv_citizen_id_number_en);
                this.tvCitizenBirthAr = (TextView) view.findViewById(R.id.tv_citizen_birth_date);
                this.tvCitizenBirthEn = (TextView) view.findViewById(R.id.tv_citizen_birth_date_en);
                this.tvCitizenExpiryAr = (TextView) view.findViewById(R.id.tv_citizen_expiry_date);
                this.tvCitizenExpiryEn = (TextView) view.findViewById(R.id.tv_citizen_expiry_date_en);
                this.tvCitizenBirthPlace = (TextView) view.findViewById(R.id.tv_citizen_birth_place);
                this.tvCitizenCopyNumber = (TextView) view.findViewById(R.id.tv_citizen_copy_number);
                this.ivQrCode = (ImageView) view.findViewById(R.id.img_citizen_qrcode);
                this.ivUserPhoto = (ImageView) view.findViewById(R.id.img_citizen_user_photo);
                this.ivBg = (ImageView) view.findViewById(R.id.img_citizen_card_bg);
                try {
                    FrameLayout frameLayout = (FrameLayout) view.findViewById(R.id.frame_layout4);
                    if (frameLayout == null || frameLayout.getChildCount() != 1) {
                        return;
                    }
                    ImageView imageView = new ImageView(context);
                    int iDpToPx = (int) NationalIdActivity.dpToPx(context, 10.0f);
                    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(iDpToPx, iDpToPx);
                    layoutParams.gravity = 17;
                    imageView.setLayoutParams(layoutParams);
                    imageView.setBackgroundColor(-1);
                    imageView.setImageResource(R.drawable.hhn_2);
                    imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    frameLayout.addView(imageView);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        class LicenseViewHolder extends RecyclerView.ViewHolder {
            ImageView ivQrCode;
            ImageView ivUserPhoto;
            TextView tvBirthDateAr;
            TextView tvBirthDateEn;
            TextView tvBloodTypeAr;
            TextView tvBloodTypeEn;
            TextView tvExpiryDateAr;
            TextView tvExpiryDateEn;
            TextView tvIdNumberAr;
            TextView tvIdNumberEn;
            TextView tvIssueDateAr;
            TextView tvIssueDateEn;
            TextView tvLicenseTypeAr;
            TextView tvLicenseTypeEn;
            TextView tvNameAr;
            TextView tvNameEn;
            TextView tvNationalityAr;
            TextView tvNationalityEn;

            LicenseViewHolder(View view) {
                super(view);
                this.tvNameAr = (TextView) view.findViewById(R.id.tvLicenseNameAr);
                this.tvNameEn = (TextView) view.findViewById(R.id.tvLicenseNameEn);
                this.tvIdNumberAr = (TextView) view.findViewById(R.id.tvLicenseIdNumberAr);
                this.tvIdNumberEn = (TextView) view.findViewById(R.id.tvLicenseIdNumberEn);
                this.tvBirthDateAr = (TextView) view.findViewById(R.id.tvLicenseBirthDateAr);
                this.tvBirthDateEn = (TextView) view.findViewById(R.id.tvLicenseBirthDateEn);
                this.tvIssueDateAr = (TextView) view.findViewById(R.id.tvLicenseIssueDateAr);
                this.tvIssueDateEn = (TextView) view.findViewById(R.id.tvLicenseIssueDateEn);
                this.tvExpiryDateAr = (TextView) view.findViewById(R.id.tvLicenseExpiryDateAr);
                this.tvExpiryDateEn = (TextView) view.findViewById(R.id.tvLicenseExpiryDateEn);
                this.tvNationalityAr = (TextView) view.findViewById(R.id.tvLicenseNationalityAr);
                this.tvNationalityEn = (TextView) view.findViewById(R.id.tvLicenseNationalityEn);
                this.tvLicenseTypeAr = (TextView) view.findViewById(R.id.tvLicenseTypeAr);
                this.tvLicenseTypeEn = (TextView) view.findViewById(R.id.tvLicenseTypeEn);
                this.tvBloodTypeAr = (TextView) view.findViewById(R.id.tvLicenseBloodTypeAr);
                this.tvBloodTypeEn = (TextView) view.findViewById(R.id.tvLicenseBloodTypeEn);
                this.ivQrCode = (ImageView) view.findViewById(R.id.imageview_license_barcode);
                this.ivUserPhoto = (ImageView) view.findViewById(R.id.imageview_license_photo);
            }
        }

        class VisitorViewHolder extends RecyclerView.ViewHolder {
            ImageView imgCardBg;
            ImageView ivQrCode;
            ImageView ivUserPhoto;
            TextView tvBirthDate;
            TextView tvBloodType;
            TextView tvExpiryDate;
            TextView tvIdNumber;
            TextView tvIssueDate;
            TextView tvIssuePlace;
            TextView tvNameAr;
            TextView tvNameEn;
            TextView tvNationality;
            TextView tvVersionNumber;
            TextView tvVisitPurpose;

            VisitorViewHolder(View view) {
                super(view);
                this.tvNameAr = (TextView) view.findViewById(R.id.tv_name_ar);
                if (this.tvNameAr == null) {
                    this.tvNameAr = (TextView) view.findViewById(R.id.tvCardNameHome);
                }
                this.tvNameEn = (TextView) view.findViewById(R.id.tv_name_en);
                if (this.tvNameEn == null) {
                    this.tvNameEn = (TextView) view.findViewById(R.id.tvCardNameEn);
                }
                this.tvIdNumber = (TextView) view.findViewById(R.id.tv_id_number);
                if (this.tvIdNumber == null) {
                    this.tvIdNumber = (TextView) view.findViewById(R.id.tvCardIdHome);
                }
                this.tvIssuePlace = (TextView) view.findViewById(R.id.tv_issue_place);
                if (this.tvIssuePlace == null) {
                    this.tvIssuePlace = (TextView) view.findViewById(R.id.tvCardIssuePlace);
                }
                this.tvIssueDate = (TextView) view.findViewById(R.id.tv_issue_date);
                this.tvExpiryDate = (TextView) view.findViewById(R.id.tv_expiry_date);
                if (this.tvExpiryDate == null) {
                    this.tvExpiryDate = (TextView) view.findViewById(R.id.tvCardExpiryDate);
                }
                this.tvBirthDate = (TextView) view.findViewById(R.id.tv_birth_date);
                if (this.tvBirthDate == null) {
                    this.tvBirthDate = (TextView) view.findViewById(R.id.tvCardBirthDate);
                }
                this.tvNationality = (TextView) view.findViewById(R.id.tv_nationality);
                if (this.tvNationality == null) {
                    this.tvNationality = (TextView) view.findViewById(R.id.tvCardNationality);
                }
                this.tvVisitPurpose = (TextView) view.findViewById(R.id.tv_visit_purpose);
                this.tvBloodType = (TextView) view.findViewById(R.id.tv_blood_type);
                this.tvVersionNumber = (TextView) view.findViewById(R.id.tv_version_number);
                if (this.tvVersionNumber == null) {
                    this.tvVersionNumber = (TextView) view.findViewById(R.id.tvCardCopyNumber);
                }
                this.ivQrCode = (ImageView) view.findViewById(R.id.img_visitor_qrcode);
                if (this.ivQrCode == null) {
                    this.ivQrCode = (ImageView) view.findViewById(R.id.imageview_qrcode);
                }
                this.ivUserPhoto = (ImageView) view.findViewById(R.id.img_user_photo);
                if (this.ivUserPhoto == null) {
                    this.ivUserPhoto = (ImageView) view.findViewById(R.id.imageview_id_photo);
                }
                this.imgCardBg = (ImageView) view.findViewById(R.id.img_card_bg);
                if (this.imgCardBg == null) {
                    this.imgCardBg = (ImageView) view.findViewById(R.id.ivDocument1Background);
                }
            }
        }

        IdentityPagerAdapter(Context context, List list, SharedPreferences sharedPreferences, String str) {
            this.context = context;
            this.pages = list;
            this.sp = sharedPreferences;
            this.cardType = str;
        }

        private void applyMagicScale(View view) {
            if (view != null) {
                view.setScaleX(1.3f);
                view.setScaleY(1.3f);
            }
        }

        private boolean isCitizenMode() {
            return a.a("Nj0yREIwOg==").equalsIgnoreCase(this.cardType);
        }

        private boolean isVisitorMode() {
            if (isCitizenMode()) {
                return false;
            }
            return a.a("Iz01REw6Jg==").equalsIgnoreCase(this.cardType) || a.a("Iz01REw6JhlEXA==").equalsIgnoreCase(this.cardType) || a.a("Iz01REw6JhlOWScw").equalsIgnoreCase(this.cardType);
        }

        public int getItemCount() {
            if (this.pages == null) {
                return 0;
            }
            return this.pages.size();
        }

        public int getItemViewType(int i) {
            return ((Integer) this.pages.get(i)).intValue();
        }

        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
            Bitmap bitmapGenerateDenseQRCode;
            Bitmap bitmapGenerateDenseQRCode2;
            Bitmap bitmapGenerateDenseQRCode3;
            Bitmap bitmapGenerateDenseQRCode4;
            Bitmap bitmapGenerateDenseQRCode5;
            if (this.sp == null) {
                return;
            }
            String string = this.sp.getString(a.a("PDAIWFU3MTQ="), a.a("Z2BxHgtnY3QcAA=="));
            String string2 = this.sp.getString(a.a("ICcjX3E4NSFI"), "");
            Bitmap bitmapDecodeByteArray = null;
            if (string2 != null && !string2.trim().isEmpty()) {
                try {
                    byte[] bArrDecode = Base64.decode(string2, 0);
                    bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArrDecode, 0, bArrDecode.length);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (getItemViewType(i) != 0) {
                BarcodeViewHolder barcodeViewHolder = (BarcodeViewHolder) viewHolder;
                if (barcodeViewHolder.ivLargeBarcode == null || (bitmapGenerateDenseQRCode = NationalIdActivity.generateDenseQRCode(string, 400, 400)) == null) {
                    return;
                }
                barcodeViewHolder.ivLargeBarcode.setImageBitmap(bitmapGenerateDenseQRCode);
                return;
            }
            if (viewHolder instanceof CitizenViewHolder) {
                CitizenViewHolder citizenViewHolder = (CitizenViewHolder) viewHolder;
                citizenViewHolder.itemView.setVisibility(0);
                if (citizenViewHolder.ivBg != null) {
                    try {
                        citizenViewHolder.ivBg.setImageResource(R.drawable.as3);
                    } catch (Exception e2) {
                    }
                }
                if (citizenViewHolder.ivUserPhoto != null && bitmapDecodeByteArray != null) {
                    citizenViewHolder.ivUserPhoto.setImageBitmap(bitmapDecodeByteArray);
                }
                String string3 = this.sp.getString(a.a("OzUrSHkn"), a.a("je2fqeHfdJ6U4dGNzA3g7I3C9LJ1jcT1n4zenoI="));
                String string4 = this.sp.getString(a.a("OzUrSH07"), a.a("FDgvDXk5PWZsVDx0F0xRMQ=="));
                String string5 = this.sp.getString(a.a("Nz00WVARNTJI"), a.a("ZG1/HRdlZWkfDw=="));
                String string6 = this.sp.getString(a.a("MCw2REosECdZXQ=="), a.a("ZG1/HRdlZWkfDw=="));
                String string7 = this.sp.getString(a.a("Nz00WVAFOCdOXQ=="), this.sp.getString(a.a("PCc1WF0FOCdOXQ=="), a.a("jfOfqeDkjcz1n43i")));
                String string8 = this.sp.getString(a.a("Njs2VHYgOSRISg=="), a.a("ZA=="));
                if (citizenViewHolder.tvCitizenNameAr != null) {
                    citizenViewHolder.tvCitizenNameAr.setText(string3);
                }
                if (citizenViewHolder.tvCitizenNameEn != null) {
                    citizenViewHolder.tvCitizenNameEn.setText(string4);
                }
                if (citizenViewHolder.tvCitizenIdAr != null) {
                    citizenViewHolder.tvCitizenIdAr.setText(NationalIdActivity.toArabicNumbers(string));
                }
                if (citizenViewHolder.tvCitizenIdEn != null) {
                    citizenViewHolder.tvCitizenIdEn.setText(string);
                }
                if (citizenViewHolder.tvCitizenBirthAr != null) {
                    citizenViewHolder.tvCitizenBirthAr.setText(NationalIdActivity.toArabicNumbers(string5));
                }
                if (citizenViewHolder.tvCitizenBirthEn != null) {
                    citizenViewHolder.tvCitizenBirthEn.setText(string5);
                }
                if (citizenViewHolder.tvCitizenExpiryAr != null) {
                    citizenViewHolder.tvCitizenExpiryAr.setText(NationalIdActivity.toArabicNumbers(string6));
                }
                if (citizenViewHolder.tvCitizenExpiryEn != null) {
                    citizenViewHolder.tvCitizenExpiryEn.setText(string6);
                }
                if (citizenViewHolder.tvCitizenBirthPlace != null) {
                    citizenViewHolder.tvCitizenBirthPlace.setText(string7);
                }
                if (citizenViewHolder.tvCitizenCopyNumber != null) {
                    citizenViewHolder.tvCitizenCopyNumber.setText(NationalIdActivity.toArabicNumbers(string8));
                }
                if (citizenViewHolder.ivQrCode == null || (bitmapGenerateDenseQRCode5 = NationalIdActivity.generateDenseQRCode(string, 150, 150)) == null) {
                    return;
                }
                citizenViewHolder.ivQrCode.setImageBitmap(bitmapGenerateDenseQRCode5);
                return;
            }
            if (viewHolder instanceof VisitorViewHolder) {
                VisitorViewHolder visitorViewHolder = (VisitorViewHolder) viewHolder;
                if (visitorViewHolder.imgCardBg != null) {
                    try {
                        visitorViewHolder.imgCardBg.setImageResource(R.drawable.as2);
                    } catch (Exception e3) {
                    }
                }
                if (visitorViewHolder.ivUserPhoto != null && bitmapDecodeByteArray != null) {
                    visitorViewHolder.ivUserPhoto.setImageBitmap(bitmapDecodeByteArray);
                }
                String string9 = this.sp.getString(a.a("OzUrSHkn"), a.a("je2fqeHfdJ6U4dGNzA3g7I3C9LJ1jcT1n4zenoI="));
                String string10 = this.sp.getString(a.a("OzUrSH07"), a.a("FDgvDXk5PWZsVDx0F0xRMQ=="));
                String string11 = this.sp.getString(a.a("Nz00WVARNTJI"), a.a("ZG1/HRdlZWkfDw=="));
                String string12 = this.sp.getString(a.a("MCw2REosECdZXQ=="), a.a("ZG1/HRdlZWkfDw=="));
                String string13 = this.sp.getString(a.a("PCc1WF0RNTJI"), a.a("ZGByHRdlZWkdCQ=="));
                String string14 = this.sp.getString(a.a("OzUyRFc7NSpETCw="), a.a("jfOfqeDmjP/0sI37n6fg/A=="));
                String string15 = this.sp.getString(a.a("PCc1WF0FOCdOXQ=="), a.a("jfOfqeDkjcz1n43i"));
                String string16 = this.sp.getString(a.a("Iz01REwFITRdVyYx"), a.a("jeafp+DyjPf1kXWM//WfjfKfqeHfjO8="));
                String string17 = this.sp.getString(a.a("NzgpQlwBLTZI"), a.a("fhs="));
                String string18 = this.sp.getString(a.a("Njs2VHYgOSRISg=="), a.a("ZA=="));
                if (visitorViewHolder.tvNameAr != null) {
                    visitorViewHolder.tvNameAr.setText(string9);
                }
                if (visitorViewHolder.tvNameEn != null) {
                    visitorViewHolder.tvNameEn.setText(string10);
                }
                if (visitorViewHolder.tvIdNumber != null) {
                    visitorViewHolder.tvIdNumber.setText(NationalIdActivity.toArabicNumbers(string));
                }
                if (visitorViewHolder.tvIssuePlace != null) {
                    visitorViewHolder.tvIssuePlace.setText(string15);
                }
                if (visitorViewHolder.tvIssueDate != null) {
                    visitorViewHolder.tvIssueDate.setText(NationalIdActivity.toArabicNumbers(string13));
                }
                if (visitorViewHolder.tvExpiryDate != null) {
                    visitorViewHolder.tvExpiryDate.setText(NationalIdActivity.toArabicNumbers(string12));
                }
                if (visitorViewHolder.tvBirthDate != null) {
                    visitorViewHolder.tvBirthDate.setText(NationalIdActivity.toArabicNumbers(string11));
                }
                if (visitorViewHolder.tvNationality != null) {
                    visitorViewHolder.tvNationality.setText(string14);
                }
                if (visitorViewHolder.tvVisitPurpose != null) {
                    visitorViewHolder.tvVisitPurpose.setText(string16);
                }
                if (visitorViewHolder.tvBloodType != null) {
                    TextView textView = visitorViewHolder.tvBloodType;
                    if (string17.isEmpty()) {
                        string17 = a.a("fhs=");
                    }
                    textView.setText(string17);
                }
                if (visitorViewHolder.tvVersionNumber != null) {
                    visitorViewHolder.tvVersionNumber.setText(NationalIdActivity.toArabicNumbers(string18.isEmpty() ? a.a("ZA==") : string18));
                }
                if (visitorViewHolder.ivQrCode == null || (bitmapGenerateDenseQRCode4 = NationalIdActivity.generateDenseQRCode(string, 150, 150)) == null) {
                    return;
                }
                visitorViewHolder.ivQrCode.setImageBitmap(bitmapGenerateDenseQRCode4);
                return;
            }
            if (!(viewHolder instanceof CardViewHolder)) {
                if (viewHolder instanceof LicenseViewHolder) {
                    LicenseViewHolder licenseViewHolder = (LicenseViewHolder) viewHolder;
                    if (licenseViewHolder.ivUserPhoto != null && bitmapDecodeByteArray != null) {
                        licenseViewHolder.ivUserPhoto.setImageBitmap(bitmapDecodeByteArray);
                    }
                    String string19 = this.sp.getString(a.a("OzUrSHkn"), a.a("je2fqeHfdJ6U4dGNzA3g7I3C9LJ1jcT1n4zenoI="));
                    String string20 = this.sp.getString(a.a("OzUrSH07"), a.a("FDgvDXk5PWZsVDx0F0xRMQ=="));
                    String string21 = this.sp.getString(a.a("Nz00WVARNTJI"), a.a("ZG1/HRdlZWkfDw=="));
                    String string22 = this.sp.getString(a.a("PCc1WF0RNTJI"), a.a("ZGByHRdlZWkdCQ=="));
                    String string23 = this.sp.getString(a.a("MCw2REosECdZXQ=="), a.a("Z2R0FBdlbWkcCg=="));
                    String string24 = this.sp.getString(a.a("OzUyRFc7NSpETCw="), a.a("jfOfqeDmjP/0sI37n6fg/A=="));
                    String string25 = this.sp.getString(a.a("OzUyRFc7NSpETCwRKA=="), null);
                    if (string25 == null || string25.trim().isEmpty()) {
                        string25 = NationalIdActivity.getEnglishNationality(string24);
                    }
                    String string26 = this.sp.getString(a.a("OT0lSFYmMRJUSDA="), a.a("jfqemOHdjPP0sg=="));
                    String string27 = this.sp.getString(a.a("OT0lSFYmMRJUSDARKA=="), null);
                    if (string27 == null || string27.trim().isEmpty()) {
                        string27 = NationalIdActivity.getEnglishLicenseType(string26);
                    }
                    String string28 = this.sp.getString(a.a("NzgpQlwBLTZI"), a.a("FH8="));
                    if (licenseViewHolder.tvNameAr != null) {
                        licenseViewHolder.tvNameAr.setText(string19);
                    }
                    if (licenseViewHolder.tvNameEn != null) {
                        licenseViewHolder.tvNameEn.setText(string20);
                    }
                    if (licenseViewHolder.tvIdNumberAr != null) {
                        licenseViewHolder.tvIdNumberAr.setText(NationalIdActivity.toArabicNumbers(string));
                    }
                    if (licenseViewHolder.tvIdNumberEn != null) {
                        licenseViewHolder.tvIdNumberEn.setText(string);
                    }
                    if (licenseViewHolder.tvBirthDateAr != null) {
                        licenseViewHolder.tvBirthDateAr.setText(NationalIdActivity.toArabicNumbers(string21));
                    }
                    if (licenseViewHolder.tvBirthDateEn != null) {
                        licenseViewHolder.tvBirthDateEn.setText(string21);
                    }
                    if (licenseViewHolder.tvIssueDateAr != null) {
                        licenseViewHolder.tvIssueDateAr.setText(NationalIdActivity.toArabicNumbers(string22));
                    }
                    if (licenseViewHolder.tvIssueDateEn != null) {
                        licenseViewHolder.tvIssueDateEn.setText(string22);
                    }
                    if (licenseViewHolder.tvExpiryDateAr != null) {
                        licenseViewHolder.tvExpiryDateAr.setText(NationalIdActivity.toArabicNumbers(string23));
                    }
                    if (licenseViewHolder.tvExpiryDateEn != null) {
                        licenseViewHolder.tvExpiryDateEn.setText(string23);
                    }
                    if (licenseViewHolder.tvNationalityAr != null) {
                        licenseViewHolder.tvNationalityAr.setText(string24);
                    }
                    if (licenseViewHolder.tvNationalityEn != null) {
                        licenseViewHolder.tvNationalityEn.setText(string25);
                    }
                    if (licenseViewHolder.tvLicenseTypeAr != null) {
                        licenseViewHolder.tvLicenseTypeAr.setText(string26);
                    }
                    if (licenseViewHolder.tvLicenseTypeEn != null) {
                        licenseViewHolder.tvLicenseTypeEn.setText(string27);
                    }
                    if (licenseViewHolder.tvBloodTypeAr != null) {
                        licenseViewHolder.tvBloodTypeAr.setText(string28);
                    }
                    if (licenseViewHolder.tvBloodTypeEn != null) {
                        licenseViewHolder.tvBloodTypeEn.setText(string28);
                    }
                    if (licenseViewHolder.ivQrCode == null || (bitmapGenerateDenseQRCode2 = NationalIdActivity.generateDenseQRCode(string, 150, 150)) == null) {
                        return;
                    }
                    licenseViewHolder.ivQrCode.setImageBitmap(bitmapGenerateDenseQRCode2);
                    return;
                }
                return;
            }
            CardViewHolder cardViewHolder = (CardViewHolder) viewHolder;
            if (cardViewHolder.ivUserPhoto != null && bitmapDecodeByteArray != null) {
                cardViewHolder.ivUserPhoto.setImageBitmap(bitmapDecodeByteArray);
            }
            String string29 = this.sp.getString(a.a("OzUrSHkn"), a.a("je2fqeHfdJ6U4dGNzA3g7I3C9LJ1jcT1n4zenoI="));
            String string30 = this.sp.getString(a.a("OzUrSH07"), a.a("FDgvDXk5PWZsVDx0F0xRMQ=="));
            String string31 = this.sp.getString(a.a("Nz00WVARNTJI"), a.a("ZG1/HRdlZWkfDw=="));
            String string32 = this.sp.getString(a.a("MCw2REosECdZXQ=="), a.a("ZG1/HRdlZWkfDw=="));
            String string33 = this.sp.getString(a.a("PCc1WF0FOCdOXQ=="), a.a("jfOfqeDkjcz1n43i"));
            String string34 = this.sp.getString(a.a("OzUyRFc7NSpETCw="), a.a("jfOfqeDmjP/0sI37n6fg/A=="));
            String string35 = this.sp.getString(a.a("Njs2VHYgOSRISg=="), a.a("ZA=="));
            if (cardViewHolder.ivBg != null) {
                try {
                    cardViewHolder.ivBg.setImageResource(R.drawable.as1);
                } catch (Exception e4) {
                }
            }
            if (cardViewHolder.tvName != null) {
                cardViewHolder.tvName.setTranslationX(0.0f);
                cardViewHolder.tvName.setTranslationY(0.0f);
                cardViewHolder.tvName.setText(string29);
            }
            if (cardViewHolder.tvNameEn != null) {
                cardViewHolder.tvNameEn.setTranslationX(0.0f);
                cardViewHolder.tvNameEn.setTranslationY(0.0f);
                cardViewHolder.tvNameEn.setText(string30);
            }
            if (cardViewHolder.tvId != null) {
                cardViewHolder.tvId.setTranslationX(0.0f);
                cardViewHolder.tvId.setTranslationY(0.0f);
                cardViewHolder.tvId.setText(NationalIdActivity.toArabicNumbers(string));
            }
            if (cardViewHolder.tvBirth != null) {
                cardViewHolder.tvBirth.setTranslationX(0.0f);
                cardViewHolder.tvBirth.setTranslationY(0.0f);
                cardViewHolder.tvBirth.setText(NationalIdActivity.toArabicNumbers(string31));
            }
            if (cardViewHolder.tvExpiryDate != null) {
                cardViewHolder.tvExpiryDate.setTranslationX(0.0f);
                cardViewHolder.tvExpiryDate.setTranslationY(0.0f);
                cardViewHolder.tvExpiryDate.setText(NationalIdActivity.toArabicNumbers(string32));
            }
            if (cardViewHolder.tvNationality != null) {
                cardViewHolder.tvNationality.setTranslationX(0.0f);
                cardViewHolder.tvNationality.setTranslationY(0.0f);
                cardViewHolder.tvNationality.setText(string34);
            }
            if (cardViewHolder.tvProfession != null) {
                cardViewHolder.tvProfession.setTranslationX(0.0f);
                cardViewHolder.tvProfession.setTranslationY(0.0f);
                cardViewHolder.tvProfession.setVisibility(0);
                cardViewHolder.tvProfession.setText(this.sp.getString(a.a("JSYpS10mJy9CVg=="), a.a("je2eiuHQjcI=")));
            }
            if (cardViewHolder.tvReligion != null) {
                cardViewHolder.tvReligion.setTranslationX(0.0f);
                cardViewHolder.tvReligion.setTranslationY(0.0f);
                cardViewHolder.tvReligion.setVisibility(0);
                cardViewHolder.tvReligion.setText(this.sp.getString(a.a("JzEqRF88Oyg="), a.a("jfOfqeDwjPX0vI3zn6g=")));
            }
            if (cardViewHolder.tvBirthPlace != null) {
                cardViewHolder.tvBirthPlace.setTranslationX(0.0f);
                cardViewHolder.tvBirthPlace.setTranslationY(0.0f);
                cardViewHolder.tvBirthPlace.setVisibility(0);
                cardViewHolder.tvBirthPlace.setText(this.sp.getString(a.a("Nz00WVAFOCdOXQ=="), a.a("jfOfqeDkjcz1n43i")));
            }
            if (cardViewHolder.tvIssuePlace != null) {
                cardViewHolder.tvIssuePlace.setTranslationX(0.0f);
                cardViewHolder.tvIssuePlace.setTranslationY(0.0f);
                cardViewHolder.tvIssuePlace.setText(string33);
            }
            if (cardViewHolder.tvEmployerId != null) {
                cardViewHolder.tvEmployerId.setTranslationX(0.0f);
                cardViewHolder.tvEmployerId.setTranslationY(0.0f);
                cardViewHolder.tvEmployerId.setVisibility(0);
                cardViewHolder.tvEmployerId.setText(NationalIdActivity.toArabicNumbers(this.sp.getString(a.a("MDk2QVcsMTRkXA=="), a.a("Z2BxHgtnY3QcAA=="))));
            }
            if (cardViewHolder.tvEmployerName != null) {
                cardViewHolder.tvEmployerName.setTranslationX(0.0f);
                cardViewHolder.tvEmployerName.setTranslationY(0.0f);
                cardViewHolder.tvEmployerName.setVisibility(0);
                cardViewHolder.tvEmployerName.setText(this.sp.getString(a.a("MDk2QVcsMTRjWTgx"), a.a("jNGegOHQjOkN4dCM6/S9jftm9L2N+Z+o4Po=")));
            }
            if (cardViewHolder.tvCopyNumber != null) {
                cardViewHolder.tvCopyNumber.setTranslationX(0.0f);
                cardViewHolder.tvCopyNumber.setTranslationY(0.0f);
                cardViewHolder.tvCopyNumber.setText(NationalIdActivity.toArabicNumbers(string35));
            }
            if (cardViewHolder.ivQrCode == null || (bitmapGenerateDenseQRCode3 = NationalIdActivity.generateDenseQRCode(string, 150, 150)) == null) {
                return;
            }
            cardViewHolder.ivQrCode.setImageBitmap(bitmapGenerateDenseQRCode3);
        }

        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View viewInflate;
            if (i != 0) {
                View viewInflate2 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.national_barcode_card, viewGroup, false);
                viewInflate2.setLayoutParams(new RecyclerView.LayoutParams(-1, -1));
                applyMagicScale(viewInflate2);
                return new BarcodeViewHolder(viewInflate2);
            }
            if (a.a("OT0lSFYmMQ==").equalsIgnoreCase(this.cardType)) {
                viewInflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.driving_license_card, viewGroup, false);
            } else if (isCitizenMode()) {
                int identifier = this.context.getResources().getIdentifier(a.a("OzUyRFc7NSpyWzwgL1ddOw=="), a.a("OTU/Qk0h"), this.context.getPackageName());
                if (identifier == 0) {
                    identifier = this.context.getResources().getIdentifier(a.a("OzUyRFc7NSpyWzwgL1ddOwslTEox"), a.a("OTU/Qk0h"), this.context.getPackageName());
                }
                viewInflate = identifier != 0 ? LayoutInflater.from(viewGroup.getContext()).inflate(identifier, viewGroup, false) : LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.national_id_card, viewGroup, false);
            } else if (isVisitorMode()) {
                int identifier2 = this.context.getResources().getIdentifier(a.a("Iz01REw6JhlEXA=="), a.a("OTU/Qk0h"), this.context.getPackageName());
                if (identifier2 == 0) {
                    identifier2 = this.context.getResources().getIdentifier(a.a("Iz01REw6JhlOWScw"), a.a("OTU/Qk0h"), this.context.getPackageName());
                }
                viewInflate = identifier2 != 0 ? LayoutInflater.from(viewGroup.getContext()).inflate(identifier2, viewGroup, false) : LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.national_id_card, viewGroup, false);
            } else {
                viewInflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.national_id_card, viewGroup, false);
            }
            FrameLayout frameLayout = new FrameLayout(viewGroup.getContext());
            frameLayout.setLayoutParams(new RecyclerView.LayoutParams(-1, -1));
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -2);
            layoutParams.gravity = 17;
            viewInflate.setLayoutParams(layoutParams);
            frameLayout.addView(viewInflate);
            applyMagicScale(frameLayout);
            if (a.a("OT0lSFYmMQ==").equalsIgnoreCase(this.cardType)) {
                return new LicenseViewHolder(frameLayout);
            }
            if (isCitizenMode()) {
                return new CitizenViewHolder(frameLayout, this.context);
            }
            return isVisitorMode() ? new VisitorViewHolder(frameLayout) : new CardViewHolder(frameLayout);
        }
    }

    public static float dpToPx(Context context, float f) {
        return context == null ? 2.0f * f : context.getResources().getDisplayMetrics().density * f;
    }

    public static Bitmap generateDenseQRCode(String str, int i, int i2) {
        if (str == null || str.trim().isEmpty()) {
            return null;
        }
        try {
            StringBuilder sb = new StringBuilder();
            for (int i3 = 0; i3 < 150; i3++) {
                sb.append(" ");
            }
            String str2 = String.valueOf(str.trim()) + sb.toString();
            Hashtable hashtable = new Hashtable();
            hashtable.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hashtable.put(EncodeHintType.CHARACTER_SET, a.a("AAAAAAA="));
            hashtable.put(EncodeHintType.MARGIN, 1);
            BitMatrix bitMatrixEncode = new QRCodeWriter().encode(str2, BarcodeFormat.QR_CODE, i, i2, hashtable);
            int width = bitMatrixEncode.getWidth();
            int height = bitMatrixEncode.getHeight();
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            for (int i4 = 0; i4 < width; i4++) {
                for (int i5 = 0; i5 < height; i5++) {
                    bitmapCreateBitmap.setPixel(i4, i5, bitMatrixEncode.get(i4, i5) ? -16777216 : -1);
                }
            }
            return bitmapCreateBitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getEnglishLicenseType(String str) {
        if (str == null || str.trim().isEmpty()) {
            return a.a("BSYvW1khMQ==");
        }
        String strTrim = str.trim();
        if (strTrim.contains(a.a("jfqemOHdjPP0sg=="))) {
            return a.a("BSYvW1khMQ==");
        }
        if (strTrim.contains(a.a("jNKfr+HRdJ6D4PKM8w=="))) {
            return a.a("BSYvW1khMWZ5SjQ6NV1XJyA=");
        }
        if (strTrim.contains(a.a("je2fqOHdjcP0sg==")) || strTrim.contains(a.a("jNKfr+HRdJ6U4PKNww=="))) {
            return a.a("BSEkQVE2dBJfWTsnNkJKIQ==");
        }
        if (strTrim.contains(a.a("jfuenODyjOr1kQ=="))) {
            return a.a("GDsyQko2LSVBXQ==");
        }
        return (strTrim.contains(a.a("jfeemeDvjOH0vA==")) || strTrim.contains(a.a("jfOemeDvjOH0vA=="))) ? a.a("HTEnW0F1GSdOUDw6I19B") : strTrim;
    }

    public static String getEnglishNationality(String str) {
        if (str == null || str.trim().isEmpty()) {
            return a.a("BhUTaXE=");
        }
        String lowerCase = str.trim().toLowerCase();
        if (lowerCase.contains(a.a("jeeelOHdjOk=")) || lowerCase.contains(a.a("JjUzSVE="))) {
            return a.a("BhUTaXE=");
        }
        if (lowerCase.contains(a.a("jN6fqOHT")) || lowerCase.contains(a.a("LDErSFY="))) {
            return a.a("DBELaHY=");
        }
        if (lowerCase.contains(a.a("jNGemODk")) || lowerCase.contains(a.a("MDM/XUw="))) {
            return a.a("EBMffWw=");
        }
        if (lowerCase.contains(a.a("jeefpeD6jOH0vg==")) || lowerCase.contains(a.a("JiEiTFY="))) {
            return a.a("BgECbHY=");
        }
        if (lowerCase.contains(a.a("jeefpeDkjcz1nw==")) || lowerCase.contains(a.a("jeefpeDkjcw=")) || lowerCase.contains(a.a("Ji00RFk="))) {
            return a.a("Bg0UZHk=");
        }
        if (lowerCase.contains(a.a("jfeenOD6jcA=")) || lowerCase.contains(a.a("jfOenOD6jcA=")) || lowerCase.contains(a.a("Pzs0SVk7"))) {
            return a.a("HxsUaXkb");
        }
        if (lowerCase.contains(a.a("jfyeiuHWjPX1ko3zn6s=")) || lowerCase.contains(a.a("JTUtREshNSg="))) {
            return a.a("BRUNZGsBFQg=");
        }
        if (lowerCase.contains(a.a("jNOfq+D6")) || lowerCase.contains(a.a("PDoiRFk="))) {
            return a.a("HBoCZHk=");
        }
        if (lowerCase.contains(a.a("jfyfq+D5jcL1n437n6fg4Q==")) || lowerCase.contains(a.a("jfyfq+DvjcL1n437n6fg4Q==")) || lowerCase.contains(a.a("jfyfq+HXjcL1n437n6fg4Q==")) || lowerCase.contains(a.a("NzUoSlQ0MCNeUA=="))) {
            return a.a("FxUIanQUEAN+cA==");
        }
        if (lowerCase.contains(a.a("jNWfqeD9jcz0vg==")) || lowerCase.contains(a.a("JTwvQVElJC9DXSY="))) {
            return a.a("BRwPYXEFBA9jfQY=");
        }
        if (lowerCase.contains(a.a("jfOehuHfjc71kIzenoo=")) || lowerCase.contains(a.a("jfeehuHfjc71kIzenoo=")) || lowerCase.contains(a.a("jfGehuHfjc71kIzenoo=")) || lowerCase.contains(a.a("jfmeheDh")) || lowerCase.contains(a.a("MCAuRFclPSc="))) {
            return a.a("EAAOZHcFHQc=");
        }
        if (lowerCase.contains(a.a("jNGeiuHRjcw=")) || lowerCase.contains(a.a("ODUqRA=="))) {
            return a.a("GBUKZA==");
        }
        if (lowerCase.contains(a.a("jfOfq+D6jc70vozenp7h34zh")) || lowerCase.contains(a.a("jfGfq+D6jc70vozenp7h34zh")) || lowerCase.contains(a.a("jfOfq+D6jc70vo3nn6fg8g==")) || lowerCase.contains(a.a("jfGfq+D6jc70vo3nn6fg8g==")) || lowerCase.contains(a.a("PDoiQlYwJy9M"))) {
            return a.a("HBoCYnYQBw9s");
        }
        if (lowerCase.contains(a.a("jNGel+DkjO4=")) || lowerCase.contains(a.a("ODs0Qls2Ow=="))) {
            return a.a("GBsUYnsWGw==");
        }
        if (lowerCase.contains(a.a("jf6fpeHTjPU=")) || lowerCase.contains(a.a("ISEoREs8NQ=="))) {
            return a.a("AQEIZGscFQ==");
        }
        if (lowerCase.contains(a.a("jfien+DyjOD1iQ==")) || lowerCase.contains(a.a("NDghSEo8NQ=="))) {
            return a.a("FBgBaGocFQ==");
        }
        if (lowerCase.contains(a.a("jNCeheHTjOH0vg==")) || lowerCase.contains(a.a("OTEkTFY6Og=="))) {
            return a.a("GREEbHYaGg==");
        }
        if (lowerCase.contains(a.a("jNWfqeDmjPH0sozS")) || lowerCase.contains(a.a("JTUqSEshPShI"))) {
            return a.a("BRUKaGsBHQho");
        }
        if (lowerCase.contains(a.a("je2enODyjcQ=")) || lowerCase.contains(a.a("PCYnXA=="))) {
            return a.a("HAYHfA==");
        }
        if (lowerCase.contains(a.a("jNefpeHfjOw=")) || lowerCase.contains(a.a("PiExTFEh"))) {
            return a.a("HgERbHEB");
        }
        if (lowerCase.contains(a.a("jfOfqODyjPf1n43+")) || lowerCase.contains(a.a("jfGfqODyjPf1n43+")) || lowerCase.contains(a.a("IDUj"))) {
            return a.a("ABUD");
        }
        if (lowerCase.contains(a.a("jNaemuDk")) || lowerCase.contains(a.a("JDUyTEo="))) {
            return a.a("BBUSbGo=");
        }
        if (lowerCase.contains(a.a("jfyegODkjcz0vg==")) || lowerCase.contains(a.a("NzUuX1k8Og=="))) {
            return a.a("FxUOf3kcGg==");
        }
        if (lowerCase.contains(a.a("je2fqODyjcA=")) || lowerCase.contains(a.a("OjknQw=="))) {
            return a.a("GhkHYw==");
        }
        if (lowerCase.contains(a.a("jNKfp+D9jOH0vA==")) || lowerCase.contains(a.a("OzE2TFQ="))) {
            return a.a("GxEWbHQ=");
        }
        if (lowerCase.contains(a.a("jeeenOHfjcL1n4zSn67g8g==")) || lowerCase.contains(a.a("JiYvQVk7Pyc="))) {
            return a.a("BgYPDXQUGg1s");
        }
        if (lowerCase.contains(a.a("jfOfrODvjOH0vo3nnofg8o3A")) || lowerCase.contains(a.a("jfefrODvjOH0vo3nnofg8o3A")) || lowerCase.contains(a.a("NDIhRVk7PTVZWTs="))) {
            return a.a("FBIBZXkbHRV5eRs=");
        }
        if (lowerCase.contains(a.a("jf6enOHWjcz1nw==")) || lowerCase.contains(a.a("ISE0Rl0s"))) {
            return a.a("AQEUZn0M");
        }
        if (lowerCase.contains(a.a("jeGfpeHQjOH0vA==")) || lowerCase.contains(a.a("JjsrTFQ8NQ=="))) {
            return a.a("BhsLbHQcFQ==");
        }
        return (lowerCase.contains(a.a("jf6emeDyjOk=")) || lowerCase.contains(a.a("NjwnSQ=="))) ? a.a("FhwHaQ==") : str.trim().toUpperCase();
    }

    public String getSafeString(DataSnapshot dataSnapshot, String... strArr) {
        for (String str : strArr) {
            if (dataSnapshot.hasChild(str) && dataSnapshot.child(str).getValue() != null) {
                return String.valueOf(dataSnapshot.child(str).getValue());
            }
        }
        return null;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [com.mhd.absher.NationalIdActivity$1] */
    public void startCountDownTimer() {
        if (this.qrCountDownTimer != null) {
            this.qrCountDownTimer.cancel();
        }
        this.qrCountDownTimer = new CountDownTimer(30000L, 1000L) {
            @Override
            public void onFinish() {
                if (NationalIdActivity.this.tvUpdateText != null) {
                    NationalIdActivity.this.tvUpdateText.setText(a.a("jN6eh+HQdJ6H4PiM6fSyjf9m9YmM0Z6fGI3zn6ng8oz19ZKN+J6K4P2M7w3g8o3C9YuN5Z+n4Ox0noPh0Yzh9Lx1jeX0mHWM7fWfjNKfp+D8"));
                }
                if (NationalIdActivity.this.adapter != null) {
                    NationalIdActivity.this.adapter.notifyDataSetChanged();
                }
                NationalIdActivity.this.startCountDownTimer();
            }

            @Override
            public void onTick(long j) {
                int i = (int) (j / 1000);
                if (NationalIdActivity.this.tvUpdateText != null) {
                    NationalIdActivity.this.tvUpdateText.setText(a.a("jN6eh+HQdJ6H4PiM6fSyjf9m9YmM0Z6fGI3zn6ng8oz19ZKN+J6K4P2M7w3g8o3C9YuN5Z+n4Ox0noPh0Yzh9Lx1") + NationalIdActivity.toArabicNumbers(String.valueOf(i)) + a.a("dYzt9Z+M0p+n4Pw="));
                }
            }
        }.start();
    }

    private void syncWithFirebase() {
        try {
            SharedPreferences sharedPreferences = getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
            SharedPreferences sharedPreferences2 = getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0);
            String string = sharedPreferences.getString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), "");
            if (string.isEmpty()) {
                string = sharedPreferences2.getString(a.a("ICcjX2swNzRITBww"), "");
            }
            if (string.isEmpty()) {
                string = this.sp.getString(a.a("ICcjX3MwLQ=="), this.sp.getString(a.a("JjElX10hHyNU"), ""));
            }
            if (string.isEmpty()) {
                this.dbRef = FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc="));
            } else {
                this.dbRef = FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(string);
            }
            this.userDataListener = new ValueEventListener() {
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }

                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    boolean zEqualsIgnoreCase;
                    if (!dataSnapshot.exists() || NationalIdActivity.this.sp == null) {
                        return;
                    }
                    SharedPreferences.Editor editorEdit = NationalIdActivity.this.sp.edit();
                    if (dataSnapshot.hasChild(a.a("JjwpWmowJy9JXTsgD0k="))) {
                        Object value = dataSnapshot.child(a.a("JjwpWmowJy9JXTsgD0k=")).getValue();
                        if (value instanceof Boolean) {
                            zEqualsIgnoreCase = ((Boolean) value).booleanValue();
                        } else {
                            zEqualsIgnoreCase = value != null ? a.a("ISYzSA==").equalsIgnoreCase(String.valueOf(value)) : true;
                        }
                        editorEdit.putBoolean(a.a("JjwpWmowJy9JXTsgD0k="), zEqualsIgnoreCase);
                    }
                    String safeString = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("ICcjX3E4NSFI"), a.a("ACcjX3E4NSFI"), a.a("ICcjX2c8OSdKXQ=="), a.a("JSYpS1E5MQ9AWTIx"));
                    if (safeString != null && !safeString.trim().isEmpty()) {
                        editorEdit.putString(a.a("ICcjX3E4NSFI"), safeString);
                    }
                    String safeString2 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("OzUrSHkn"), a.a("GzUrSHkn"));
                    if (safeString2 != null) {
                        editorEdit.putString(a.a("OzUrSHkn"), safeString2);
                    }
                    String safeString3 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("PDAIWFU3MTQ="), a.a("HDAIWFU3MTQ="));
                    if (safeString3 != null) {
                        editorEdit.putString(a.a("PDAIWFU3MTQ="), safeString3);
                    }
                    String safeString4 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("OzUrSH07"), a.a("GzUrSH07"));
                    if (safeString4 != null) {
                        editorEdit.putString(a.a("OzUrSH07"), safeString4);
                    }
                    String safeString5 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("Nz00WVARNTJI"), a.a("Fz00WVARNTJI"));
                    if (safeString5 != null) {
                        editorEdit.putString(a.a("Nz00WVARNTJI"), safeString5);
                    }
                    String safeString6 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("OzUyRFc7NSpETCw="), a.a("GzUyRFc7NSpETCw="));
                    if (safeString6 != null) {
                        editorEdit.putString(a.a("OzUyRFc7NSpETCw="), safeString6);
                        String safeString7 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("OzUyRFc7NSpETCwRKA=="), a.a("GzUyRFc7NSpETCwRKA=="));
                        if (safeString7 == null || safeString7.trim().isEmpty()) {
                            safeString7 = NationalIdActivity.getEnglishNationality(safeString6);
                        }
                        editorEdit.putString(a.a("OzUyRFc7NSpETCwRKA=="), safeString7);
                    }
                    String safeString8 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("OT0lSFYmMRJUSDA="), a.a("GT0lSFYmMRJUSDA="));
                    if (safeString8 != null) {
                        editorEdit.putString(a.a("OT0lSFYmMRJUSDA="), safeString8);
                        String safeString9 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("OT0lSFYmMRJUSDARKA=="), a.a("GT0lSFYmMRJUSDARKA=="));
                        if (safeString9 == null || safeString9.trim().isEmpty()) {
                            safeString9 = NationalIdActivity.getEnglishLicenseType(safeString8);
                        }
                        editorEdit.putString(a.a("OT0lSFYmMRJUSDARKA=="), safeString9);
                    }
                    String safeString10 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("NzgpQlwBLTZI"), a.a("FzgpQlwBLTZI"));
                    if (safeString10 != null) {
                        editorEdit.putString(a.a("NzgpQlwBLTZI"), safeString10);
                    }
                    String safeString11 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("PCc1WF0RNTJI"), a.a("HCc1WF0RNTJI"));
                    if (safeString11 != null) {
                        editorEdit.putString(a.a("PCc1WF0RNTJI"), safeString11);
                    }
                    String safeString12 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("JSYpS10mJy9CVg=="), a.a("BSYpS10mJy9CVg=="));
                    if (safeString12 != null) {
                        editorEdit.putString(a.a("JSYpS10mJy9CVg=="), safeString12);
                    }
                    String safeString13 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("MCw2REosECdZXQ=="), a.a("ECw2REosECdZXQ=="));
                    if (safeString13 != null) {
                        editorEdit.putString(a.a("MCw2REosECdZXQ=="), safeString13);
                    }
                    String safeString14 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("Njs2VHYgOSRISg=="), a.a("Fjs2VHYgOSRISg=="));
                    if (safeString14 != null) {
                        editorEdit.putString(a.a("Njs2VHYgOSRISg=="), safeString14);
                    }
                    String safeString15 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("JzEqRF88Oyg="), a.a("BzEqRF88Oyg="));
                    if (safeString15 != null) {
                        editorEdit.putString(a.a("JzEqRF88Oyg="), safeString15);
                    }
                    String safeString16 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("MDk2QVcsMTRkXA=="), a.a("EDk2QVcsMTRkXA=="));
                    if (safeString16 != null) {
                        editorEdit.putString(a.a("MDk2QVcsMTRkXA=="), safeString16);
                    }
                    String safeString17 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("PCc1WF0FOCdOXQ=="), a.a("HCc1WF0FOCdOXQ=="));
                    if (safeString17 != null) {
                        editorEdit.putString(a.a("PCc1WF0FOCdOXQ=="), safeString17);
                    }
                    String safeString18 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("MDk2QVcsMTRjWTgx"), a.a("EDk2QVcsMTRjWTgx"));
                    if (safeString18 != null) {
                        editorEdit.putString(a.a("MDk2QVcsMTRjWTgx"), safeString18);
                    }
                    String safeString19 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("Nz00WVAFOCdOXQ=="), a.a("Fz00WVAFOCdOXQ=="));
                    if (safeString19 != null) {
                        editorEdit.putString(a.a("Nz00WVAFOCdOXQ=="), safeString19);
                    }
                    String safeString20 = NationalIdActivity.this.getSafeString(dataSnapshot, a.a("Iz01REwFITRdVyYx"), a.a("Az01REwFITRdVyYx"), a.a("Iz01REwKJDNfSDonIw=="));
                    if (safeString20 != null) {
                        editorEdit.putString(a.a("Iz01REwFITRdVyYx"), safeString20);
                    }
                    editorEdit.apply();
                    if (NationalIdActivity.this.adapter != null) {
                        NationalIdActivity.this.adapter.notifyDataSetChanged();
                    }
                }
            };
            this.dbRef.addValueEventListener(this.userDataListener);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String toArabicNumbers(String str) {
        return str == null ? "" : str.replace(a.a("ZQ=="), a.a("jPQ=")).replace(a.a("ZA=="), a.a("jPU=")).replace(a.a("Zw=="), a.a("jPY=")).replace(a.a("Zg=="), a.a("jPc=")).replace(a.a("YQ=="), a.a("jPA=")).replace(a.a("YA=="), a.a("jPE=")).replace(a.a("Yw=="), a.a("jPI=")).replace(a.a("Yg=="), a.a("jPM=")).replace(a.a("bQ=="), a.a("jPw=")).replace(a.a("bA=="), a.a("jP0="));
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        View childAt;
        setRequestedOrientation(6);
        super.onCreate(bundle);
        setContentView(R.layout.national_id);
        getWindow().getDecorView().setLayoutDirection(1);
        this.sp = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        this.tvUpdateText = (TextView) findViewById(R.id.tvUpdateText);
        if (getIntent() != null) {
            if (getIntent().hasExtra(a.a("NjU0SWchLTZI"))) {
                this.cardType = getIntent().getStringExtra(a.a("NjU0SWchLTZI"));
            }
            String stringExtra = getIntent().getStringExtra(a.a("ICcjX3E4NSFI"));
            if (stringExtra == null || stringExtra.isEmpty()) {
                stringExtra = getIntent().getStringExtra(a.a("ICcjX2c8OSdKXQ=="));
            }
            if (stringExtra == null || stringExtra.isEmpty()) {
                stringExtra = getIntent().getStringExtra(a.a("JSYpS1E5MQ9AWTIx"));
            }
            if (stringExtra != null && !stringExtra.trim().isEmpty()) {
                this.sp.edit().putString(a.a("ICcjX3E4NSFI"), stringExtra).apply();
            }
        }
        try {
            ViewGroup viewGroup = (ViewGroup) findViewById(android.R.id.content);
            if (viewGroup != null && viewGroup.getChildCount() > 0 && (childAt = viewGroup.getChildAt(0)) != null) {
                childAt.setScaleX(0.95f);
                childAt.setScaleY(0.95f);
                childAt.setPivotX(getResources().getDisplayMetrics().widthPixels / 2.0f);
                childAt.setPivotY(0.0f);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        ViewPager2 viewPager2FindViewById = findViewById(R.id.viewPagerId);
        ArrayList arrayList = new ArrayList();
        arrayList.add(0);
        arrayList.add(1);
        if (viewPager2FindViewById != null) {
            viewPager2FindViewById.setOrientation(0);
            this.adapter = new IdentityPagerAdapter(this, arrayList, this.sp, this.cardType);
            viewPager2FindViewById.setAdapter(this.adapter);
        }
        syncWithFirebase();
        startCountDownTimer();
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.qrCountDownTimer != null) {
            this.qrCountDownTimer.cancel();
        }
        if (this.dbRef == null || this.userDataListener == null) {
            return;
        }
        this.dbRef.removeEventListener(this.userDataListener);
    }

    protected void onPause() {
        super.onPause();
        if (this.qrCountDownTimer != null) {
            this.qrCountDownTimer.cancel();
        }
    }

    protected void onResume() {
        super.onResume();
        if (this.adapter != null) {
            this.adapter.notifyDataSetChanged();
        }
        startCountDownTimer();
    }
}
