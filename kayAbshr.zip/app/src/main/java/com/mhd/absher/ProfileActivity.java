package com.mhd.absher;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileActivity extends AppCompatActivity {
    private LinearLayout cardMyNationalId;
    private DatabaseReference dbRef;
    private ImageView imgProfileUser;
    private ImageView imgTravelHistory;
    private RelativeLayout relativelayout12;
    private LinearLayout rowDrivingLicense;
    private LinearLayout rowRecruitmentRequests;
    private SharedPreferences sp;
    private TextView textview206;
    private TextView tvUserIdProfile;
    private TextView tvUserNameProfile;
    private ValueEventListener userDataListener;
    private View view101;

    public static Bitmap decodeBase64ToBitmap(String str) {
        if (str == null || str.trim().isEmpty()) {
            return null;
        }
        try {
            String strTrim = str.trim();
            if (strTrim.contains(a.a("eQ=="))) {
                strTrim = strTrim.substring(strTrim.indexOf(a.a("eQ==")) + 1);
            }
            byte[] bArrDecode = Base64.decode(strTrim.replaceAll(a.a("CSdt"), ""), 0);
            return BitmapFactory.decodeByteArray(bArrDecode, 0, bArrDecode.length);
        } catch (Exception e) {
            try {
                byte[] bArrDecode2 = Base64.decode(str.trim(), 2);
                return BitmapFactory.decodeByteArray(bArrDecode2, 0, bArrDecode2.length);
            } catch (Exception e2) {
                e2.printStackTrace();
                return null;
            }
        }
    }

    public String getSafeString(DataSnapshot dataSnapshot, String... strArr) {
        for (String str : strArr) {
            if (dataSnapshot.hasChild(str) && dataSnapshot.child(str).getValue() != null) {
                return String.valueOf(dataSnapshot.child(str).getValue());
            }
        }
        return null;
    }

    public boolean parseBoolean(DataSnapshot dataSnapshot, String str, boolean z) {
        if (!dataSnapshot.hasChild(str)) {
            return z;
        }
        Object value = dataSnapshot.child(str).getValue();
        if (value instanceof Boolean) {
            return ((Boolean) value).booleanValue();
        }
        return value != null ? a.a("ISYzSA==").equalsIgnoreCase(String.valueOf(value)) : z;
    }

    private void syncWithFirebase() {
        try {
            SharedPreferences sharedPreferences = getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
            SharedPreferences sharedPreferences2 = getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0);
            String string = sharedPreferences.getString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), "");
            if (string.isEmpty()) {
                string = sharedPreferences2.getString(a.a("ICcjX2swNzRITBww"), "");
            }
            if (string.isEmpty()) {
                string = this.sp.getString(a.a("ICcjX3MwLQ=="), this.sp.getString(a.a("JjElX10hHyNU"), ""));
            }
            if (string.isEmpty()) {
                this.dbRef = FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc="));
            } else {
                this.dbRef = FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(string);
            }
            this.userDataListener = new ValueEventListener() {
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }

                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        SharedPreferences.Editor editorEdit = ProfileActivity.this.sp.edit();
                        String safeString = ProfileActivity.this.getSafeString(dataSnapshot, a.a("OzUrSHkn"), a.a("GzUrSHkn"));
                        if (safeString != null) {
                            editorEdit.putString(a.a("OzUrSHkn"), safeString);
                        }
                        String safeString2 = ProfileActivity.this.getSafeString(dataSnapshot, a.a("PDAIWFU3MTQ="), a.a("HDAIWFU3MTQ="));
                        if (safeString2 != null) {
                            editorEdit.putString(a.a("PDAIWFU3MTQ="), safeString2);
                        }
                        if (dataSnapshot.hasChild(a.a("JjwpWns8IC9XXTsdIg=="))) {
                            editorEdit.putBoolean(a.a("JjwpWns8IC9XXTsdIg=="), ProfileActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWns8IC9XXTsdIg=="), true));
                        }
                        if (dataSnapshot.hasChild(a.a("JjwpWmowJy9JXTsgD0k="))) {
                            editorEdit.putBoolean(a.a("JjwpWmowJy9JXTsgD0k="), ProfileActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWmowJy9JXTsgD0k="), true));
                        }
                        if (dataSnapshot.hasChild(a.a("JjwpWm48Jy9ZVycdIg==")) || dataSnapshot.hasChild(a.a("JjwpWm48Jy9ZVycXJ19c"))) {
                            editorEdit.putBoolean(a.a("JjwpWm48Jy9ZVycdIg=="), ProfileActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWm48Jy9ZVycdIg=="), false));
                        }
                        if (dataSnapshot.hasChild(a.a("JjwpWnQ8NyNDSzA="))) {
                            editorEdit.putBoolean(a.a("JjwpWnQ8NyNDSzA="), ProfileActivity.this.parseBoolean(dataSnapshot, a.a("JjwpWnQ8NyNDSzA="), true));
                        }
                        String safeString3 = ProfileActivity.this.getSafeString(dataSnapshot, a.a("ICcjX3E4NSFI"), a.a("ACcjX3E4NSFI"), a.a("ICcjX2c8OSdKXQ=="), a.a("JSYpS1E5MQ9AWTIx"), a.a("JTwpWVc="), a.a("PDknSl0="), a.a("JTE0Xlc7NSp9UDogKQ=="), a.a("JT0lWU0nMQ=="));
                        if (safeString3 != null && !safeString3.trim().isEmpty()) {
                            editorEdit.putString(a.a("ICcjX3E4NSFI"), safeString3);
                            editorEdit.putString(a.a("ICcjX2c8OSdKXQ=="), safeString3);
                            editorEdit.putString(a.a("JSYpS1E5MQ9AWTIx"), safeString3);
                            editorEdit.putString(a.a("JTwpWVc="), safeString3);
                        }
                        editorEdit.apply();
                        ProfileActivity.this.updateUI();
                    }
                }
            };
            this.dbRef.addValueEventListener(this.userDataListener);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateUI() {
        Bitmap bitmapDecodeBase64ToBitmap;
        if (this.sp == null) {
            return;
        }
        String string = this.sp.getString(a.a("OzUrSHkn"), a.a("je2fqeHfdJ6U4dGNzA3g7I3C9LJ1jcT1n4zenoI="));
        String string2 = this.sp.getString(a.a("PDAIWFU3MTQ="), a.a("jPOfjOHwjeP0n4z9n4/h943i"));
        boolean z = this.sp.getBoolean(a.a("JjwpWns8IC9XXTsdIg=="), true);
        boolean z2 = this.sp.getBoolean(a.a("JjwpWmowJy9JXTsgD0k="), true);
        boolean z3 = this.sp.getBoolean(a.a("JjwpWm48Jy9ZVycdIg=="), false);
        boolean z4 = this.sp.getBoolean(a.a("JjwpWnQ8NyNDSzA="), true);
        String string3 = this.sp.getString(a.a("ICcjX3E4NSFI"), "");
        if (string3.isEmpty()) {
            string3 = this.sp.getString(a.a("ICcjX2c8OSdKXQ=="), "");
        }
        if (string3.isEmpty()) {
            string3 = this.sp.getString(a.a("JSYpS1E5MQ9AWTIx"), "");
        }
        String string4 = string3.isEmpty() ? this.sp.getString(a.a("JTwpWVc="), "") : string3;
        if (this.tvUserNameProfile != null) {
            this.tvUserNameProfile.setText(string);
        }
        if (this.tvUserIdProfile != null) {
            this.tvUserIdProfile.setText(string2);
        }
        if (this.textview206 != null) {
            if (z) {
                this.textview206.setText(a.a("jNGelOHRjc70vY3znocYjNOfpeHfjOz0snWM4fS8jNyemuHTjcz1kQ=="));
            } else if (!z2 && z3) {
                this.textview206.setText(a.a("jNGelOHRjc70vY3znocYjNOfpeHfjO8N4OeM4fWejeU="));
            } else {
                this.textview206.setText(a.a("jNGelOHRjc70vY3znocYjNOfpeHfjO8N4dCNxPSyjNE="));
            }
        }
        if (this.cardMyNationalId != null) {
            this.cardMyNationalId.setVisibility(z || z2 || z3 ? 0 : 8);
        }
        if (this.rowDrivingLicense != null) {
            this.rowDrivingLicense.setVisibility(z4 ? 0 : 8);
        }
        if (this.view101 != null) {
            this.view101.setVisibility(z4 ? 0 : 8);
        }
        if (this.imgProfileUser == null) {
            this.imgProfileUser = (ImageView) findViewById(R.id.ivUserPhotoProfile);
        }
        if (this.imgProfileUser == null || string4.isEmpty() || (bitmapDecodeBase64ToBitmap = decodeBase64ToBitmap(string4)) == null) {
            return;
        }
        this.imgProfileUser.setImageBitmap(bitmapDecodeBase64ToBitmap);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.profile);
        getWindow().getDecorView().setLayoutDirection(1);
        this.sp = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        this.tvUserNameProfile = (TextView) findViewById(R.id.tvUserNameProfile);
        this.tvUserIdProfile = (TextView) findViewById(R.id.tvUserIdProfile);
        this.imgProfileUser = (ImageView) findViewById(R.id.ivUserPhotoProfile);
        this.rowDrivingLicense = (LinearLayout) findViewById(R.id.rowDrivingLicense);
        this.view101 = findViewById(R.id.view101);
        this.cardMyNationalId = (LinearLayout) findViewById(R.id.cardMyNationalId);
        this.textview206 = (TextView) findViewById(R.id.textview206);
        this.relativelayout12 = (RelativeLayout) findViewById(R.id.relativelayout12);
        this.imgTravelHistory = (ImageView) findViewById(R.id.imgTravelHistory);
        this.rowRecruitmentRequests = (LinearLayout) findViewById(R.id.rowRecruitmentRequests);
        updateUI();
        ImageView imageView = (ImageView) findViewById(R.id.imageview205);
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (ProfileActivity.this.tvUserIdProfile != null) {
                        String string = ProfileActivity.this.tvUserIdProfile.getText().toString();
                        if (string.isEmpty()) {
                            Toast.makeText((Context) ProfileActivity.this, (CharSequence) a.a("jNCeihiM3p+l4PmM6Q3h04zzDeHRjcL0vo3nnoM="), 0).show();
                            return;
                        }
                        ClipboardManager clipboardManager = (ClipboardManager) ProfileActivity.this.getSystemService(a.a("NjgvXVo6NTRJ"));
                        if (clipboardManager != null) {
                            clipboardManager.setPrimaryClip(ClipData.newPlainText(a.a("Fjs2RF0xdA9p"), string));
                            Toast.makeText((Context) ProfileActivity.this, (CharSequence) a.a("jf6fqBiM0p6e4Pt0npzh143DDeDyjcL0v4zcn6fg/HSeheHTjOr1n435"), 0).show();
                        }
                    }
                }
            });
        }
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.layoutProfileCard);
        if (linearLayout != null) {
            linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent((Context) ProfileActivity.this, (Class<?>) PersonalInfoActivity.class);
                    if (ProfileActivity.this.tvUserNameProfile != null) {
                        intent.putExtra(a.a("AAcDf2cbFQto"), ProfileActivity.this.tvUserNameProfile.getText().toString());
                    }
                    ProfileActivity.this.startActivity(intent);
                }
            });
        }
        LinearLayout linearLayout2 = (LinearLayout) findViewById(R.id.cardMyPassport);
        if (linearLayout2 != null) {
            linearLayout2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ProfileActivity.this.startActivity(new Intent((Context) ProfileActivity.this, (Class<?>) PassportDetailsActivity.class));
                }
            });
        }
        ImageView imageView2 = (ImageView) findViewById(R.id.btnBackProfile);
        if (imageView2 != null) {
            imageView2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ProfileActivity.this.finish();
                }
            });
        }
        if (this.cardMyNationalId != null) {
            this.cardMyNationalId.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ProfileActivity.this.startActivity(new Intent((Context) ProfileActivity.this, (Class<?>) NationalIdDetailsActivity.class));
                }
            });
        }
        if (this.rowDrivingLicense != null) {
            this.rowDrivingLicense.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ProfileActivity.this.startActivity(new Intent((Context) ProfileActivity.this, (Class<?>) DrivingLicenseActivity.class));
                }
            });
        }
        View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProfileActivity.this.startActivity(new Intent((Context) ProfileActivity.this, (Class<?>) TravelHistoryActivity.class));
            }
        };
        if (this.relativelayout12 != null) {
            this.relativelayout12.setOnClickListener(onClickListener);
        }
        if (this.imgTravelHistory != null) {
            this.imgTravelHistory.setOnClickListener(onClickListener);
        }
        if (this.rowRecruitmentRequests != null) {
            this.rowRecruitmentRequests.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ProfileActivity.this.startActivity(new Intent((Context) ProfileActivity.this, (Class<?>) RecruitmentRequestsActivity.class));
                }
            });
        }
        LinearLayout linearLayout3 = (LinearLayout) findViewById(R.id.navHome);
        if (linearLayout3 != null) {
            linearLayout3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent((Context) ProfileActivity.this, (Class<?>) ActivityHomeActivity.class);
                    intent.addFlags(67108864);
                    ProfileActivity.this.startActivity(intent);
                }
            });
        }
        syncWithFirebase();
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.dbRef == null || this.userDataListener == null) {
            return;
        }
        this.dbRef.removeEventListener(this.userDataListener);
    }

    protected void onResume() {
        super.onResume();
        updateUI();
    }
}
