package com.almlkid.kay.ui;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Immutable description of the cursor context used by the native completion pipeline. */
public final class CompletionContext {
  public enum Kind { GLOBAL, MEMBER, CLASS, XML, GRADLE }

  private static final Pattern NEW_TYPE =
      Pattern.compile("(?:^|[^A-Za-z0-9_$])new\\s+([A-Za-z_$][A-Za-z0-9_$]*)?$");

  public final Kind kind;
  public final String prefix;
  public final String receiver;
  public final int tokenStart;

  private CompletionContext(Kind kind, String prefix, String receiver, int tokenStart) {
    this.kind = kind;
    this.prefix = prefix;
    this.receiver = receiver;
    this.tokenStart = tokenStart;
  }

  public static CompletionContext detect(String fileName, String source, int cursorOffset) {
    String text = source == null ? "" : source;
    int cursor = Math.max(0, Math.min(cursorOffset, text.length()));
    String lower = fileName == null ? "" : fileName.toLowerCase(Locale.US);
    if (lower.endsWith(".xml")) return new CompletionContext(Kind.XML, languagePrefix(text, cursor), "", cursor);
    if (lower.endsWith(".gradle") || lower.endsWith(".gradle.kts"))
      return new CompletionContext(Kind.GRADLE, languagePrefix(text, cursor), "", cursor);

    int start = CodeLanguageTools.completionStart(text, cursor);
    String prefix = text.substring(start, cursor);
    int dot = start - 1;
    while (dot >= 0 && Character.isWhitespace(text.charAt(dot))) dot--;
    if (dot >= 0 && text.charAt(dot) == '.') {
      return new CompletionContext(Kind.MEMBER, prefix, receiverBeforeDot(text, dot), start);
    }

    String localBefore = UsageSearchEngine.mask(text.substring(Math.max(0, cursor - 512), cursor));
    Matcher newType = NEW_TYPE.matcher(localBefore);
    if (newType.find()) return new CompletionContext(Kind.CLASS, newType.group(1), "", start);
    return new CompletionContext(Kind.GLOBAL, prefix, "", start);
  }

  private static String languagePrefix(String source, int cursor) {
    int start = cursor;
    while (start > 0) {
      char value = source.charAt(start - 1);
      if (Character.isJavaIdentifierPart(value) || value == '-' || value == '/' || value == '@') start--;
      else break;
    }
    return source.substring(start, cursor);
  }

  private static String receiverBeforeDot(String source, int dot) {
    int end = dot;
    while (end > 0 && Character.isWhitespace(source.charAt(end - 1))) end--;
    int start = end;
    while (start > 0) {
      char value = source.charAt(start - 1);
      if (Character.isJavaIdentifierPart(value) || value == '.') start--;
      else break;
    }
    return source.substring(start, end).trim();
  }
}
