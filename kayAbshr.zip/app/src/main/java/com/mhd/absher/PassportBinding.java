package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class PassportBinding {
    public final TextView ivBack;
    public final ImageView ivPassport;
    public final RelativeLayout rootPassport;
    public final RelativeLayout topBarPassport;
    public final TextView tvPassportTitle;

    private PassportBinding(RelativeLayout relativeLayout, ImageView imageView, RelativeLayout relativeLayout2, TextView textView, TextView textView2) {
        this.rootPassport = relativeLayout;
        this.ivPassport = imageView;
        this.topBarPassport = relativeLayout2;
        this.ivBack = textView;
        this.tvPassportTitle = textView2;
    }

    public static PassportBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        ImageView imageView = (ImageView) findChildViewById(view, R.id.ivPassport);
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBarPassport);
        TextView textView = (TextView) findChildViewById(view, R.id.ivBack);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvPassportTitle);
        if (imageView == null || relativeLayout2 == null || textView == null || textView2 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new PassportBinding(relativeLayout, imageView, relativeLayout2, textView, textView2);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static PassportBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static PassportBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.passport, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootPassport;
    }
}
