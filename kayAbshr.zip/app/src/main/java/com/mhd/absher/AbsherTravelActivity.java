package com.mhd.absher;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;
import com.google.firebase.FirebaseApp;

public class AbsherTravelActivity extends AppCompatActivity {
    private AbsherTravelBinding binding;

    private void initialize(Bundle bundle) {
    }

    private void initializeLogic() {
        setContentView(R.layout.absher_travel);
        ImageView imageView = (ImageView) findViewById(R.id.btnBack);
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AbsherTravelActivity.this.finish();
                }
            });
        }
        final LinearLayout linearLayout = (LinearLayout) findViewById(R.id.cardNotifications);
        TextView textView = (TextView) findViewById(R.id.tvClose);
        if (textView != null) {
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (linearLayout != null) {
                        linearLayout.setVisibility(8);
                    }
                }
            });
        }
        TextView textView2 = (TextView) findViewById(R.id.tvEnableNotif);
        if (textView2 != null) {
            textView2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText((Context) AbsherTravelActivity.this, (CharSequence) a.a("jf6fqBiN85+p4OOM/PWPdYz/9LyM3Wb1kozVnpTh343CDeDyjcL1nY3gnpTg8oz39Z+N/g=="), 0).show();
                }
            });
        }
        TextView textView3 = (TextView) findViewById(R.id.btnCreateTrip);
        if (textView3 != null) {
            textView3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText((Context) AbsherTravelActivity.this, (CharSequence) a.a("jfGfq+DhjOH1mXWM8fS8jfxm9YuM1Z6c"), 0).show();
                }
            });
        }
        LinearLayout linearLayout2 = (LinearLayout) findViewById(R.id.navHome);
        if (linearLayout2 != null) {
            linearLayout2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AbsherTravelActivity.this.finish();
                }
            });
        }
        LinearLayout linearLayout3 = (LinearLayout) findViewById(R.id.linear12);
        if (linearLayout3 != null) {
            linearLayout3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText((Context) AbsherTravelActivity.this, (CharSequence) a.a("jfqeguHQjOH1koze"), 0).show();
                }
            });
        }
        LinearLayout linearLayout4 = (LinearLayout) findViewById(R.id.linear11);
        if (linearLayout4 != null) {
            linearLayout4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText((Context) AbsherTravelActivity.this, (CharSequence) a.a("je2eiuDzjcL1koze"), 0).show();
                }
            });
        }
        LinearLayout linearLayout5 = (LinearLayout) findViewById(R.id.linear10);
        if (linearLayout5 != null) {
            linearLayout5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText((Context) AbsherTravelActivity.this, (CharSequence) a.a("je2fqODyjcL1koze"), 0).show();
                }
            });
        }
        LinearLayout linearLayout6 = (LinearLayout) findViewById(R.id.linear9);
        if (linearLayout6 != null) {
            linearLayout6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText((Context) AbsherTravelActivity.this, (CharSequence) a.a("jfqeguHQjOH1knWM5fWWjeWfpA=="), 0).show();
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = AbsherTravelBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        FirebaseApp.initializeApp(this);
        initializeLogic();
    }
}
