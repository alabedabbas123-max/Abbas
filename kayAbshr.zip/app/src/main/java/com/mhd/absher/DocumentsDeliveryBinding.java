package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class DocumentsDeliveryBinding {
    public final LinearLayout bottomNav;
    public final ImageView btnBack;
    public final Button btnCreate;
    public final LinearLayout contentWrap;
    public final ImageView imageview116;
    public final ImageView imageview117;
    public final ImageView imageview118;
    public final ImageView imageview119;
    public final ImageView imageview120;
    public final View indicatorReceived;
    public final View indicatorSent;
    public final ImageView ivEmptyIcon;
    public final LinearLayout linear124;
    public final LinearLayout navFamily;
    public final LinearLayout navHome;
    public final LinearLayout navMyServices;
    public final LinearLayout navOtherServices;
    public final LinearLayout navWorkers;
    public final RelativeLayout rootDelivery;
    public final LinearLayout tabReceived;
    public final LinearLayout tabSent;
    public final LinearLayout tabsRow;
    public final TextView textview208;
    public final TextView textview209;
    public final TextView textview210;
    public final TextView textview211;
    public final TextView textview212;
    public final RelativeLayout topBar;
    public final TextView tvMainMessage;
    public final TextView tvSubMessage;
    public final TextView tvTabReceived;
    public final TextView tvTabSent;
    public final TextView tvTitle;

    private DocumentsDeliveryBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, LinearLayout linearLayout, LinearLayout linearLayout2, ImageView imageView2, TextView textView2, LinearLayout linearLayout3, ImageView imageView3, TextView textView3, LinearLayout linearLayout4, ImageView imageView4, TextView textView4, LinearLayout linearLayout5, ImageView imageView5, TextView textView5, LinearLayout linearLayout6, ImageView imageView6, TextView textView6, LinearLayout linearLayout7, LinearLayout linearLayout8, LinearLayout linearLayout9, TextView textView7, View view, LinearLayout linearLayout10, TextView textView8, View view2, LinearLayout linearLayout11, ImageView imageView7, TextView textView9, TextView textView10, Button button) {
        this.rootDelivery = relativeLayout;
        this.topBar = relativeLayout2;
        this.btnBack = imageView;
        this.tvTitle = textView;
        this.bottomNav = linearLayout;
        this.navHome = linearLayout2;
        this.imageview120 = imageView2;
        this.textview212 = textView2;
        this.navMyServices = linearLayout3;
        this.imageview119 = imageView3;
        this.textview211 = textView3;
        this.navFamily = linearLayout4;
        this.imageview118 = imageView4;
        this.textview210 = textView4;
        this.navWorkers = linearLayout5;
        this.imageview117 = imageView5;
        this.textview209 = textView5;
        this.navOtherServices = linearLayout6;
        this.imageview116 = imageView6;
        this.textview208 = textView6;
        this.contentWrap = linearLayout7;
        this.tabsRow = linearLayout8;
        this.tabReceived = linearLayout9;
        this.tvTabReceived = textView7;
        this.indicatorReceived = view;
        this.tabSent = linearLayout10;
        this.tvTabSent = textView8;
        this.indicatorSent = view2;
        this.linear124 = linearLayout11;
        this.ivEmptyIcon = imageView7;
        this.tvMainMessage = textView9;
        this.tvSubMessage = textView10;
        this.btnCreate = button;
    }

    public static DocumentsDeliveryBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBar);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBack);
        TextView textView = (TextView) findChildViewById(view, R.id.tvTitle);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.bottomNav);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.navHome);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview120);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview212);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.navMyServices);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.imageview119);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview211);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.navFamily);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.imageview118);
        TextView textView4 = (TextView) findChildViewById(view, R.id.textview210);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.navWorkers);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.imageview117);
        TextView textView5 = (TextView) findChildViewById(view, R.id.textview209);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.navOtherServices);
        ImageView imageView6 = (ImageView) findChildViewById(view, R.id.imageview116);
        TextView textView6 = (TextView) findChildViewById(view, R.id.textview208);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.contentWrap);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.tabsRow);
        LinearLayout linearLayout9 = (LinearLayout) findChildViewById(view, R.id.tabReceived);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tvTabReceived);
        View viewFindChildViewById = findChildViewById(view, R.id.indicatorReceived);
        LinearLayout linearLayout10 = (LinearLayout) findChildViewById(view, R.id.tabSent);
        TextView textView8 = (TextView) findChildViewById(view, R.id.tvTabSent);
        View viewFindChildViewById2 = findChildViewById(view, R.id.indicatorSent);
        LinearLayout linearLayout11 = (LinearLayout) findChildViewById(view, R.id.linear124);
        ImageView imageView7 = (ImageView) findChildViewById(view, R.id.ivEmptyIcon);
        TextView textView9 = (TextView) findChildViewById(view, R.id.tvMainMessage);
        TextView textView10 = (TextView) findChildViewById(view, R.id.tvSubMessage);
        Button button = (Button) findChildViewById(view, R.id.btnCreate);
        if (relativeLayout2 == null || imageView == null || textView == null || linearLayout == null || linearLayout2 == null || imageView2 == null || textView2 == null || linearLayout3 == null || imageView3 == null || textView3 == null || linearLayout4 == null || imageView4 == null || textView4 == null || linearLayout5 == null || imageView5 == null || textView5 == null || linearLayout6 == null || imageView6 == null || textView6 == null || linearLayout7 == null || linearLayout8 == null || linearLayout9 == null || textView7 == null || viewFindChildViewById == null || linearLayout10 == null || textView8 == null || viewFindChildViewById2 == null || linearLayout11 == null || imageView7 == null || textView9 == null || textView10 == null || button == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new DocumentsDeliveryBinding(relativeLayout, relativeLayout2, imageView, textView, linearLayout, linearLayout2, imageView2, textView2, linearLayout3, imageView3, textView3, linearLayout4, imageView4, textView4, linearLayout5, imageView5, textView5, linearLayout6, imageView6, textView6, linearLayout7, linearLayout8, linearLayout9, textView7, viewFindChildViewById, linearLayout10, textView8, viewFindChildViewById2, linearLayout11, imageView7, textView9, textView10, button);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static DocumentsDeliveryBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static DocumentsDeliveryBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.documents_delivery, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootDelivery;
    }
}
