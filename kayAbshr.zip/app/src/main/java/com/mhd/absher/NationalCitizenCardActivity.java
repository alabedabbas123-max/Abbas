package com.mhd.absher;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.FirebaseApp;

public class NationalCitizenCardActivity extends AppCompatActivity {
    private NationalCitizenCardBinding binding;

    private void initialize(Bundle bundle) {
    }

    private void initializeLogic() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = NationalCitizenCardBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        FirebaseApp.initializeApp(this);
        initializeLogic();
    }
}
