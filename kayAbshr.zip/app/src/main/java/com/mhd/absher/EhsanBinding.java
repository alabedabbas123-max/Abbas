package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class EhsanBinding {
    public final ImageView btnBackEhsan;
    public final FrameLayout frameLayout4;
    public final ImageView imageview3;
    public final ImageView imageview4;
    public final LinearLayout linear3;
    public final RelativeLayout rootView;
    public final TextView textview4;
    public final TextView textview5;
    public final TextView textview6;
    public final RelativeLayout topHeaderEhsan;

    private EhsanBinding(RelativeLayout relativeLayout, ImageView imageView, LinearLayout linearLayout, FrameLayout frameLayout, ImageView imageView2, TextView textView, TextView textView2, RelativeLayout relativeLayout2, ImageView imageView3, TextView textView3) {
        this.rootView = relativeLayout;
        this.imageview4 = imageView;
        this.linear3 = linearLayout;
        this.frameLayout4 = frameLayout;
        this.imageview3 = imageView2;
        this.textview5 = textView;
        this.textview6 = textView2;
        this.topHeaderEhsan = relativeLayout2;
        this.btnBackEhsan = imageView3;
        this.textview4 = textView3;
    }

    public static EhsanBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        ImageView imageView = (ImageView) findChildViewById(view, R.id.imageview4);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear3);
        FrameLayout frameLayout = (FrameLayout) findChildViewById(view, R.id.frame_layout4);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview3);
        TextView textView = (TextView) findChildViewById(view, R.id.textview5);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview6);
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topHeaderEhsan);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.btnBackEhsan);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview4);
        if (imageView == null || linearLayout == null || frameLayout == null || imageView2 == null || textView == null || textView2 == null || relativeLayout2 == null || imageView3 == null || textView3 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new EhsanBinding(relativeLayout, imageView, linearLayout, frameLayout, imageView2, textView, textView2, relativeLayout2, imageView3, textView3);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static EhsanBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static EhsanBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.ehsan, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
