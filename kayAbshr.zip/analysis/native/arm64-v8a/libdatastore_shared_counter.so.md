# libdatastore_shared_counter.so

- المسار: `app/src/main/jniLibs/arm64-v8a/libdatastore_shared_counter.so`
- SHA-256: `d3e48717c9aa147e0ab21063ba0e8e0211cabf8bf40b222640829519edbf58e1`
- المعمارية: **ARM64 (AArch64)**
- ELF: 64-bit، الحجم: 6.9 KB
- Entry: `0x0`
- الحماية: NX=✓، RELRO=✓، PIE/ASLR=✓، Stack Canary=✓

## المكتبات المطلوبة (DT_NEEDED)

- `libm.so`
- `libdl.so`
- `libc.so`

## الأقسام

| القسم | العنوان | إزاحة الملف | الحجم | الصلاحيات |
|---|---:|---:|---:|---|
|.note.android.ident|0x238|0x238|152|A--|
|.note.gnu.build-id|0x2d0|0x2d0|36|A--|
|.dynsym|0x2f8|0x2f8|480|A--|
|.gnu.version|0x4d8|0x4d8|40|A--|
|.gnu.version_r|0x500|0x500|32|A--|
|.gnu.hash|0x520|0x520|76|A--|
|.hash|0x56c|0x56c|168|A--|
|.dynstr|0x614|0x614|699|A--|
|.rela.dyn|0x8d0|0x8d0|96|A--|
|.rela.plt|0x930|0x930|336|A--|
|.rodata|0xa80|0xa80|39|A--|
|.eh_frame_hdr|0xaa8|0xaa8|140|A--|
|.eh_frame|0xb38|0xb38|492|A--|
|.text|0xd30|0xd30|908|A-X|
|.plt|0x10c0|0x10c0|256|A-X|
|.data.rel.ro|0x51c0|0x11c0|8|AW-|
|.fini_array|0x51c8|0x11c8|16|AW-|
|.init_array|0x51d8|0x11d8|8|AW-|
|.dynamic|0x51e0|0x11e0|448|AW-|
|.got.plt|0x53a0|0x13a0|136|AW-|
|.bss|0x9428|0x1428|1|AW-|
|.comment|0x0|0x1428|178|---|
|.shstrtab|0x0|0x14da|231|---|

## الرموز والدوال

| النوع | الاسم | العنوان | الحجم |
|---|---|---:|---:|
|import|`__cxa_atexit`|0x0|0|
|import|`__cxa_finalize`|0x0|0|
|import|`__errno`|0x0|0|
|import|`__stack_chk_fail`|0x0|0|
|import|`__system_property_get`|0x0|0|
|import|`ftruncate`|0x0|0|
|import|`getauxval`|0x0|0|
|import|`mmap`|0x0|0|
|import|`strerror`|0x0|0|
|import|`strncmp`|0x0|0|
|function|`_Z16ThrowIoExceptionP7_JNIEnvPKc`|0xd80|92|
|function|`Java_androidx_datastore_core_NativeSharedCounter_nativeTruncateFile`|0xddc|120|
|function|`Java_androidx_datastore_core_NativeSharedCounter_nativeCreateSharedCounter`|0xe54|192|
|function|`Java_androidx_datastore_core_NativeSharedCounter_nativeGetCounterValue`|0xf14|24|
|function|`Java_androidx_datastore_core_NativeSharedCounter_nativeIncrementAndGetCounterValue`|0xf2c|24|
|function|`_ZN9datastore12TruncateFileEi`|0xf44|36|
|function|`_ZN9datastore19CreateSharedCounterEiPPv`|0xf68|88|
|function|`_ZN9datastore15GetCounterValueEPNSt6__ndk16atomicIjEE`|0xfc0|8|
|function|`_ZN9datastore27IncrementAndGetCounterValueEPNSt6__ndk16atomicIjEE`|0xfc8|32|

## معاينة التعليمات

```asm
; .text
0x00000D30  5F 24 03 D5  .word 0xD503245F
0x00000D34  20 00 00 B0  .word 0xB0000020
0x00000D38  00 00 07 91  .word 0x91070000
0x00000D3C  E9 00 00 14  b 0x10E0
0x00000D40  5F 24 03 D5  .word 0xD503245F
0x00000D44  C0 03 5F D6  ret
0x00000D48  5F 24 03 D5  .word 0xD503245F
0x00000D4C  FD FF FF 17  b 0xD40
0x00000D50  5F 24 03 D5  .word 0xD503245F
0x00000D54  60 00 00 B4  cbz w0, 0xD60
0x00000D58  F0 03 00 AA  .word 0xAA0003F0
0x00000D5C  00 02 1F D6  .word 0xD61F0200
0x00000D60  C0 03 5F D6  ret
0x00000D64  5F 24 03 D5  .word 0xD503245F
0x00000D68  E1 03 00 AA  .word 0xAA0003E1
0x00000D6C  00 00 00 90  .word 0x90000000
0x00000D70  22 00 00 B0  .word 0xB0000022
0x00000D74  00 40 35 91  .word 0x91354000
0x00000D78  42 00 07 91  .word 0x91070042
0x00000D7C  DD 00 00 14  b 0x10F0
0x00000D80  FD 7B BE A9  .word 0xA9BE7BFD
0x00000D84  F4 4F 01 A9  .word 0xA9014FF4
0x00000D88  FD 03 00 91  .word 0x910003FD
0x00000D8C  08 00 40 F9  .word 0xF9400008
0x00000D90  F3 03 01 AA  .word 0xAA0103F3
0x00000D94  01 00 00 90  .word 0x90000001
0x00000D98  F4 03 00 AA  .word 0xAA0003F4
0x00000D9C  21 2C 2A 91  .word 0x912A2C21
0x00000DA0  08 19 40 F9  .word 0xF9401908
0x00000DA4  00 01 3F D6  .word 0xD63F0100
0x00000DA8  20 01 00 B4  cbz w0, 0xDCC
0x00000DAC  88 02 40 F9  .word 0xF9400288
0x00000DB0  E1 03 00 AA  .word 0xAA0003E1
0x00000DB4  E0 03 14 AA  .word 0xAA1403E0
0x00000DB8  E2 03 13 AA  .word 0xAA1303E2
0x00000DBC  F4 4F 41 A9  .word 0xA9414FF4
0x00000DC0  03 39 40 F9  .word 0xF9403903
0x00000DC4  FD 7B C2 A8  .word 0xA8C27BFD
0x00000DC8  60 00 1F D6  .word 0xD61F0060
0x00000DCC  F4 4F 41 A9  .word 0xA9414FF4
0x00000DD0  00 00 80 12  .word 0x12800000
0x00000DD4  FD 7B C2 A8  .word 0xA8C27BFD
0x00000DD8  C0 03 5F D6  ret
0x00000DDC  FD 7B BE A9  .word 0xA9BE7BFD
0x00000DE0  F4 4F 01 A9  .word 0xA9014FF4
0x00000DE4  FD 03 00 91  .word 0x910003FD
0x00000DE8  F3 03 00 AA  .word 0xAA0003F3
0x00000DEC  E0 03 02 2A  .word 0x2A0203E0
0x00000DF0  C4 00 00 94  bl 0x1100
0x00000DF4  40 02 00 34  cbz w0, 0xE3C
0x00000DF8  C6 00 00 94  bl 0x1110
0x00000DFC  68 02 40 F9  .word 0xF9400268
0x00000E00  01 00 00 90  .word 0x90000001
0x00000E04  F4 03 00 AA  .word 0xAA0003F4
0x00000E08  21 2C 2A 91  .word 0x912A2C21
0x00000E0C  E0 03 13 AA  .word 0xAA1303E0
0x00000E10  08 19 40 F9  .word 0xF9401908
0x00000E14  00 01 3F D6  .word 0xD63F0100
0x00000E18  60 01 00 B4  cbz w0, 0xE44
0x00000E1C  68 02 40 F9  .word 0xF9400268
0x00000E20  E1 03 00 AA  .word 0xAA0003E1
0x00000E24  E0 03 13 AA  .word 0xAA1303E0
0x00000E28  E2 03 14 AA  .word 0xAA1403E2
0x00000E2C  08 39 40 F9  .word 0xF9403908
; .plt
0x000010C0  F0 7B BF A9  .word 0xA9BF7BF0
0x000010C4  30 00 00 90  .word 0x90000030
0x000010C8  11 DA 41 F9  .word 0xF941DA11
0x000010CC  10 C2 0E 91  .word 0x910EC210
0x000010D0  20 02 1F D6  .word 0xD61F0220
0x000010D4  1F 20 03 D5  nop
0x000010D8  1F 20 03 D5  nop
0x000010DC  1F 20 03 D5  nop
0x000010E0  30 00 00 90  .word 0x90000030
0x000010E4  11 DE 41 F9  .word 0xF941DE11
0x000010E8  10 E2 0E 91  .word 0x910EE210
0x000010EC  20 02 1F D6  .word 0xD61F0220
0x000010F0  30 00 00 90  .word 0x90000030
0x000010F4  11 E2 41 F9  .word 0xF941E211
0x000010F8  10 02 0F 91  .word 0x910F0210
0x000010FC  20 02 1F D6  .word 0xD61F0220
0x00001100  30 00 00 90  .word 0x90000030
0x00001104  11 E6 41 F9  .word 0xF941E611
0x00001108  10 22 0F 91  .word 0x910F2210
0x0000110C  20 02 1F D6  .word 0xD61F0220
0x00001110  30 00 00 90  .word 0x90000030
0x00001114  11 EA 41 F9  .word 0xF941EA11
0x00001118  10 42 0F 91  .word 0x910F4210
0x0000111C  20 02 1F D6  .word 0xD61F0220
0x00001120  30 00 00 90  .word 0x90000030
0x00001124  11 EE 41 F9  .word 0xF941EE11
0x00001128  10 62 0F 91  .word 0x910F6210
0x0000112C  20 02 1F D6  .word 0xD61F0220
0x00001130  30 00 00 90  .word 0x90000030
0x00001134  11 F2 41 F9  .word 0xF941F211
0x00001138  10 82 0F 91  .word 0x910F8210
0x0000113C  20 02 1F D6  .word 0xD61F0220
0x00001140  30 00 00 90  .word 0x90000030
0x00001144  11 F6 41 F9  .word 0xF941F611
0x00001148  10 A2 0F 91  .word 0x910FA210
0x0000114C  20 02 1F D6  .word 0xD61F0220
0x00001150  30 00 00 90  .word 0x90000030
0x00001154  11 FA 41 F9  .word 0xF941FA11
0x00001158  10 C2 0F 91  .word 0x910FC210
0x0000115C  20 02 1F D6  .word 0xD61F0220
0x00001160  30 00 00 90  .word 0x90000030
0x00001164  11 FE 41 F9  .word 0xF941FE11
0x00001168  10 E2 0F 91  .word 0x910FE210
0x0000116C  20 02 1F D6  .word 0xD61F0220
0x00001170  30 00 00 90  .word 0x90000030
0x00001174  11 02 42 F9  .word 0xF9420211
0x00001178  10 02 10 91  .word 0x91100210
0x0000117C  20 02 1F D6  .word 0xD61F0220
0x00001180  30 00 00 90  .word 0x90000030
0x00001184  11 06 42 F9  .word 0xF9420611
0x00001188  10 22 10 91  .word 0x91102210
0x0000118C  20 02 1F D6  .word 0xD61F0220
0x00001190  30 00 00 90  .word 0x90000030
0x00001194  11 0A 42 F9  .word 0xF9420A11
0x00001198  10 42 10 91  .word 0x91104210
0x0000119C  20 02 1F D6  .word 0xD61F0220
0x000011A0  30 00 00 90  .word 0x90000030
0x000011A4  11 0E 42 F9  .word 0xF9420E11
0x000011A8  10 62 10 91  .word 0x91106210
0x000011AC  20 02 1F D6  .word 0xD61F0220
0x000011B0  30 00 00 90  .word 0x90000030
0x000011B4  11 12 42 F9  .word 0xF9421211
0x000011B8  10 82 10 91  .word 0x91108210
0x000011BC  20 02 1F D6  .word 0xD61F0220
```

## سلامة التعديل

المحرر الداخلي لا يغير حجم التعليمات: يتحقق من المعمارية والمحاذاة وحدود المقطع التنفيذي، ويحفظ الأصل قبل أي كتابة ويستخدم استبدالاً ذرياً. للتغييرات البنيوية أو إعادة توزيع الأقسام استخدم حزمة Ghidra/IDA ثم أعد استيراد `.so`.
