package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class EmptyPageBinding {
    public final ImageView btnBackEmpty;
    public final ImageView ivEmptyIcon;
    public final LinearLayout linear122;
    public final RelativeLayout rootView;
    public final RelativeLayout topBar;
    public final TextView tvMainMessage;
    public final TextView tvSubMessage;
    public final TextView tvTitleEmpty;

    private EmptyPageBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, TextView textView, ImageView imageView, LinearLayout linearLayout, ImageView imageView2, TextView textView2, TextView textView3) {
        this.rootView = relativeLayout;
        this.topBar = relativeLayout2;
        this.tvTitleEmpty = textView;
        this.btnBackEmpty = imageView;
        this.linear122 = linearLayout;
        this.ivEmptyIcon = imageView2;
        this.tvMainMessage = textView2;
        this.tvSubMessage = textView3;
    }

    public static EmptyPageBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBar);
        TextView textView = (TextView) findChildViewById(view, R.id.tvTitleEmpty);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBackEmpty);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear122);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.ivEmptyIcon);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvMainMessage);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tvSubMessage);
        if (relativeLayout2 == null || textView == null || imageView == null || linearLayout == null || imageView2 == null || textView2 == null || textView3 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new EmptyPageBinding(relativeLayout, relativeLayout2, textView, imageView, linearLayout, imageView2, textView2, textView3);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static EmptyPageBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static EmptyPageBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.empty_page, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
