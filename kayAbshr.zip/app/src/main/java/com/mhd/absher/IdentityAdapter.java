package com.mhd.absher;

import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class IdentityAdapter extends RecyclerView.Adapter {
    private final List images;

    public class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView img;

        public ViewHolder(ImageView imageView) {
            super(imageView);
            this.img = imageView;
        }
    }

    public IdentityAdapter(List list) {
        this.images = list;
    }

    public int getItemCount() {
        if (this.images == null) {
            return 0;
        }
        return this.images.size();
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.img.setImageResource(((Integer) this.images.get(i)).intValue());
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        ImageView imageView = new ImageView(viewGroup.getContext());
        imageView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        return new ViewHolder(imageView);
    }
}
