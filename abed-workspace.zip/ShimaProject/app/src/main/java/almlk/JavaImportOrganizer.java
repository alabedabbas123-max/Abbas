package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Source-only Java import cleanup with conservative removal and optional missing-import resolution. */
public final class JavaImportOrganizer {
  private JavaImportOrganizer() {}

  private static final Pattern IMPORT_LINE = Pattern.compile(
      "^import\\s+(static\\s+)?([\\p{javaJavaIdentifierPart}.*]+)\\s*;\\s*$");
  private static final Pattern PACKAGE_LINE = Pattern.compile(
      "^package\\s+([\\p{javaJavaIdentifierPart}.]+)\\s*;\\s*$");
  private static final Pattern TYPE_DECLARATION = Pattern.compile(
      "\\b(?:class|interface|enum|record)\\s+([\\p{javaJavaIdentifierStart}][\\p{javaJavaIdentifierPart}]*)");
  private static final Pattern IDENTIFIER = Pattern.compile(
      "[\\p{javaJavaIdentifierStart}][\\p{javaJavaIdentifierPart}]*");

  private static final Map<String, String> COMMON_TYPES = commonTypes();

  private static final class ImportLine {
    final String name;
    final boolean isStatic;
    final int start, end;
    ImportLine(String name, boolean isStatic, int start, int end) {
      this.name = name;
      this.isStatic = isStatic;
      this.start = start;
      this.end = end;
    }
  }

  /**
   * Organizes existing imports and adds unambiguous imports from the supplied project candidates
   * and the conservative built-in type catalogue. Comments and string contents do not count as
   * usages. A non-positive collapse threshold disables package wildcard conversion.
   */
  public static String organize(String source, List<String> projectCandidates, int collapseThreshold) {
    if (source == null || source.isEmpty()) return source;
    String masked = JavaSourceScanner.maskNonCode(source);
    ArrayList<ImportLine> existing = new ArrayList<>();
    String packageName = "";
    StringBuilder bodyBuilder = new StringBuilder(source.length());
    int insertion = -1;
    boolean sawPackage = false;
    int firstTypeOffset = firstTypeOffset(masked);
    int cursor = 0;
    while (cursor < source.length()) {
      int newline = source.indexOf('\n', cursor);
      int lineEnd = newline < 0 ? source.length() : newline;
      int lineWithEnding = newline < 0 ? lineEnd : newline + 1;
      String codeLine = masked.substring(cursor, lineEnd).trim();
      Matcher importMatcher = IMPORT_LINE.matcher(codeLine);
      if (importMatcher.matches()) {
        String name = importMatcher.group(2).trim();
        existing.add(new ImportLine(name, importMatcher.group(1) != null, cursor, lineWithEnding));
      } else {
        Matcher packageMatcher = PACKAGE_LINE.matcher(codeLine);
        if (packageMatcher.matches() && !sawPackage) {
          packageName = packageMatcher.group(1);
          sawPackage = true;
        } else if (insertion < 0 && cursor >= firstTypeOffset && firstTypeOffset >= 0) {
          insertion = bodyBuilder.length();
        }
        bodyBuilder.append(source, cursor, lineWithEnding);
        if (packageMatcher.matches() && sawPackage) insertion = bodyBuilder.length();
      }
      cursor = lineWithEnding;
    }
    if (source.charAt(source.length() - 1) != '\n') {
      // The final line is already copied (or removed) by the loop; no synthetic newline is added.
    }
    if (insertion < 0) insertion = bodyBuilder.length();
    String body = bodyBuilder.toString();

    String usageSource = JavaSourceScanner.maskNonCode(source);
    char[] usage = usageSource.toCharArray();
    for (ImportLine line : existing) {
      for (int i = line.start; i < line.end && i < usage.length; i++)
        if (usage[i] != '\n' && usage[i] != '\r') usage[i] = ' ';
    }
    String usedCode = new String(usage);

    TreeSet<String> regular = new TreeSet<>(IMPORT_ORDER);
    TreeSet<String> staticImports = new TreeSet<>(IMPORT_ORDER);
    Set<String> explicitSimpleNames = new LinkedHashSet<>();
    for (ImportLine line : existing) {
      String simple = simpleName(line.name);
      if (!line.name.endsWith(".*")) explicitSimpleNames.add(simple);
      if (line.name.endsWith(".*")) {
        (line.isStatic ? staticImports : regular).add(line.name);
        continue;
      }
      if (isUsed(usedCode, simple)) (line.isStatic ? staticImports : regular).add(line.name);
    }

    Set<String> declaredTypes = declaredTypes(masked);
    Map<String, TreeSet<String>> candidatesBySimpleName = new TreeMap<>();
    addCandidates(candidatesBySimpleName, projectCandidates);
    for (String identifier : classLikeIdentifiers(masked)) {
      if (explicitSimpleNames.contains(identifier) || declaredTypes.contains(identifier)
          || !isUsed(usedCode, identifier)) continue;
      String candidate = COMMON_TYPES.get(identifier);
      if (candidate != null) addCandidate(candidatesBySimpleName, candidate);
    }
    for (Map.Entry<String, TreeSet<String>> entry : candidatesBySimpleName.entrySet()) {
      String simple = entry.getKey();
      if (declaredTypes.contains(simple) || explicitSimpleNames.contains(simple)
          || !isUsed(usedCode, simple)) continue;
      TreeSet<String> options = entry.getValue();
      if (options.size() != 1) continue;
      String candidate = options.first();
      int split = candidate.lastIndexOf('.');
      if (split <= 0) continue;
      String candidatePackage = candidate.substring(0, split);
      if (candidatePackage.equals(packageName) || candidatePackage.equals("java.lang")) continue;
      if (coveredByWildcard(candidatePackage, regular)) continue;
      regular.add(candidate);
    }

    if (collapseThreshold > 0) collapsePackages(regular, collapseThreshold);
    ArrayList<String> allImports = new ArrayList<>();
    allImports.addAll(regular);
    for (String item : staticImports) allImports.add("static " + item);
    if (existing.isEmpty() && allImports.isEmpty()) return source;

    String newline = source.contains("\r\n") ? "\r\n" : "\n";
    int safeInsertion = Math.max(0, Math.min(insertion, body.length()));
    String prefix = trimTrailingLineBreaks(body.substring(0, safeInsertion));
    String suffix = stripLeadingLineBreaks(body.substring(safeInsertion));
    StringBuilder organized = new StringBuilder(body.length() + allImports.size() * 24 + 8);
    organized.append(prefix);
    if (!prefix.isEmpty()) organized.append(newline).append(newline);
    for (String item : allImports) {
      organized.append("import ").append(item).append(';').append(newline);
    }
    if (!suffix.isEmpty()) {
      if (!allImports.isEmpty()) organized.append(newline);
      organized.append(suffix);
    }
    return organized.toString();
  }

  /** Returns the first source offset containing a top-level type declaration, or -1. */
  public static int firstTypeOffset(String source) {
    if (source == null || source.isEmpty()) return -1;
    String masked = JavaSourceScanner.maskNonCode(source);
    Matcher matcher = TYPE_DECLARATION.matcher(masked);
    return matcher.find() ? matcher.start() : -1;
  }

  /** Uppercase-leading Java identifiers present in executable/type source, excluding literals. */
  public static Set<String> classLikeIdentifiers(String source) {
    if (source == null || source.isEmpty()) return Collections.emptySet();
    char[] code = JavaSourceScanner.maskNonCode(source).toCharArray();
    int start = 0;
    while (start < code.length) {
      int end = start;
      while (end < code.length && code[end] != '\n') end++;
      String line = new String(code, start, end - start).trim();
      if (line.startsWith("package ") || line.startsWith("import ")) {
        for (int i = start; i < end; i++) if (code[i] != '\r') code[i] = ' ';
      }
      start = end + 1;
    }
    LinkedHashSet<String> result = new LinkedHashSet<>();
    Matcher matcher = IDENTIFIER.matcher(new String(code));
    while (matcher.find()) {
      String value = matcher.group();
      if (!value.isEmpty() && Character.isUpperCase(value.charAt(0))) result.add(value);
    }
    return result;
  }

  private static Set<String> declaredTypes(String masked) {
    LinkedHashSet<String> result = new LinkedHashSet<>();
    Matcher matcher = TYPE_DECLARATION.matcher(masked);
    while (matcher.find()) result.add(matcher.group(1));
    return result;
  }

  private static void addCandidates(Map<String, TreeSet<String>> bySimple, List<String> candidates) {
    if (candidates == null) return;
    for (String candidate : candidates) addCandidate(bySimple, candidate);
  }

  private static void addCandidate(Map<String, TreeSet<String>> bySimple, String value) {
    if (value == null) return;
    String candidate = value.trim();
    if (candidate.startsWith("import ")) candidate = candidate.substring(7).trim();
    if (candidate.startsWith("static ")) return;
    if (candidate.endsWith(".*")) return;
    int split = candidate.lastIndexOf('.');
    if (split <= 0 || split == candidate.length() - 1) return;
    String simple = candidate.substring(split + 1);
    if (!Character.isJavaIdentifierStart(simple.charAt(0))) return;
    bySimple.computeIfAbsent(simple, ignored -> new TreeSet<>(IMPORT_ORDER)).add(candidate);
  }

  private static boolean isUsed(String masked, String name) {
    if (name == null || name.isEmpty()) return false;
    Matcher matcher = Pattern.compile("(?<![\\p{javaJavaIdentifierPart}])"
        + Pattern.quote(name) + "(?![\\p{javaJavaIdentifierPart}])").matcher(masked);
    return matcher.find();
  }

  private static boolean coveredByWildcard(String packageName, Set<String> imports) {
    return imports.contains(packageName + ".*");
  }

  private static void collapsePackages(TreeSet<String> imports, int threshold) {
    Map<String, List<String>> byPackage = new LinkedHashMap<>();
    for (String item : imports) {
      if (item.endsWith(".*")) continue;
      int split = item.lastIndexOf('.');
      if (split <= 0) continue;
      byPackage.computeIfAbsent(item.substring(0, split), ignored -> new ArrayList<>()).add(item);
    }
    for (Map.Entry<String, List<String>> entry : byPackage.entrySet()) {
      if (entry.getValue().size() > threshold) {
        imports.removeAll(entry.getValue());
        imports.add(entry.getKey() + ".*");
      }
    }
  }

  private static String simpleName(String qualifiedName) {
    int dot = qualifiedName.lastIndexOf('.');
    return dot < 0 ? qualifiedName : qualifiedName.substring(dot + 1);
  }

  private static String trimTrailingLineBreaks(String value) {
    int end = value.length();
    while (end > 0 && (value.charAt(end - 1) == '\n' || value.charAt(end - 1) == '\r')) end--;
    return value.substring(0, end);
  }

  private static String stripLeadingLineBreaks(String value) {
    int start = 0;
    while (start < value.length() && (value.charAt(start) == '\n' || value.charAt(start) == '\r')) start++;
    return value.substring(start);
  }

  private static final Comparator<String> IMPORT_ORDER = (first, second) -> {
    int insensitive = first.compareToIgnoreCase(second);
    return insensitive != 0 ? insensitive : first.compareTo(second);
  };

  private static Map<String, String> commonTypes() {
    Map<String, String> types = new LinkedHashMap<>();
    addTypes(types, "java.util", "ArrayDeque ArrayList Arrays BitSet Calendar Collection Collections Comparator Deque EnumMap EnumSet Enumeration HashMap HashSet Hashtable Iterator LinkedHashMap LinkedHashSet LinkedList List Locale Map NavigableMap NavigableSet Objects Optional Properties Queue Random Scanner Set SortedMap SortedSet Stack StringTokenizer Timer TreeMap TreeSet UUID Vector WeakHashMap");
    addTypes(types, "java.io", "BufferedInputStream BufferedOutputStream BufferedReader BufferedWriter ByteArrayInputStream ByteArrayOutputStream File FileInputStream FileNotFoundException FileOutputStream FileReader FileWriter FilterInputStream FilterOutputStream IOException InputStream InputStreamReader ObjectInputStream ObjectOutputStream OutputStream OutputStreamWriter PrintStream PrintWriter Reader Serializable StringReader StringWriter Writer");
    addTypes(types, "java.nio.file", "CopyOption DirectoryStream FileSystem FileSystems Files LinkOption Path PathMatcher Paths StandardCopyOption WatchKey WatchService");
    addTypes(types, "java.nio.charset", "Charset StandardCharsets");
    addTypes(types, "java.net", "HttpURLConnection InetAddress InetSocketAddress URI URL URLConnection URLEncoder URLDecoder");
    addTypes(types, "java.util.concurrent", "Callable CompletionService CountDownLatch CyclicBarrier Executor ExecutorService Executors Future FutureTask ScheduledExecutorService Semaphore TimeUnit TimeoutException");
    addTypes(types, "java.util.concurrent.atomic", "AtomicBoolean AtomicInteger AtomicLong AtomicReference");
    addTypes(types, "java.util.regex", "Matcher Pattern");
    addTypes(types, "java.text", "DateFormat DecimalFormat NumberFormat SimpleDateFormat");
    addTypes(types, "java.math", "BigDecimal BigInteger MathContext RoundingMode");
    addTypes(types, "java.time", "Clock Duration Instant LocalDate LocalDateTime LocalTime MonthDay Period Year YearMonth ZoneId ZonedDateTime");
    addTypes(types, "android.app", "Activity AlertDialog Application Dialog ProgressDialog Service");
    addTypes(types, "android.content", "BroadcastReceiver ContentProvider ContentResolver Context DialogInterface Intent SharedPreferences");
    addTypes(types, "android.os", "AsyncTask Bundle Handler Looper Message Parcelable StrictMode SystemClock");
    addTypes(types, "android.view", "Gravity KeyEvent LayoutInflater Menu MenuItem MotionEvent View ViewGroup Window");
    addTypes(types, "android.widget", "Adapter ArrayAdapter Button CheckBox EditText FrameLayout ImageButton ImageView LinearLayout ListView ProgressBar RelativeLayout ScrollView Spinner TextView Toast");
    addTypes(types, "android.graphics", "Bitmap BitmapFactory Canvas Color Paint Rect Typeface");
    addTypes(types, "android.net", "Uri ConnectivityManager NetworkInfo");
    addTypes(types, "androidx.recyclerview.widget", "LinearLayoutManager RecyclerView GridLayoutManager");
    addTypes(types, "androidx.appcompat.app", "AppCompatActivity AlertDialog");
    return Collections.unmodifiableMap(types);
  }

  private static void addTypes(Map<String, String> target, String packageName, String values) {
    for (String value : values.split(" ")) target.put(value, packageName + "." + value);
  }
}
