package com.mhd.absher;

import android.content.Context;
import android.content.Intent;
import com.a.a.a.a.a;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SketchLogger {
    private static volatile boolean isRunning = false;
    private static Thread loggerThread = new Thread() {
        @Override
        public void run() {
            SketchLogger.isRunning = true;
            try {
                Runtime.getRuntime().exec(a.a("OTshTlkhdGtO"));
                Throwable th = null;
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(a.a("OTshTlkh")).getInputStream()));
                    try {
                        String line = bufferedReader.readLine();
                        do {
                            SketchLogger.broadcastLog(line);
                            if (!SketchLogger.isRunning) {
                                break;
                            } else {
                                line = bufferedReader.readLine();
                            }
                        } while (line != null);
                        if (SketchLogger.isRunning) {
                            SketchLogger.broadcastLog(a.a("GTshSl0ndCFCTHU/L0FUMDBoDWowJzJMSiE9KEoW"));
                            SketchLogger.startLogging();
                        } else {
                            SketchLogger.broadcastLog(a.a("GTshSl0ndDVZVyUkI0kW"));
                        }
                        if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                    } catch (Throwable th2) {
                        if (bufferedReader == null) {
                            throw th2;
                        }
                        bufferedReader.close();
                        throw th2;
                    }
                } catch (Throwable th3) {
                    if (0 == 0) {
                        throw th3;
                    }
                    if (null != th3) {
                        th.addSuppressed(th3);
                    }
                }
            } catch (IOException e) {
                SketchLogger.broadcastLog(e.getMessage());
            }
        }
    };

    public static void broadcastLog(String str) {
        Context context = SketchApplication.getContext();
        Intent intent = new Intent();
        intent.setAction(a.a("JSYpA0s+MTJOUCI1NEgWFBcSZHcbCwhobwoQA29tEgsKYn8="));
        intent.putExtra(a.a("OTsh"), str);
        intent.putExtra(a.a("JTUlRlkyMQhMVTA="), context.getPackageName());
        context.sendBroadcast(intent);
    }

    public static synchronized void startLogging() {
        if (isRunning) {
            broadcastLog(a.a("GTshSl0ndCdBSjA1IlQYJyEoQ1E7Mw=="));
        } else {
            loggerThread.start();
        }
    }

    public static synchronized void stopLogging() {
        if (isRunning) {
            isRunning = false;
            broadcastLog(a.a("BiApXUg8OiENVDozIUhKdTY/DU0mMTQNSjAlM0hLIXo="));
        } else {
            broadcastLog(a.a("GTshSl0ndChCTHUmM0NWPDoh"));
        }
    }
}
