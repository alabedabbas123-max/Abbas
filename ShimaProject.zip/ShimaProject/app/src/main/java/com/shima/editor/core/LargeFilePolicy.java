package com.shima.editor.core;

public final class LargeFilePolicy {
  public enum Mode { FULL_EDIT, PARTIAL_ANALYSIS, VIEWPORT_ONLY, READ_ONLY }

  public final long fullEditLimit = 2L * 1024L * 1024L;
  public final long partialAnalysisLimit = 20L * 1024L * 1024L;
  public final long viewportLimit = 100L * 1024L * 1024L;

  public Mode mode(long bytes) {
    if (bytes < fullEditLimit) return Mode.FULL_EDIT;
    if (bytes < partialAnalysisLimit) return Mode.PARTIAL_ANALYSIS;
    if (bytes <= viewportLimit) return Mode.VIEWPORT_ONLY;
    return Mode.READ_ONLY;
  }

  public boolean editable(long bytes) {
    Mode value = mode(bytes);
    return value == Mode.FULL_EDIT || value == Mode.PARTIAL_ANALYSIS;
  }
}
