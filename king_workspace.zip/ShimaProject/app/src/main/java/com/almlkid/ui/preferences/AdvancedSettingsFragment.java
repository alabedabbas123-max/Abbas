package com.almlkid.ui.preferences;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.widget.EditText;
import android.widget.Toast;
import almlk.AppSettings;
import com.shima.demo.R;
import com.shima.demo.ThemeActivity;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Map;
import org.json.JSONObject;

/**
 * تبويب Advanced Settings — المرحلة 4: الشاشات الثمان كما اللقطة، وكل أمر بمعالج حي:
 * ثيم/رموز سريعة/خط/خلفية (تُطبق فورًا)، ملفات gradle/proguard، نسخ/استعادة،
 * تحديث/جهات (حوارات محلية صادقة).
 */
public class AdvancedSettingsFragment extends BasePreferenceFragment {

  private static final int REQUEST_BG_IMAGE = 100;

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    SharedPreferences sp = AppSettings.prefs(getActivity());
    String home = sp.getString("project_home", null);
    if (home == null || !home.startsWith("/"))
      sp.edit().putString("project_home", "/sdcard/AppProject").apply();

    addPreferencesFromResource(R.xml.preferences_advanced_setting);

    click("preference_highlight", p -> {
      startActivity(new Intent(getActivity(), ThemeActivity.class));
      return true;
    });
    click("preference_quick_key", p -> { promptQuickKey(); return true; });
    change("disable_quickkeybar", (p, v) -> { visual(); return true; });
    change("advanced_setting_editor_font", (p, v) -> { visual(); return true; });
    change("advanced_setting_editor_bg", (p, v) -> { visual(); return true; });
    click("choose_bg_image", p -> {
      Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
      intent.setType("image/*");
      try {
        startActivityForResult(intent, REQUEST_BG_IMAGE);
      } catch (Exception e) {
        Toast.makeText(getActivity(), "لا منتقي ملفات متاح", Toast.LENGTH_SHORT).show();
      }
      return true;
    });
    click("advanced_setting_pref_gradle_config", p -> {
      BuildActions.Delegate d = BuildActions.delegate;
      if (d != null) d.configureGradle();
      return true;
    });
    click("add_proguard_config", p -> {
      BuildActions.Delegate d = BuildActions.delegate;
      if (d != null) d.writeProguardConfig();
      return true;
    });
    click("preference_stringfog", p -> {
      info("StringFog", "تشفير السلاسل داخل ملفات class زمن الترجمة. يُحترم المفتاح ضمن نطاق"
          + " بنائنا الداخلي فقط.");
      return true;
    });
    click("gradle_comple", p -> {
      info("Gradle completion", "قاعدة واحدة في كل سطر؛ الملف المخصص من المفتاح المجاور، وإلا"
          + " الافتراضي.");
      return true;
    });
    click("shima_backup", p -> { backup(); return true; });
    click("shima_restore", p -> { restore(); return true; });

    Preference log = findPreference("shima_update_log");
    if (log != null) {
      String detected = "";
      try {
        detected = getActivity().getPackageManager()
            .getPackageInfo(getActivity().getPackageName(), 0).versionName;
      } catch (Exception ignored) {
        // بلا معلومات إصدار
      }
      final String version = detected;
      log.setSummary(version == null ? "" : version);
      log.setOnPreferenceClickListener(p -> {
        info("Update log", "شيما " + version + "\nخطة الإعدادات: خمس مراحل — مضيف بتبويبين،"
            + " مستهلكون حقيقيون لكل قسم، إحلال شامل.");
        return true;
      });
    }
    click("shima_check_update", p -> {
      info("Check for updates", "لا قناة تحديث خارجية في هذا البناء؛ التحديثات تصل مع"
          + " الإصدارات الموقّعة.");
      return true;
    });
    click("aidero_sponsor", p -> {
      info("Sponsor", "شكرًا لدعمك؛ الدعم يُبقي التطوير مستمرًا.");
      return true;
    });
  }

  @Override
  public void onActivityResult(int request, int result, Intent data) {
    super.onActivityResult(request, result, data);
    if (request != REQUEST_BG_IMAGE || result != -1 || data == null || data.getData() == null)
      return;
    String path = data.getData().getPath();
    if (path == null) {
      Toast.makeText(getActivity(), "مسار غير صالح", Toast.LENGTH_SHORT).show();
      return;
    }
    AppSettings.prefs(getActivity()).edit().putString("advanced_setting_editor_bg", path).apply();
    Toast.makeText(getActivity(), "ضُبطت الخلفية: " + path, Toast.LENGTH_SHORT).show();
    visual();
  }

  private void visual() {
    BuildActions.Delegate d = BuildActions.delegate;
    if (d != null) d.applyEditorVisual();
  }

  private void promptQuickKey() {
    EditText edit = new EditText(getActivity());
    edit.setHint("مثال: {}();=+");
    edit.setText(AppSettings.prefs(getActivity()).getString("quick_key_symbol", ""));
    new AlertDialog.Builder(getActivity())
        .setTitle("Custom shortcut symbols")
        .setView(edit)
        .setPositiveButton("حفظ", (d, w) -> {
          AppSettings.prefs(getActivity())
              .edit()
              .putString("quick_key_symbol", edit.getText().toString())
              .apply();
          visual();
        })
        .setNegativeButton("إلغاء", null)
        .show();
  }

  private void info(String title, String message) {
    new AlertDialog.Builder(getActivity())
        .setTitle(title)
        .setMessage(message)
        .setPositiveButton("حسنًا", null)
        .show();
  }

  private File backupFile() {
    return new File(getActivity().getExternalFilesDir(null), "shima_backup.json");
  }

  /** تصدير كل التفضيلات JSON بوسوم أنواع — ملف واحد في مجلد التطبيق الخارجي. */
  private void backup() {
    try {
      Map<String, ?> all = AppSettings.prefs(getActivity()).getAll();
      JSONObject root = new JSONObject();
      for (Map.Entry<String, ?> entry : all.entrySet()) {
        Object value = entry.getValue();
        if (value instanceof Boolean) root.put(entry.getKey(), "B|" + value);
        else if (value instanceof Integer) root.put(entry.getKey(), "I|" + value);
        else if (value instanceof Long) root.put(entry.getKey(), "L|" + value);
        else if (value instanceof Float) root.put(entry.getKey(), "F|" + value);
        else root.put(entry.getKey(), "S|" + value);
      }
      FileOutputStream out = new FileOutputStream(backupFile());
      out.write(root.toString().getBytes("UTF-8"));
      out.close();
      Toast.makeText(getActivity(), "نُسخ احتياطيًا: " + backupFile().getAbsolutePath(),
          Toast.LENGTH_LONG).show();
    } catch (Exception error) {
      Toast.makeText(getActivity(), "تعذّر النسخ الاحتياطي", Toast.LENGTH_SHORT).show();
    }
  }

  /** استيراد من ملف النسخة — يُعيد كل مفتاح بنوعه. */
  private void restore() {
    File file = backupFile();
    if (!file.isFile()) {
      Toast.makeText(getActivity(), "لا نسخة احتياطية بعد", Toast.LENGTH_SHORT).show();
      return;
    }
    try {
      FileInputStream in = new FileInputStream(file);
      byte[] buffer = new byte[(int) file.length()];
      in.read(buffer);
      in.close();
      JSONObject root = new JSONObject(new String(buffer, "UTF-8"));
      SharedPreferences.Editor editor = AppSettings.prefs(getActivity()).edit();
      java.util.Iterator<String> keys = root.keys();
      if (!keys.hasNext()) throw new Exception("فارغ");
      while (keys.hasNext()) {
        String key = keys.next();
        String tagged = root.getString(key);
        int bar = tagged.indexOf('|');
        if (bar < 1) continue;
        String type = tagged.substring(0, bar);
        String value = tagged.substring(bar + 1);
        if ("B".equals(type)) editor.putBoolean(key, Boolean.parseBoolean(value));
        else if ("I".equals(type)) editor.putInt(key, Integer.parseInt(value));
        else if ("L".equals(type)) editor.putLong(key, Long.parseLong(value));
        else if ("F".equals(type)) editor.putFloat(key, Float.parseFloat(value));
        else editor.putString(key, value);
      }
      editor.apply();
      Toast.makeText(getActivity(), "استُعيدت الإعدادات", Toast.LENGTH_LONG).show();
      visual();
    } catch (Exception error) {
      Toast.makeText(getActivity(), "تعذّرت الاستعادة: ملف غير صالح", Toast.LENGTH_SHORT).show();
    }
  }
}
