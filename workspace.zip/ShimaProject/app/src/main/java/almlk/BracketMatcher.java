package almlk;

/**
 * بند almlk ← أسلوب مطابقة الأقواس في AIDE (علم سطر التطابق «model.j6(i)» والرسم «m569j6»):
 * فحص متوازن عبر {} () [] يعود بموقع القوس المطابق لموقع المؤشر — يُستدعى عند حركة المؤشر
 * فقط (وليس داخل حلقة الرسم)، ونتيجته تُعرض كتظليل خط عرضي في الإطار التالي.
 */
public final class BracketMatcher {

  private static final String OPEN = "({[";
  private static final String CLOSE = ")}]";

  /**
   * موقع القوس المطابق لأقرب قوس ملاصق للمؤشر (نص كامل). يعيد -1 عند غياب مطابقة.
   *
   * <p>الخوارزمية O(n) أسوأ حالة لكنها تُستدعى مرة لكل حركة مؤشر فحسب.
   */
  public static int match(CharSequence text, int caretOffset) {
    if (text == null) return -1;
    int length = text.length();
    if (length == 0) return -1;
    int anchor = bracketAt(text, caretOffset, length);
    if (anchor < 0) return -1;
    char bracket = text.charAt(anchor);
    if (OPEN.indexOf(bracket) >= 0) return scanForward(text, anchor, bracket, length);
    return scanBackward(text, anchor, bracket);
  }

  private static int bracketAt(CharSequence text, int caret, int length) {
    int at = Math.min(caret, length - 1);
    if (isBracket(text.charAt(at))) return at;
    if (at - 1 >= 0 && isBracket(text.charAt(at - 1))) return at - 1;
    return -1;
  }

  private static boolean isBracket(char c) {
    return OPEN.indexOf(c) >= 0 || CLOSE.indexOf(c) >= 0;
  }

  private static int scanForward(CharSequence text, int from, char open, int length) {
    char close = OPEN.length() > 0 ? CLOSE.charAt(OPEN.indexOf(open)) : 0;
    int depth = 0;
    for (int i = from; i < length; i++) {
      char c = text.charAt(i);
      if (c == open) depth++;
      else if (c == close) {
        depth--;
        if (depth == 0) return i;
      }
    }
    return -1;
  }

  private static int scanBackward(CharSequence text, int from, char close) {
    char open = OPEN.charAt(CLOSE.indexOf(close));
    int depth = 0;
    for (int i = from; i >= 0; i--) {
      char c = text.charAt(i);
      if (c == close) depth++;
      else if (c == open) {
        depth--;
        if (depth == 0) return i;
      }
    }
    return -1;
  }

  /**
   * نسخة مستند-سطر: يعيد رقم السطر المحتوي للمطابقة من المؤشر داخل سطر — أداة الرسم تظلل
   * «سطر التطابق» مباشرة دون تحليل نصي في onDraw.
   */
  public static int matchingLine(LineDocument document, int caretLine, int caretColumn) {
    if (document == null || caretLine >= document.lineCount()) return -1;
    // تجميع النص قصير المدى: نلاحظ فقط ما يلزم للتوازن (في أسوأ حالة المستند كله).
    StringBuilder builder = new StringBuilder();
    int targetOffset = 0;
    for (int i = 0; i < document.lineCount(); i++) {
      LineBuffer line = document.line(i);
      for (int j = 0; j < line.length(); j++) builder.append(line.charAt(j));
      if (i == caretLine) targetOffset = builder.length() - Math.max(0, line.length() - caretColumn);
      builder.append('\n');
    }
    int match = match(builder, Math.max(0, targetOffset));
    if (match < 0) return -1;
    int line = 0, col = 0;
    for (int i = 0; i < builder.length() && i <= match; i++) {
      if (builder.charAt(i) == '\n') {
        line++;
        col = i;
      }
      if (i == match) return line;
    }
    return -1;
  }
}
