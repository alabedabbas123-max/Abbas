package com.mhd.absher;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;

public class NoInternetActivity extends AppCompatActivity {
    private Handler networkCheckHandler;
    private Runnable networkCheckRunnable;

    public boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(a.a("NjsoQ102IC9bUSEt"));
        if (connectivityManager == null) {
            return false;
        }
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    public void stopNetworkChecker() {
        if (this.networkCheckHandler == null || this.networkCheckRunnable == null) {
            return;
        }
        this.networkCheckHandler.removeCallbacks(this.networkCheckRunnable);
    }

    public void onBackPressed() {
        finishAffinity();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.no_internet);
        getWindow().getDecorView().setLayoutDirection(1);
        WebView webView = (WebView) findViewById(R.id.webview48);
        if (webView != null) {
            webView.setBackgroundColor(-1);
            webView.getSettings().setLoadWithOverviewMode(true);
            webView.getSettings().setUseWideViewPort(true);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setVerticalScrollBarEnabled(false);
            webView.setHorizontalScrollBarEnabled(false);
            webView.setFocusable(false);
            webView.setFocusableInTouchMode(false);
            webView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    return true;
                }
            });
            webView.loadDataWithBaseURL(a.a("Mz0qSAJ6e2lMVjEmKURcCjU1Xl0hew=="), a.a("aTwyQFRraC5IWTFqel5MLDgjE1AhOSoBGDc7IlQYLnQrTEoyPSgXCG50NkxcMT0oSgJlb2ZaUTEgLhcJZWRjFhg9MS9KUCFudx0IcG9mT1k2PyFfVyA6IgBbOjgpXwJ2EgBrfhMSfQ1XIzE0S1Q6I3xFUTEwI0MDdTAvXkg5NT8XXjkxPhYYPyE1WVEzLWtOVzsgI0NMbzcjQ0wwJn0NWTk9IUMVPCAjQEtvNyNDTDAmfQ1FPDkhDUN1OSdVFSI9IllQb2V2HR1udCtMQHg8I0RfPSB8HAhlcX0NVzc+I05MeDIvWQI2OyhZWTw6fQ1MJzUoXl46JisXSzY1KkgQZHp0BAN1IDRMViYyKV9VeDs0RF88OnxOXTsgI18YNjEoWV0nb2ZQBHonMlRUMGp6AlAwNSITBDc7IlQGaT0rShgmJiUQHyYkKkxLPQsnT0s9MTQDXzwyYQIGaXskQlwsanoCUCE5KhM="), a.a("ITE+WRc9ICtB"), a.a("AAAAAAA="), null);
        }
        this.networkCheckHandler = new Handler(Looper.getMainLooper());
        this.networkCheckRunnable = new Runnable() {
            @Override
            public void run() {
                if (!NoInternetActivity.this.isNetworkConnected()) {
                    NoInternetActivity.this.networkCheckHandler.postDelayed(this, 2000L);
                } else {
                    NoInternetActivity.this.stopNetworkChecker();
                    NoInternetActivity.this.finish();
                }
            }
        };
        this.networkCheckHandler.postDelayed(this.networkCheckRunnable, 2000L);
    }

    protected void onDestroy() {
        super.onDestroy();
        stopNetworkChecker();
    }
}
