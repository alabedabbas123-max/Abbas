package almlk;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import com.shima.demo.UiStrings;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * تقرير فتح الملفات + بند almlk — إعادة بناء دور خدمة الملفات المفتوحة في المحرك (مثل U.er()
 * المشوّهة في المرجع) باسم مفهوم وبلا رموز حماية.
 *
 * <p>القاعدة الذهبية المُكتشفة من دراسة العطل: قراءة محتوى الملف «خدمة محرك» حياتها مستقلة
 * عن دورة حياة الواجهات. الدرج يُغلق والبانل يُزال والقارئ يبقى — لذلك الملف يُفتح فورًا
 * دائمًا مهما تغيرت الواجهة أثناء القراءة.
 *
 * <p>النطاق (ميزة فتح الملفات فقط): قراءة نصية (File/SAF)، حدّ 8MB، كاش LRU صغير، تسليم
 * على الخيط الرئيسي، تجاهل الردود البالية تلقائيًا.
 */
public final class FileContentService {

  /** نتيجة قراءة واحدة: success=false تعني تعذّرت القراءة (المحتوى = رسالة مرئية). */
  public interface OpenCallback {
    void completed(String name, boolean success, String content);
  }

  private static FileContentService instance;

  public static synchronized FileContentService get() {
    if (instance == null) instance = new FileContentService();
    return instance;
  }

  private static final int MAX_BYTES = 8 * 1024 * 1024;
  private static final int CACHE_ENTRIES = 6;

  private final ExecutorService reader = Executors.newSingleThreadExecutor();
  private final Handler mainHandler = new Handler(Looper.getMainLooper());
  private final LruContentCache cache = new LruContentCache();
  private final java.util.HashMap<String, Integer> latestRequestByName = new java.util.HashMap<>();
  private int requestGeneration;

  private FileContentService() {}

  /**
   * يفتح محتوى ملف. يُلغي أثر أي طلب سابق بالي، ويسلّم النتيجة على الخيط الرئيسي دائمًا.
   *
   * @param reference مسار مطلق يبدأ «/» أو SAF URI «content://...»; يمر فارغًا = فشل فوري مرئي.
   */
  public void open(Context context, String name, String reference, OpenCallback callback) {
    if (name == null || callback == null) return;
    final String ref = reference == null ? "" : reference;
    final String cached = cache.get(cacheKey(name, ref));
    if (cached != null) {
      callback.completed(name, true, cached);
      return;
    }
    final int request = ++requestGeneration;
    latestRequestByName.put(name, request);
    final Context app = context.getApplicationContext();
    reader.execute(
        () -> {
          String content = null;
          boolean success = false;
          if (!ref.isEmpty()) {
            try {
              byte[] bytes = readAll(openStream(app, ref), MAX_BYTES);
              if (bytes != null && !looksBinary(bytes)) {
                content = new String(bytes, StandardCharsets.UTF_8);
                success = true;
              } else if (bytes != null) {
                content = UiStrings.get(app, "ui_binary_file_no_text_preview");
              }
            } catch (Throwable failure) {
              content = UiStrings.format(app, "ui_error_open_file_named", name, UiStrings.message(app, failure));
            }
          }
          if (content == null) {
            content = UiStrings.format(app, "ui_error_open_file_retry", name);
          }
          final boolean ok = success;
          final String body = content;
          if (ok) cache.put(cacheKey(name, ref), body);
          mainHandler.post(
              () -> {
                // تحقق لكل ملف: طلب جديد لنفس الملف فقط يُبطل القديم — أما ملف آخر فلا يصله.
                Integer latest = latestRequestByName.get(name);
                if (latest == null || latest != request) return;
                callback.completed(name, ok, body);
              });
        });
  }

  /** يُبطل أي رد قيد الانتظار (يستخدم عند تغيّر التركيز جذريًا). */
  public void discardPending() {
    requestGeneration++;
  }

  private static String cacheKey(String name, String reference) {
    return reference.isEmpty() ? name : reference;
  }

  private static InputStream openStream(Context context, String reference) throws Exception {
    if (reference.startsWith("/")) return new FileInputStream(new java.io.File(reference));
    return context.getContentResolver().openInputStream(Uri.parse(reference));
  }

  private static byte[] readAll(InputStream in, int cap) throws Exception {
    if (in == null) return null;
    try (InputStream input = in) {
      ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(cap, 64 * 1024));
      byte[] chunk = new byte[8192];
      int n;
      while ((n = input.read(chunk)) > 0 && out.size() < cap) {
        out.write(chunk, 0, Math.min(n, cap - out.size()));
      }
      return out.toByteArray();
    }
  }

  /** شمّ ثنائي خفيف: «NUL» خلال أول 2KB يعني غير نصي. */
  private static boolean looksBinary(byte[] bytes) {
    int probe = Math.min(bytes.length, 2048);
    for (int i = 0; i < probe; i++) if (bytes[i] == 0) return true;
    return false;
  }

  private static final class LruContentCache {
    private final LinkedHashMap<String, String> map =
        new LinkedHashMap<String, String>(CACHE_ENTRIES, 0.75f, true) {
          @Override
          protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
            return size() > CACHE_ENTRIES;
          }
        };

    synchronized String get(String key) {
      return key == null ? null : map.get(key);
    }

    synchronized void put(String key, String value) {
      if (key != null && value != null) map.put(key, value);
    }
  }
}
