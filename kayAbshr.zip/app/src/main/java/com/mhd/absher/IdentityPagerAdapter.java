package com.mhd.absher;

import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class IdentityPagerAdapter extends RecyclerView.Adapter {
    private final List images;

    public class ImageViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

        public ImageViewHolder(ImageView imageView) {
            super(imageView);
            this.imageView = imageView;
        }
    }

    public IdentityPagerAdapter(List list) {
        this.images = list;
    }

    public int getItemCount() {
        return this.images.size();
    }

    public void onBindViewHolder(ImageViewHolder imageViewHolder, int i) {
        imageViewHolder.imageView.setImageResource(((Integer) this.images.get(i)).intValue());
    }

    public ImageViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        ImageView imageView = new ImageView(viewGroup.getContext());
        imageView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setAdjustViewBounds(true);
        return new ImageViewHolder(imageView);
    }
}
