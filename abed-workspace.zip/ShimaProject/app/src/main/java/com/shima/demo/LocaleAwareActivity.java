package com.shima.demo;

import android.app.Activity;
import android.content.Context;

/** Activity base that applies the saved app locale before Android creates its views. */
public abstract class LocaleAwareActivity extends Activity {
  @Override
  protected void attachBaseContext(Context base) {
    super.attachBaseContext(ShimaApplication.localize(base));
  }
}
