package com.shima.performance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Editor text model with O(1) line lookup. It deliberately does not expose a giant TextView
 * Layout; the viewport view asks for only the lines that it needs to paint.
 */
public final class LineArrayModel {
  private final ArrayList<String> lines = new ArrayList<>();
  private final ArrayList<Integer> starts = new ArrayList<>();
  private int textLength;

  public LineArrayModel() {
    setText("");
  }

  public void setText(String text) {
    lines.clear();
    starts.clear();
    if (text == null) text = "";
    textLength = text.length();
    int lineStart = 0;
    starts.add(0);
    for (int i = 0; i < text.length(); i++) {
      if (text.charAt(i) == '\n') {
        lines.add(text.substring(lineStart, i));
        lineStart = i + 1;
        starts.add(lineStart);
      }
    }
    lines.add(text.substring(lineStart));
    if (lines.isEmpty()) lines.add("");
  }

  public int lineCount() {
    return lines.size();
  }

  public String lineAt(int line) {
    if (line < 0 || line >= lines.size()) return "";
    return lines.get(line);
  }

  public int lineStart(int line) {
    if (line <= 0) return 0;
    if (line >= starts.size()) return textLength;
    return starts.get(line);
  }

  public int lineEnd(int line) {
    if (line < 0 || line >= lines.size()) return 0;
    return lineStart(line) + lines.get(line).length();
  }

  public int length() {
    return textLength;
  }

  public int offsetFor(int line, int column) {
    int safeLine = Math.max(0, Math.min(line, lineCount() - 1));
    return Math.min(lineEnd(safeLine), lineStart(safeLine) + Math.max(0, column));
  }

  public Position positionFor(int offset) {
    int safe = Math.max(0, Math.min(offset, textLength));
    int low = 0;
    int high = starts.size() - 1;
    while (low <= high) {
      int middle = (low + high) >>> 1;
      if (starts.get(middle) <= safe) low = middle + 1;
      else high = middle - 1;
    }
    int line = Math.max(0, high);
    return new Position(line, safe - lineStart(line));
  }

  public String substring(int start, int end) {
    int from = Math.max(0, Math.min(start, textLength));
    int to = Math.max(from, Math.min(end, textLength));
    StringBuilder value = new StringBuilder(to - from);
    for (int i = from; i < to; i++) {
      Position position = positionFor(i);
      if (position.column < lineAt(position.line).length()) value.append(lineAt(position.line).charAt(position.column));
      else value.append('\n');
    }
    return value.toString();
  }

  public List<String> snapshotLines() {
    return Collections.unmodifiableList(new ArrayList<>(lines));
  }

  public static final class Position {
    public final int line;
    public final int column;

    public Position(int line, int column) {
      this.line = line;
      this.column = column;
    }
  }
}
