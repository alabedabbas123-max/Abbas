package com.almlkid.kay.ui;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Native Shima completion engine following the reference editor's context-first flow.
 *
 * <p>The engine performs no I/O and no DEX loading. It only interprets the immutable source
 * snapshot, asks ProjectSymbolIndex for symbols, and ranks the bounded result set.
 */
public final class KayStyleCompletionEngine {
  private static final Pattern IMPORT =
      Pattern.compile("(?m)^\\s*import\\s+(?:static\\s+)?([A-Za-z_$][A-Za-z0-9_$.]*)");
  private static final int MAX_RESULTS = 40; // تقرير 02: اعرض 30–50 نتيجة كحد أقصى للحفاظ على السرعة

  private KayStyleCompletionEngine() {}

  public static List<ProjectSymbolIndex.CompletionItem> complete(
      String fileName, String source, int cursorOffset) {
    String text = source == null ? "" : source;
    if (fileName != null && fileName.toLowerCase(Locale.US).endsWith(".smali"))
      return smaliSuggestions(text, cursorOffset);
    CompletionContext context = CompletionContext.detect(fileName, text, cursorOffset);
    switch (context.kind) {
      case XML:
      case GRADLE:
        return ProjectSymbolIndex.complete(fileName, text, cursorOffset);
      case CLASS:
        return classSuggestions(text, context.prefix);
      case MEMBER:
        String type = ProjectSymbolIndex.resolveExpressionType(text, context.receiver);
        return type.isEmpty()
            ? new ArrayList<>()
            : ProjectSymbolIndex.members(type, context.prefix);
      case GLOBAL:
      default:
        return ProjectSymbolIndex.complete(fileName, text, cursorOffset);
    }
  }

  private static List<ProjectSymbolIndex.CompletionItem> smaliSuggestions(
      String source, int cursorOffset) {
    ArrayList<ProjectSymbolIndex.CompletionItem> result = new ArrayList<>();
    for (String value : com.shima.editor.core.SmaliCompletionEngine.complete(source, cursorOffset, MAX_RESULTS)) {
      int kind = value.startsWith(".") ? ProjectSymbolIndex.CompletionItem.BUILD
          : value.startsWith(":") ? ProjectSymbolIndex.CompletionItem.VARIABLE
          : value.startsWith("L") ? ProjectSymbolIndex.CompletionItem.CLASS
          : ProjectSymbolIndex.CompletionItem.METHOD;
      result.add(new ProjectSymbolIndex.CompletionItem(kind, value, value, "Smali"));
    }
    return result;
  }

  private static List<ProjectSymbolIndex.CompletionItem> classSuggestions(
      String source, String prefix) {
    LinkedHashMap<String, ProjectSymbolIndex.CompletionItem> unique = new LinkedHashMap<>();
    for (String name : ProjectSymbolIndex.classNamesMatching(prefix, MAX_RESULTS)) {
      addClass(unique, name, prefix, "class");
    }
    Matcher imports = IMPORT.matcher(UsageSearchEngine.mask(source));
    while (imports.find()) {
      String qualified = imports.group(1);
      int dot = qualified.lastIndexOf('.');
      addClass(unique, dot < 0 ? qualified : qualified.substring(dot + 1), prefix, "import");
    }
    ArrayList<ProjectSymbolIndex.CompletionItem> result = new ArrayList<>(unique.values());
    result.sort(
        (left, right) -> {
          int score = Integer.compare(
              ProjectSymbolIndex.matchScore(left.label, prefix),
              ProjectSymbolIndex.matchScore(right.label, prefix));
          return score != 0 ? score : left.label.compareToIgnoreCase(right.label);
        });
    return result.size() > MAX_RESULTS
        ? new ArrayList<>(result.subList(0, MAX_RESULTS))
        : result;
  }

  private static void addClass(
      LinkedHashMap<String, ProjectSymbolIndex.CompletionItem> output,
      String name,
      String prefix,
      String detail) {
    if (name == null || name.isEmpty() || ProjectSymbolIndex.matchScore(name, prefix) == Integer.MAX_VALUE)
      return;
    output.put(
        name.toLowerCase(Locale.US),
        new ProjectSymbolIndex.CompletionItem(
            ProjectSymbolIndex.CompletionItem.CLASS, name, name, detail));
  }
}
