package almlk;

import java.util.regex.Pattern;

/**
 * محرك إعادة التسمية النقي (بلا أندرويد): يستبدل كل مواضع الرمز كـ«كلمة كاملة» متجاوزًا
 * التعليقات والنصوص الحرفية، ويتحقق من صلاحية الاسم الجديد. قابل للاختبار خارج الجهاز (بند 2/3).
 */
public final class Renamer {
  private Renamer() {}

  private static final String[] KEYWORDS = {
    "abstract","assert","boolean","break","byte","case","catch","char","class","const","continue",
    "default","do","double","else","enum","extends","final","finally","float","for","goto","if",
    "implements","import","instanceof","int","interface","long","native","new","package","private",
    "protected","public","return","short","static","strictfp","super","switch","synchronized","this",
    "throw","throws","transient","try","var","void","volatile","while","true","false","null"
  };

  public static boolean isValidJavaIdentifier(String s) {
    if (s == null || s.isEmpty()) return false;
    if (!Character.isJavaIdentifierStart(s.charAt(0))) return false;
    for (int i = 1; i < s.length(); i++) if (!Character.isJavaIdentifierPart(s.charAt(i))) return false;
    return true;
  }

  public static boolean isKeyword(String s) {
    for (String k : KEYWORDS) if (k.equals(s)) return true;
    return false;
  }

  /** يُعيد null إن كان الاسم الجديد مقبولًا، وإلا سبب الرفض الظاهر للمستخدم. */
  public static String validate(String oldName, String newName) {
    if (newName == null || newName.trim().isEmpty()) return "ui_rename_name_empty";
    newName = newName.trim();
    if (!isValidJavaIdentifier(newName)) return "ui_rename_name_invalid_identifier";
    if (isKeyword(newName)) return "ui_rename_name_keyword";
    if (newName.equals(oldName)) return "ui_rename_name_unchanged";
    return null;
  }

  /** يستبدل كل مواضع {@code symbol} ككلمة كاملة في {@code source} متجاوزًا التعليقات والنصوص. */
  public static String renameAll(String source, String symbol, String newName) {
    if (source == null || symbol == null || symbol.isEmpty() || newName == null) return source;
    String masked = mask(source);
    StringBuilder out = new StringBuilder(source.length());
    int from = 0;
    while (from <= masked.length() - symbol.length()) {
      int at = masked.indexOf(symbol, from);
      if (at < 0) { out.append(source, from, source.length()); return out.toString(); }
      int end = at + symbol.length();
      boolean left = at > 0 && Character.isJavaIdentifierPart(masked.charAt(at - 1));
      boolean right = end < masked.length() && Character.isJavaIdentifierPart(masked.charAt(end));
      out.append(source, from, at);
      if (!left && !right) out.append(newName); else out.append(source, at, end);
      from = end;
    }
    out.append(source, from, source.length());
    return out.toString();
  }

  /** عدد مواضع الرمز ككلمة كاملة (لعدّ التعديلات وعرض الملخص). */
  public static int countOccurrences(String source, String symbol) {
    if (source == null || symbol == null || symbol.isEmpty()) return 0;
    String masked = mask(source);
    int n = 0, from = 0;
    while (from <= masked.length() - symbol.length()) {
      int at = masked.indexOf(symbol, from);
      if (at < 0) break;
      int end = at + symbol.length();
      boolean left = at > 0 && Character.isJavaIdentifierPart(masked.charAt(at - 1));
      boolean right = end < masked.length() && Character.isJavaIdentifierPart(masked.charAt(end));
      if (!left && !right) n++;
      from = end;
    }
    return n;
  }

  /**
   * إعادة تسمية مورد XML: يحدّث مراجع {@code @type/old} و{@code @+type/old} و{@code R.type.old}
   * وإعلانات {@code name="old"} — أي كل صيغ المرجع الموثقة في XmlResourceReference.
   */
  public static String renameResource(String source, String oldName, String newName) {
    if (source == null || oldName == null || oldName.isEmpty() || newName == null) return source;
    String o = Pattern.quote(oldName);
    String r = source;
    r = r.replaceAll("(@\\+?[A-Za-z_][A-Za-z0-9_]*/)" + o + "(?![A-Za-z0-9_])", "$1" + newName);
    r = r.replaceAll("(R\\.[A-Za-z_][A-Za-z0-9_]*\\.)" + o + "(?![A-Za-z0-9_])", "$1" + newName);
    r = r.replaceAll("(name=\")" + o + "(?=\")", "$1" + newName);
    return r;
  }

  /** يُقنّع التعليقات والنصوص الحرفية بمسافات فلا تطالها إعادة التسمية. */
  public static String mask(String source) {
    char[] c = source.toCharArray();
    int i = 0, n = c.length;
    while (i < n) {
      char ch = c[i];
      if (ch == '/' && i + 1 < n && c[i + 1] == '/') {
        while (i < n && c[i] != '\n') { c[i] = ' '; i++; }
      } else if (ch == '/' && i + 1 < n && c[i + 1] == '*') {
        c[i] = ' '; if (i + 1 < n) c[i + 1] = ' '; i += 2;
        while (i + 1 < n && !(c[i] == '*' && c[i + 1] == '/')) { if (c[i] != '\n') c[i] = ' '; i++; }
        if (i + 1 < n) { c[i] = ' '; c[i + 1] = ' '; i += 2; }
      } else if (ch == '"') {
        c[i] = ' '; i++;
        while (i < n && c[i] != '"') { if (c[i] == '\\') { c[i] = ' '; i++; if (i < n) { c[i] = ' '; i++; } continue; } if (c[i] != '\n') c[i] = ' '; i++; }
        if (i < n) { c[i] = ' '; i++; }
      } else if (ch == '\'') {
        c[i] = ' '; i++;
        while (i < n && c[i] != '\'') { if (c[i] == '\\') { c[i] = ' '; i++; if (i < n) { c[i] = ' '; i++; } continue; } if (c[i] != '\n') c[i] = ' '; i++; }
        if (i < n) { c[i] = ' '; i++; }
      } else {
        i++;
      }
    }
    return new String(c);
  }
}
