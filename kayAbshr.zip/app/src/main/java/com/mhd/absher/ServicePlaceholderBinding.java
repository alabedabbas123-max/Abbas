package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class ServicePlaceholderBinding {
    public final ImageView ivServiceIcon;
    public final LinearLayout rootView;
    public final Space space95;
    public final Space space96;
    public final TextView tvMainMessage;
    public final TextView tvSubMessage;

    private ServicePlaceholderBinding(LinearLayout linearLayout, ImageView imageView, Space space, TextView textView, Space space2, TextView textView2) {
        this.rootView = linearLayout;
        this.ivServiceIcon = imageView;
        this.space95 = space;
        this.tvMainMessage = textView;
        this.space96 = space2;
        this.tvSubMessage = textView2;
    }

    public static ServicePlaceholderBinding bind(View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        ImageView imageView = (ImageView) findChildViewById(view, R.id.ivServiceIcon);
        Space space = (Space) findChildViewById(view, R.id.space95);
        TextView textView = (TextView) findChildViewById(view, R.id.tvMainMessage);
        Space space2 = (Space) findChildViewById(view, R.id.space96);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvSubMessage);
        if (imageView == null || space == null || textView == null || space2 == null || textView2 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new ServicePlaceholderBinding(linearLayout, imageView, space, textView, space2, textView2);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static ServicePlaceholderBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ServicePlaceholderBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.service_placeholder, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}
