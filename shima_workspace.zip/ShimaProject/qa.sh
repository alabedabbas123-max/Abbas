#!/usr/bin/env bash
# مجموعة الانحدار الدائمة — المرحلة التاسعة.
#
# تُشغَّل بأمر واحد:  ./qa.sh
# بلا أي تبعية خارجية (لا JUnit ولا Gradle): جافا صرفة + بدائل android.content وandroid.os
# تحت qa/stubs/ لتشغيل منطق التفضيلات والملوّن التزايدي خارج android.jar.
#
# حدّ التغطية: أصناف المنطق الصرفة (12 من 19 في almlk + سجل القوائم + أدوات اللغة).
# أصناف الرسم تغطيها qa/acceptance.sh (البناء + فحص الحزمة) لأنها تحتاج جهازًا.

set -uo pipefail
cd "$(dirname "$0")"

# ── إيجاد JDK ────────────────────────────────────────────────────────────
if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/javac" ]; then
  JAVAC="$JAVA_HOME/bin/javac"; JAVA="$JAVA_HOME/bin/java"
elif [ -x /home/user/.cache/jdk21/bin/javac ]; then
  JAVAC=/home/user/.cache/jdk21/bin/javac; JAVA=/home/user/.cache/jdk21/bin/java
elif command -v javac >/dev/null 2>&1; then
  JAVAC=$(command -v javac); JAVA=$(command -v java)
else
  echo "✘ لم يُعثر على JDK. شغّل .cache_setup.sh أولًا أو اضبط JAVA_HOME." >&2
  exit 2
fi

SRC=app/src/main/java
OUT=qa/.out
rm -rf "$OUT"; mkdir -p "$OUT"

# ── الترجمة ──────────────────────────────────────────────────────────────
echo "### [1/2] ترجمة المجموعة ..."
"$JAVAC" -encoding UTF-8 -nowarn -proc:none \
  -sourcepath "qa/stubs:qa/probes:$SRC" -d "$OUT" \
  qa/stubs/android/content/Context.java \
  qa/stubs/android/content/SharedPreferences.java \
  qa/stubs/android/preference/PreferenceManager.java \
  qa/stubs/android/os/Looper.java \
  qa/stubs/android/os/Handler.java \
  "$SRC/almlk/CodeStyle.java" \
  "$SRC/almlk/IdentifierBounds.java" \
  "$SRC/almlk/LineBuffer.java" \
  "$SRC/almlk/LineDocument.java" \
  "$SRC/almlk/LineStyler.java" \
  "$SRC/almlk/StyleRunBatcher.java" \
  "$SRC/almlk/UndoRedoStack.java" \
  "$SRC/almlk/XmlColorLiteral.java" \
  "$SRC/almlk/XmlCodeFormatter.java" \
  "$SRC/almlk/XmlCommentEditor.java" \
  "$SRC/almlk/XmlResourceIndex.java" \
  "$SRC/almlk/XmlResourceReference.java" \
  "$SRC/almlk/XmlStructureScanner.java" \
  "$SRC/almlk/XmlCompletionEngine.java" \
  "$SRC/com/almlkid/ui/EditorMenuRegistry.java" \
  "$SRC/com/almlkid/kay/ui/CodeLanguageTools.java" \
  "$SRC/net/margaritov/preference/colorpicker/HexColorCodec.java" \
  qa/probes/almlk/ColorLiteralFactory.java \
  qa/RegressionSuite.java
if [ $? -ne 0 ]; then echo "✘ فشلت الترجمة" >&2; exit 2; fi

# ── التشغيل ──────────────────────────────────────────────────────────────
echo "### [2/2] تشغيل البوابات ..."
LANG=C.UTF-8 "$JAVA" -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$OUT" RegressionSuite
CODE=$?

rm -rf "$OUT"
if [ $CODE -eq 0 ]; then echo "### ✔ مجموعة الانحدار نجحت"; else echo "### ✘ مجموعة الانحدار فشلت" >&2; fi
exit $CODE
