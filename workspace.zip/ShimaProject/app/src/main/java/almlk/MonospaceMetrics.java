package almlk;

import android.graphics.Paint;

/**
 * بند almlk ← دور منطق «m572j6» في OConsole: قياسات الخط تُحسب مرة واحدة وتُخزَّن،
 * وكشف monospace شامل (كل محارف ASCII المرئية تساوي عرض «M») يفعّل المسار السريع:
 * كل موضع أفقي = رقم حرف × عرض-ثابت، وصفر measureText أثناء الرسم.
 */
public final class MonospaceMetrics {

  public final float spaceWidth;
  public final float mWidth;
  public final float digitWidth;
  public final float lineHeight;
  public final float ascent;
  public final float descent;
  public final boolean monospaceFastPath;

  private MonospaceMetrics(
      float spaceWidth,
      float mWidth,
      float digitWidth,
      float lineHeight,
      float ascent,
      float descent,
      boolean monospaceFastPath) {
    this.spaceWidth = spaceWidth;
    this.mWidth = mWidth;
    this.digitWidth = digitWidth;
    this.lineHeight = lineHeight;
    this.ascent = ascent;
    this.descent = descent;
    this.monospaceFastPath = monospaceFastPath;
  }

  public static MonospaceMetrics measure(Paint probe) {
    Paint.FontMetrics metrics = probe.getFontMetrics();
    float spaceWidth = probe.measureText(" ");
    float mWidth = probe.measureText("M");
    float digitWidth = probe.measureText("8");
    float lineHeight = (-metrics.top) + metrics.bottom + metrics.leading;
    float ascent = -metrics.top;
    float descent = metrics.bottom;
    float uniform = mWidth;
    boolean monospace = true;
    char[] sample = new char[1];
    for (char c = 33; c < 127; c++) {
      sample[0] = c;
      if ((int) probe.measureText(sample, 0, 1) != (int) uniform) {
        monospace = false;
        break;
      }
    }
    return new MonospaceMetrics(
        spaceWidth, mWidth, digitWidth, lineHeight, ascent, descent, monospace);
  }

  /** تحويل عرضي: بكسل←عمود مباشرة في المسار السريع. */
  public float columnToX(int column) {
    return column * mWidth;
  }

  /** تحويل معكوس: بكسل→عمود (للمسّ/المؤشر). */
  public int xToColumn(float x) {
    return mWidth <= 0 ? 0 : Math.max(0, (int) (x / mWidth + 0.5f));
  }

  public float lineToY(int line) {
    return line * lineHeight;
  }

  public int yToLine(float y) {
    return lineHeight <= 0 ? 0 : Math.max(0, (int) (y / lineHeight));
  }
}
