package com.shima.demo;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.TypedValue;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** شاشة About — معلومات قانونية وعن الإصدار (رأس تبويب Settings). */
public class AboutActivity extends Activity {
  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    setTitle(R.string.preference_title_legal);
    if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);

    TextView body = new TextView(this);
    body.setTextColor(Color.rgb(220, 220, 220));
    body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
    body.setLineSpacing(8, 1f);
    body.setPadding(48, 40, 48, 40);
    body.setMovementMethod(LinkMovementMethod.getInstance());
    body.setText(buildText());

    ScrollView scroll = new ScrollView(this);
    scroll.setBackgroundColor(Color.rgb(25, 25, 25));
    scroll.addView(
        body,
        new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    setContentView(scroll);
  }

  private String buildText() {
    String version = "";
    try {
      version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
    } catch (Exception ignored) {
      // بلا معلومات إصدار
    }
    return getString(R.string.app_name)
        + (version == null ? "" : " — " + version)
        + "\n\n"
        + "محرر وأداة تطوير متكاملة للجوال.\n"
        + "جميع الحقوق محفوظة.\n"
        + "يُوزَّع البرنامج كما هو دون ضمان من أي نوع.";
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      finish();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }
}
