package almlk;

/**
 * تعليق XML الآمن وفكّه — المرحلة السادسة.
 *
 * <p>يُنتج الكلاس **نتيجة وصفية** (مدى + نص بديل، أو سبب رفض) ولا يلمس المحرر، فيبقى
 * قابلًا للاختبار مستقلًا عن أندرويد. التطبيق في المضيف استبدال واحد عبر {@code replaceRange}
 * = تراجع واحد.
 *
 * <p>قواعد الأمان المتحققة قبل أي كتابة:
 *
 * <ul>
 *   <li>الرمز {@code <!-- … -->} لا {@code //} — ومسار {@code //} يبقى محجوبًا عن XML.
 *   <li>لا يُلفّ نطاق داخل CDATA (محتوى حرفي لا يقبل التعليق).
 *   <li>لا يُعلَّق نطاق معلّق أصلًا.
 *   <li>يُرفض أي نطاق يحوي {@code --} لأن XML يحرّمه داخل التعليق — بلا إنتاج XML مكسور.
 *   <li>التعليق المتعدد الأسطر يلفّ النطاق **مرة واحدة**، فلا تداخل تعليقات.
 * </ul>
 */
public final class XmlCommentEditor {

  private static final String OPEN = "<!--";
  private static final String CLOSE = "-->";

  /** نتيجة عملية: إما مدى ونص بديل، أو سبب رفض ظاهر. */
  public static final class Outcome {
    /** بداية المدى المستبدَل. */
    public final int start;
    /** نهاية المدى المستبدَل (حصري). */
    public final int end;
    /** النص البديل. */
    public final String text;
    /** سبب الرفض؛ {@code null} يعني أن العملية صالحة للتطبيق. */
    public final String rejection;

    private Outcome(int start, int end, String text, String rejection) {
      this.start = start;
      this.end = end;
      this.text = text;
      this.rejection = rejection;
    }

    static Outcome apply(int start, int end, String text) {
      return new Outcome(start, end, text, null);
    }

    static Outcome reject(String reason) {
      return new Outcome(-1, -1, "", reason);
    }

    public boolean applies() {
      return rejection == null;
    }
  }

  private XmlCommentEditor() {}

  /**
   * اختيار الاتجاه من الحالة: إن كان مرساة التحديد داخل تعليق → فكّ تعليق، وإلا → تعليق.
   *
   * @return نتيجة العملية، أو {@code null} عند غياب المحتوى أصلًا.
   */
  public static Outcome toggle(String text, int selStart, int selEnd) {
    int anchor = normalize(text, selStart, selEnd)[0];
    int[] region = lineRegion(text, selStart, selEnd);
    boolean insideComment =
        XmlStructureScanner.commentSpanContaining(text, anchor) != null
            || XmlStructureScanner.firstCommentSpanInRange(text, region[0], region[1]) != null;
    return insideComment ? uncomment(text, selStart, selEnd) : comment(text, selStart, selEnd);
  }

  /** أمر المرجع «Outcomment Code» لـXML: لفّ أسطر التحديد بتعليق واحد. */
  public static Outcome comment(String text, int selStart, int selEnd) {
    int[] region = lineRegion(text, selStart, selEnd);
    int regionStart = region[0];
    int regionEnd = region[1];
    String body = text.substring(regionStart, regionEnd);
    if (body.trim().isEmpty()) return Outcome.reject("ui_xml_comment_no_content");

    // فحص التراكب على المدى كاملًا لا على حالة بداية السطر: CDATA وتعليق قد يفتحان ويغلقان
    // داخل السطر نفسه، وفحص بداية السطر وحدها يفلتهما.
    if (XmlStructureScanner.rangeTouchesState(text, regionStart, regionEnd, XmlStructureScanner.CDATA)) {
      return Outcome.reject("ui_xml_comment_cdata_unsafe");
    }
    if (XmlStructureScanner.rangeTouchesState(text, regionStart, regionEnd, XmlStructureScanner.COMMENT)) {
      return Outcome.reject("ui_xml_comment_already_commented");
    }

    XmlStructureScanner.Layout layout = XmlStructureScanner.scan(text);
    int firstLine = layout.lineAt(regionStart);
    int lastLine = layout.lineAt(Math.max(regionStart, regionEnd - 1));

    int firstContent = -1;
    int contentLines = 0;
    for (int line = firstLine; line <= lastLine; line++) {
      if (!isBlankLine(text, layout, line)) {
        if (firstContent < 0) firstContent = line;
        contentLines++;
      }
    }
    if (firstContent < 0) return Outcome.reject("ui_xml_comment_no_content");
    // XML يحرّم «--» داخل التعليق؛ الرفض أهون من إنتاج ملف مكسور.
    if (XmlStructureScanner.indexOf(body, "--", 0) >= 0) {
      return Outcome.reject("ui_xml_comment_double_hyphen");
    }

    int indentEnd = firstNonSpace(text, layout.lineStart[firstContent], layout.lineEnd[firstContent]);
    String indent = text.substring(layout.lineStart[firstContent], indentEnd);

    // سطر محتوى واحد → تعليق سطري؛ وإلا لفّ كتلي يحفظ بايتات النطاق حرفيًا.
    if (contentLines == 1 && firstLine == lastLine) {
      int contentEnd = trimCarriageReturn(text, indentEnd, layout.lineEnd[firstContent]);
      String content = text.substring(indentEnd, contentEnd).trim();
      String wrapped = indent + OPEN + " " + content + " " + CLOSE;
      int lineEnd = layout.lineEnd[firstContent];
      if (lineEnd < text.length() && text.charAt(lineEnd) == '\r') lineEnd++;
      return Outcome.apply(layout.lineStart[firstContent], lineEnd, wrapped);
    }

    String wrapped = indent + OPEN + "\n" + body + "\n" + indent + CLOSE;
    return Outcome.apply(regionStart, regionEnd, wrapped);
  }

  /** أمر المرجع «Un-Outcomment Code» لـXML: إزالة طبقة تعليق واحدة محيطَة. */
  public static Outcome uncomment(String text, int selStart, int selEnd) {
    int[] region = lineRegion(text, selStart, selEnd);
    int anchor = normalize(text, selStart, selEnd)[0];
    int[] span = XmlStructureScanner.commentSpanContaining(text, anchor);
    if (span == null) span = XmlStructureScanner.firstCommentSpanInRange(text, region[0], region[1]);
    if (span == null) return Outcome.reject("ui_xml_comment_none_to_remove");

    int open = span[0];
    int closeEnd = span[1];
    XmlStructureScanner.Layout layout = XmlStructureScanner.scan(text);
    int openLine = layout.lineAt(open);
    int closeLine = layout.lineAt(Math.max(open, closeEnd - 1));

    boolean openAlone = isBlankRange(text, layout.lineStart[openLine], open);
    boolean closeAlone = isBlankRange(text, closeEnd, layout.lineEnd[closeLine]);

    // شارتان كلٌّ على سطره → يُحذف السطران ويبقى المحتوى حرفيًا.
    if (openAlone && closeAlone && openLine != closeLine) {
      int contentStart = layout.lineEnd[openLine];
      if (contentStart < text.length() && text.charAt(contentStart) == '\r') contentStart++;
      if (contentStart < text.length() && text.charAt(contentStart) == '\n') contentStart++;
      int rangeEnd = layout.lineEnd[closeLine];
      if (rangeEnd < text.length() && text.charAt(rangeEnd) == '\r') rangeEnd++;
      if (rangeEnd < text.length() && text.charAt(rangeEnd) == '\n') rangeEnd++;
      return Outcome.apply(
          layout.lineStart[openLine], rangeEnd, text.substring(contentStart, layout.lineStart[closeLine]));
    }

    // وإلا تُنزع الشارتان فقط مع مسافة واحدة ملاصقة لكل منهما.
    int innerStart = open + OPEN.length();
    if (innerStart < closeEnd - CLOSE.length() && text.charAt(innerStart) == ' ') innerStart++;
    int innerEnd = closeEnd - CLOSE.length();
    if (innerEnd > innerStart && text.charAt(innerEnd - 1) == ' ') innerEnd--;
    return Outcome.apply(open, closeEnd, text.substring(innerStart, innerEnd));
  }

  /**
   * مدى الأسطر الكاملة المغطاة بالتحديد — بنفس دلالة مسار Java: تحديد ينتهي عند بداية سطر لا
   * يُدخِل ذلك السطر في النطاق.
   */
  public static int[] lineRegion(String text, int selStart, int selEnd) {
    int[] bounds = normalize(text, selStart, selEnd);
    int start = bounds[0];
    int end = bounds[1];
    int effectiveEnd = (end > start && end > 0 && text.charAt(end - 1) == '\n') ? end - 1 : end;
    int regionStart = start <= 0 ? 0 : text.lastIndexOf('\n', start - 1) + 1;
    int regionEnd = text.indexOf('\n', effectiveEnd);
    if (regionEnd < 0) regionEnd = text.length();
    if (regionStart > regionEnd) regionStart = regionEnd;
    return new int[] {regionStart, regionEnd};
  }

  private static int[] normalize(String text, int selStart, int selEnd) {
    int start = clamp(selStart, text.length());
    int end = clamp(selEnd, text.length());
    if (end < start) {
      int swap = start;
      start = end;
      end = swap;
    }
    return new int[] {start, end};
  }

  private static int clamp(int value, int length) {
    return value < 0 ? 0 : Math.min(value, length);
  }

  private static boolean isBlankLine(String text, XmlStructureScanner.Layout layout, int line) {
    return firstNonSpace(text, layout.lineStart[line], layout.lineEnd[line]) >= layout.lineEnd[line];
  }

  private static boolean isBlankRange(String text, int from, int to) {
    for (int i = from; i < to; i++) {
      if (!XmlStructureScanner.isSpace(text.charAt(i))) return false;
    }
    return true;
  }

  private static int firstNonSpace(String text, int from, int to) {
    int i = from;
    while (i < to && XmlStructureScanner.isSpace(text.charAt(i))) i++;
    return i;
  }

  private static int trimCarriageReturn(String text, int from, int to) {
    return to > from && text.charAt(to - 1) == '\r' ? to - 1 : to;
  }
}
