package com.shima.demo;

import almlk.CodeStyle;
import android.app.ActionBar;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

/**
 * إعدادات نمط الكود — المرحلة الثامنة.
 *
 * <p>شاشة عربية داكنة تُدار يدويًا على نمط {@code activity_settings}، وتكشف **حجمين فقط**:
 * إزاحة XML وإزاحة جافا — وهما الحجمان اللذان يُشرّفهما منسّق حقيقي في التطبيق. بقية مفاتيح
 * التفضيل التاريخية (html/css/js/cpp و max_single_imports) لا يُشرّفها أي منسّق، فلم تُعرض
 * مفاتيح كاذبة لها.
 *
 * <p>القراءة والكتابة تتمان عبر {@link CodeStyle} وحده، فالمنسّقان والشاشة يقرآن المصدر نفسه.
 */
public class CodeStyleActivity extends Activity {

  private EditText xmlField;
  private EditText javaField;

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    setContentView(R.layout.activity_code_style);
    setTitle(R.string.code_style_title);
    ActionBar bar = getActionBar();
    if (bar != null) {
      bar.setDisplayHomeAsUpEnabled(true);
      bar.setHomeAsUpIndicator(R.drawable.ic_navigation_back);
      bar.setBackgroundDrawable(new ColorDrawable(Color.rgb(34, 34, 34)));
    }
    getWindow().setStatusBarColor(Color.BLACK);
    getWindow().setNavigationBarColor(Color.rgb(35, 35, 35));

    xmlField = findViewById(R.id.codeStyleXmlIndent);
    javaField = findViewById(R.id.codeStyleJavaIndent);
    xmlField.setText(
        String.valueOf(CodeStyle.indentSize(this, CodeStyle.XML_INDENT_KEY)));
    javaField.setText(
        String.valueOf(CodeStyle.indentSize(this, CodeStyle.JAVA_INDENT_KEY)));
    findViewById(R.id.codeStyleSave).setOnClickListener(v -> save());
  }

  private void save() {
    Integer xml = parse(xmlField);
    Integer java = parse(javaField);
    if (xml == null || java == null) {
      Toast.makeText(this, R.string.code_style_invalid, Toast.LENGTH_SHORT).show();
      return;
    }
    CodeStyle.setIndentSize(this, CodeStyle.XML_INDENT_KEY, xml);
    CodeStyle.setIndentSize(this, CodeStyle.JAVA_INDENT_KEY, java);
    Toast.makeText(this, R.string.code_style_saved, Toast.LENGTH_SHORT).show();
    finish();
  }

  /**
   * تحقق صريح قبل الكتابة: رقم صحيح ضمن الحد الأعلى.
   *
   * <p>القراءة نفسها تسامحية (ترتد إلى الافتراضي)، لكن الكتابة ترفض العبث من البداية كي لا
   * يرى المستخدم قيمة تختلف عن سلوك المحرر.
   */
  private static Integer parse(EditText field) {
    String raw = field.getText().toString().trim();
    if (raw.isEmpty()) return null;
    int value;
    try {
      value = Integer.parseInt(raw);
    } catch (NumberFormatException error) {
      return null;
    }
    if (value < 0 || value > CodeStyle.MAX_INDENT) return null;
    return value;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      finish();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }
}
