package com.google.zxing.qrcode.decoder;

import com.google.zxing.FormatException;
import com.google.zxing.common.BitMatrix;

final class BitMatrixParser {
    private final BitMatrix bitMatrix;
    private boolean mirror;
    private FormatInformation parsedFormatInfo;
    private Version parsedVersion;

    BitMatrixParser(BitMatrix bitMatrix) throws FormatException {
        int height = bitMatrix.getHeight();
        if (height < 21 || (height & 3) != 1) {
            throw FormatException.getFormatInstance();
        }
        this.bitMatrix = bitMatrix;
    }

    private int copyBit(int i, int i2, int i3) {
        return this.mirror ? this.bitMatrix.get(i2, i) : this.bitMatrix.get(i, i2) ? (i3 << 1) | 1 : i3 << 1;
    }

    void mirror() {
        for (int i = 0; i < this.bitMatrix.getWidth(); i++) {
            for (int i2 = i + 1; i2 < this.bitMatrix.getHeight(); i2++) {
                if (this.bitMatrix.get(i, i2) != this.bitMatrix.get(i2, i)) {
                    this.bitMatrix.flip(i2, i);
                    this.bitMatrix.flip(i, i2);
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:31:0x0080 A[PHI: r3 r5
      0x0080: PHI (r3v4 int) = (r3v3 int), (r3v6 int) binds: [B:15:0x0048, B:20:0x005c] A[DONT_GENERATE, DONT_INLINE]
      0x0080: PHI (r5v4 int) = (r5v3 int), (r5v7 int) binds: [B:15:0x0048, B:20:0x005c] A[DONT_GENERATE, DONT_INLINE]] */
    byte[] readCodewords() throws FormatException {
        int i;
        FormatInformation formatInformation = readFormatInformation();
        Version version = readVersion();
        DataMask dataMask = DataMask.values()[formatInformation.getDataMask()];
        int height = this.bitMatrix.getHeight();
        dataMask.unmaskBitMatrix(this.bitMatrix, height);
        BitMatrix bitMatrixBuildFunctionPattern = version.buildFunctionPattern();
        byte[] bArr = new byte[version.getTotalCodewords()];
        int i2 = height - 1;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        boolean z = true;
        while (i2 > 0) {
            if (i2 == 6) {
                i2--;
            }
            for (int i6 = 0; i6 < height; i6++) {
                int i7 = z ? (height - 1) - i6 : i6;
                int i8 = 0;
                while (i8 < 2) {
                    if (bitMatrixBuildFunctionPattern.get(i2 - i8, i7)) {
                        i = i5;
                    } else {
                        i3++;
                        i4 <<= 1;
                        if (this.bitMatrix.get(i2 - i8, i7)) {
                            i4 |= 1;
                        }
                        if (i3 == 8) {
                            i = i5 + 1;
                            bArr[i5] = (byte) i4;
                            i3 = 0;
                            i4 = 0;
                        } else {
                            i = i5;
                        }
                    }
                    i8++;
                    i5 = i;
                }
            }
            i2 -= 2;
            z = !z;
        }
        if (i5 != version.getTotalCodewords()) {
            throw FormatException.getFormatInstance();
        }
        return bArr;
    }

    FormatInformation readFormatInformation() throws FormatException {
        int iCopyBit = 0;
        if (this.parsedFormatInfo != null) {
            return this.parsedFormatInfo;
        }
        int iCopyBit2 = 0;
        for (int i = 0; i < 6; i++) {
            iCopyBit2 = copyBit(i, 8, iCopyBit2);
        }
        int iCopyBit3 = copyBit(8, 7, copyBit(8, 8, copyBit(7, 8, iCopyBit2)));
        for (int i2 = 5; i2 >= 0; i2--) {
            iCopyBit3 = copyBit(8, i2, iCopyBit3);
        }
        int height = this.bitMatrix.getHeight();
        int i3 = height - 7;
        for (int i4 = height - 1; i4 >= i3; i4--) {
            iCopyBit = copyBit(8, i4, iCopyBit);
        }
        for (int i5 = height - 8; i5 < height; i5++) {
            iCopyBit = copyBit(i5, 8, iCopyBit);
        }
        this.parsedFormatInfo = FormatInformation.decodeFormatInformation(iCopyBit3, iCopyBit);
        if (this.parsedFormatInfo != null) {
            return this.parsedFormatInfo;
        }
        throw FormatException.getFormatInstance();
    }

    Version readVersion() throws FormatException {
        int iCopyBit = 0;
        if (this.parsedVersion != null) {
            return this.parsedVersion;
        }
        int height = this.bitMatrix.getHeight();
        int i = (height - 17) / 4;
        if (i <= 6) {
            return Version.getVersionForNumber(i);
        }
        int i2 = height - 11;
        int iCopyBit2 = 0;
        for (int i3 = 5; i3 >= 0; i3--) {
            for (int i4 = height - 9; i4 >= i2; i4--) {
                iCopyBit2 = copyBit(i4, i3, iCopyBit2);
            }
        }
        Version versionDecodeVersionInformation = Version.decodeVersionInformation(iCopyBit2);
        if (versionDecodeVersionInformation != null && versionDecodeVersionInformation.getDimensionForVersion() == height) {
            this.parsedVersion = versionDecodeVersionInformation;
            return versionDecodeVersionInformation;
        }
        for (int i5 = 5; i5 >= 0; i5--) {
            for (int i6 = height - 9; i6 >= i2; i6--) {
                iCopyBit = copyBit(i5, i6, iCopyBit);
            }
        }
        Version versionDecodeVersionInformation2 = Version.decodeVersionInformation(iCopyBit);
        if (versionDecodeVersionInformation2 == null || versionDecodeVersionInformation2.getDimensionForVersion() != height) {
            throw FormatException.getFormatInstance();
        }
        this.parsedVersion = versionDecodeVersionInformation2;
        return versionDecodeVersionInformation2;
    }

    void remask() {
        if (this.parsedFormatInfo == null) {
            return;
        }
        DataMask.values()[this.parsedFormatInfo.getDataMask()].unmaskBitMatrix(this.bitMatrix, this.bitMatrix.getHeight());
    }

    void setMirror(boolean z) {
        this.parsedVersion = null;
        this.parsedFormatInfo = null;
        this.mirror = z;
    }
}
