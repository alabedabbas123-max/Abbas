package com.shima.editor.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Background global index for Smali/source metadata. It never executes or loads project code. */
public final class InMemoryWorkspaceIndex implements WorkspaceIndex {
  private static final Pattern CLASS = Pattern.compile("^\\s*\\.class\\s+[^\\s]+\\s+(L[^;]+;)", Pattern.MULTILINE);
  private static final Pattern METHOD = Pattern.compile("^\\s*\\.method\\s+(?:[^\\s]+\\s+)*([A-Za-z0-9_$<>]+)(\\([^\\n]+)", Pattern.MULTILINE);
  private static final Pattern FIELD = Pattern.compile("^\\s*\\.field\\s+(?:[^\\s]+\\s+)*([A-Za-z0-9_$]+):([^\\s]+)", Pattern.MULTILINE);
  private static final Pattern REFERENCE = Pattern.compile("(L[^;\\s]+;)->([A-Za-z0-9_$<>]+)(\\([^\\n]*\\)[^\\s]+)");

  private final ExecutorService worker = Executors.newSingleThreadExecutor(runnable -> {
    Thread thread = new Thread(runnable, "shima-workspace-index");
    thread.setPriority(Thread.NORM_PRIORITY - 1);
    return thread;
  });
  private final Map<String, SourceEntry> sources = new HashMap<>();
  private final Map<SymbolId, SymbolLocation> definitions = new LinkedHashMap<>();
  private final Map<SymbolId, List<SymbolLocation>> references = new LinkedHashMap<>();
  private final Object lock = new Object();

  @Override
  public void update(String file, CharSequence source, Callback<Boolean> callback) {
    worker.execute(() -> {
      boolean success = false;
      Throwable error = null;
      try {
        synchronized (lock) {
          sources.put(file == null ? "" : file, new SourceEntry(file, source == null ? "" : source.toString()));
          rebuildLocked();
        }
        success = true;
      } catch (Throwable failure) {
        error = failure;
      }
      complete(callback, success, error);
    });
  }

  @Override
  public void remove(String file, Callback<Boolean> callback) {
    worker.execute(() -> {
      boolean removed;
      synchronized (lock) {
        removed = sources.remove(file == null ? "" : file) != null;
        rebuildLocked();
      }
      complete(callback, removed, null);
    });
  }

  @Override
  public void findDefinition(SymbolId symbol, Callback<SymbolLocation> callback) {
    worker.execute(() -> {
      SymbolLocation value = null;
      synchronized (lock) {
        value = definitions.get(symbol);
        if (value == null && symbol != null) {
          for (Map.Entry<SymbolId, SymbolLocation> entry : definitions.entrySet()) {
            if (entry.getKey().owner.equals(symbol.owner) && entry.getKey().name.equals(symbol.name)) {
              value = entry.getValue();
              break;
            }
          }
        }
      }
      complete(callback, value, null);
    });
  }

  @Override
  public void findReferences(SymbolId symbol, Callback<List<SymbolLocation>> callback) {
    worker.execute(() -> {
      List<SymbolLocation> value;
      synchronized (lock) {
        value = references.get(symbol);
        if (value == null) value = Collections.emptyList();
        else value = new ArrayList<>(value);
      }
      complete(callback, value, null);
    });
  }

  @Override
  public void searchClasses(String prefix, int limit, Callback<List<SymbolId>> callback) {
    worker.execute(() -> {
      String query = prefix == null ? "" : prefix;
      int max = Math.max(1, limit);
      ArrayList<SymbolId> result = new ArrayList<>();
      synchronized (lock) {
        for (SymbolId symbol : definitions.keySet()) {
          if (symbol.name.isEmpty() && (query.isEmpty() || symbol.owner.startsWith(query))) result.add(symbol);
          else if (symbol.name.isEmpty() && symbol.owner.startsWith(query)) result.add(symbol);
          if (result.size() >= max) break;
        }
      }
      complete(callback, result, null);
    });
  }

  private void rebuildLocked() {
    definitions.clear();
    references.clear();
    for (SourceEntry source : sources.values()) indexDefinitions(source);
    for (SourceEntry source : sources.values()) indexReferences(source);
  }

  private void indexDefinitions(SourceEntry source) {
    String text = source.text;
    String owner = "";
    Matcher classMatcher = CLASS.matcher(text);
    if (classMatcher.find()) {
      owner = classMatcher.group(1);
      int line = lineOf(text, classMatcher.start(1));
      definitions.put(new SymbolId(owner, "", ""), location(source.file, text, classMatcher.start(1), classMatcher.end(1), line));
    }
    Matcher methods = METHOD.matcher(text);
    while (methods.find()) {
      String descriptor = methods.group(2);
      int nameStart = methods.start(1);
      definitions.put(new SymbolId(owner, methods.group(1), descriptor), location(source.file, text, nameStart, methods.end(1), lineOf(text, nameStart)));
    }
    Matcher fields = FIELD.matcher(text);
    while (fields.find()) {
      definitions.put(new SymbolId(owner, fields.group(1), fields.group(2)), location(source.file, text, fields.start(1), fields.end(1), lineOf(text, fields.start(1))));
    }
  }

  private void indexReferences(SourceEntry source) {
    Matcher matcher = REFERENCE.matcher(source.text);
    while (matcher.find()) {
      SymbolId symbol = new SymbolId(matcher.group(1), matcher.group(2), matcher.group(3));
      List<SymbolLocation> values = references.get(symbol);
      if (values == null) {
        values = new ArrayList<>();
        references.put(symbol, values);
      }
      values.add(location(source.file, source.text, matcher.start(), matcher.end(), lineOf(source.text, matcher.start())));
    }
  }

  private SymbolLocation location(String file, String source, int start, int end, int line) {
    int lineStart = source.lastIndexOf('\n', Math.max(0, start - 1)) + 1;
    return new SymbolLocation(file, start, end, line, start - lineStart + 1);
  }

  private int lineOf(String source, int offset) {
    int line = 1;
    for (int i = 0; i < offset && i < source.length(); i++) if (source.charAt(i) == '\n') line++;
    return line;
  }

  private <T> void complete(Callback<T> callback, T value, Throwable error) {
    if (callback != null) callback.completed(value, error);
  }

  @Override
  public void close() {
    worker.shutdownNow();
  }

  private static final class SourceEntry {
    final String file;
    final String text;

    SourceEntry(String file, String text) {
      this.file = file == null ? "" : file;
      this.text = text;
    }
  }
}
