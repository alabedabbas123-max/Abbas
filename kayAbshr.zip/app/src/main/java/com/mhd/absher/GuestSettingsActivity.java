package com.mhd.absher;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.a.a.a.a.a;
import com.google.firebase.FirebaseApp;

public class GuestSettingsActivity extends AppCompatActivity {
    private GuestSettingsBinding binding;

    private void initialize(Bundle bundle) {
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initializeLogic() {
        getWindow().getDecorView().setLayoutDirection(1);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(Color.parseColor(a.a("dmV0HApkZg==")));
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setPadding(40, 40, 40, 60);
        TextView textView = new TextView(this);
        textView.setText(a.a("jf6fqA=="));
        textView.setTextSize(18.0f);
        textView.setTextColor(Color.parseColor(a.a("dmQFGnlhFQ==")));
        textView.setPadding(10, 10, 10, 30);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 8388611;
        textView.setLayoutParams(layoutParams);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GuestSettingsActivity.this.finish();
            }
        });
        linearLayout.addView(textView);
        TextView textView2 = new TextView(this);
        textView2.setText(a.a("jfOfqeD/jcf1jozen6ng8ozs"));
        textView2.setTextSize(14.0f);
        textView2.setTextColor(Color.parseColor(a.a("dhUHbHkUFQ==")));
        textView2.setGravity(8388611);
        textView2.setPadding(0, 0, 10, 20);
        linearLayout.addView(textView2);
        View cardView = new CardView(this);
        cardView.setRadius(24.0f);
        cardView.setCardBackgroundColor(Color.parseColor(a.a("dmZyHwBnFw==")));
        cardView.setContentPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.setMargins(0, 10, 0, 0);
        cardView.setLayoutParams(layoutParams2);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutDirection(1);
        TextView textView3 = new TextView(this);
        textView3.setText(a.a("jfOfqeHRjPz1kQ=="));
        textView3.setTextSize(16.0f);
        textView3.setTextColor(-1);
        textView3.setGravity(8388611);
        textView3.setPadding(20, 20, 20, 20);
        linearLayout2.addView(textView3);
        View view = new View(this);
        view.setLayoutParams(new LinearLayout.LayoutParams(-1, 2));
        view.setBackgroundColor(Color.parseColor(a.a("dmcHHn5hYQ==")));
        linearLayout2.addView(view);
        RadioGroup radioGroup = new RadioGroup(this);
        radioGroup.setPadding(10, 20, 10, 10);
        radioGroup.setLayoutDirection(1);
        RadioButton radioButton = new RadioButton(this);
        radioButton.setText(a.a("jfOfqeDsjPf1kIzenoQ="));
        radioButton.setTextSize(16.0f);
        radioButton.setTextColor(-1);
        radioButton.setLayoutDirection(1);
        final RadioButton radioButton2 = new RadioButton(this);
        radioButton2.setText(a.a("EDohQVEmPA=="));
        radioButton2.setTextSize(16.0f);
        radioButton2.setTextColor(-1);
        radioButton2.setLayoutDirection(1);
        radioGroup.addView(radioButton);
        radioGroup.addView(radioButton2);
        final SharedPreferences sharedPreferences = getSharedPreferences(a.a("NCQ2ckswIDJEVjIn"), 0);
        if (sharedPreferences.getString(a.a("NCQ2clQ0OiFYWTIx"), a.a("NCY=")).equals(a.a("MDo="))) {
            radioButton2.setChecked(true);
        } else {
            radioButton.setChecked(true);
        }
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup2, int i) {
                String strA = a.a("NCY=");
                if (i == radioButton2.getId()) {
                    strA = a.a("MDo=");
                }
                sharedPreferences.edit().putString(a.a("NCQ2clQ0OiFYWTIx"), strA).apply();
                Toast.makeText(GuestSettingsActivity.this.getApplicationContext(), a.a("jf6fqBiN/p6A4PqNzPWTdYzh9LyM0J6X4Px0noXh04zq9Z+N+Q=="), 0).show();
            }
        });
        linearLayout2.addView(radioGroup);
        cardView.addView(linearLayout2);
        linearLayout.addView(cardView);
        setContentView(linearLayout);
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = GuestSettingsBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        FirebaseApp.initializeApp(this);
        initializeLogic();
    }
}
