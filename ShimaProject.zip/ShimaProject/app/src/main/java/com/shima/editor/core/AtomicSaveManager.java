package com.shima.editor.core;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/** Debounced save queue with recovery copies and a single I/O lane. */
public final class AtomicSaveManager implements AutoCloseable {
  public interface Callback {
    void completed(boolean success, Throwable error);
  }

  private final Context context;
  private final ContentResolver resolver;
  private final Handler main = new Handler(Looper.getMainLooper());
  private final ScheduledExecutorService io = Executors.newSingleThreadScheduledExecutor(runnable -> {
    Thread thread = new Thread(runnable, "shima-atomic-save");
    thread.setPriority(Thread.NORM_PRIORITY - 1);
    return thread;
  });
  private final Map<String, ScheduledFuture<?>> pending = new HashMap<>();

  public AtomicSaveManager(Context context) {
    this.context = context.getApplicationContext();
    this.resolver = this.context.getContentResolver();
  }

  public synchronized void requestSave(
      String key, String reference, String content, SavePolicy policy, Callback callback) {
    final String safeKey = key == null || key.isEmpty() ? reference : key;
    ScheduledFuture<?> old = pending.remove(safeKey);
    if (old != null) old.cancel(false);
    SavePolicy effective = policy == null ? SavePolicy.editorDefault() : policy;
    ScheduledFuture<?> task =
        io.schedule(
            () -> {
              try {
                if (effective.createRecoveryCopy) writeRecovery(safeKey, content, effective.maxRecoveryCopies);
                writeReference(reference, content);
                if (effective.createRecoveryCopy) deleteRecovery(safeKey);
                finish(safeKey, true, null, callback);
              } catch (Throwable error) {
                finish(safeKey, false, error, callback);
              }
            },
            effective.debounceMs,
            TimeUnit.MILLISECONDS);
    pending.put(safeKey, task);
  }

  public synchronized void cancel(String key) {
    ScheduledFuture<?> task = pending.remove(key);
    if (task != null) task.cancel(false);
  }

  public File recoveryDirectory() {
    File directory = new File(context.getFilesDir(), "editor-recovery");
    if (!directory.exists()) directory.mkdirs();
    return directory;
  }

  private void writeReference(String reference, String content) throws IOException {
    if (reference == null || reference.trim().isEmpty()) throw new IOException("مسار الملف فارغ");
    if (reference.startsWith("content://")) {
      try (OutputStream output = resolver.openOutputStream(Uri.parse(reference), "wt")) {
        if (output == null) throw new IOException("مزود الملفات لم يسمح بالكتابة");
        output.write((content == null ? "" : content).getBytes(StandardCharsets.UTF_8));
        output.flush();
      }
      return;
    }
    AtomicFileWriter.write(new File(reference.startsWith("file://") ? Uri.parse(reference).getPath() : reference), content, StandardCharsets.UTF_8);
  }

  private void writeRecovery(String key, String content, int maxCopies) throws IOException {
    File directory = recoveryDirectory();
    String safe = Integer.toHexString((key == null ? "" : key).hashCode());
    File target = new File(directory, safe + ".recovery");
    AtomicFileWriter.write(target, content, StandardCharsets.UTF_8);
    File[] files = directory.listFiles((dir, name) -> name.startsWith(safe + ".") && name.endsWith(".recovery"));
    if (files != null && files.length > Math.max(1, maxCopies)) {
      ArrayList<File> ordered = new ArrayList<>();
      Collections.addAll(ordered, files);
      Collections.sort(ordered, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
      for (int i = 0; i < ordered.size() - maxCopies; i++) ordered.get(i).delete();
    }
  }

  private void deleteRecovery(String key) {
    String safe = Integer.toHexString((key == null ? "" : key).hashCode());
    new File(recoveryDirectory(), safe + ".recovery").delete();
  }

  private void finish(String key, boolean success, Throwable error, Callback callback) {
    synchronized (this) {
      pending.remove(key);
    }
    if (callback != null) main.post(() -> callback.completed(success, error));
  }

  @Override
  public synchronized void close() {
    for (ScheduledFuture<?> task : pending.values()) task.cancel(true);
    pending.clear();
    io.shutdownNow();
  }
}
