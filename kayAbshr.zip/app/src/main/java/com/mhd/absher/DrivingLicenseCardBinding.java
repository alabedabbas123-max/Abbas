package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class DrivingLicenseCardBinding {
    public final RelativeLayout documentCard2;
    public final FrameLayout frameLicenseQrcode;
    public final ImageView imageviewLicenseBarcode;
    public final ImageView imageviewLicensePhoto;
    public final ImageView imageviewLicenseQrLogo;
    public final ImageView ivDocument2;
    public final RelativeLayout rootView;
    public final TextView tvLicenseBirthDateAr;
    public final TextView tvLicenseBirthDateEn;
    public final TextView tvLicenseBloodTypeAr;
    public final TextView tvLicenseBloodTypeEn;
    public final TextView tvLicenseExpiryDateAr;
    public final TextView tvLicenseExpiryDateEn;
    public final TextView tvLicenseIdNumberAr;
    public final TextView tvLicenseIdNumberEn;
    public final TextView tvLicenseIssueDateAr;
    public final TextView tvLicenseIssueDateEn;
    public final TextView tvLicenseNameAr;
    public final TextView tvLicenseNameEn;
    public final TextView tvLicenseNationalityAr;
    public final TextView tvLicenseNationalityEn;
    public final TextView tvLicenseTypeAr;
    public final TextView tvLicenseTypeEn;

    private DrivingLicenseCardBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, ImageView imageView2, FrameLayout frameLayout, ImageView imageView3, ImageView imageView4, TextView textView, TextView textView2, TextView textView3, TextView textView4, TextView textView5, TextView textView6, TextView textView7, TextView textView8, TextView textView9, TextView textView10, TextView textView11, TextView textView12, TextView textView13, TextView textView14, TextView textView15, TextView textView16) {
        this.rootView = relativeLayout;
        this.documentCard2 = relativeLayout2;
        this.ivDocument2 = imageView;
        this.imageviewLicensePhoto = imageView2;
        this.frameLicenseQrcode = frameLayout;
        this.imageviewLicenseBarcode = imageView3;
        this.imageviewLicenseQrLogo = imageView4;
        this.tvLicenseNameAr = textView;
        this.tvLicenseNameEn = textView2;
        this.tvLicenseIdNumberAr = textView3;
        this.tvLicenseIdNumberEn = textView4;
        this.tvLicenseTypeAr = textView5;
        this.tvLicenseTypeEn = textView6;
        this.tvLicenseIssueDateAr = textView7;
        this.tvLicenseIssueDateEn = textView8;
        this.tvLicenseBirthDateAr = textView9;
        this.tvLicenseBirthDateEn = textView10;
        this.tvLicenseNationalityAr = textView11;
        this.tvLicenseNationalityEn = textView12;
        this.tvLicenseExpiryDateAr = textView13;
        this.tvLicenseExpiryDateEn = textView14;
        this.tvLicenseBloodTypeAr = textView15;
        this.tvLicenseBloodTypeEn = textView16;
    }

    public static DrivingLicenseCardBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.documentCard2);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.ivDocument2);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview_license_photo);
        FrameLayout frameLayout = (FrameLayout) findChildViewById(view, R.id.frame_license_qrcode);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.imageview_license_barcode);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.imageview_license_qr_logo);
        TextView textView = (TextView) findChildViewById(view, R.id.tvLicenseNameAr);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvLicenseNameEn);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tvLicenseIdNumberAr);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tvLicenseIdNumberEn);
        TextView textView5 = (TextView) findChildViewById(view, R.id.tvLicenseTypeAr);
        TextView textView6 = (TextView) findChildViewById(view, R.id.tvLicenseTypeEn);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tvLicenseIssueDateAr);
        TextView textView8 = (TextView) findChildViewById(view, R.id.tvLicenseIssueDateEn);
        TextView textView9 = (TextView) findChildViewById(view, R.id.tvLicenseBirthDateAr);
        TextView textView10 = (TextView) findChildViewById(view, R.id.tvLicenseBirthDateEn);
        TextView textView11 = (TextView) findChildViewById(view, R.id.tvLicenseNationalityAr);
        TextView textView12 = (TextView) findChildViewById(view, R.id.tvLicenseNationalityEn);
        TextView textView13 = (TextView) findChildViewById(view, R.id.tvLicenseExpiryDateAr);
        TextView textView14 = (TextView) findChildViewById(view, R.id.tvLicenseExpiryDateEn);
        TextView textView15 = (TextView) findChildViewById(view, R.id.tvLicenseBloodTypeAr);
        TextView textView16 = (TextView) findChildViewById(view, R.id.tvLicenseBloodTypeEn);
        if (relativeLayout2 == null || imageView == null || imageView2 == null || frameLayout == null || imageView3 == null || imageView4 == null || textView == null || textView2 == null || textView3 == null || textView4 == null || textView5 == null || textView6 == null || textView7 == null || textView8 == null || textView9 == null || textView10 == null || textView11 == null || textView12 == null || textView13 == null || textView14 == null || textView15 == null || textView16 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new DrivingLicenseCardBinding(relativeLayout, relativeLayout2, imageView, imageView2, frameLayout, imageView3, imageView4, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13, textView14, textView15, textView16);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static DrivingLicenseCardBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static DrivingLicenseCardBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.driving_license_card, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
