package com.almlkid.kay.ui;

import android.content.Context;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import almlk.CodeEditorView;
import almlk.IdentifierBounds;
import almlk.LineDocument;
import almlk.LineStyler;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.shima.demo.ThemeConfig;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * واجهة المحرر الرسمية للتطبيق — نفس اسم الكلاس والـAPI العام كما كان، لكنها بعد بند الإحلال
 * (البند 4) يقودها محرك almlk الكامل: لوحة رسم مخصصة + موديل أسطر + ملوّن تزايدي خلفي +
 * إدخال OEditor + تراجع مدمج. حُذف مسار EditText/Spans القديم نهائيًا (لا مساران متوازيان).
 *
 * <p>محوّلات التوافق الباقية (adapters — يسمح بها البند 4): التشخيصات والإكمال والتنسيق عبر
 * {@link CodeLanguageTools}، وفهرسة الرموز عبر ProjectSymbolIndex من طبقة الـPager كما كانت.
 */
public class AlmlkEditor extends CodeEditorView {

  public interface DiagnosticsListener {
    void onDiagnostics(List<CodeLanguageTools.Diagnostic> items);
  }

  public interface ChangeListener {
    void onChanged(long documentVersion);
  }

  public interface ScrollListener {
    void onEditorScroll(int x, int y);

    void onEditorZoom(float textSizePixels);
  }

  // ---------------- الحقول ----------------

  private int keyword, string, comment, number, annotation, tag, identifier, function, variable,
      operator, namespace, separator;
  private int plainColor = 0xFFECEFF1;

  private String fileName = "";
  private volatile boolean analysisPaused;

  private final LineStyler styler;
  private final ExecutorService diagnosticsWorker = Executors.newSingleThreadExecutor();
  private final Runnable diagnosticsTask = this::runDiagnostics;
  private List<CodeLanguageTools.Diagnostic> diagnostics = Collections.emptyList();
  private final HashMap<Integer, Integer> lineFlags = new HashMap<>();

  private ChangeListener changeListener;
  private ScrollListener scrollListener;
  private DiagnosticsListener diagnosticsListener;
  private final ArrayList<TextWatcher> watchers = new ArrayList<>();

  /** مخزن النص الكامل بالإصدار — يبنى مرة لكل إصدار (callers تقرأه بلا كلفة متكررة). */
  private String textCache = "";
  private long textCacheVersion = -1;
  private String lastDispatchedText = "";

  public AlmlkEditor(Context context) {
    this(context, null);
  }

  public AlmlkEditor(Context context, AttributeSet attrs) {
    this(context, attrs, 0);
  }

  public AlmlkEditor(Context context, AttributeSet attrs, int style) {
    super(context);
    styler = new LineStyler(getDocument());
    styler.setListener((from, to) -> postInvalidate());
    setStyleProvider(
        new StyleProvider() {
          @Override
          public int[] lineStyles(LineDocument document, int line) {
            return styler.stylesForLine(line);
          }

          @Override
          public int colorFor(int styleId) {
            return AlmlkEditor.this.colorFor(styleId);
          }
        });
    setLineFlagProvider(
        line -> {
          synchronized (lineFlags) {
            Integer flags = lineFlags.get(line);
            return flags == null ? 0 : flags;
          }
        });
    setReplacementListener(this::onContentReplaced);
    applyEditorInteraction();
    applyTheme();
  }

  // ---------------- التوصيل بطبقة الإدخال (hooks من CodeEditorView) ----------------

  private void applyEditorInteraction() {
    // CodeEditorView يملك بالفعل مستمع تفاعلات للوحة (قائمة التحديد/الكيبورد)؛ هنا نضيف
    // بثّ التمرير/التكبير الخارجي عبر hooks محمية في الأب.
  }

  @Override
  protected void onEditorScrolledExternal(int x, int y) {
    ScrollListener listener = scrollListener;
    if (listener != null) listener.onEditorScroll(x, y);
  }

  @Override
  protected void onEditorZoomedExternal(float textSizePixels) {
    ScrollListener listener = scrollListener;
    if (listener != null) listener.onEditorZoom(textSizePixels);
  }

  // ---------------- نص الواجهة (CharSequence المقروء) ----------------

  private String currentText() {
    long version = getDocument().version();
    if (version != textCacheVersion) {
      textCacheVersion = version;
      textCache = getDocument().toString();
    }
    return textCache;
  }

  /** متوافق مع EditText.getText() — للقراءة فقط. التحرير يمر بـ replaceRange/الإدخال. */
  public CharSequence getText() {
    return currentText();
  }

  public void setText(CharSequence text) {
    String before = currentText();
    getDocument().setAll(text == null ? "" : text.toString());
    clearHistory();
    clearSelection();
    setCaret(0, 0);
    styler.request(0, Integer.MAX_VALUE);
    scrollTo(0, 0);
    dispatchTextChanged(before, currentText(), 0, before.length());
    scheduleDiagnostics(120);
  }

  public int length() {
    return getDocument().length();
  }

  // ---------------- التحديد بالإزاحات (واجهة TextView) ----------------

  public int getSelectionStart() {
    return selectionOffsets()[0];
  }

  public int getSelectionEnd() {
    return selectionOffsets()[1];
  }

  public void setSelection(int index) {
    int offset = Math.max(0, Math.min(index, length()));
    int line = getDocument().lineForOffset(offset);
    setCaret(line, offset - getDocument().lineStartOffset(line));
  }

  public void setSelection(int start, int end) {
    int from = Math.max(0, Math.min(Math.min(start, end), length()));
    int to = Math.max(from, Math.min(Math.max(start, end), length()));
    if (from == to) {
      setSelection(from);
      return;
    }
    int startLine = getDocument().lineForOffset(from);
    int endLine = getDocument().lineForOffset(to);
    setSelectionRange(
        startLine, from - getDocument().lineStartOffset(startLine),
        endLine, to - getDocument().lineStartOffset(endLine));
  }

  public int[] selectionOrIdentifier() {
    int start = getSelectionStart(), end = getSelectionEnd();
    if (start != end) return new int[] {start, end};
    String text = currentText();
    if (text.isEmpty() || start >= text.length())
      return new int[] {Math.max(0, Math.min(start, text.length())),
          Math.max(0, Math.min(start, text.length()))};
    int from = IdentifierBounds.start(text, start);
    int to = IdentifierBounds.end(text, start);
    return new int[] {from, to};
  }

  public void normalizeSelectionToTouchedIdentifier() {
    int[] range = selectionOrIdentifier();
    if (range[0] < range[1]) setSelection(range[0], range[1]);
  }

  // ---------------- TextWatcher مكافئ (الـPager يعتمدها) ----------------

  public void addTextChangedListener(TextWatcher watcher) {
    if (!watchers.contains(watcher)) watchers.add(watcher);
  }

  public void removeTextChangedListener(TextWatcher watcher) {
    watchers.remove(watcher);
  }

  private void dispatchTextChanged(String before, String after, int start, int removedCount) {
    int addedCount = Math.max(0, after.length() - (before.length() - removedCount));
    for (int i = watchers.size() - 1; i >= 0; i--) {
      TextWatcher watcher = watchers.get(i);
      watcher.beforeTextChanged(before, start, removedCount, addedCount);
      watcher.onTextChanged(after, start, removedCount, addedCount);
      watcher.afterTextChanged(null);
    }
    lastDispatchedText = after;
  }

  private void onContentReplaced(int start, int removedCount, int insertedCount) {
    String before = lastDispatchedText;
    String after = currentText();
    dispatchTextChanged(before, after, start, removedCount);
    ChangeListener listener = changeListener;
    if (listener != null) listener.onChanged(getDocument().version());
    scheduleDiagnostics(600);
  }

  // ---------------- المستمعون الخارجيون ----------------

  public void setChangeListener(ChangeListener listener) {
    changeListener = listener;
  }

  public void setScrollListener(ScrollListener listener) {
    scrollListener = listener;
  }

  public void setDiagnosticsListener(DiagnosticsListener listener) {
    diagnosticsListener = listener;
  }

  public void setAnalysisPaused(boolean paused) {
    analysisPaused = paused;
    styler.setPaused(paused);
    if (paused) removeCallbacks(diagnosticsTask);
    else refreshNow();
  }

  /** توافق واجهة EditText: عناصر قائمة تحديد مخصصة تُلحق بالقائمة المدمجة. */
  public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
    if (callback == null) {
      setActionModeContributor(null);
      return;
    }
    setActionModeContributor(
        new ActionModeContributor() {
          @Override
          public void onCreateMenu(ActionMode mode, Menu menu) {
            callback.onCreateActionMode(mode, menu);
          }

          @Override
          public boolean onMenuItem(ActionMode mode, MenuItem item) {
            return callback.onActionItemClicked(mode, item);
          }

          @Override
          public void onDestroy(ActionMode mode) {
            callback.onDestroyActionMode(mode);
          }
        });
  }

  /** توافق TextView.setLineSpacing (الإضافة بالبكسل تمرر لمقاسات اللوحة). */
  public void setLineSpacing(float add, float mult) {
    setLineSpacingExtra(mult <= 0 ? add : add * mult);
  }

  /** توافق TextView.setHint بمورد نصي. */
  public void setHint(int resource) {
    setHint(getContext().getString(resource));
  }

  /** توافق EditText.onTextContextMenuItem (قائمة السياق أندرويد من الـPager). */
  public boolean onTextContextMenuItem(int id) {
    if (id == android.R.id.selectAll) {
      selectAll();
      return true;
    }
    if (id == android.R.id.cut) {
      cutSelection();
      return true;
    }
    if (id == android.R.id.copy) {
      copySelection();
      return true;
    }
    if (id == android.R.id.paste) {
      pasteClipboard();
      return true;
    }
    return false;
  }

  /** توافق EditText.bringPointIntoView: التمرير حتى تظهر الإزاحة (بحث/انتقال). */
  public boolean bringPointIntoView(int offset) {
    return scrollOffsetIntoView(offset);
  }

  /** موضع إزاحة داخل الـView: [x أفقي، y أسفل السطر] — بديل Layout القديم لنوافذ الإكمال. */
  public int[] offsetToViewPosition(int offset) {
    int clamped = Math.max(0, Math.min(offset, length()));
    int line = getDocument().lineForOffset(clamped);
    int column = clamped - getDocument().lineStartOffset(line);
    float x = gutterWidth() + metrics().columnToX(column) - getScrollX();
    float y = (line + 1) * lineStride() - getScrollY();
    return new int[] {(int) x, (int) y};
  }

  // ---------------- الملف والتحليل ----------------

  public void setFileName(String name) {
    fileName = name == null ? "" : name;
    styler.setFileName(fileName);
    scheduleDiagnostics(150);
  }

  /**
   * توافق تاريخي مع استدعاء الـPager بعد الحفظ: الموديل الجديد هو المرجع الوحيد فلا شيء
   * يُعاد ربطه — يكتفي بتحديث اسم الملف.
   */
  public void resetCoreModel(String uri, CharSequence currentText) {
    setFileName(uri);
  }

  public String formatCode() {
    return CodeLanguageTools.format(fileName, currentText());
  }

  public void refreshNow() {
    if (analysisPaused) return;
    styler.request(0, Integer.MAX_VALUE);
    scheduleDiagnostics(250);
  }

  public List<String> completions() {
    return CodeLanguageTools.complete(fileName, currentText(), getSelectionStart());
  }

  public void applyCompletion(String value) {
    String text = currentText();
    int cursor = Math.max(0, Math.min(getSelectionStart(), text.length()));
    int start = Math.max(0, Math.min(CodeLanguageTools.completionStart(text, cursor), cursor));
    replaceRange(start, cursor, value);
    int target = start + value.length();
    if (value.endsWith("()")) target--;
    setSelection(Math.min(target, length()));
    requestFocus();
  }

  // ---------------- التشخيصات (محوّل — كما كانت، خلفية + أعلام سطور بدل Spans) ----------------

  private void scheduleDiagnostics(long delayMs) {
    if (analysisPaused) return;
    removeCallbacks(diagnosticsTask);
    postDelayed(diagnosticsTask, delayMs);
  }

  private void runDiagnostics() {
    if (analysisPaused) return;
    final String name = fileName;
    final String text = currentText();
    if (text.length() > 80000 || name.isEmpty()) {
      // سياسة الملفات الضخمة (من 1.0.13): لا تشخيص كامل — يبقى التلوين التزايدي وحده.
      updateDiagnostics(Collections.<CodeLanguageTools.Diagnostic>emptyList());
      return;
    }
    diagnosticsWorker.execute(
        () -> {
          try {
            final List<CodeLanguageTools.Diagnostic> found = CodeLanguageTools.inspect(name, text);
            post(() -> updateDiagnostics(found));
          } catch (Throwable error) {
            Log.w("AlmlkEditor", "diagnostics failed", error);
          }
        });
  }

  private void updateDiagnostics(List<CodeLanguageTools.Diagnostic> found) {
    if (analysisPaused) return;
    diagnostics = found;
    synchronized (lineFlags) {
      lineFlags.clear();
      for (CodeLanguageTools.Diagnostic item : found) {
        int line = Math.max(0, item.line);
        int flags = lineFlags.containsKey(line) ? lineFlags.get(line) : 0;
        lineFlags.put(line, flags | FLAG_ERROR);
      }
    }
    invalidate();
    DiagnosticsListener listener = diagnosticsListener;
    if (listener != null) listener.onDiagnostics(getDiagnostics());
  }

  public List<CodeLanguageTools.Diagnostic> getDiagnostics() {
    return new ArrayList<>(diagnostics);
  }

  // ---------------- الثيم والألوان ----------------

  public void applyTheme() {
    ThemeConfig theme = new ThemeConfig(getContext());
    keyword = theme.color(ThemeConfig.KEYWORD);
    string = theme.color(ThemeConfig.LITERAL);
    comment = theme.color(ThemeConfig.COMMENT);
    number = theme.color(ThemeConfig.LITERAL);
    annotation = theme.color(ThemeConfig.OPERATOR);
    tag = theme.color(ThemeConfig.TYPE);
    identifier = theme.color(ThemeConfig.IDENTIFIER);
    function = theme.color(ThemeConfig.FUNCTION);
    variable = theme.color(ThemeConfig.VARIABLE);
    operator = theme.color(ThemeConfig.OPERATOR);
    namespace = theme.color(ThemeConfig.NAMESPACE);
    separator = theme.color(ThemeConfig.SEPARATOR);
    plainColor = theme.color(ThemeConfig.PLAIN);

    int background = theme.color(ThemeConfig.BACKGROUND);
    int backgroundRgb = background | 0xFF000000;
    int gutterBackground =
        (((int) ((backgroundRgb & 0xFF) * 1.15f) & 0xFF))
            | (((int) (((backgroundRgb >> 8) & 0xFF) * 1.15f) & 0xFF) << 8)
            | (((int) (((backgroundRgb >> 16) & 0xFF) * 1.15f) & 0xFF) << 16)
            | 0xFF000000;
    setEditorColors(
        plainColor,
        theme.color(ThemeConfig.LINE_NUMBER),
        background,
        gutterBackground,
        theme.color(ThemeConfig.SELECTED_LINE),
        theme.color(ThemeConfig.SELECTED_TEXT),
        plainColor,
        theme.color(ThemeConfig.OPERATOR));
    setFlagColors(0xFFEF5350, 0xFFFFA726, 0xFFEC407A, 0xFF42A5F5);
    refreshNow();
  }

  public int colorFor(int type) {
    switch (type) {
      case CodeLanguageTools.KEYWORD:
        return keyword;
      case CodeLanguageTools.STRING:
        return string;
      case CodeLanguageTools.COMMENT:
        return comment;
      case CodeLanguageTools.NUMBER:
        return number;
      case CodeLanguageTools.ANNOTATION:
        return annotation;
      case CodeLanguageTools.TAG:
        return tag;
      case CodeLanguageTools.IDENTIFIER:
        return identifier;
      case CodeLanguageTools.FUNCTION:
        return function;
      case CodeLanguageTools.VARIABLE:
        return variable;
      case CodeLanguageTools.OPERATOR:
        return operator;
      case CodeLanguageTools.NAMESPACE:
        return namespace;
      case CodeLanguageTools.SEPARATOR:
        return separator;
      default:
        return plainColor;
    }
  }

  // ---------------- دورة الحياة ----------------

  @Override
  protected void onDetachedFromWindow() {
    removeCallbacks(diagnosticsTask);
    styler.shutdown();
    diagnosticsWorker.shutdownNow();
    super.onDetachedFromWindow();
  }
}
