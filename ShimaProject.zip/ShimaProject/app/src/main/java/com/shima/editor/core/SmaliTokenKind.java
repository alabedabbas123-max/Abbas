package com.shima.editor.core;

public enum SmaliTokenKind {
  COMMENT,
  DIRECTIVE,
  OPCODE,
  REGISTER,
  LABEL,
  TYPE_DESCRIPTOR,
  STRING,
  NUMBER,
  METHOD_NAME,
  FIELD_NAME,
  ANNOTATION,
  ERROR,
  PLAIN
}
