import almlk.CodeStyle;
import almlk.IdentifierBounds;
import almlk.LineBuffer;
import almlk.LineDocument;
import almlk.StyleRunBatcher;
import almlk.UndoRedoStack;
import almlk.XmlColorLiteral;
import almlk.XmlCodeFormatter;
import almlk.XmlCommentEditor;
import almlk.XmlResourceIndex;
import almlk.XmlResourceReference;
import almlk.XmlStructureScanner;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.ui.EditorMenuRegistry;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import net.margaritov.preference.colorpicker.HexColorCodec;

/**
 * مجموعة الانحدار الدائمة — المرحلة التاسعة (القبول الشامل).
 *
 * <p><b>لماذا داخل المشروع لا في /tmp:</b> بوابات المراحل السابقة كانت تُولَّد في {@code /tmp}
 * فتُمسح كل جلسة، وكنا نُعيد بناءها من الذاكرة. هذه المجموعة تبقى مع المصدر وتُشغَّل بأمر واحد
 * ({@code ./qa.sh})، فلا انحدار يمرّ بصمت بعد اليوم.
 *
 * <p><b>بلا أي تبعية خارجية:</b> جافا صرفة — لا JUnit ولا androidx.test. البدائل الثلاثة تحت
 * {@code qa/stubs/} تُصرَّف بدل android.jar لتغطية سطح {@code android.content} الذي تلمسه
 * {@code almlk.CodeStyle} فقط.
 *
 * <p><b>حدّ التغطية المُعلَن:</b> تُشغَّل أصناف المنطق الصرفة (12 من 19 في {@code almlk} + سجل
 * القوائم + أدوات اللغة). أصناف الرسم السبعة ({@code CodeCanvasView} ورفاقها) يغطيها
 * **البناء** و**فحص الحزمة** في {@code qa/acceptance.sh} لا هذه المجموعة — فهي تحتاج جهازًا.
 */
public class RegressionSuite {

  static int pass = 0;
  static int fail = 0;
  static final List<String> failures = new ArrayList<>();
  static String section = "";

  static final String SRC = "/home/user/ShimaProject/app/src/main/java";

  // ───────────────────────────────── أدوات ─────────────────────────────────

  static void section(String title) {
    section = title;
    System.out.println("\n[" + title + "]");
  }

  static void check(String name, boolean ok, String detail) {
    if (ok) {
      pass++;
      System.out.println("  ✔ " + name);
    } else {
      fail++;
      failures.add(section + " › " + name + " — " + (detail == null ? "" : detail));
      System.out.println("  ✘ " + name + " — " + detail);
    }
  }

  static android.content.Context freshPrefs() {
    android.preference.PreferenceManager.reset();
    return new android.content.Context();
  }

  static void putPref(String key, String value) {
    android.preference.PreferenceManager.store.put(key, value);
  }

  /** تجريد المسافات البادئة — لمقارنة «المحتوى نفسه بلا إزاحة». */
  static String stripIndent(String text) {
    StringBuilder out = new StringBuilder();
    for (String line : text.replace("\r", "").split("\n", -1)) {
      int i = 0;
      while (i < line.length() && line.charAt(i) == ' ') i++;
      out.append(line.substring(i)).append('\n');
    }
    return out.toString();
  }

  static int leadingOf(String text, int lineIndex) {
    String[] lines = text.split("\n", -1);
    if (lineIndex >= lines.length) return -1;
    String line = lines[lineIndex];
    int i = 0;
    while (i < line.length() && line.charAt(i) == ' ') i++;
    return i;
  }

  static int count(String text, char c) {
    int n = 0;
    for (int i = 0; i < text.length(); i++) if (text.charAt(i) == c) n++;
    return n;
  }

  /** البصمة غير البيضاء: كل المحارف عدا المسافة/الجدولة/السطر الجديد، بالترتيب. */
  static String nonWhitespaceSignature(String text) {
    StringBuilder out = new StringBuilder();
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c != ' ' && c != '\t' && c != '\n' && c != '\r') out.append(c);
    }
    return out.toString();
  }

  static String read(String relativePath) throws Exception {
    return new String(
        Files.readAllBytes(Paths.get("/home/user/ShimaProject", relativePath)),
        StandardCharsets.UTF_8);
  }

  static boolean containsInTree(String needle, String dir) throws Exception {
    File[] children = new File(dir).listFiles();
    if (children == null) return false;
    for (File child : children) {
      if (child.isDirectory()) {
        if (containsInTree(needle, child.getAbsolutePath())) return true;
      } else if (child.getName().endsWith(".java") || child.getName().endsWith(".xml")) {
        if (new String(Files.readAllBytes(child.toPath()), StandardCharsets.UTF_8).contains(needle)) {
          return true;
        }
      }
    }
    return false;
  }

  static EditorMenuRegistry.Entry entry(
      EditorMenuRegistry registry, String page, EditorMenuRegistry.Context context, String id) {
    for (EditorMenuRegistry.Entry e : registry.entries(page, context)) if (e.id.equals(id)) return e;
    return null;
  }

  // ─────────────────────────────── المدخل ───────────────────────────────

  public static void main(String[] args) throws Exception {
    structuralSoundness();
    xmlCompletion();
    coreAlmlk();
    phase6XmlEngine();
    phase7XmlSemantics();
    phase8CodeStyle();
    menuRegistry();
    noDeadPaths();

    System.out.println("\n══════════════════════════════════════════════════════");
    System.out.println("RegressionSuite: passed=" + pass + " failed=" + fail);
    if (fail > 0) {
      System.out.println("الإخفاقات:");
      for (String f : failures) System.out.println("  - " + f);
    }
    System.out.println("══════════════════════════════════════════════════════");
    if (fail > 0) System.exit(1);
  }

  // ═══════════════ §A السلامة البنيوية لمخرَج المنسّقات ═══════════════
  // العقد المتبنّى من دراسة المرجع (تقرير بند 2 §3): المنسّق لا يُفترَض سليمًا بل
  // **يُتحقَّق** من مخرَجه — google-java-format يرفض المصدر الذي لا يُحلَّل بدل إنتاج
  // مخرَج مكسور صمتًا. لا نسخنا المنسّق؛ تبنّينا العقد.

  static void structuralSoundness() {
    section("أ — السلامة البنيوية لمخرَج المنسّقات (عقد المرجع)");

    String java =
        "class A {\n"
            + "  void f() {\n"
            + "    if (x) { g(1, 2); }\n"
            + "    for (int i = 0; i < n; i++) { }\n"
            + "  }\n"
            + "}\n";
    String xml =
        "<resources>\n"
            + "  <string name=\"a\">1</string>\n"
            + "  <item>\n"
            + "    <sub/>\n"
            + "  </item>\n"
            + "</resources>\n";

    for (int indent : new int[] {0, 2, 4, 8, 16}) {
      String out = CodeLanguageTools.format(java, indent);
      check(
          "جافا: البصمة غير البيضاء محفوظة عند إزاحة " + indent,
          nonWhitespaceSignature(out).equals(nonWhitespaceSignature(java)),
          "اختلفت البصمة");
      check(
          "جافا: توازن { } محفوظ عند إزاحة " + indent,
          count(out, '{') == count(java, '{') && count(out, '}') == count(java, '}'),
          count(out, '{') + "/" + count(out, '}'));
      check(
          "جافا: توازن ( ) محفوظ عند إزاحة " + indent,
          count(out, '(') == count(java, '(') && count(out, ')') == count(java, ')'),
          count(out, '(') + "/" + count(out, ')'));
      check(
          "جافا: التنسيق ثابت (idempotent) عند إزاحة " + indent,
          CodeLanguageTools.format(out, indent).equals(out),
          "تغيّر الناتج عند إعادة التنسيق");
    }

    for (int indent : new int[] {0, 2, 4, 8, 16}) {
      String out = XmlCodeFormatter.format(xml, indent);
      check(
          "XML: البصمة غير البيضاء محفوظة عند إزاحة " + indent,
          nonWhitespaceSignature(out).equals(nonWhitespaceSignature(xml)),
          "اختلفت البصمة");
      check(
          "XML: عدد الوسوم محفوظ عند إزاحة " + indent,
          count(out, '<') == count(xml, '<') && count(out, '>') == count(xml, '>'),
          count(out, '<') + "/" + count(out, '>'));
      check(
          "XML: العمق يعود إلى الصفر بعد التنسيق عند إزاحة " + indent,
          XmlStructureScanner.scan(out).depthBefore[
                  XmlStructureScanner.scan(out).lineCount - 1]
                  + XmlStructureScanner.scan(out)
                          .depthDelta[XmlStructureScanner.scan(out).lineCount - 1]
              == 0,
          "عمق نهائي ≠ 0");
      check(
          "XML: التنسيق ثابت (idempotent) عند إزاحة " + indent,
          XmlCodeFormatter.format(out, indent).equals(out),
          "تغيّر الناتج عند إعادة التنسيق");
    }

    // مدخل مكسور: لا يُسمح للمنسّق أن يزيد الكسر أو يفقد محتوى.
    String brokenJava = "class A {\n  void f() {\n    if (x) { g(1;\n";
    String brokenOut = CodeLanguageTools.format(brokenJava, 4);
    check(
        "جافا: مدخل مكسور لا يفقد محتوى",
        nonWhitespaceSignature(brokenOut).equals(nonWhitespaceSignature(brokenJava)),
        "فُقد محتوى من مدخل مكسور");
    String brokenXml = "<resources>\n  <string name=\"a\">1\n</resources>\n";
    String brokenXmlOut = XmlCodeFormatter.format(brokenXml, 4);
    check(
        "XML: مدخل مكسور لا يفقد محتوى",
        nonWhitespaceSignature(brokenXmlOut).equals(nonWhitespaceSignature(brokenXml)),
        "فُقد محتوى من مدخل مكسور");
    check(
        "XML: وسوم الاقتباس محفوظة في مدخل مكسور",
        count(brokenXmlOut, '"') == count(brokenXml, '"'),
        count(brokenXmlOut, '"') + " مقابل " + count(brokenXml, '"'));

    // نص فارغ وفارغ-أبيض: لا استثناء ولا فقدان.
    check("جافا: نص فارغ آمن", CodeLanguageTools.format("", 4) != null, null);
    check("XML: نص فارغ آمن", XmlCodeFormatter.format("", 4) != null, null);
    check(
        "جافا: نص أبيض فقط يبقى أبيض",
        CodeLanguageTools.format("   \n  \n", 4).trim().isEmpty(),
        "[" + CodeLanguageTools.format("   \n  \n", 4) + "]");
  }

  // ═══════════════ §A2 المرحلتان 3+4: إكمال XML السياقي ═══════════════

  static void xmlCompletion() {
    section("أ2 — إكمال XML السياقي (المراحل 3+4)");

    // قيمة سمة العرض: قوائم مقيدة + أبعاد تقبل الأرقام
    String w = "<Button android:layout_width=\"";
    java.util.List<String> vals = almlk.XmlCompletionEngine.complete(w, w.length());
    check("XML: قيم layout_width تحوي wrap_content", vals.contains("wrap_content"), vals.toString());
    check("XML: قيم layout_width تحوي match_parent", vals.contains("match_parent"), vals.toString());

    // إدخال رقم داخل قيمة العرض لا يُعترض: تُشتق أبعاد تبدأ بالرقم
    String d = "<Button android:layout_width=\"5";
    java.util.List<String> dims = almlk.XmlCompletionEngine.complete(d, d.length());
    check("XML: بادئة رقمية تُنتج 5.0dip", dims.contains("5.0dip"), dims.toString());
    check("XML: بادئة رقمية تُنتج 5dp", dims.contains("5dp"), dims.toString());
    check("XML: بادئة رقمية لا تُسقِط الاقتراحات", !dims.isEmpty(), "فارغة");

    // بداية الرمز داخل القيمة = بعد الاقتباس مباشرة (فيُحفظ الرقم المكتوب)
    check("XML: completionStart داخل القيمة بعد الاقتباس",
        almlk.XmlCompletionEngine.completionStart(d, d.length()) == d.length() - 1,
        "" + almlk.XmlCompletionEngine.completionStart(d, d.length()));

    // اسم سمة بعد وسم
    String a = "<Button ";
    java.util.List<String> attrs = almlk.XmlCompletionEngine.complete(a, a.length());
    check("XML: اقتراح أسماء سمات يحوي android:layout_width",
        attrs.contains("android:layout_width"), attrs.toString());
    check("XML: اقتراح أسماء سمات يحوي android:id", attrs.contains("android:id"), attrs.toString());

    // اسم وسم بعد '<'
    String t = "<But";
    java.util.List<String> tags = almlk.XmlCompletionEngine.complete(t, t.length());
    check("XML: اقتراح وسوم يرشّح Button بالبادئة", tags.contains("Button"), tags.toString());
    check("XML: اقتراح وسوم لا يحوي LinearLayout لبـBut", !tags.contains("LinearLayout"),
        tags.toString());

    // قيمة منطقية
    String b = "<Button android:clickable=\"";
    java.util.List<String> bools = almlk.XmlCompletionEngine.complete(b, b.length());
    check("XML: قيمة منطقية true/false", bools.contains("true") && bools.contains("false"),
        bools.toString());

    // قيمة نص → موارد
    String tx = "<TextView android:text=\"";
    java.util.List<String> texts = almlk.XmlCompletionEngine.complete(tx, tx.length());
    check("XML: قيمة text تقترح @string/", texts.contains("@string/"), texts.toString());

    // خارج أي وسم: لا اقتراح (لا اقتحام على نص عادي)
    String none = "hello world ";
    check("XML: خارج الوسوم لا اقتراح", almlk.XmlCompletionEngine.complete(none, none.length()).isEmpty(),
        "أقحم اقتراحًا");
    check("XML: complete(null-safe) على نص فارغ آمن",
        almlk.XmlCompletionEngine.complete("", 0).isEmpty(), "رمى");
    check("XML: completionStart على نص فارغ آمن",
        almlk.XmlCompletionEngine.completionStart("", 0) == 0, "رمى");
  }

  // ═══════════════════ §B أصناف almlk الأساسية ═══════════════════

  static void coreAlmlk() {
    section("ب — أصناف almlk الأساسية (محرك المحرر)");

    // LineBuffer
    LineBuffer buffer = new LineBuffer();
    buffer.append('a');
    buffer.append('b');
    buffer.append('c');
    check("LineBuffer: الطول بعد الإلحاق", buffer.length() == 3, "" + buffer.length());
    check("LineBuffer: المحتوى", buffer.toString().equals("abc"), buffer.toString());
    buffer.insert(1, 'X');
    check("LineBuffer: الإدراج في المنتصف", buffer.toString().equals("aXbc"), buffer.toString());
    buffer.delete(1, 1);
    check("LineBuffer: الحذف", buffer.toString().equals("abc"), buffer.toString());
    buffer.replace("hello".toCharArray());
    check("LineBuffer: الاستبدال الكامل", buffer.toString().equals("hello"), buffer.toString());
    char[] dest = new char[3];
    buffer.getChars(1, 3, dest, 0);
    check("LineBuffer: getChars", new String(dest).equals("ell"), new String(dest));
    check("LineBuffer: charAt", buffer.charAt(0) == 'h', "" + buffer.charAt(0));
    buffer.insert(5, "!!".toCharArray(), 0, 2);
    check("LineBuffer: إدراج مصفوفة", buffer.toString().equals("hello!!"), buffer.toString());

    // LineDocument
    LineDocument document = new LineDocument();
    check("LineDocument: سطر واحد ابتداءً", document.lineCount() == 1, "" + document.lineCount());
    document.insertLine(1, "second".toCharArray());
    check("LineDocument: الإدراج يضيف سطرًا", document.lineCount() == 2, "" + document.lineCount());
    document.insertLine(2, "third".toCharArray());
    check("LineDocument: ثلاثة أسطر", document.lineCount() == 3, "" + document.lineCount());
    check(
        "LineDocument: lineStartOffset للسطر الثاني",
        document.lineStartOffset(1) == 1,
        "" + document.lineStartOffset(1));
    check(
        "LineDocument: lineLength",
        document.lineLength(1) == 6,
        "" + document.lineLength(1));
    document.insertChar(1, 0, 'S');
    check("LineDocument: insertChar", document.line(1).toString().equals("Ssecond"),
        document.line(1).toString());
    document.delete(1, 0, 1);
    check("LineDocument: delete", document.line(1).toString().equals("second"),
        document.line(1).toString());
    long before = document.version();
    document.setLine(1, "changed".toCharArray());
    check("LineDocument: version تتقدم عند التغيير", document.version() > before,
        before + " → " + document.version());
    document.removeLine(2);
    check("LineDocument: removeLine", document.lineCount() == 2, "" + document.lineCount());
    check("LineDocument: lineChars", new String(document.lineChars(1)).equals("changed"),
        new String(document.lineChars(1)));

    // IdentifierBounds
    String id = "int fooBar = x;";
    int at = id.indexOf('o');
    check("IdentifierBounds: inside على حرف من المعرّف", IdentifierBounds.inside(id, at), "ليست داخلًا");
    check("IdentifierBounds: start", IdentifierBounds.start(id, at) == 4,
        "" + IdentifierBounds.start(id, at));
    // end نهاية حصرية كمديات جافا: fooBar = [4, 10)
    check("IdentifierBounds: end نهاية حصرية", IdentifierBounds.end(id, at) == 10,
        "" + IdentifierBounds.end(id, at));
    // inside تُعرَّف لموضع المؤشر: الموضع المجاور لمعرّف يُعَدّ داخله. موضع خارجي حقًا هو '='.
    check("IdentifierBounds: موضع خارج أي معرّف", !IdentifierBounds.inside(id, 11), "عُدَّت داخلًا");
    check("IdentifierBounds: موضع مجاور لمعرّف يُعَدّ داخله (دلالة المؤشر)",
        IdentifierBounds.inside(id, 10), "لم تُعَدّ");
    check("IdentifierBounds: isPart على رقم", IdentifierBounds.isPart('7'), "ليست جزءًا");
    check("IdentifierBounds: isPart على مسافة", !IdentifierBounds.isPart(' '), "عُدَّت جزءًا");
    check("IdentifierBounds: isStart على رقم", !IdentifierBounds.isStart('7'), "عُدَّت بداية");
    check("IdentifierBounds: isStart على شرطة سفلية", IdentifierBounds.isStart('_'), "ليست بداية");
    check("IdentifierBounds: offset=0 آمن", IdentifierBounds.start(id, 0) == 0, "رمى أو أخطأ");
    check("IdentifierBounds: offset=الطول آمن",
        IdentifierBounds.end(id, id.length()) <= id.length(), "تجاوز الطول");

    // StyleRunBatcher
    int[] styles = {1, 1, 2, 2, 2, 1, 0};
    final int[] runs = {0};
    StyleRunBatcher.batch(styles, 0, styles.length, (styleId, start, end) -> runs[0]++);
    check("StyleRunBatcher: عدد runs = 4", runs[0] == 4, "" + runs[0]);
    check("StyleRunBatcher: countRuns يطابق batch",
        StyleRunBatcher.countRuns(styles, 0, styles.length) == 4,
        "" + StyleRunBatcher.countRuns(styles, 0, styles.length));
    check("StyleRunBatcher: نافذة جزئية", StyleRunBatcher.countRuns(styles, 2, 5) == 1,
        "" + StyleRunBatcher.countRuns(styles, 2, 5));
    check("StyleRunBatcher: مصفوفة null آمنة", StyleRunBatcher.countRuns(null, 0, 5) == 0, "رمى");
    StyleRunBatcher.batch(null, 0, 5, (styleId, start, end) -> runs[0]++);
    check("StyleRunBatcher: batch(null) آمن", true, null);
    // النافذة [0,3) = {1,1,2} ← runان
    check("StyleRunBatcher: نافذة من أول المصفوفة", StyleRunBatcher.countRuns(styles, 0, 3) == 2,
        "" + StyleRunBatcher.countRuns(styles, 0, 3));
    final int[] untouched = {0};
    StyleRunBatcher.batch(styles, 0, 3, null);
    check("StyleRunBatcher: consumer=null آمن", untouched[0] == 0, "رمى");

    // UndoRedoStack
    UndoRedoStack stack = new UndoRedoStack();
    check("UndoRedoStack: فارغ ابتداءً — لا تراجع", !stack.canUndo(), "كان قابلًا للتراجع");
    check("UndoRedoStack: فارغ ابتداءً — لا إعادة", !stack.canRedo(), "كان قابلًا للإعادة");
    stack.record(0, "", "abc");
    check("UndoRedoStack: بعد التسجيل قابل للتراجع", stack.canUndo(), "لم يكن");
    check("UndoRedoStack: قبل التراجع لا إعادة", !stack.canRedo(), "كانت متاحة");
    UndoRedoStack.Applied undone = stack.popUndo();
    check("UndoRedoStack: popUndo يعيد العملية", undone != null && undone.inserted.equals("abc"),
        undone == null ? "null" : undone.inserted);
    check("UndoRedoStack: بعد التراجع صارت الإعادة متاحة", stack.canRedo(), "لم تكن");
    check("UndoRedoStack: بعد التراجع لا تراجع", !stack.canUndo(), "بقي متاحًا");
    UndoRedoStack.Applied redone = stack.popRedo();
    check("UndoRedoStack: popRedo يعيد العملية", redone != null && redone.inserted.equals("abc"),
        redone == null ? "null" : redone.inserted);
    check("UndoRedoStack: بعد الإعادة لا إعادة", !stack.canRedo(), "بقيت متاحة");
    check("UndoRedoStack: بعد الإعادة تراجع متاح", stack.canUndo(), "لم يكن");
    stack.record(5, "x", "y");
    stack.clear();
    check("UndoRedoStack: clear يمسح التراجع", !stack.canUndo(), "بقي متاحًا");
    check("UndoRedoStack: clear يمسح الإعادة", !stack.canRedo(), "بقيت متاحة");
    check("UndoRedoStack: popUndo على فارغ لا يُرمي", stack.popUndo() == null, "رمى أو أعاد");
    check("UndoRedoStack: popRedo على فارغ لا يُرمي", stack.popRedo() == null, "رمى أو أعاد");

    // HexColorCodec
    check("HexColorCodec: RRGGBB صالح", HexColorCodec.isValid("C9A227", true), "رُفض");
    check("HexColorCodec: #RRGGBB صالح", HexColorCodec.isValid("#C9A227", true), "رُفض");
    check("HexColorCodec: AARRGGBB صالح مع ألفا", HexColorCodec.isValid("33C9A227", true), "رُفض");
    check("HexColorCodec: AARRGGBB مرفوض بلا ألفا", !HexColorCodec.isValid("33C9A227", false),
        "قُبل");
    check("HexColorCodec: RRGGBB يُصبح معتمًا",
        HexColorCodec.parse("C9A227", true) == 0xFFC9A227,
        Integer.toHexString(HexColorCodec.parse("C9A227", true)));
    check("HexColorCodec: AARRGGBB يُقرأ حرفيًا",
        HexColorCodec.parse("33C9A227", true) == 0x33C9A227,
        Integer.toHexString(HexColorCodec.parse("33C9A227", true)));
    check("HexColorCodec: الأحرف الصغيرة مقبولة",
        HexColorCodec.parse("c9a227", true) == 0xFFC9A227, "اختلفت");
    check("HexColorCodec: الصيغة القصيرة مرفوضة", !HexColorCodec.isValid("C9A", true), "قُبلت");
    check("HexColorCodec: خانة غير hex تُرفض", !HexColorCodec.isValid("C9A22G", true), "قُبلت");
    check("HexColorCodec: null يُرفض", !HexColorCodec.isValid(null, true), "قُبل");
    check("HexColorCodec: فارغ يُرفض", !HexColorCodec.isValid("", true), "قُبل");
    boolean threw = false;
    try {
      HexColorCodec.parse("XYZ", true);
    } catch (IllegalArgumentException expected) {
      threw = true;
    }
    check("HexColorCodec: parse يرمي IllegalArgumentException لا قيمة خاطئة", threw, "لم يرمِ");

    // XmlColorLiteral
    XmlColorLiteral rgb =
        almlk.ColorLiteralFactory.make(0, 5, 12, 0xFFC9A227, XmlColorLiteral.Format.RGB6);
    check("XmlColorLiteral: containsColumn داخل القيمة", rgb.containsColumn(6), "لم تحتوِ");
    check("XmlColorLiteral: containsColumn خارج القيمة", !rgb.containsColumn(2), "احتوت");
    check("XmlColorLiteral: length", rgb.length() == 7, "" + rgb.length());
    check(
        "XmlColorLiteral: formatReplacement يحفظ صيغة RGB6",
        rgb.formatReplacement(0xFF112233).equals("#112233"),
        rgb.formatReplacement(0xFF112233));
    XmlColorLiteral argb =
        almlk.ColorLiteralFactory.make(0, 5, 14, 0x33C9A227, XmlColorLiteral.Format.ARGB8);
    check(
        "XmlColorLiteral: formatReplacement يحفظ صيغة ARGB8",
        argb.formatReplacement(0x33112233).equals("#33112233"),
        argb.formatReplacement(0x33112233));
    // العقد: RGB6 مع لون معتم ← 6 خانات؛ ومع لون شفّاف ← 8 خانات حتى لا تُفقد الألفا صمتًا.
    check(
        "XmlColorLiteral: RGB6 + لون معتم ← 6 خانات",
        rgb.formatReplacement(0xFF112233).equals("#112233"),
        rgb.formatReplacement(0xFF112233));
    check(
        "XmlColorLiteral: RGB6 + لون شفّاف ← 8 خانات (لا تُفقد الألفا)",
        rgb.formatReplacement(0x33112233).equals("#33112233"),
        rgb.formatReplacement(0x33112233));
    check(
        "XmlColorLiteral: الحروف كبيرة دائمًا",
        argb.formatReplacement(0x33aabbcc).equals("#33AABBCC"),
        argb.formatReplacement(0x33aabbcc));
    XmlColorLiteral[] literals = {rgb};
    check("XmlColorLiteral: atColumn يجد القيمة",
        XmlColorLiteral.atColumn(literals, 7) == rgb, "لم يجد");
    check("XmlColorLiteral: atColumn خارج المدى يعيد null",
        XmlColorLiteral.atColumn(literals, 99) == null, "أعاد قيمة");
    check("XmlColorLiteral: atColumn على null آمن",
        XmlColorLiteral.atColumn(null, 7) == null, "رمى");
    check("XmlColorLiteral: containsRange داخل القيمة", rgb.containsRange(6, 8), "لم تحتوِ");
  }

  // ═══════════════════ §C المرحلة السادسة ═══════════════════

  static void phase6XmlEngine() {
    section("ج — المرحلة 6: ماسح البنية + التعليق + المنسق البنيوي");

    String xml = "<a>\n  <b/>\n  <!-- تعليق -->\n  <![CDATA[x]]>\n</a>\n";
    XmlStructureScanner.Layout layout = XmlStructureScanner.scan(xml);
    // خمسة أسطر نص + سطر سادس فارغ بعد آخر \n
    check("Scanner: عدد الأسطر (مع السطر الفارغ الأخير)", layout.lineCount == 6,
        "" + layout.lineCount);
    check("Scanner: الحالة الابتدائية NORMAL",
        layout.startState[0] == XmlStructureScanner.NORMAL, "" + layout.startState[0]);
    check("Scanner: سطر التعليق يدخل حالة COMMENT",
        layout.startState[2] == XmlStructureScanner.COMMENT
            || layout.endState[2] == XmlStructureScanner.COMMENT
            || XmlStructureScanner.firstCommentSpanInRange(xml,
                   layout.lineStart[2], layout.lineEnd[2]) != null,
        "لم يُلتقط التعليق");
    check("Scanner: سطر CDATA يمسّ حالة CDATA",
        XmlStructureScanner.rangeTouchesState(
            xml, layout.lineStart[3], layout.lineEnd[3], XmlStructureScanner.CDATA),
        "لم يُلتقط CDATA");
    check("Scanner: العمق يعود إلى الصفر في النهاية",
        layout.depthBefore[layout.lineCount - 1] + layout.depthDelta[layout.lineCount - 1] == 0,
        "" + (layout.depthBefore[layout.lineCount - 1] + layout.depthDelta[layout.lineCount - 1]));
    check("Scanner: startsWithClose يلتقط </a>",
        layout.startsWithClose[4], "لم يُلتقط");
    check("Scanner: startsWithClose سالب لسطر فتح",
        !layout.startsWithClose[1], "التُقط خطأً");
    check("Scanner: commentSpanContaining يجد التعليق",
        XmlStructureScanner.commentSpanContaining(xml, xml.indexOf("تعليق")) != null, "لم يجد");
    check("Scanner: نص فارغ آمن", XmlStructureScanner.scan("").lineCount >= 1, "رمى");

    // XmlCommentEditor
    String file =
        "<resources>\n  <string name=\"a\">1</string>\n  <string name=\"b\">2</string>\n</resources>\n";
    int from = file.indexOf("  <string name=\"a\"");
    int to = file.indexOf("  <string name=\"b\"");
    XmlCommentEditor.Outcome commented = XmlCommentEditor.comment(file, from, to);
    check("Comment: ينجح على نطاق صالح", commented.applies(), commented.rejection);
    check("Comment: يستخدم وسوم XML لا //",
        commented.text.contains("<!--") && !commented.text.contains("//"),
        commented.text);
    // تحديد بطول صفر يتوسّع إلى سطره، وسطر 0 فيه محتوى — فالرفض الصحيح يكون على سطر أبيض.
    String blank = "<a>\n\n</a>\n";
    check("Comment: يفشل على سطر أبيض", !XmlCommentEditor.comment(blank, 4, 4).applies(), "نجح");
    check("Comment: يفشل على نص فارغ", !XmlCommentEditor.comment("", 0, 0).applies(), "نجح");
    check("Comment: يرفض CDATA",
        !XmlCommentEditor.comment("<a><![CDATA[x]]></a>", 0, 18).applies(), "قبل CDATA");
    check("Comment: يرفض النطاق المعلّق",
        !XmlCommentEditor.comment("<!-- <a/> -->", 4, 8).applies(), "قبل معلّقًا");
    check("Comment: يرفض ما يحوي --",
        !XmlCommentEditor.comment("<a>\nx--y\n</a>", 0, 12).applies(), "قبل --");
    check("Comment: السطر الواحد يُعلَّق سطريًا",
        XmlCommentEditor.comment(file, from, from + 5).text.trim().startsWith("<!--")
            && !XmlCommentEditor.comment(file, from, from + 5).text.contains("\n"),
        XmlCommentEditor.comment(file, from, from + 5).text);

    // دورات ذهاب/إياب دقيقة بالبايت
    check("Comment: دورة دقيقة في منتصف ملف", exactRoundTrip(file, from, to), "غير دقيقة");
    check("Comment: دورة دقيقة لسطر واحد",
        exactRoundTrip(file, from, file.indexOf("\n  <string name=\"b\"")), "غير دقيقة");
    String tail = "<resources>\n  <string name=\"a\">1</string>\n</resources>\n";
    check("Comment: دورة دقيقة لآخر سطر",
        exactRoundTrip(tail, tail.indexOf("</resources>"), tail.length()), "غير دقيقة");
    String tailNoNl = "<resources>\n  <string name=\"a\">1</string>\n</resources>";
    check("Comment: دورة دقيقة لآخر سطر بلا سطر نهاية",
        exactRoundTrip(tailNoNl, tailNoNl.indexOf("</resources>"), tailNoNl.length()), "غير دقيقة");
    check("Comment: toggle يعلّق ثم يفكّ",
        XmlCommentEditor.toggle(file, from, to).applies(), null);
    check("Comment: lineRegion يرجع مدى",
        XmlCommentEditor.lineRegion(file, from, to)[0] == from, "مدى خاطئ");

    // XmlCodeFormatter
    check("Formatter: isXmlName على .xml", XmlCodeFormatter.isXmlName("a.xml"), "رفض");
    check("Formatter: isXmlName على .XML", XmlCodeFormatter.isXmlName("a.XML"), "رفض");
    check("Formatter: isXmlName على .java", !XmlCodeFormatter.isXmlName("A.java"), "قبل");
    check("Formatter: isXmlName على null", !XmlCodeFormatter.isXmlName(null), "قبل");
    check("Formatter: الوسوم الذاتية لا تزيد العمق",
        leadingOf(XmlCodeFormatter.format("<a>\n<b/>\n<c/>\n</a>", 2), 2) == 2,
        "" + leadingOf(XmlCodeFormatter.format("<a>\n<b/>\n<c/>\n</a>", 2), 2));
    check("Formatter: <?xml?> عند الصفر",
        leadingOf(XmlCodeFormatter.format("<?xml version=\"1.0\"?>\n<a/>", 2), 0) == 0,
        "أُزيح إعلان XML");
    check("Formatter: <!DOCTYPE> عند الصفر",
        leadingOf(XmlCodeFormatter.format("<!DOCTYPE a>\n<a/>", 2), 0) == 0, "أُزيح DOCTYPE");
    String commentXml = "<a>\n<!--\n<b/>\n-->\n</a>";
    check("Formatter: التعليق لا يُعامل كوسم",
        XmlCodeFormatter.format(commentXml, 2) != null, "رمى");
    check("Formatter: قيم السمات لا تُمس",
        XmlCodeFormatter.format("<a t=\"  x  \"/>", 2).contains("t=\"  x  \""),
        XmlCodeFormatter.format("<a t=\"  x  \"/>", 2));
  }

  static boolean exactRoundTrip(String text, int start, int end) {
    XmlCommentEditor.Outcome commented = XmlCommentEditor.comment(text, start, end);
    if (!commented.applies()) return false;
    String withComment =
        text.substring(0, commented.start) + commented.text + text.substring(commented.end);
    XmlCommentEditor.Outcome back =
        XmlCommentEditor.uncomment(
            withComment, commented.start, commented.start + commented.text.length());
    if (!back.applies()) return false;
    String restored =
        withComment.substring(0, back.start) + back.text + withComment.substring(back.end);
    return restored.equals(text);
  }

  /** يبني فهرسًا فيه @+id داخل تعليق — يجب ألّا يُفهرس الاسم. */
  static String buildCommentedIdIndex() throws Exception {
    File dir = new File("/tmp/shima-qa/commented/res/layout");
    dir.mkdirs();
    try (OutputStreamWriter writer =
        new OutputStreamWriter(
            new FileOutputStream(new File(dir, "c.xml")), StandardCharsets.UTF_8)) {
      writer.write("<LinearLayout>\n  <!-- android:id=\"@+id/hiddenInComment\" -->\n</LinearLayout>\n");
    }
    XmlResourceIndex index = XmlResourceIndex.build(new File("/tmp/shima-qa/commented"));
    XmlResourceIndex.Declaration found = index.lookup("id", "hiddenInComment");
    return found == null ? null : found.file;
  }

  /** يبني فهرسًا فيه @+id داخل CDATA — يجب ألّا يُفهرس الاسم. */
  static String buildCdataIdIndex() throws Exception {
    File dir = new File("/tmp/shima-qa/cdata/res/layout");
    dir.mkdirs();
    try (OutputStreamWriter writer =
        new OutputStreamWriter(
            new FileOutputStream(new File(dir, "d.xml")), StandardCharsets.UTF_8)) {
      writer.write("<LinearLayout>\n  <![CDATA[ android:id=\"@+id/hiddenInCdata\" ]]>\n</LinearLayout>\n");
    }
    XmlResourceIndex index = XmlResourceIndex.build(new File("/tmp/shima-qa/cdata"));
    XmlResourceIndex.Declaration found = index.lookup("id", "hiddenInCdata");
    return found == null ? null : found.file;
  }

  // ═══════════════════ §D المرحلة السابعة ═══════════════════

  static void phase7XmlSemantics() throws Exception {
    section("د — المرحلة 7: دلاليات موارد XML");

    String decl = "<LinearLayout android:id=\"@+id/root\" android:text=\"@string/app_name\" />";
    XmlResourceReference plus = XmlResourceReference.at(decl, decl.indexOf("@+id") + 2);
    check("Ref: @+id/root يُستخرج", plus != null && plus.name.equals("root"),
        plus == null ? "null" : plus.name);
    check("Ref: @+id و@id يُطبَّعان إلى مفتاح واحد",
        plus != null && plus.key().equals("id/root"), plus == null ? "null" : plus.key());
    String use = "<TextView android:id=\"@id/root\" />";
    XmlResourceReference plain = XmlResourceReference.at(use, use.indexOf("@id") + 1);
    check("Ref: @id/root له المفتاح نفسه",
        plain != null && plain.key().equals("id/root"), plain == null ? "null" : plain.key());
    check("Ref: @+id معلَّم إعلانًا", plus != null && plus.declaration, "لم يُعلَّم");
    check("Ref: @id ليس إعلانًا", plain != null && !plain.declaration, "عُلِّم خطأً");

    String framework = "<TextView android:theme=\"@android:style/Theme.Dark\" />";
    XmlResourceReference fw =
        XmlResourceReference.at(framework, framework.indexOf("@android") + 4);
    check("Ref: @android:style/… يُلتقط", fw != null && fw.type.equals("style"),
        fw == null ? "null" : fw.type);
    check("Ref: البادئة android: تفصل موارد الإطار", fw != null && fw.framework, "لم تُفصل");
    check("Ref: display للمورد الإطاري",
        fw != null && fw.display().equals("android:style/Theme.Dark"),
        fw == null ? "null" : fw.display());
    String project = "<TextView android:text=\"@string/app_name\" />";
    XmlResourceReference proj = XmlResourceReference.at(project, project.indexOf("@string") + 3);
    check("Ref: مورد المشروع ليس إطاريًا", proj != null && !proj.framework, "عُدَّ إطاريًا");
    check("Ref: display لمورد المشروع",
        proj != null && proj.display().equals("string/app_name"),
        proj == null ? "null" : proj.display());
    String attr = "<TextView style=\"?attr/colorPrimary\" />";
    XmlResourceReference attrRef = XmlResourceReference.at(attr, attr.indexOf("?attr") + 2);
    check("Ref: ?attr/ يُلتقط", attrRef != null && attrRef.key().equals("attr/colorPrimary"),
        attrRef == null ? "null" : attrRef.key());
    String androidAttr = "<TextView style=\"?android:attr/textColor\" />";
    XmlResourceReference androidAttrRef =
        XmlResourceReference.at(androidAttr, androidAttr.indexOf("?android") + 3);
    check("Ref: ?android:attr/ يُلتقط",
        androidAttrRef != null && androidAttrRef.key().equals("attr/textColor"),
        androidAttrRef == null ? "null" : androidAttrRef.key());
    check("Ref: موضع بلا مرجع يعيد null",
        XmlResourceReference.at("plain text here", 3) == null, "أعاد قيمة");
    check("Ref: نص null آمن", XmlResourceReference.at(null, 0) == null, "رمى");
    check("Ref: nameStart/nameEnd يحددان الاسم لا البادئة",
        proj != null
            && project.substring(proj.nameStart, proj.nameEnd).equals("app_name"),
        proj == null ? "null" : project.substring(proj.nameStart, proj.nameEnd));

    // XmlResourceIndex على مشروع مؤقت
    File root = new File("/tmp/shima-qa/proj/res");
    root.mkdirs();
    File values = new File(root, "values");
    values.mkdirs();
    try (OutputStreamWriter writer =
        new OutputStreamWriter(
            new FileOutputStream(new File(values, "strings.xml")), StandardCharsets.UTF_8)) {
      writer.write(
          "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n"
              + "  <string name=\"app_name\">Shima</string>\n"
              + "  <string name=\"empty\"></string>\n</resources>\n");
    }
    File layouts = new File(root, "layout");
    layouts.mkdirs();
    try (OutputStreamWriter writer =
        new OutputStreamWriter(
            new FileOutputStream(new File(layouts, "main.xml")), StandardCharsets.UTF_8)) {
      writer.write("<LinearLayout android:id=\"@+id/root\" />\n");
    }
    File skipped = new File("/tmp/shima-qa/proj/build/res/values");
    skipped.mkdirs();
    try (OutputStreamWriter writer =
        new OutputStreamWriter(
            new FileOutputStream(new File(skipped, "gen.xml")), StandardCharsets.UTF_8)) {
      writer.write("<resources>\n  <string name=\"generated\">no</string>\n</resources>\n");
    }
    XmlResourceIndex index = XmlResourceIndex.build(new File("/tmp/shima-qa/proj"));
    check("Index: بُني من الجذر", index != null && !index.isEmpty(), "فارغ");
    check("Index: root يعيد الجذر", index != null && index.root() != null, "null");
    check("Index: حجم ≥ 3 إعلانات", index != null && index.size() >= 3,
        index == null ? "null" : "" + index.size());
    XmlResourceIndex.Declaration name = index == null ? null : index.lookup("string", "app_name");
    check("Index: حلّ string/app_name", name != null && "Shima".equals(name.value),
        name == null ? "null" : name.value);
    check("Index: الإعلان يحمل الملف والسطر", name != null && name.line >= 0 && name.file != null,
        name == null ? "null" : name.file + ":" + name.line);
    check("Index: مجلد build/ مستثنى",
        index != null && index.lookup("string", "generated") == null, "فهرس build/");
    check("Index: @+id/root مفهرس",
        index != null && index.lookup("id", "root") != null, "لم يُفهرس");
    check("Index: الحلّ بالمرجع يعمل", index != null && index.lookup(proj) != null, "لم يحلّ");
    check("Index: مفتاح غير موجود يعيد null",
        index != null && index.lookup("string", "nope") == null, "أعاد قيمة");
    check("Index: empty() فارغ", XmlResourceIndex.empty().isEmpty(), "ليس فارغًا");
    check("Index: build(null) لا يُرمي", XmlResourceIndex.build(null) != null, "رمى");

    // المرحلة 9: الإعلانات المكتوبة داخل الملفات (@+id/x في layout) كانت تُفلت من الفهرس
    // رغم أن توثيق lookup يَعِد بحلّها — أُغلقت الفجوة، وهذه بواباتها.
    check("Index: @+id المعلَن داخل layout مفهرس",
        index != null && index.lookup("id", "root") != null, "لم يُفهرس");
    XmlResourceIndex.Declaration inline = index == null ? null : index.lookup("id", "root");
    check("Index: الإعلان الداخلي يشير إلى ملف layout",
        inline != null && inline.file != null && inline.file.endsWith("main.xml"),
        inline == null ? "null" : inline.file);
    check("Index: الإعلان الداخلي يحمل موضع @+",
        inline != null && inline.offset >= 0 && inline.line >= 0,
        inline == null ? "null" : inline.line + ":" + inline.offset);
    check("Index: @+id داخل تعليق لا يُفهرس", buildCommentedIdIndex() == null,
        "فُهرس اسم من داخل تعليق");
    check("Index: @+id في CDATA لا يُفهرس", buildCdataIdIndex() == null, "فُهرس من CDATA");
  }

  // ═══════════════════ §E المرحلة الثامنة ═══════════════════

  static void phase8CodeStyle() {
    section("هـ — المرحلة 8: نمط الكود والتفويض");

    android.content.Context context = freshPrefs();
    check("CodeStyle: افتراضي .xml = 4", CodeStyle.indentSizeFor(context, "s.xml") == 4,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    check("CodeStyle: افتراضي .java = 4", CodeStyle.indentSizeFor(context, "A.java") == 4,
        "" + CodeStyle.indentSizeFor(context, "A.java"));
    putPref(CodeStyle.XML_INDENT_KEY, "2");
    check("CodeStyle: xml=2 معزول عن جافا",
        CodeStyle.indentSizeFor(context, "s.xml") == 2
            && CodeStyle.indentSizeFor(context, "A.java") == 4,
        CodeStyle.indentSizeFor(context, "s.xml") + "/" + CodeStyle.indentSizeFor(context, "A.java"));
    putPref(CodeStyle.JAVA_INDENT_KEY, "8");
    check("CodeStyle: java=8 معزول عن XML",
        CodeStyle.indentSizeFor(context, "A.java") == 8
            && CodeStyle.indentSizeFor(context, "s.xml") == 2,
        CodeStyle.indentSizeFor(context, "A.java") + "/" + CodeStyle.indentSizeFor(context, "s.xml"));
    for (String bad : new String[] {"abc", "999", "-3", "", "1.5", "  ", "0x10"}) {
      putPref(CodeStyle.XML_INDENT_KEY, bad);
      check("CodeStyle: القيمة الفاسدة «" + bad.trim() + "» ترتدّ إلى 4",
          CodeStyle.indentSizeFor(context, "s.xml") == 4,
          "" + CodeStyle.indentSizeFor(context, "s.xml"));
    }
    putPref(CodeStyle.XML_INDENT_KEY, " 6 ");
    check("CodeStyle: المسافات تُقتطع", CodeStyle.indentSizeFor(context, "s.xml") == 6,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    putPref(CodeStyle.XML_INDENT_KEY, "0");
    check("CodeStyle: الصفر مقبول", CodeStyle.indentSizeFor(context, "s.xml") == 0,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    putPref(CodeStyle.XML_INDENT_KEY, "16");
    check("CodeStyle: الحد الأقصى مقبول", CodeStyle.indentSizeFor(context, "s.xml") == 16,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    check("CodeStyle: context=null آمن", CodeStyle.indentSize(null, CodeStyle.XML_INDENT_KEY) == 4,
        "رمى أو أخطأ");
    check("CodeStyle: indentSizeFor(null,…) آمن", CodeStyle.indentSizeFor(null, "a.xml") == 4, "أخطأ");
    check("CodeStyle: key=null آمن", CodeStyle.indentSize(context, null) == 4, "رمى أو أخطأ");

    freshPrefs();
    CodeStyle.setIndentSize(context, CodeStyle.XML_INDENT_KEY, 3);
    check("CodeStyle: setIndentSize يكتب", CodeStyle.indentSizeFor(context, "s.xml") == 3,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    CodeStyle.setIndentSize(context, CodeStyle.XML_INDENT_KEY, 500);
    check("CodeStyle: الكتابة تُقيَّد بالسقف", CodeStyle.indentSizeFor(context, "s.xml") == 16,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    CodeStyle.setIndentSize(context, CodeStyle.XML_INDENT_KEY, -9);
    check("CodeStyle: الكتابة تُقيَّد بالصفر", CodeStyle.indentSizeFor(context, "s.xml") == 0,
        "" + CodeStyle.indentSizeFor(context, "s.xml"));
    CodeStyle.setIndentSize(null, CodeStyle.XML_INDENT_KEY, 2);
    check("CodeStyle: setIndentSize(null) آمن", true, null);

    freshPrefs();
    CodeStyle.seedDefaults(context);
    check("CodeStyle: seedDefaults يبذل المفتاحين",
        android.preference.PreferenceManager.store.containsKey(CodeStyle.XML_INDENT_KEY)
            && android.preference.PreferenceManager.store.containsKey(CodeStyle.JAVA_INDENT_KEY),
        android.preference.PreferenceManager.store.toString());
    putPref(CodeStyle.JAVA_INDENT_KEY, "2");
    CodeStyle.seedDefaults(context);
    check("CodeStyle: seedDefaults لا يدهس اختيار المستخدم",
        CodeStyle.indentSizeFor(context, "A.java") == 2,
        "" + CodeStyle.indentSizeFor(context, "A.java"));
    CodeStyle.seedDefaults(null);
    check("CodeStyle: seedDefaults(null) آمن", true, null);

    // التفويض — مصدر حقيقة واحد
    check("XmlCodeFormatter: INDENT_KEY مُعار",
        XmlCodeFormatter.INDENT_KEY.equals(CodeStyle.XML_INDENT_KEY), XmlCodeFormatter.INDENT_KEY);
    check("XmlCodeFormatter: DEFAULT_INDENT مُعار",
        XmlCodeFormatter.DEFAULT_INDENT == CodeStyle.DEFAULT_INDENT,
        "" + XmlCodeFormatter.DEFAULT_INDENT);
    check("XmlCodeFormatter: MAX_INDENT مُعار",
        XmlCodeFormatter.MAX_INDENT == CodeStyle.MAX_INDENT, "" + XmlCodeFormatter.MAX_INDENT);
    freshPrefs();
    check("XmlCodeFormatter: resolveIndentSize(null) = 4",
        XmlCodeFormatter.resolveIndentSize(null) == 4,
        "" + XmlCodeFormatter.resolveIndentSize(null));
    putPref(CodeStyle.XML_INDENT_KEY, "2");
    check("XmlCodeFormatter: resolveIndentSize يقرأ التفضيل",
        XmlCodeFormatter.resolveIndentSize(context) == 2,
        "" + XmlCodeFormatter.resolveIndentSize(context));
    putPref(CodeStyle.XML_INDENT_KEY, "zzz");
    check("XmlCodeFormatter: resolveIndentSize يرتدّ عند الفساد",
        XmlCodeFormatter.resolveIndentSize(context) == 4,
        "" + XmlCodeFormatter.resolveIndentSize(context));

    // منسّق جافا يكرّم الإزاحة
    String java = "class A {\nvoid f() {\nif (x) {\nreturn;\n}\n}\n}";
    check("جافا: مستوى ثانٍ = 8 عند إزاحة 4",
        leadingOf(CodeLanguageTools.format(java, 4), 2) == 8,
        "" + leadingOf(CodeLanguageTools.format(java, 4), 2));
    check("جافا: مستوى ثانٍ = 4 عند إزاحة 2",
        leadingOf(CodeLanguageTools.format(java, 2), 2) == 4,
        "" + leadingOf(CodeLanguageTools.format(java, 2), 2));
    check("جافا: لا إزاحة عند 0",
        leadingOf(CodeLanguageTools.format(java, 0), 2) == 0,
        "" + leadingOf(CodeLanguageTools.format(java, 0), 2));
    check("جافا: المحتوى مطابق تمامًا بلا الإزاحة",
        stripIndent(CodeLanguageTools.format(java, 2)).equals(stripIndent(CodeLanguageTools.format(java, 4))),
        "اختلف المحتوى");
    check("جافا: عدد الأسطر ثابت",
        CodeLanguageTools.format(java, 2).split("\n", -1).length
            == CodeLanguageTools.format(java, 4).split("\n", -1).length,
        "اختلف العدد");
    check("جافا: خطوة سالبة لا تُسقط",
        leadingOf(CodeLanguageTools.format(java, -5), 2) == 0, "رمى أو أخطأ");
  }

  // ═══════════════════ §F سجل القوائم ═══════════════════

  static void menuRegistry() {
    section("و — سجل القوائم: أهلية حية وأمان null");

    EditorMenuRegistry registry = new EditorMenuRegistry();
    String[] pages = {
      EditorMenuRegistry.PAGE_TOOLBAR,
      EditorMenuRegistry.PAGE_ROOT,
      EditorMenuRegistry.PAGE_REFACTOR,
      EditorMenuRegistry.PAGE_CODE,
      EditorMenuRegistry.PAGE_FORMAT,
      EditorMenuRegistry.PAGE_FIND,
      EditorMenuRegistry.PAGE_SMALL,
    };

    check("Registry: entries(page, null) يعيد فارغًا بلا رمي",
        registry.entries(EditorMenuRegistry.PAGE_FORMAT, null).isEmpty(), "رمى أو أعاد");
    check("Registry: صفحة مجهولة تعيد فارغًا",
        registry.entries("no-such-page", new EditorMenuRegistry.Context()).isEmpty(), "أعادت");
    check("Registry: entries(null, ctx) لا تُرمي",
        registry.entries(null, new EditorMenuRegistry.Context()).isEmpty(), "رمت");

    EditorMenuRegistry.Context xmlContext = new EditorMenuRegistry.Context();
    xmlContext.xml = true;
    xmlContext.hasOpenFile = true;
    xmlContext.writable = true;
    xmlContext.hasSelection = true;
    EditorMenuRegistry.Context javaContext = new EditorMenuRegistry.Context();
    javaContext.hasOpenFile = true;
    javaContext.writable = true;
    javaContext.hasSelection = true;
    EditorMenuRegistry.Context readOnly = new EditorMenuRegistry.Context();
    readOnly.hasOpenFile = true;
    readOnly.writable = false;
    readOnly.xml = true;
    EditorMenuRegistry.Context closed = new EditorMenuRegistry.Context();

    check("Registry: XML يفتح التنسيق",
        enabled(registry, EditorMenuRegistry.PAGE_FORMAT, xmlContext, "format_code"), "معطّل");
    check("Registry: XML يفتح التعليق",
        enabled(registry, EditorMenuRegistry.PAGE_CODE, xmlContext, "comment"), "معطّل");
    check("Registry: XML يفتح فكّ التعليق",
        enabled(registry, EditorMenuRegistry.PAGE_CODE, xmlContext, "uncomment"), "معطّل");
    check("Registry: XML يفتح إعداد نمط الكود",
        enabled(registry, EditorMenuRegistry.PAGE_FORMAT, xmlContext, "configure_style"), "معطّل");
    check("Registry: XML يفتح استعراض الاستخدامات",
        enabled(registry, EditorMenuRegistry.PAGE_FIND, xmlContext, "find_usages"), "معطّل");
    check("Registry: XML يفتح الاستخدامات الموسعة",
        enabled(registry, EditorMenuRegistry.PAGE_FIND, xmlContext, "find_extended"), "معطّل");
    check("Registry: XML يفتح الانتقال إلى",
        enabled(registry, EditorMenuRegistry.PAGE_ROOT, xmlContext, "goto"), "معطّل");
    check("Registry: XML يفتح التوثيق",
        enabled(registry, EditorMenuRegistry.PAGE_ROOT, xmlContext, "documentation"), "معطّل");
    check("Registry: تنظيم الاستيرادات جافا فقط",
        !enabled(registry, EditorMenuRegistry.PAGE_CODE, xmlContext, "organize_imports")
            && enabled(registry, EditorMenuRegistry.PAGE_CODE, javaContext, "organize_imports"),
        "خالف العزل");
    check("Registry: try/catch جافا فقط",
        !enabled(registry, EditorMenuRegistry.PAGE_CODE, xmlContext, "surround_try")
            && enabled(registry, EditorMenuRegistry.PAGE_CODE, javaContext, "surround_try"),
        "خالف العزل");
    check("Registry: ملف للقراءة فقط يعطّل التنسيق",
        !enabled(registry, EditorMenuRegistry.PAGE_FORMAT, readOnly, "format_code"), "بقي مفعّلًا");
    check("Registry: ملف للقراءة فقط يعطّل التعليق",
        !enabled(registry, EditorMenuRegistry.PAGE_CODE, readOnly, "comment"), "بقي مفعّلًا");
    check("Registry: إعداد النمط لا يحتاج كتابة",
        enabled(registry, EditorMenuRegistry.PAGE_FORMAT, readOnly, "configure_style"), "عُطّل");
    check("Registry: إعداد النمط لا يحتاج ملفًا مفتوحًا",
        enabled(registry, EditorMenuRegistry.PAGE_FORMAT, closed, "configure_style"), "عُطّل");
    check("Registry: بلا تحديد يعطّل الاستبدال",
        !enabled(registry, EditorMenuRegistry.PAGE_CODE, closed, "replace"), "بقي مفعّلًا");
    check("Registry: بالتحديد يفتح الاستبدال",
        enabled(registry, EditorMenuRegistry.PAGE_CODE, javaContext, "replace"), "معطّل");
    check("Registry: بلا ملف مفتوح يعطّل الإغلاق",
        !enabled(registry, EditorMenuRegistry.PAGE_ROOT, closed, "close"), "بقي مفعّلًا");
    check("Registry: بملف مفتوح يفتح الإغلاق",
        enabled(registry, EditorMenuRegistry.PAGE_ROOT, xmlContext, "close"), "معطّل");

    // أسباب التعطيل يجب أن تكون ظاهرة لا فارغة صامتة
    for (String page : pages) {
      EditorMenuRegistry.Entry disabled = firstDisabled(registry, page, closed);
      if (disabled != null) {
        check("Registry: سبب تعطيل ظاهر في «" + page + "»",
            !disabled.disabledReason.isEmpty(), disabled.id + " بلا سبب");
      }
    }

    // لا سبب تعطيل يَعِد بمرحلة قادمة — بوابة انحدار للجولات التالية كلها
    check("Registry: لا سبب تعطيل يَعِد بمرحلة", !containsInRegistryReason("المرحلة"),
        "وُجد وعد بمرحلة غير منفّذة");

    // القائمة المصغرة
    EditorMenuRegistry.Context layoutContext = new EditorMenuRegistry.Context();
    layoutContext.xml = true;
    layoutContext.layoutXml = true;
    layoutContext.writable = true;
    layoutContext.hasOpenFile = true;
    check("Registry: «تصميم» يظهر لملف layout فقط",
        entry(registry, EditorMenuRegistry.PAGE_SMALL, layoutContext, "design") != null
            && entry(registry, EditorMenuRegistry.PAGE_SMALL, xmlContext, "design") == null,
        "خالف شرط layoutXml");
    check("Registry: Fix بلا مساهمين لا يظهر",
        entry(registry, EditorMenuRegistry.PAGE_SMALL, xmlContext, "fix") == null, "ظهر بلا مساهم");
    List<EditorMenuRegistry.DynamicCommand> fixes = new ArrayList<>();
    fixes.add(new EditorMenuRegistry.DynamicCommand(
        "f1", "إنشاء method() في class", true, "", null));
    EditorMenuRegistry.Context withFix = new EditorMenuRegistry.Context();
    withFix.xml = true;
    withFix.hasOpenFile = true;
    withFix.fixes = fixes;
    check("Registry: Fix يظهر بمساهم",
        entry(registry, EditorMenuRegistry.PAGE_SMALL, withFix, "fix") != null, "لم يظهر");
  }

  static boolean enabled(
      EditorMenuRegistry registry, String page, EditorMenuRegistry.Context context, String id) {
    EditorMenuRegistry.Entry entry = entry(registry, page, context, id);
    return entry != null && entry.enabled;
  }

  static EditorMenuRegistry.Entry firstDisabled(
      EditorMenuRegistry registry, String page, EditorMenuRegistry.Context context) {
    for (EditorMenuRegistry.Entry entry : registry.entries(page, context)) {
      if (!entry.enabled) return entry;
    }
    return null;
  }

  /** يقرأ مصدر السجل ويبحث عن كلمة في نص سبب تعطيل ({@code c -> "…"}). */
  static boolean containsInRegistryReason(String needle) {
    String source;
    try {
      source = read("app/src/main/java/com/almlkid/ui/EditorMenuRegistry.java");
    } catch (Exception unreadable) {
      System.out.println("      (تعذّرت قراءة مصدر السجل: " + unreadable + ")");
      return false;
    }
    int index = 0;
    while ((index = source.indexOf("c -> \"", index)) >= 0) {
      int end = source.indexOf('"', index + 6);
      if (end < 0) break;
      String reason = source.substring(index + 6, end);
      if (reason.contains(needle)) {
        System.out.println("      (سبب تعطيل: «" + reason + "»)");
        return true;
      }
      index = end;
    }
    return false;
  }

  // ═══════════════════ §G لا مسارات ميتة ═══════════════════

  static void noDeadPaths() throws Exception {
    section("ز — لا مسارات ميتة (بند 4: الإحلال الكامل)");

    String tools = read("app/src/main/java/com/almlkid/kay/ui/CodeLanguageTools.java");
    check("Dead: formatXml محذوف", !tools.contains("formatXml"), "ما زال");
    check("Dead: rtrim اليتيم محذوف", !tools.contains("rtrim"), "ما زال");
    check("Dead: لا تفريع XML في التنسيق", !tools.contains("isXml(fileName) ? format"), "ما زال");
    check("Dead: لا ثابت أربع مسافات مضمّن", !tools.contains("output.append(\"    \")"), "ما زال");
    check("Dead: isXml باقٍ للملوّن والمفتّش", tools.contains("private static boolean isXml("),
        "حُذف خطأً");
    check("Dead: لا نداء .formatXml( في المشروع", !containsInTree(".formatXml(", SRC), "وُجد");
    check("Dead: مسار XML الحي formatXmlSource سليم",
        containsInTree("formatXmlSource", SRC + "/com/almlkid/ui"), "اختفى");
    // المرحلة 1: أُحيي الملف بربط حي — وجوده ومرجعه مطلوبان الآن.
    check("إعدادات: preferences_codestyle.xml موجود",
        new File("/home/user/ShimaProject/app/src/main/res/xml/preferences_codestyle.xml").exists(),
        "الملف مفقود");
    check("إعدادات: مرجع حي لـ preferences_codestyle",
        read("app/src/main/java/com/almlkid/ui/preferences/CodestylePreferencesFragment.java")
            .contains("R.xml.preferences_codestyle"),
        "بلا مرجع");

    String formatter = read("app/src/main/java/almlk/XmlCodeFormatter.java");
    check("Dead: XmlCodeFormatter لا يقرأ التفضيل مباشرة",
        !formatter.contains("getSharedPreferences"), "يقرأ مباشرة");
    check("Dead: مفتاح الإزاحة الحرفي في CodeStyle وحده",
        !formatter.contains("\"xml_indentation_size\""), "مكتوب هنا أيضًا");
    check("Dead: CodeStyle يفوّض عبر indentSize",
        read("app/src/main/java/almlk/CodeStyle.java").contains("indentSize("), "لا يفوّض");

    section("ح — منظومة الاقتراحات: أيقونات الأنواع + الاستيراد التلقائي (المراحل 1-4)");
    String pager = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("اقتراح: النافذة العامة showCompletionPopup موجودة",
        pager.contains("public void showCompletionPopup()"), "مفقودة");
    check("اقتراح: التفويض applyTypedCompletion في الصفحات",
        pager.contains("public void applyTypedCompletion(ProjectSymbolIndex.CompletionItem"), "مفقود");
    check("اقتراح: النقر يلتزم منمطًا لا insertText مجرّد",
        pager.contains("applyTypedCompletion(completionAdapter.getItem(position))"), "ما زال مجرّد");
    check("اقتراح: لا نقر قديم بـ insertText في النافذة الحية",
        !pager.contains("applyCompletion(completionAdapter.getItem(position).insertText)"), "باقٍ");
    String ed = read("app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java");
    check("اقتراح: typedCompletions من فهرس الرموز", ed.contains("typedCompletions()"), "مفقود");
    check("اقتراح: applyTypedCompletion في المحرر",
        ed.contains("public void applyTypedCompletion("), "مفقود");
    check("اقتراح: الدالة تُدرج قوسين والمؤشر بداخلهما",
        ed.contains("isMethod && insert.indexOf('(') < 0")
            && ed.contains("caret = start + insert.length() + 1"), "منقوص");
    check("اقتراح: الكلاس يستورد تلقائيًا عبر addImportIfNeeded",
        ed.contains("private void addImportIfNeeded(String className)")
            && ed.contains("addImportIfNeeded(item.label)"), "منقوص");
    check("اقتراح: الاستيراد يتخطى java.lang", ed.contains("java.lang"), "منقوص");
    check("اقتراح: الاستيراد يتخطى نفس الحزمة", ed.contains("pkg.equals(currentPkg)"), "منقوص");
    check("اقتراح: إدراج سطر الاستيراد", ed.contains("replaceRange(insertAt, insertAt,"), "منقوص");
    check("اقتراح: packageOf يقرأ حزمة الصنف",
        ed.contains("ProjectSymbolIndex.packageOf(simple)"), "منقوص");
    String psi = read("app/src/main/java/com/almlkid/kay/ui/ProjectSymbolIndex.java");
    check("فهرس: packageOf عام ومتزامن",
        psi.contains("public static synchronized String packageOf("), "مفقود");
    String adapter = read("app/src/main/java/com/almlkid/ui/EditorCompletionAdapter.java");
    check("أيقونات: METHOD→box_red", adapter.contains("R.drawable.box_red"), "مفقود");
    check("أيقونات: CLASS→box_blue", adapter.contains("return R.drawable.box_blue"), "مفقود");
    check("أيقونات: VARIABLE→objects", adapter.contains("R.drawable.objects"), "مفقود");
    String icons = "/home/user/ShimaProject/app/src/main/res/drawable-hdpi/";
    check("أيقونات: ملفات المرجع المنسوخة موجودة",
        new File(icons + "box_red.png").exists() && new File(icons + "box_blue.png").exists()
            && new File(icons + "objects.png").exists()
            && new File(icons + "box_light_blue.png").exists()
            && new File(icons + "pakage.png").exists(), "ملف ناقص");
    String mainAct = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("اقتراح: الأمر اليدوي يوحَّد على النافذة الحية",
        mainAct.contains("editor.showCompletionPopup()"), "لا يفوّض");
    check("اقتراح: لا محول مزدوج في MainActivity",
        !mainAct.contains("completionIcon("), "باقٍ");

    section("ط — عزل قوائم المحرر عن الكيبورد (علّة «المزيد»)");
    String pg = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("عزل: لا نافذة حاوية focusable متبقية",
        !pg.contains("ViewGroup.LayoutParams.WRAP_CONTENT, true)"), "ما زالت focusable");
    check("عزل: selectionMenu = INPUT_METHOD_NOT_NEEDED",
        pg.contains("selectionMenu.setInputMethodMode(PopupWindow.INPUT_METHOD_NOT_NEEDED)"), "مفقود");
    check("عزل: selectionMenu = SOFT_INPUT_STATE_UNCHANGED",
        pg.contains("selectionMenu.setSoftInputMode(")
            && pg.contains("SOFT_INPUT_STATE_UNCHANGED"), "مفقود");
    check("عزل: القائمة المصغّرة أُزيلت كليًا (إحلال 1.0.68)",
        !pg.contains("smallContextMenu"), "ما زالت");
    check("عزل: نافذة الإكمال ما زالت غير focusable (حارس انحدار)",
        pg.contains("completionWindow = new PopupWindow(completionList, width, height, false)"), "تغيّرت");
    check("عزل: setOutsideTouchable باقٍ لـselectionMenu",
        pg.contains("selectionMenu.setOutsideTouchable(true)"), "مفقود");
    check("عزل: المانيفست ما زال adjustResize (لم نكسر التحرير)",
        read("app/src/main/AndroidManifest.xml").contains("stateHidden|adjustResize"), "تغيّر");

    section("ي — الضغط المطول على الفراغ يُخرج شريط إجراءات التحديد (لا دايلوق «تحرير»)");
    String canvas = read("app/src/main/java/almlk/CodeCanvasView.java");
    check("مطول/فراغ: يستدعي شريط إجراءات التحديد",
        canvas.contains("interactions.onShowSelectionActionsRequested()"), "مفقود");
    check("مطول/فراغ: يضع المؤشر مكان الضغط أولًا",
        canvas.contains("setCaret(pos[0], pos[1]);"), "مفقود");
    check("مطول/فراغ: لا القائمة المصغرة القديمة",
        !canvas.contains("onSmallContextMenuRequested"), "ما زالت");
    String edv = read("app/src/main/java/almlk/CodeEditorView.java");
    check("مطول/فراغ: المحرر يبدأ وضع التحديد",
        edv.contains("onShowSelectionActionsRequested") && edv.contains("startSelectionActionMode();"),
        "مفقود");
    check("مطول/فراغ: hook القائمة المصغرة محذوف",
        !edv.contains("onSmallContextMenuRequestedExternal"), "باقٍ");
    check("مطول/فراغ: SmallContextMenuListener محذوف من AlmlkEditor",
        !read("app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java").contains("SmallContextMenuListener"),
        "باقٍ");
    check("مطول/فراغ: showSmallContextMenu محذوف من الصفحات",
        !read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java").contains("showSmallContextMenu"),
        "باقٍ");
    check("مطول/فراغ: «تصميم» ما زال متاحًا (لا وظيفة مفقودة)",
        read("app/src/main/java/com/shima/demo/MainActivity.java").contains("case \"design\":"), "فُقد");

    section("ك — المرحلة 1: اكتمال القائمة الرئيسية (بدون تحديد) بلا عناصر ميتة");
    String cc = read("app/src/main/java/com/shima/demo/CommandCenter.java");
    check("مرحلة1: الأوامر الناقصة مسجلة (exit/close/publish/variant/forward)",
        cc.contains("add(\"exit\"") && cc.contains("add(\"close_project\"")
            && cc.contains("add(\"publish_project\"") && cc.contains("add(\"select_build_variant\"")
            && cc.contains("add(\"forward\""), "ناقصة");
    check("مرحلة1: «للأمام» أهلية حية صريحة لا عنصر ميت",
        cc.contains("add(\"forward\", \"للأمام\", \"المحرر\", false, true, h -> false, null)"), "ميت");
    String ma = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("مرحلة1: dispatch ينفّذ الأوامر الجديدة",
        ma.contains("case \"exit\":") && ma.contains("case \"close_project\":")
            && ma.contains("case \"publish_project\":") && ma.contains("case \"select_build_variant\":")
            && ma.contains("case \"forward\":"), "غير منفذة");
    check("مرحلة1: قائمة المشروع حية بلا disabledEntry ميت",
        ma.contains("commandEntry(\"select_build_variant\")") && ma.contains("commandEntry(\"publish_project\")")
            && ma.contains("commandEntry(\"close_project\")") && !ma.contains("disabledEntry(\"متغيرات البناء\")"),
        "ميتة");
    check("مرحلة1: قائمة التنسيق — إعداد النمط أمر حي",
        ma.contains("commandEntry(\"configure_style\")") && !ma.contains("disabledEntry(\"إعداد نمط الشيفرة\")"),
        "ميتة");
    check("مرحلة1: الجذر يحوي «للأمام»", ma.contains("commandEntry(\"forward\")"), "مفقود");

    section("ل — المرحلة 2: محرك إعادة التسمية Renamer (وظيفي)");
    String src = "int foo = 1;\nfoo++; // foo\nString s = \"foo\";\n";
    String renamed = almlk.Renamer.renameAll(src, "foo", "bar");
    check("إعادة تسمية: تستبدل التعريف والاستخدام", renamed.contains("int bar = 1;") && renamed.contains("bar++;"),
        renamed);
    check("إعادة تسمية: لا تلمس التعليقات والنصوص", renamed.contains("// foo") && renamed.contains("\"foo\""),
        renamed);
    check("إعادة تسمية: عدّ المواضع = 2", almlk.Renamer.countOccurrences(src, "foo") == 2,
        "" + almlk.Renamer.countOccurrences(src, "foo"));
    check("تحقق: كلمة محجوزة مرفوضة", almlk.Renamer.validate("foo", "class") != null, "قُبلت");
    check("تحقق: اسم مطابق مرفوض", almlk.Renamer.validate("foo", "foo") != null, "قُبل");
    check("تحقق: اسم صالح مقبول", almlk.Renamer.validate("foo", "bar") == null, "رُفض");
    String res = "<Button android:id=\"@+id/oldBtn\"/>\n<Button android:id=\"@id/oldBtn\"/>\n";
    String res2 = almlk.Renamer.renameResource(res, "oldBtn", "newBtn");
    check("مورد XML: @+id و@id يُحدَّثان", res2.contains("@+id/newBtn") && res2.contains("@id/newBtn")
        && !res2.contains("oldBtn"), res2);
    check("مورد XML: R.id يُحدَّث", almlk.Renamer.renameResource("int x = R.id.oldBtn;", "oldBtn", "newBtn")
        .contains("R.id.newBtn"), "لا");

    section("م — المرحلة 2: ربط إعادة التسمية بالقوائم (لا عنصر ميت)");
    String reg = read("app/src/main/java/com/almlkid/ui/EditorMenuRegistry.java");
    check("ربط: rename مفعّلة بتحديد+كتابة",
        reg.contains("add(PAGE_REFACTOR, \"rename\", \"إعادة التسمية\", null, ALWAYS,")
            && !reg.contains("\"rename\", \"إعادة التسمية\", null, ALWAYS, c -> false"), "معطلة");
    String pgr = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("ربط: renameCurrentSelection + case rename + Renamer",
        pgr.contains("public void renameCurrentSelection()") && pgr.contains("case \"rename\":")
            && pgr.contains("almlk.Renamer.renameAll") && pgr.contains("almlk.Renamer.renameResource"), "ناقص");
    String mnx = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("ربط: القائمة الرئيسية rename حية",
        mnx.contains("case \"rename\":") && mnx.contains("commandEntry(\"rename\")")
            && !mnx.contains("disabledEntry(\"إعادة تسمية Rename\")"), "ميتة");
    check("ربط: rename مسجلة + projectJavaFiles متاحة",
        read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"rename\"")
            && read("app/src/main/java/com/almlkid/kay/ui/ProjectSymbolIndex.java").contains("projectJavaFiles()"),
        "ناقصة");

    section("ن — المرحلة 3: محرك إعادة البناء Refactor (وظيفي)");
    String inl = almlk.Refactor.inlineVariable("int a = 5;\nint b = a + 1;\n", "a");
    check("Inline: يحذف الإعلان ويستبدل الاستخدام", inl != null && inl.contains("int b = (5) + 1;")
        && !inl.contains("int a"), String.valueOf(inl));
    check("Inline: null عند غياب الاستخدامات",
        almlk.Refactor.inlineVariable("int a = 5;\n", "a") == null, "ليس null");
    String srcI = "int b = 1 + 2;\n";
    String intro = almlk.Refactor.introduceVariable(srcI, srcI.indexOf("1 + 2"), srcI.indexOf("1 + 2") + 5, "x");
    check("Introduce: يضيف var ويستبدل التعبير", intro != null && intro.contains("var x = 1 + 2;")
        && intro.contains("int b = x;"), String.valueOf(intro));
    check("Introduce: يرفض اسمًا محجوزًا",
        almlk.Refactor.introduceVariable(srcI, 8, 13, "class") == null, "قُبل");
    String srcE = "class C {\n  void m() {\n    foo();\n  }\n}";
    String ext = almlk.Refactor.extractMethod(srcE, srcE.indexOf("foo();"), srcE.indexOf("foo();") + 6, "doFoo");
    check("Extract: يستبدل بنداء ويضيف الدالة", ext != null && ext.contains("doFoo();")
        && ext.contains("private void doFoo() {") && ext.contains("    foo();"), String.valueOf(ext));

    section("س — المرحلة 3: ربط أوامر إعادة البناء بالقوائم (لا ميت)");
    String reg3 = read("app/src/main/java/com/almlkid/ui/EditorMenuRegistry.java");
    check("ربط3: inline/introduce/extract مفعّلة (Java+تحديد+كتابة)",
        reg3.contains("add(PAGE_REFACTOR, \"inline\", \"تضمين المتغير\", null, ALWAYS,\n        c -> !c.xml && c.hasSelection && c.writable")
            && reg3.contains("add(PAGE_REFACTOR, \"extract_method\", \"استخراج دالة\", null, ALWAYS,\n        c -> !c.xml && c.hasSelection && c.writable"),
        "معطلة");
    String pg3 = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("ربط3: دوال Refactor موجودة ومربوطة بالحالات",
        pg3.contains("public void refactorInline()") && pg3.contains("public void refactorIntroduce()")
            && pg3.contains("public void refactorExtract()") && pg3.contains("case \"inline\":")
            && pg3.contains("case \"introduce\":") && pg3.contains("case \"extract_method\":"), "ناقص");
    String mn3 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("ربط3: القائمة الرئيسية أوامر حية بلا disabledEntry",
        mn3.contains("commandEntry(\"inline\")") && mn3.contains("commandEntry(\"introduce\")")
            && mn3.contains("commandEntry(\"extract_method\")") && mn3.contains("case \"inline\":")
            && !mn3.contains("disabledEntry(\"تضمين المتغير Inline\")"), "ميتة");
    check("ربط3: مسجلة في CommandCenter",
        read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"inline\"")
            && read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"extract_method\""),
        "ناقصة");

    section("ع — المرحلة 4: توليد الكود CodeGen (وظيفي)");
    String cls = "class P {\n  private int age;\n  private String name;\n}";
    String sg = almlk.CodeGen.createSettersGetters(cls);
    check("CodeGen: Getters/Setters لكل الحقول", sg != null && sg.contains("public int getAge()")
        && sg.contains("public void setAge(int age)") && sg.contains("public String getName()")
        && sg.contains("this.name = name;"), String.valueOf(sg));
    String ctor = almlk.CodeGen.createConstructor(cls);
    check("CodeGen: باني يهيّئ الحقول بترتيبها", ctor != null && ctor.contains("public P(int age, String name)")
        && ctor.contains("this.age = age;") && ctor.contains("this.name = name;"), String.valueOf(ctor));
    check("CodeGen: null بلا صنف", almlk.CodeGen.createConstructor("int x;") == null, "ليس null");
    String xml = "<TextView android:text=\"Hi\"/>";
    int a = xml.indexOf("Hi");
    String ex = almlk.CodeGen.extractResource(xml, a, a + 2, "greeting");
    check("CodeGen: استخراج مورد يستبدل بـ@string", ex != null && ex.contains("android:text=\"@string/greeting\""),
        String.valueOf(ex));
    check("CodeGen: إدخال string سليم", almlk.CodeGen.stringEntry("greeting", "Hi")
        .contains("<string name=\"greeting\">Hi</string>"), "لا");
    String cls2 = "class P {\n  private int age;\n  private String name;\n}";
    check("CodeGen: لا يكرر Getters/Setters موجودة",
        almlk.CodeGen.createSettersGetters(almlk.CodeGen.createSettersGetters(cls2)) == null, "كرر");
    check("CodeGen: لا يكرر بانيًا موجودًا",
        almlk.CodeGen.createConstructor(almlk.CodeGen.createConstructor(cls2)) == null, "كرر");

    section("ف — المرحلة 4: ربط توليد الكود بالقوائم (لا ميت)");
    String reg4 = read("app/src/main/java/com/almlkid/ui/EditorMenuRegistry.java");
    check("ربط4: setters/constructor مفعّلة (Java+كتابة) وextract (XML+تحديد)",
        reg4.contains("add(PAGE_CODE, \"create_setters\", \"إنشاء Setters وGetters\", null, ALWAYS,\n        c -> !c.xml && c.writable")
            && reg4.contains("add(PAGE_CODE, \"extract_resources\", \"استخراج الموارد\", null, ALWAYS,\n        c -> c.xml && c.hasSelection && c.writable"),
        "معطلة");
    String pg4 = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("ربط4: دوال CodeGen موجودة ومربوطة",
        pg4.contains("public void codegenSetters()") && pg4.contains("public void codegenConstructor()")
            && pg4.contains("public void codegenExtractResource()") && pg4.contains("case \"create_setters\":")
            && pg4.contains("case \"create_constructor\":") && pg4.contains("case \"extract_resources\":"),
        "ناقصة");
    String mn4 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("ربط4: القائمة الرئيسية أوامر حية بلا disabledEntry",
        mn4.contains("commandEntry(\"create_setters\")") && mn4.contains("commandEntry(\"create_constructor\")")
            && mn4.contains("commandEntry(\"extract_resources\")") && mn4.contains("case \"create_setters\":")
            && !mn4.contains("disabledEntry(\"إنشاء Setters/Getters\")"), "ميتة");
    check("ربط4: مسجلة في CommandCenter",
        read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"create_setters\"")
            && read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"extract_resources\""),
        "ناقصة");

    section("ص — استكمال قائمة Code: organize/surround حية (لا ميت)");
    String mn5 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("ص: dispatch ينفّذ organize/surround",
        mn5.contains("case \"organize_imports\":") && mn5.contains("case \"surround_try\":"), "غير منفذة");
    check("ص: قائمة Code حية بلا disabledEntry لهما",
        mn5.contains("commandEntry(\"organize_imports\")") && mn5.contains("commandEntry(\"surround_try\")")
            && !mn5.contains("disabledEntry(\"تنظيم الاستيرادات\")") && !mn5.contains("disabledEntry(\"إحاطة بـ try-catch\")"),
        "ميتة");
    check("ص: مسجلة في CommandCenter بأهلية كتابة",
        read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"organize_imports\"")
            && read("app/src/main/java/com/shima/demo/CommandCenter.java").contains("add(\"surround_try\""),
        "ناقصة");

    section("ق — المرحلة 5: نقاط التوقف + تعلّم النمط (وظيفي + ربط)");
    check("نمط: detectIndent يستدل 4", almlk.CodeStyle.detectIndent("    a\n        b\n") == 4,
        "" + almlk.CodeStyle.detectIndent("    a\n        b\n"));
    check("نمط: detectIndent يستدل 2", almlk.CodeStyle.detectIndent("  a\n    b\n") == 2,
        "" + almlk.CodeStyle.detectIndent("  a\n    b\n"));
    String ed5 = read("app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java");
    check("توقف: toggleBreakpointAtCaret + دمج FLAG_BREAKPOINT",
        ed5.contains("public boolean toggleBreakpointAtCaret()") && ed5.contains("breakpoints.contains(line)) flags |= FLAG_BREAKPOINT"),
        "ناقص");
    String rg5 = read("app/src/main/java/com/almlkid/ui/EditorMenuRegistry.java");
    check("توقف/نمط: مفعّلتان (Java / كتابة)",
        rg5.contains("add(PAGE_ROOT, \"breakpoint\", \"نقطة توقف\", null, ALWAYS, c -> !c.xml")
            && rg5.contains("add(PAGE_FORMAT, \"learn_style\", \"تعلم نمط الكود\", null, ALWAYS, c -> c.writable"),
        "معطلة");
    String pg5 = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("توقف/نمط: معالجان في قائمة التحديد",
        pg5.contains("case \"breakpoint\":") && pg5.contains("code.toggleBreakpointAtCaret()")
            && pg5.contains("case \"learn_style\":"), "ناقص");
    String mn6 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("نمط: learn_style حي في الرئيسية + dispatch",
        mn6.contains("commandEntry(\"learn_style\")") && mn6.contains("case \"learn_style\":")
            && mn6.contains("void learnCodeStyle()") && !mn6.contains("disabledEntry(\"تعلّم نمط الشيفرة\")"),
        "ميتة");

    section("ر — المرحلة 1 (الإعدادات): المضيف + المستهلكون");
    check("إعدادات: clampInt/choiceInt نقيان",
        almlk.AppSettings.clampInt("7", 12, 6, 40) == 7
            && almlk.AppSettings.clampInt("99", 12, 6, 40) == 12
            && almlk.AppSettings.clampInt("abc", 12, 6, 40) == 12
            && almlk.AppSettings.choiceInt("2", 4, new int[] {2, 4, 8}) == 2
            && almlk.AppSettings.choiceInt("3", 4, new int[] {2, 4, 8}) == 4,
        "تحليل");
    String host1 = read("app/src/main/java/com/almlkid/ui/preferences/AlmlkPreferencesActivity.java");
    check("مضيف: تبويبان + رؤوس + About + قائمة شظايا",
        host1.contains("NAVIGATION_MODE_TABS") && host1.contains("onBuildHeaders")
            && host1.contains("AboutActivity.class") && host1.contains("isValidFragment")
            && host1.contains("AdvancedSettingsFragment"),
        "ناقص");
    String[] frags1 = {"ApplicationPreferencesFragment", "EditorPreferencesFragment",
        "CodestylePreferencesFragment", "CompilerPreferencesFragment",
        "DropboxPreferencesFragment", "SourceControlPreferencesFragment",
        "KeyBindingsPreferencesFragment", "AdvancedSettingsFragment"};
    boolean fragsOk = true;
    for (String fr : frags1)
      fragsOk &= read("app/src/main/java/com/almlkid/ui/preferences/" + fr + ".java")
          .contains("addPreferencesFromResource") || fr.equals("KeyBindingsPreferencesFragment");
    check("شظايا: الثمان كلها حاضرة", fragsOk
        && read("app/src/main/java/com/almlkid/ui/preferences/KeyBindingsPreferencesFragment.java")
            .contains("createPreferenceScreen"), "ناقص");
    check("xml النمط: 7 مفاتيح",
        read("app/src/main/res/xml/preferences_codestyle.xml").contains("xml_indentation_size")
            && read("app/src/main/res/xml/preferences_codestyle.xml").contains("max_single_imports")
            && read("app/src/main/res/xml/preferences_codestyle.xml").contains("cpp_indentation_size"),
        "ناقص");
    check("مانيفست: نشاطان جديدان",
        read("app/src/main/AndroidManifest.xml")
            .contains("com.almlkid.ui.preferences.AlmlkPreferencesActivity")
            && read("app/src/main/AndroidManifest.xml").contains(".AboutActivity"),
        "غير مسجل");
    String mn7 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("رئيسي: دخول المضيف + حفظ تلقائي + سحب + markSaved",
        mn7.contains("AlmlkPreferencesActivity.class") && mn7.contains("scheduleAutosave()")
            && mn7.contains("attachBrowserSwipe()") && mn7.contains("editor.markSaved()"),
        "ناقص");
    check("تطبيق: لغة من الإعداد",
        read("app/src/main/java/com/shima/demo/ShimaApplication.java").contains("localeFor(")
            && read("app/src/main/java/com/shima/demo/ShimaApplication.java")
                .contains("KEY_LANGUAGE"),
        "ناقص");
    check("محرر: Tab مسافات/\t في الموقعين",
        read("app/src/main/java/almlk/CodeEditorView.java").contains("insertTabOrSpaces()")
            && read("app/src/main/java/almlk/CodeInputConnection.java")
                .contains("editor.insertTabOrSpaces()"),
        "ناقص");
    check("لوحة: عرض تبويب قابل للضبط",
        read("app/src/main/java/almlk/CodeCanvasView.java").contains("setTabSizeChars")
            && read("app/src/main/java/almlk/CodeCanvasView.java")
                .contains("metrics.spaceWidth * tabSizeChars"),
        "ثابت");
    String pg6 = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("pager: تطبيق إعدادات + أهلية الإكمال + لوحة قسرية",
        pg6.contains("applyEditorSettings()") && pg6.contains("completeAfterDot(getContext())")
            && pg6.contains("completeAllTypes(getContext())") && pg6.contains("hasPendingEdits()")
            && pg6.contains("KEYBOARD_NOKEYS"),
        "ناقص");
    check("xml التطبيق: تبويبات المحرر افتراضيًا ظاهرة",
        read("app/src/main/res/xml/preferences_application.xml")
            .contains("android:key=\"editor_tabs\"")
            && read("app/src/main/res/xml/preferences_application.xml")
                .contains("android:defaultValue=\"true\""),
        "رجوع سلوك");

    section("س — المرحلة 2: Code Style متعدد اللغات + Build & Run");
    android.preference.PreferenceManager.reset();
    android.content.Context ctxS = new android.content.Context();
    android.preference.PreferenceManager.store.put("html_indentation_size", "2");
    android.preference.PreferenceManager.store.put("css_indentation_size", "2");
    android.preference.PreferenceManager.store.put("js_indentation_size", "6");
    android.preference.PreferenceManager.store.put("cpp_indentation_size", "8");
    check("نمط: توزّع html/css",
        almlk.CodeStyle.indentSizeFor(ctxS, "a.html") == 2
            && almlk.CodeStyle.indentSizeFor(ctxS, "b.css") == 2,
        almlk.CodeStyle.indentSizeFor(ctxS, "a.html") + "/" + almlk.CodeStyle.indentSizeFor(ctxS, "b.css"));
    check("نمط: توزّع js/cpp",
        almlk.CodeStyle.indentSizeFor(ctxS, "c.js") == 6
            && almlk.CodeStyle.indentSizeFor(ctxS, "d.cpp") == 8,
        almlk.CodeStyle.indentSizeFor(ctxS, "c.js") + "/" + almlk.CodeStyle.indentSizeFor(ctxS, "d.cpp"));
    check("نمط: java/xml كما كانت + سقف الاستيرادات",
        almlk.CodeStyle.indentSizeFor(ctxS, "A.java") == 4
            && almlk.CodeStyle.indentSizeFor(ctxS, "s.xml") == 4
            && almlk.CodeStyle.maxSingleImports(ctxS) == 100,
        "ارتداد");
    android.preference.PreferenceManager.store.put("max_single_imports", "5");
    check("نمط: maxSingleImports يقرأ 5", almlk.CodeStyle.maxSingleImports(ctxS) == 5,
        "" + almlk.CodeStyle.maxSingleImports(ctxS));
    android.preference.PreferenceManager.store.put("max_single_imports", "abc");
    check("نمط: الفاسد يرتدّ 100", almlk.CodeStyle.maxSingleImports(ctxS) == 100,
        "" + almlk.CodeStyle.maxSingleImports(ctxS));
    check("استيرادات: طيّ نجمي حي",
        read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java")
            .contains("almlk.CodeStyle.maxSingleImports(getContext())"),
        "ناقص");
    String cf2 = read("app/src/main/java/com/almlkid/ui/preferences/CompilerPreferencesFragment.java");
    check("بناء: معالجات keystore/maven/ndk",
        cf2.contains("generate_keystore") && cf2.contains("refresh_maven_repository")
            && cf2.contains("install_uninstall_ndksupport") && cf2.contains("PKCS12"),
        "ناقص");
    String mn8 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("بناء: جسر + بيئة + root",
        mn8.contains("BuildActions.delegate") && mn8.contains("buildEnv(root)")
            && mn8.contains("Arrays.asList(\"su\", \"-c\"") && mn8.contains("SHIMA_KEYSTORE"),
        "ناقص");
    check("نمط: بذل المفاتيح الجديدة",
        read("app/src/main/java/almlk/CodeStyle.java").contains("HTML_INDENT_KEY, \"2\"")
            && read("app/src/main/java/almlk/CodeStyle.java").contains("CPP_INDENT_KEY, \"4\""),
        "ناقص");

    section("ش — المرحلة 3: اختصارات + Dropbox/Git");
    android.preference.PreferenceManager.reset();
    android.content.Context ctxK = new android.content.Context();
    check("اختصارات: تحليل نقي",
        almlk.Keybinds.parseMeta("CTRL+SHIFT+F") == 5
            && almlk.Keybinds.keyToken("CTRL+S").equals("S")
            && almlk.Keybinds.tokenForAndroidKeyCode(android.view.KeyEvent.KEYCODE_S).equals("S")
            && almlk.Keybinds.tokenForAndroidKeyCode(android.view.KeyEvent.KEYCODE_F5).equals("F5"),
        "تحليل");
    check("اختصارات: الافتراضيات تُطابق",
        "save".equals(almlk.Keybinds.commandFor(ctxK, true, false, false, android.view.KeyEvent.KEYCODE_S))
            && "run".equals(almlk.Keybinds.commandFor(ctxK, false, false, false, android.view.KeyEvent.KEYCODE_F5))
            && almlk.Keybinds.commandFor(ctxK, false, false, true, android.view.KeyEvent.KEYCODE_S) == null,
        "مطابقة");
    android.preference.PreferenceManager.store.put("keybind_save", "ALT+K");
    check("اختصارات: ربط مخزّن يسبق الافتراضي",
        "save".equals(almlk.Keybinds.commandFor(ctxK, false, true, false, android.view.KeyEvent.KEYCODE_K))
            && almlk.Keybinds.commandFor(ctxK, true, false, false, android.view.KeyEvent.KEYCODE_S) == null,
        "مخزّن");
    String mn9 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("رئيسي: dispatchKeyEvent + مرآة + git",
        mn9.contains("public boolean dispatchKeyEvent(") && mn9.contains("mirrorSync(")
            && mn9.contains("maybeInitGitRepo()") && mn9.contains("SHIMA_GIT_SSH_DIR"),
        "ناقص");
    check("شظية: افتراضات من Keybinds",
        read("app/src/main/java/com/almlkid/ui/preferences/KeyBindingsPreferencesFragment.java")
            .contains("almlk.Keybinds.defaultLabel(id)"),
        "مزدوج");

    section("ت — المرحلة 4: تبويب Advanced كاملًا");
    String adv4 = read("app/src/main/res/xml/preferences_advanced_setting.xml");
    check("متقدم: 8 شاشات كما اللقطة",
        adv4.contains("android:title=\"Application\"") && adv4.contains("android:title=\"Editor\"")
            && adv4.contains("android:title=\"Build &amp; Run\"") && adv4.contains("android:title=\"Project\"")
            && adv4.contains("android:title=\"Shortcut code\"")
            && adv4.contains("android:title=\"Backup and restore\"")
            && adv4.contains("android:title=\"Experimental functions\"") && adv4.contains("android:title=\"About\""),
        "بنية");
    check("متقدم: مفاتيح حية (نسخ/تجارب/رموز)",
        adv4.contains("shima_backup") && adv4.contains("shima_restore")
            && adv4.contains("experimental_crash_report") && adv4.contains("experimental_nav_history")
            && adv4.contains("quick_key_symbol".replace("quick_key_symbol", "preference_quick_key"))
            && adv4.contains("use_adjustPan") && adv4.contains("dark_statusbar"),
        "مفاتيح");
    String af4 = read("app/src/main/java/com/almlkid/ui/preferences/AdvancedSettingsFragment.java");
    check("متقدم: معالجات الشظية",
        af4.contains("ThemeActivity.class") && af4.contains("choose_bg_image")
            && af4.contains("onActivityResult") && af4.contains("shima_backup")
            && af4.contains("shima_restore") && af4.contains("writeProguardConfig")
            && af4.contains("configureGradle"),
        "ناقص");
    String cc4 = read("app/src/main/java/almlk/CodeCanvasView.java");
    check("لوحة: خط مخصص + صورة خلفية",
        cc4.contains("public void setFontPath(") && cc4.contains("setBackgroundImagePath")
            && cc4.contains("backgroundBitmap"),
        "ناقص");
    String pg7 = read("app/src/main/java/com/almlkid/ui/AIDEEditorPager.java");
    check("pager: شريط سريع مخصص + علم تجارب",
        pg7.contains("buildQuickKeys()") && pg7.contains("quickBarDisabled()")
            && pg7.contains("experimental_nav_history") && pg7.contains("applyAdvancedSettings()"),
        "ناقص");
    String mn10 = read("app/src/main/java/com/shima/demo/MainActivity.java");
    check("رئيسي: نافذة/شريط + جسر موسّع",
        mn10.contains("SOFT_INPUT_ADJUST_PAN") && mn10.contains("dark_statusbar")
            && mn10.contains("applyEditorVisual()") && mn10.contains("proguard-rules.pro")
            && mn10.contains("gradle.properties"),
        "ناقص");
    check("تطبيق: علم تقرير الانهيار",
        read("app/src/main/java/com/shima/demo/ShimaApplication.java")
            .contains("experimental_crash_report"),
        "ناقص");

    section("ث — المرحلة 5: الإحلال الشامل");
    check("إحلال: SettingsActivity زالت ملفًا ومرجعًا",
        !new File("/home/user/ShimaProject/app/src/main/java/com/shima/demo/SettingsActivity.java")
            .exists()
            && !read("app/src/main/AndroidManifest.xml").contains("SettingsActivity")
            && !read("app/src/main/java/com/shima/demo/MainActivity.java")
                .contains("SettingsActivity"),
        "بقايا");
    check("قبول: فحوص الأنشطة تحدّثت",
        read("qa/acceptance.sh").contains("AlmlkPreferencesActivity")
            && !read("qa/acceptance.sh").contains("SettingsActivity"),
        "فحوص قديمة");
    check("إحلال: درج وزر رئيسي مستهلَكان",
        read("app/src/main/java/com/shima/demo/MainActivity.java")
            .contains("applyDrawerSettings()")
            && read("app/src/main/java/com/shima/demo/MainActivity.java")
                .contains("LOCK_MODE_LOCKED_CLOSED")
            && read("app/src/main/java/com/shima/demo/MainActivity.java")
                .contains("masterAllowed()"),
        "ناقص");
    check("إحلال: بيت المشاريع من الإعداد",
        read("app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java")
            .contains("projectsHomeDir()")
            && read("app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java")
                .contains("getString(\"project_home\""),
        "ناقص");
    check("إحلال: الزر الرئيسي افتراضي ظاهر",
        read("app/src/main/res/xml/preferences_advanced_setting.xml")
            .contains("android:key=\"enableMainMasterButton\"")
            && read("app/src/main/res/xml/preferences_advanced_setting.xml")
                .contains("android:defaultValue=\"true\""),
        "رجوع سلوك");
    check("إحلال: لا عناصر ميتة مسمّاة في الرئيسية",
        !read("app/src/main/java/com/shima/demo/MainActivity.java").contains("disabledEntry(\"")
            && read("app/src/main/java/com/shima/demo/MainActivity.java")
                .contains("private IdeMenuEntry disabledEntry("),
        "ميت");
    check("إصدار: 1.0.83", read("VERSION").trim().equals("1.0.83"), read("VERSION").trim());

    section("خ — إصلاح ربط الكيبورد بالقوائم الفرعية لقائمة مينو");
    check("مينو: PopupWindow معزولة عن الكيبورد",
        read("app/src/main/java/com/shima/demo/MainActivity.java")
            .contains("ideMenuWindow = new PopupWindow(container, dp(280), ViewGroup.LayoutParams.WRAP_CONTENT, false)")
            && read("app/src/main/java/com/shima/demo/MainActivity.java")
                .contains("ideMenuWindow.setInputMethodMode(PopupWindow.INPUT_METHOD_NOT_NEEDED)")
            && read("app/src/main/java/com/shima/demo/MainActivity.java")
                .contains("ideMenuWindow.setSoftInputMode("),
        "خطف تركيز");

    section("ذ — إصلاح «commit already called» في تبويبي الإعدادات");
    String hostZ = read("app/src/main/java/com/almlkid/ui/preferences/AlmlkPreferencesActivity.java");
    int tabSelStart = hostZ.indexOf("public void onTabSelected");
    int tabSelEnd = hostZ.indexOf("public void onTabUnselected");
    check("مضيف: onTabSelected لا يلمس معاملة الإطار",
        tabSelStart >= 0 && tabSelEnd > tabSelStart
            && !hostZ.substring(tabSelStart, tabSelEnd).contains("transaction.")
            && hostZ.substring(tabSelStart, tabSelEnd).contains("commitAllowingStateLoss()"),
        "معاملة الإطار");
  }
}
