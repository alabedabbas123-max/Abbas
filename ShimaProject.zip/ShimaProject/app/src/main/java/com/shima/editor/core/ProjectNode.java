package com.shima.editor.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class ProjectNode {
  public final String path;
  public final String name;

  protected ProjectNode(String path, String name) {
    this.path = path == null ? "" : path;
    this.name = name == null ? "" : name;
  }

  public static final class Directory extends ProjectNode {
    private final ArrayList<ProjectNode> children = new ArrayList<>();
    public boolean expanded;
    public boolean childrenLoaded;

    public Directory(String path, String name) {
      super(path, name);
    }

    public synchronized List<ProjectNode> children() {
      return Collections.unmodifiableList(new ArrayList<>(children));
    }

    public synchronized void replaceChildren(List<ProjectNode> values) {
      children.clear();
      if (values != null) children.addAll(values);
      childrenLoaded = true;
    }
  }

  public static final class FileNode extends ProjectNode {
    public final FileType type;
    public final long size;
    public final long modifiedAt;

    public FileNode(String path, String name, FileType type, long size, long modifiedAt) {
      super(path, name);
      this.type = type == null ? FileType.UNKNOWN : type;
      this.size = size;
      this.modifiedAt = modifiedAt;
    }
  }

  public enum FileType {
    DEX,
    SMALI,
    JAVA,
    KOTLIN,
    JSON,
    XML,
    CSV,
    TXT,
    REPORT,
    BINARY,
    UNKNOWN
  }
}
