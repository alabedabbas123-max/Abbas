package android.net.http;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import org.apache.http.HttpConnection;
import org.apache.http.HttpConnectionMetrics;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpInetConnection;
import org.apache.http.HttpRequest;
import org.apache.http.ParseException;
import org.apache.http.StatusLine;
import org.apache.http.params.HttpParams;

public class AndroidHttpClientConnection implements HttpInetConnection, HttpConnection {
    public AndroidHttpClientConnection() {
        throw new RuntimeException("Stub!");
    }

    public void bind(Socket socket, HttpParams httpParams) throws IOException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void close() throws IOException {
        throw new RuntimeException("Stub!");
    }

    protected void doFlush() throws IOException {
        throw new RuntimeException("Stub!");
    }

    public void flush() throws IOException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public InetAddress getLocalAddress() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int getLocalPort() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public HttpConnectionMetrics getMetrics() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public InetAddress getRemoteAddress() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int getRemotePort() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int getSocketTimeout() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean isOpen() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean isStale() {
        throw new RuntimeException("Stub!");
    }

    public StatusLine parseResponseHeader(Headers headers) throws ParseException, IOException {
        throw new RuntimeException("Stub!");
    }

    public HttpEntity receiveResponseEntity(Headers headers) {
        throw new RuntimeException("Stub!");
    }

    public void sendRequestEntity(HttpEntityEnclosingRequest httpEntityEnclosingRequest) throws org.apache.http.HttpException, IOException {
        throw new RuntimeException("Stub!");
    }

    public void sendRequestHeader(HttpRequest httpRequest) throws org.apache.http.HttpException, IOException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setSocketTimeout(int i) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void shutdown() throws IOException {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }
}
