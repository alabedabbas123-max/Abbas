package almlk;

import com.almlkid.kay.ui.CodeLanguageTools;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * بند almlk ← الملوّن التزايدي «C0032va» بروحه الحرفية:
 *
 * <ul>
 *   <li>حالة معجمية لكل سطر (LINE_END_STATE): عادي / داخل تعليق كتلي — تعيد الإعراب من أول
 *       سطر متّسخ فقط وتتوقف عند أول سطر لم تتغير حالته (تقارب مبكر).
 *   <li>يعمل على خيط خلفي واحد بعيدًا عن الواجهة؛ أول تنفيذ يكسو الشاشة فورًا دون انتظار أي
 *       معالجة أخرى (الملفات الضخمة تُلوَّن نافذةً نافذةً بصمت).
 *   <li>إلغاء المهام الباهتة: أي تغيّر جديد يلغي الجولة السابقة (جيل متقدّم).
 *   <li>أنماط الإخراج تعيد استعمال ثوابت {@link CodeLanguageTools} — نفس لوحة ألوان التطبيق.
 * </ul>
 */
public final class LineStyler {

  /** يُستدعى على خيط الواجهة بعد كل جولة لإعادة رسم النطاق المتأثر. */
  public interface StylesListener {
    void onStylesUpdated(int fromLine, int toLine);
  }

  private static final int MODE_PLAIN = 0;
  private static final int MODE_JAVA = 1;
  private static final int MODE_XML = 2;
  private static final int MODE_SMALI = 3;
  private static final int MODE_CONF = 4; // properties/pro/ini/yml… — تعليق # وقيم فقط

  private static final int STATE_NORMAL = 0;
  private static final int STATE_BLOCK_COMMENT = 1; // /* ... */ أو <!-- ... -->
  private static final int STATE_XML_TAG = 2; // وسم XML ممتد عبر الأسطر <View \n attr=...
  private static final int STATE_XML_CDATA = 3; // <![CDATA[ ... ]]> عبر الأسطر

  private final LineDocument document;
  private final ExecutorService worker = Executors.newSingleThreadExecutor();
  private StylesListener listener;

  private volatile int[][] stylesByLine = new int[0][];
  private int[] endStates = new int[0];
  private int generation;
  private Future<?> running;
  private int mode = MODE_PLAIN;
  /** ملف Gradle: لوحة جافا مع إبقاء أسماء الأوامر بيضاء (مطابقة مظهر المرجع). */
  private volatile boolean gradleFile = false;
  private String fileName = "";
  private boolean paused;

  public LineStyler(LineDocument document) {
    this.document = document;
    document.addChangeListener((from, to) -> request(from, to));
  }

  public void setListener(StylesListener listener) {
    this.listener = listener;
  }

  public void setPaused(boolean paused) {
    this.paused = paused;
  }

  /** تغيّر الملف/المحتوى كاملًا: تصفير كامل وجولة جديدة. */
  public void setFileName(String name) {
    fileName = name == null ? "" : name;
    String lower = fileName.toLowerCase(java.util.Locale.US);
    // ملفات البناء: لوحة جافا نفسها (بما فيها تلوين الدوال) لكن أسماء أوامر Gradle تبقى بيضاء.
    gradleFile = lower.endsWith(".gradle") || lower.endsWith(".gradle.kts");
    // ‎.class: العرض للقراءة مصدرُ جافا مولّد — يُلوَّن بلوحة جافا كاملة كما في المرجع.
    if (lower.endsWith(".java") || lower.endsWith(".class") || lower.endsWith(".kt") || lower.endsWith(".c")
        || lower.endsWith(".cpp") || lower.endsWith(".h") || lower.endsWith(".cs")
        || lower.endsWith(".gradle") || lower.endsWith(".kts") || lower.endsWith(".groovy")
        || lower.endsWith(".js") || lower.endsWith(".ts") || lower.endsWith(".json")
        || lower.endsWith(".css")) {
      mode = MODE_JAVA;
    } else if (lower.endsWith(".xml") || lower.endsWith(".html") || lower.endsWith(".htm")
        || lower.endsWith(".svg")) {
      mode = MODE_XML;
    } else if (lower.endsWith(".smali")) {
      mode = MODE_SMALI;
    } else if (lower.endsWith(".properties") || lower.endsWith(".pro") || lower.endsWith(".ini")
        || lower.endsWith(".cfg") || lower.endsWith(".toml") || lower.endsWith(".yml")
        || lower.endsWith(".yaml") || lower.endsWith(".gitignore")) {
      mode = MODE_CONF;
    } else {
      mode = MODE_PLAIN;
    }
    synchronized (this) {
      stylesByLine = new int[Math.max(0, document.lineCount())][];
      endStates = new int[Math.max(0, document.lineCount())];
      for (int i = 0; i < endStates.length; i++) endStates[i] = -1; // يجبر إكساء كل سطر
    }
    request(0, Integer.MAX_VALUE);
  }

  /** طلب إكساء من سطر إلى سطر (تغيّر تزايدي أو تحديث شامل). */
  public void request(int fromLine, int toLine) {
    if (paused) return;
    final int generationAtRequest;
    synchronized (this) {
      generationAtRequest = ++generation;
      if (running != null) running.cancel(false);
    }
    final int from = Math.max(0, fromLine);
    running =
        worker.submit(
            () -> runStylingPass(generationAtRequest, from, toLine));
  }

  /** جولة واحدة: من السطر الأول المتّسخ حتى التقارب. */
  private void runStylingPass(int generationAtRun, int from, int to) {
    int lineCount = document.lineCount();
    if (lineCount == 0) return;
    synchronized (this) {
      if (stylesByLine.length < lineCount) {
        int[][] bigger = new int[lineCount][];
        System.arraycopy(stylesByLine, 0, bigger, 0, stylesByLine.length);
        stylesByLine = bigger;
        int[] biggerState = new int[lineCount];
        System.arraycopy(endStates, 0, biggerState, 0, endStates.length);
        for (int i = endStates.length; i < lineCount; i++) biggerState[i] = -1;
        endStates = biggerState;
      }
    }
    ensureCapacity(lineCount);
    int firstLine = Math.min(from, lineCount - 1);
    int lastTouched = firstLine;
    // حالة الدخول عند أول سطر = حالة نهاية السطر السابق.
    int state = firstLine > 0 && endStates[firstLine - 1] >= 0
        ? endStates[firstLine - 1]
        : STATE_NORMAL;
    for (int line = firstLine; line < lineCount; line++) {
      if (generationAtRun != generation || paused) return; // مهمة باهتة — تُلغى فورًا.
      if (line > to && endStates[line] == state && stylesByLine[line] != null) {
        break; // تقارب مبكر: سطر تجاوز المتّسخ وحالته لم تتغير — بقية المستند صالحة.
      }
      char[] chars;
      synchronized (document) {
        chars = document.lineChars(line);
      }
      int[] styles = lexLine(chars, state);
      stylesByLine[line] = styles;
      state = lexLineEndState;
      endStates[line] = lexLineEndState;
      lastTouched = line;
      // دفعات 512 سطرًا: الألوان تظهر على الشاشة تدريجيًا أثناء جولة الملفات الضخمة
      // (نفس إحساس نافذة المرجع — لا انتظار اكتمال المستند كله).
      if (line - firstLine > 0 && (line - firstLine) % 512 == 0) {
        postStylesUpdated(generationAtRun, firstLine + lastBatchOffset, line);
        lastBatchOffset = line - firstLine;
      }
    }
    postStylesUpdated(generationAtRun, firstLine + lastBatchOffset, lastTouched);
    lastBatchOffset = 0;
  }

  private int lastBatchOffset;

  private void postStylesUpdated(int generationAtRun, int from, int to) {
    if (to < from) return;
    new android.os.Handler(android.os.Looper.getMainLooper())
        .post(
            () -> {
              StylesListener target = listener;
              if (target != null && generationAtRun == generation)
                target.onStylesUpdated(from, to);
            });
  }

  private int lexLineEndState = STATE_NORMAL;

  private void ensureCapacity(int lineCount) {
    if (endStates.length < lineCount) {
      int[] bigger = new int[lineCount + 64];
      System.arraycopy(endStates, 0, bigger, 0, endStates.length);
      for (int i = Math.max(0, endStates.length - 1); i < bigger.length; i++)
        if (i >= endStates.length) bigger[i] = -1;
      endStates = bigger;
    }
  }

  /** أنماط سطر (كما طوله) أو null إن لم يُكسَ بعد — قراءة الواجهة بلا حجب. */
  public int[] stylesForLine(int line) {
    int[][] snapshot = stylesByLine;
    if (line < 0 || line >= snapshot.length) return null;
    return snapshot[line];
  }

  public void shutdown() {
    worker.shutdownNow();
  }

  // ---------------- اللكسير السطري (حالات: عادي/كتلي) ----------------

  private int[] lexLine(char[] chars, int entryState) {
    // عزل كامل لمسار XML (دراسة 1.0.24): آلة حالات خاصة تطابق إسقاط المرجع، ولا تمس Java.
    if (mode == MODE_XML) return lexXmlLine(chars, entryState);
    int length = chars.length;
    int[] styles = new int[length];
    lexLineEndState = STATE_NORMAL;
    // سياق التصنيف داخل السطر (إثراء 1.0.16 + مطابقة لوحة المرجع 1.0.19):
    // qualifiedName: داخل اسم مؤهل بعد import/package حتى «;» → مقاطع الحزم NAMESPACE.
    // expectType: بعد class/extends/new... → المعرف التالي نوع TAG.
    // prevIdentLike: الرمز السابق معرف/نوع — يميّز «تعريف دالة» (أبيض Plain) عن «استدعاء»
    // (أزرق FUNCTION) كما يظهر سلوك التطبيق المصدر (تقرير دراسة التلوين 1.0.19).
    boolean qualifiedName = false;
    boolean expectType = false;
    boolean prevIdentLike = false;
    int i = 0;
    if (entryState == STATE_BLOCK_COMMENT) {
      i = consumeBlockComment(chars, 0, styles);
      // consumeBlockComment يضبط نهاية الحالة بنفسه عند عدم الإنهاء فقط — لا فرض هنا.
      if (i >= length) return styles;
    }
    while (i < length) {
      char c = chars[i];
      if (c == ';') qualifiedName = false;
      if (c == ' ' || c == '\t') {
        i++;
        continue;
      }
      if (c == '/' && i + 1 < length && chars[i + 1] == '/' && mode == MODE_JAVA) {
        fill(styles, i, length, CodeLanguageTools.COMMENT);
        i = length;
      } else if (c == '/' && i + 1 < length && chars[i + 1] == '*' && mode == MODE_JAVA) {
        i = consumeBlockComment(chars, i, styles);
      } else if (c == '#' && (mode == MODE_SMALI || mode == MODE_CONF)) {
        fill(styles, i, length, CodeLanguageTools.COMMENT);
        i = length;
      } else if (c == '"') {
        i = consumeQuoted(chars, i, styles, '"');
        prevIdentLike = false;
      } else if (c == '\'') {
        i = consumeQuoted(chars, i, styles, '\'');
        prevIdentLike = false;
      } else if (c == '@' && mode != MODE_XML && i + 1 < length
          && Character.isJavaIdentifierStart(chars[i + 1])) {
        int end = i + 1;
        while (end < length && Character.isJavaIdentifierPart(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.ANNOTATION);
        prevIdentLike = false;
        i = end;
      } else if (Character.isDigit(c)) {
        int end = i + 1;
        while (end < length
            && (Character.isLetterOrDigit(chars[end]) || chars[end] == '.' || chars[end] == '_'))
          end++;
        fill(styles, i, end, CodeLanguageTools.NUMBER);
        prevIdentLike = false;
        i = end;
      } else if (c == '.' && mode == MODE_SMALI && i + 1 < length
          && Character.isJavaIdentifierStart(chars[i + 1])) {
        // تعليمة smali (.method .field .registers ...) — كلمات مفتاحية.
        int end = i + 1;
        while (end < length && Character.isJavaIdentifierPart(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.KEYWORD);
        i = end;
      } else if ((c == 'L' || c == '[') && mode == MODE_SMALI
          && i + 1 < length && isSmaliTypeStart(chars, i)) {
        int end = i;
        while (end < length && chars[end] != ';') end++;
        fill(styles, i, Math.min(end + 1, length), CodeLanguageTools.FUNCTION);
        i = Math.min(end + 1, length);
      } else if (c == 'v' && mode == MODE_SMALI && i + 1 < length
          && Character.isDigit(chars[i + 1])) {
        int end = i + 1;
        while (end < length && Character.isDigit(chars[end])) end++;
        fill(styles, i, end, CodeLanguageTools.NUMBER);
        i = end;
      } else if (Character.isJavaIdentifierStart(c)) {
        int end = i + 1;
        while (end < length && Character.isJavaIdentifierPart(chars[end])) end++;
        String word = new String(chars, i, end - i);
        if (mode == MODE_JAVA && PRIMITIVE_TYPES.contains(word)) {
          // قاعدة المصدر: الأنواع البدائية (void/float/int...) زرقاء كنوع لا حمراء ككلمة.
          fill(styles, i, end, CodeLanguageTools.TAG);
          expectType = false;
          prevIdentLike = true;
        } else if (isKeyword(word)) {
          fill(styles, i, end, CodeLanguageTools.KEYWORD);
          prevIdentLike = false;
          if (mode == MODE_JAVA) {
            if ("import".equals(word) || "package".equals(word)) qualifiedName = true;
            expectType = "class".equals(word) || "interface".equals(word) || "enum".equals(word)
                || "extends".equals(word) || "implements".equals(word) || "new".equals(word)
                || "instanceof".equals(word) || "throws".equals(word) || "record".equals(word);
          }
        } else if (mode == MODE_JAVA) {
          // تصنيف مطابق للتطبيق المصدر (تقرير 1.0.19):
          // حزم/متغيرات/ثوابت عنبرية، أنواع واستدعاءات زرقاء، أسماء التعريفات بيضاء.
          int next = end;
          while (next < length && (chars[next] == ' ' || chars[next] == '\t')) next++;
          boolean function = next < length && chars[next] == '(';
          if (qualifiedName && !Character.isUpperCase(word.charAt(0))) {
            fill(styles, i, end, CodeLanguageTools.NAMESPACE);
          } else if (isAllCapsConstant(word)) {
            // الثوابت ALL_CAPS (VISIBLE/MIN_...) معرفات عنبرية لا أنواعًا رغم بدايتها الكبيرة.
            fill(styles, i, end, CodeLanguageTools.IDENTIFIER);
          } else if (expectType || Character.isUpperCase(word.charAt(0))) {
            fill(styles, i, end, CodeLanguageTools.TAG);
          } else if (function) {
            // مسبوق بنوع/معرف ⇒ تعريف دالة يبقى Plain أبيض؛ غير ذلك ⇒ استدعاء أزرق.
            if (!prevIdentLike) fill(styles, i, end, CodeLanguageTools.FUNCTION);
          } else if (!gradleFile) {
            fill(styles, i, end, CodeLanguageTools.IDENTIFIER); // المتغيرات/الحقول/البراميترات
          }
          // في gradle: أسماء الأوامر (implementation/android/...) تبقى بيضاء كما في المرجع.
          expectType = false;
          prevIdentLike = true;
        }
        i = end;
      } else if ("(){}[];,.".indexOf(c) >= 0) {
        // فواصل وترقيم (أقواس/فواصل/نقاط) — فئة مستقلة زرقاء كما في المصدر.
        styles[i] = CodeLanguageTools.SEPARATOR;
        prevIdentLike = false;
        i++;
      } else if ("=+-*/%&|!<>~^?:".indexOf(c) >= 0) {
        styles[i] = CodeLanguageTools.OPERATOR;
        prevIdentLike = false;
        i++;
      } else {
        prevIdentLike = false;
        i++;
      }
    }
    return styles;
  }

  /**
   * مُكْسي XML بإسقاط المرجع (تقرير 1.0.24): اسم العنصر أحمر KEYWORD، الخاصية عنبرية
   * IDENTIFIER، القيمة خضراء LITERAL، ترقيم الوسم أحمر، = عنبرية، التعليق وCDATA عبر
   * الأسطر بحالتي STATE_XML_* ضمن endStates — فيصح تلوين خصائص الأسطر التالية للوسم.
   */
  private int[] lexXmlLine(char[] chars, int entryState) {
    int length = chars.length;
    int[] styles = new int[length];
    lexLineEndState = STATE_NORMAL;
    int i = 0;
    boolean inTag = entryState == STATE_XML_TAG;
    boolean expectElementName = false;
    if (entryState == STATE_BLOCK_COMMENT) {
      i = consumeBlockComment(chars, 0, styles);
      if (i >= length) return styles;
    } else if (entryState == STATE_XML_CDATA) {
      i = consumeCdata(chars, 0, styles);
      if (i >= length) return styles;
    }
    while (i < length) {
      char c = chars[i];
      if (!inTag) {
        if (c == '<' && matches(chars, i, "<!--")) {
          i = consumeBlockComment(chars, i, styles);
          if (lexLineEndState == STATE_BLOCK_COMMENT) return styles;
          continue;
        }
        if (c == '<' && matches(chars, i, "<![CDATA[")) {
          i = consumeCdata(chars, i, styles);
          if (lexLineEndState == STATE_XML_CDATA) return styles;
          continue;
        }
        if (c == '<') {
          styles[i] = CodeLanguageTools.KEYWORD;
          inTag = true;
          expectElementName = true;
          i++;
          continue;
        }
        if (c == '&') {
          // كيان &amp; / &#160; — قيمة حرفية خضراء كما يرسمها المرجع.
          int end = i + 1;
          while (end < length && end - i < 10
              && (Character.isLetterOrDigit(chars[end]) || chars[end] == '#')) end++;
          if (end < length && chars[end] == ';') {
            fill(styles, i, end + 1, CodeLanguageTools.STRING);
            i = end + 1;
            continue;
          }
        }
        i++; // نص حر بين الوسوم — أبيض Plain.
        continue;
      }
      // داخل وسم (ولو عبر أسطر متعددة):
      if (c == '>') {
        styles[i] = CodeLanguageTools.KEYWORD;
        inTag = false;
        i++;
        continue;
      }
      if (c == '/' || c == '?' || c == '!') {
        styles[i] = CodeLanguageTools.KEYWORD;
        i++;
        continue;
      }
      if (c == '"' || c == '\'') {
        i = consumeQuoted(chars, i, styles, c);
        continue;
      }
      if (c == '=') {
        styles[i] = CodeLanguageTools.OPERATOR;
        i++;
        continue;
      }
      if (Character.isJavaIdentifierStart(c) || c == ':') {
        int end = i + 1;
        while (end < length
            && (Character.isJavaIdentifierPart(chars[end])
                || chars[end] == '-' || chars[end] == ':' || chars[end] == '.')) end++;
        // دلالة المرجع: أسماء السمات بلون المتغيرات — لا الأصفر الذهبي (لون الدوال/المعرفات).
        fill(styles, i, end,
            expectElementName ? CodeLanguageTools.KEYWORD : CodeLanguageTools.VARIABLE);
        expectElementName = false;
        i = end;
        continue;
      }
      i++;
    }
    if (inTag && lexLineEndState == STATE_NORMAL) lexLineEndState = STATE_XML_TAG;
    return styles;
  }

  /** CDATA: محتوى حرفي أخضر؛ غير المغلق يمدد الحالة للسطر التالي. */
  private int consumeCdata(char[] chars, int start, int[] styles) {
    int i = start;
    while (i < chars.length) {
      if (matches(chars, i, "]]>")) {
        i += 3;
        fill(styles, start, i, CodeLanguageTools.STRING);
        return i;
      }
      i++;
    }
    fill(styles, start, chars.length, CodeLanguageTools.STRING);
    lexLineEndState = STATE_XML_CDATA;
    return chars.length;
  }

  private boolean matches(char[] chars, int at, String token) {
    if (at + token.length() > chars.length) return false;
    for (int i = 0; i < token.length(); i++)
      if (chars[at + i] != token.charAt(i)) return false;
    return true;
  }

  private boolean isSmaliTypeStart(char[] chars, int at) {
    if (chars[at] == '[') return true;
    if (at + 1 >= chars.length) return false;
    char next = chars[at + 1];
    return Character.isUpperCase(next) || next == 'a' || next == 'b' || next == 'c';
  }

  private int consumeQuoted(char[] chars, int start, int[] styles, char quote) {
    int i = start + 1;
    boolean escaped = false;
    while (i < chars.length) {
      char c = chars[i];
      if (escaped) escaped = false;
      else if (c == '\\') escaped = true;
      else if (c == quote) {
        i++;
        break;
      }
      i++;
    }
    fill(styles, start, Math.min(i, chars.length), CodeLanguageTools.STRING);
    return Math.min(i, chars.length);
  }

  private int consumeBlockComment(char[] chars, int start, int[] styles) {
    String terminator = mode == MODE_XML ? "-->" : "*/";
    int i = start;
    int from = start;
    while (i < chars.length) {
      if (matches(chars, i, terminator)) {
        i += terminator.length();
        fill(styles, from, Math.min(i, chars.length), CodeLanguageTools.COMMENT);
        return i;
      }
      i++;
    }

    fill(styles, from, chars.length, CodeLanguageTools.COMMENT);
    lexLineEndState = STATE_BLOCK_COMMENT;
    return chars.length;
  }

  private static void fill(int[] styles, int from, int to, int id) {
    for (int i = Math.max(0, from); i < Math.min(to, styles.length); i++) styles[i] = id;
  }

  /** الأنواع البدائية — تُلوَّن كأنواع (زرقاء) لا ككلمات مفتاحية، مطابقة للتطبيق المصدر. */
  private static final HashSet<String> PRIMITIVE_TYPES = new HashSet<>();

  static {
    String[] primitives = {
      "void", "boolean", "byte", "char", "short", "int", "long", "float", "double"
    };
    for (String word : primitives) PRIMITIVE_TYPES.add(word);
  }

  /** ثابت ALL_CAPS (حرفان فأكثر، كبائر/أرقام/شرطات سفلية فقط وفيه حرف واحد على الأقل). */
  private static boolean isAllCapsConstant(String word) {
    if (word.length() < 2) return false;
    boolean hasLetter = false;
    for (int i = 0; i < word.length(); i++) {
      char c = word.charAt(i);
      if (c >= 'A' && c <= 'Z') hasLetter = true;
      else if (!(c >= '0' && c <= '9') && c != '_' && c != '$') return false;
    }
    return hasLetter;
  }

  /** كلمات Java الشائعة (تغطي أيضًا C/C++/smali بشكل معقول كما في المصدر). */
  private static final HashSet<String> JAVA_KEYWORDS = new HashSet<>();

  static {
    String[] words = {
      "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class",
      "const", "continue", "default", "do", "double", "else", "enum", "extends", "final",
      "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int",
      "interface", "long", "native", "new", "package", "private", "protected", "public",
      "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
      "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false",
      "null", "record", "sealed", "permits", "var", "yield", "synchronized",
      "int32_t", "int64_t", "struct", "typedef", "union", "unsigned", "register", "sizeof",
      "override", "virtual", "template", "namespace", "using", "inline", "explicit"
    };
    for (String word : words) JAVA_KEYWORDS.add(word);
  }

  private boolean isKeyword(String word) {
    if (mode == MODE_JAVA) return JAVA_KEYWORDS.contains(word);
    if (mode == MODE_SMALI)
      return "move".equals(word) || "invoke-virtual".equals(word) || "invoke-static".equals(word)
          || "invoke-direct".equals(word) || "return-void".equals(word);
    return false;
  }
}
