package com.shima.projects;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * معالج إنشاء المشاريع بدلالات المرجع: قوالب JSON مصنفة من assets، حوار اسم/حزمة
 * بتحقق حي واسم تلقائي App/App2، نسخ القالب مع استبدالات $package_name$/$project_name$،
 * ثم فتح ملفات البداية. كل الأعمال الثقيلة في خيوط خلفية.
 */
public final class ProjectWizard {

  /** يستلم نتيجة الإنشاء/الاستيراد على خيط الواجهة. */
  public interface Host {
    void onProjectCreated(File projectRoot, File mainModule, List<File> starterFiles);

    void onProjectImported(File targetDirectory);
  }

  private ProjectWizard() {}

  // ===== نموذج القوالب =====
  private static final class Template {
    String id, title, description, main, icon;
    final ArrayList<String> open = new ArrayList<>();
  }

  private static final class Category {
    String title, icon;
    final ArrayList<Template> templates = new ArrayList<>();
  }

  /** أيقونات الحوار بدلالات المرجع: الفئة ببوصلة الاستوديو، والأنواع بأيقوناتها. */
  private static int iconResource(String name) {
    if ("ic_androidstudio".equals(name)) return com.shima.demo.R.drawable.ic_androidstudio;
    if ("ic_project_android".equals(name)) return com.shima.demo.R.drawable.ic_project_android;
    if ("ic_project_xposed".equals(name)) return com.shima.demo.R.drawable.ic_project_xposed;
    if ("ic_project_java".equals(name)) return com.shima.demo.R.drawable.file_type_java;
    return com.shima.demo.R.drawable.ic_project_android;
  }

  /** نقطة الدخول: فحص قابلية الكتابة ثم حوار اختيار القالب — كما في المرجع. */
  public static void show(Activity activity, File targetDirectory, Host host) {
    if (targetDirectory == null || !isWritableDirectory(targetDirectory)) {
      new AlertDialog.Builder(activity)
          .setTitle("تنبيه")
          .setMessage(
              "لا يمكن الكتابة في مجلد المشاريع الحالي.\nامنح صلاحية جميع الملفات أو اختر مجلدًا قابلًا للكتابة.")
          .setPositiveButton("حسنًا", null)
          .show();
      return;
    }
    final List<Category> categories = loadCategories(activity);
    if (categories.isEmpty()) {
      Toast.makeText(activity, "تعذر تحميل قوالب المشاريع", Toast.LENGTH_SHORT).show();
      return;
    }
    ExpandableListView listView = new ExpandableListView(activity);
    AlertDialog dialog =
        new AlertDialog.Builder(activity)
            .setTitle("إنشاء مشروع جديد")
            .setView(listView)
            .setNegativeButton("إلغاء", null)
            .setNeutralButton("استيراد ZIP", (d, w) -> promptImport(activity, targetDirectory, host))
            .create();
    listView.setAdapter(new TemplateAdapter(activity, categories));
    listView.setOnChildClickListener(
        (parent, view, group, child, id) -> {
          dialog.dismiss();
          promptDetails(activity, targetDirectory, categories.get(group).templates.get(child), host);
          return true;
        });
    dialog.show();
    if (!categories.isEmpty()) listView.expandGroup(0);
  }

  // ===== حوار بيانات المشروع: اسم/حزمة بتحقق حي (بنية المرجع) =====
  private static void promptDetails(Activity activity, File target, Template template, Host host) {
    LinearLayout layout = new LinearLayout(activity);
    layout.setOrientation(LinearLayout.VERTICAL);
    int pad = dp(activity, 24);
    layout.setPadding(pad, dp(activity, 12), pad, 0);

    // رأس المرجع createproject: نوع المشروع ثم الموقع بسطر صغير.
    TextView typeLabel = new TextView(activity);
    typeLabel.setText(template.title);
    typeLabel.setTextSize(16);
    typeLabel.setTypeface(null, android.graphics.Typeface.BOLD);
    TextView locationLabel = new TextView(activity);
    locationLabel.setText(new File(target, "").getAbsolutePath());
    locationLabel.setTextSize(12);
    locationLabel.setTextColor(Color.GRAY);
    locationLabel.setPadding(0, dp(activity, 4), 0, dp(activity, 10));
    layout.addView(typeLabel);
    layout.addView(locationLabel);

    TextView nameLabel = new TextView(activity);
    nameLabel.setText("اسم التطبيق");
    EditText nameInput = new EditText(activity);
    nameInput.setSingleLine(true);
    TextView pkgLabel = new TextView(activity);
    pkgLabel.setText("اسم الحزمة");
    pkgLabel.setPadding(0, dp(activity, 10), 0, 0);
    EditText pkgInput = new EditText(activity);
    pkgInput.setSingleLine(true);
    layout.addView(nameLabel);
    layout.addView(nameInput);
    layout.addView(pkgLabel);
    layout.addView(pkgInput);

    AlertDialog dialog =
        new AlertDialog.Builder(activity)
            .setTitle(template.title)
            .setView(layout)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("إنشاء", null)
            .create();
    if (dialog.getWindow() != null)
      dialog.getWindow().setSoftInputMode(
          android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    dialog.show();
    Button create = dialog.getButton(AlertDialog.BUTTON_POSITIVE);

    String defaultName = freeProjectName(target);
    nameInput.setText(defaultName);
    pkgInput.setText("com.my." + defaultName.toLowerCase(java.util.Locale.US));
    nameInput.selectAll();

    Runnable validate =
        () -> {
          String name = nameInput.getText().toString().trim();
          String pkg = pkgInput.getText().toString().trim();
          boolean ok = isValidProjectName(name);
          if (ok && new File(target, name).exists()) {
            nameInput.setError("الاسم موجود مسبقًا");
            ok = false;
          }
          if (ok && !isValidPackage(pkg)) ok = false;
          create.setEnabled(ok);
        };
    TextWatcher watcher =
        new TextWatcher() {
          public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

          public void onTextChanged(CharSequence s, int a, int b, int c) {
            validate.run();
          }

          public void afterTextChanged(Editable s) {}
        };
    nameInput.addTextChangedListener(watcher);
    pkgInput.addTextChangedListener(watcher);
    validate.run();

    create.setOnClickListener(
        v -> {
          dialog.dismiss();
          createProject(
              activity,
              target,
              template,
              nameInput.getText().toString().trim(),
              pkgInput.getText().toString().trim(),
              host);
        });
  }

  // ===== الإنشاء: نسخ القالب مع الاستبدالات في خيط خلفي (بنية المرجع) =====
  private static void createProject(
      Activity activity, File target, Template template, String name, String pkg, Host host) {
    AlertDialog progress =
        new AlertDialog.Builder(activity)
            .setMessage("جارٍ إنشاء المشروع…")
            .setCancelable(false)
            .create();
    progress.show();
    new Thread(
            () -> {
              Exception failure = null;
              final File root = new File(target, name);
              try {
                copyAssetTree(
                    activity.getAssets(),
                    "templates/" + template.id,
                    root,
                    pkg.replace('.', '/'),
                    name,
                    pkg);
              } catch (Exception error) {
                failure = error;
              }
              final Exception error = failure;
              activity.runOnUiThread(
                  () -> {
                    progress.dismiss();
                    if (error != null) {
                      Toast.makeText(
                              activity, "تعذر إنشاء المشروع: " + error.getMessage(), Toast.LENGTH_LONG)
                          .show();
                      return;
                    }
                    File mainModule =
                        template.main == null || template.main.isEmpty()
                            ? root
                            : new File(root, template.main);
                    ArrayList<File> starters = new ArrayList<>();
                    for (String relative : template.open) {
                      File starter =
                          new File(root, relative.replace("$package_name$", pkg.replace('.', '/')));
                      if (starter.isFile()) starters.add(starter);
                    }
                    Toast.makeText(activity, "تم إنشاء المشروع " + name, Toast.LENGTH_SHORT).show();
                    if (host != null) host.onProjectCreated(root, mainModule, starters);
                  });
            })
        .start();
  }

  /**
   * نسخ شجرة assets إلى القرص: مجلد «pkg» يتحول لمسار الحزمة، أسماء «dot_» تستعيد
   * نقطتها (aapt يقصي الملفات النقطية من assets)، والملفات النصية تمر بالاستبدالات.
   */
  private static void copyAssetTree(
      AssetManager assets, String source, File destination, String pkgPath, String name, String pkg)
      throws Exception {
    String[] children = assets.list(source);
    if (children != null && children.length > 0) {
      for (String child : children) {
        String childDest = child;
        if (child.equals("pkg")) childDest = pkgPath;
        else if (child.startsWith("dot_")) childDest = "." + child.substring(4);
        copyAssetTree(
            assets, source + "/" + child, new File(destination, childDest), pkgPath, name, pkg);
      }
      return;
    }
    File parent = destination.getParentFile();
    if (parent != null && !parent.exists() && !parent.mkdirs())
      throw new java.io.IOException("تعذر إنشاء " + parent.getName());
    try (InputStream in = assets.open(source)) {
      byte[] raw = readAll(in);
      if (isTextTemplate(destination.getName())) {
        String text = new String(raw, "UTF-8");
        text =
            text.replace("$package_name$", pkg)
                .replace("$project_name$", name)
                .replace("$package_name_jni$", pkg.replace('.', '_'));
        raw = text.getBytes("UTF-8");
      }
      try (FileOutputStream out = new FileOutputStream(destination)) {
        out.write(raw);
      }
    }
  }

  // ===== استيراد مشروع من ZIP (بنية المرجع) =====
  private static void promptImport(Activity activity, File target, Host host) {
    EditText input = new EditText(activity);
    input.setHint("المسار الكامل لملف ZIP");
    input.setSingleLine(true);
    LinearLayout wrap = new LinearLayout(activity);
    int pad = dp(activity, 24);
    wrap.setPadding(pad, 0, pad, 0);
    wrap.addView(
        input,
        new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    new AlertDialog.Builder(activity)
        .setTitle("استيراد مشروع")
        .setMessage("تأكد أن الأرشيف يحوي مجلد مشروع من المستوى الأول.")
        .setView(wrap)
        .setNegativeButton("إلغاء", null)
        .setPositiveButton(
            "استيراد",
            (d, w) -> {
              File zip = new File(input.getText().toString().trim());
              if (!zip.isFile()) {
                Toast.makeText(activity, "مسار غير صالح", Toast.LENGTH_SHORT).show();
                return;
              }
              importZip(activity, zip, target, host);
            })
        .show();
  }

  private static void importZip(Activity activity, File zip, File target, Host host) {
    AlertDialog progress =
        new AlertDialog.Builder(activity)
            .setMessage("جارٍ استيراد المشروع…")
            .setCancelable(false)
            .create();
    progress.show();
    new Thread(
            () -> {
              Exception failure = null;
              try {
                unzip(zip, target);
              } catch (Exception error) {
                failure = error;
              }
              final Exception error = failure;
              activity.runOnUiThread(
                  () -> {
                    progress.dismiss();
                    if (error != null) {
                      Toast.makeText(
                              activity, "فشل الاستيراد: " + error.getMessage(), Toast.LENGTH_LONG)
                          .show();
                      return;
                    }
                    Toast.makeText(activity, "تم استيراد المشروع", Toast.LENGTH_SHORT).show();
                    if (host != null) host.onProjectImported(target);
                  });
            })
        .start();
  }

  /** فك آمن: حارس Zip-Slip يرفض أي مدخل يخرج عن المجلد الهدف. */
  private static void unzip(File zip, File target) throws Exception {
    String canonicalTarget = target.getCanonicalPath() + File.separator;
    try (ZipInputStream in = new ZipInputStream(new FileInputStream(zip))) {
      ZipEntry entry;
      byte[] buffer = new byte[16384];
      while ((entry = in.getNextEntry()) != null) {
        File out = new File(target, entry.getName());
        if (!out.getCanonicalPath().startsWith(canonicalTarget))
          throw new SecurityException("مدخل أرشيف غير آمن: " + entry.getName());
        if (entry.isDirectory()) {
          out.mkdirs();
          continue;
        }
        File parent = out.getParentFile();
        if (parent != null) parent.mkdirs();
        try (FileOutputStream stream = new FileOutputStream(out)) {
          int read;
          while ((read = in.read(buffer)) > 0) stream.write(buffer, 0, read);
        }
      }
    }
  }

  // ===== تحميل القوالب والمساعدات =====
  private static List<Category> loadCategories(Activity activity) {
    ArrayList<Category> result = new ArrayList<>();
    try (InputStream in = activity.getAssets().open("templates/templates.json")) {
      JSONObject rootJson = new JSONObject(new String(readAll(in), "UTF-8"));
      JSONArray categoriesJson = rootJson.getJSONArray("categories");
      for (int i = 0; i < categoriesJson.length(); i++) {
        JSONObject categoryJson = categoriesJson.getJSONObject(i);
        Category category = new Category();
        category.title = categoryJson.getString("title");
        category.icon = categoryJson.optString("icon", "ic_androidstudio");
        JSONArray templatesJson = categoryJson.getJSONArray("templates");
        for (int j = 0; j < templatesJson.length(); j++) {
          JSONObject templateJson = templatesJson.getJSONObject(j);
          Template template = new Template();
          template.id = templateJson.getString("id");
          template.title = templateJson.getString("title");
          template.description = templateJson.optString("description", "");
          template.main = templateJson.optString("main", "");
          template.icon = templateJson.optString("icon", "ic_project_android");
          JSONArray openJson = templateJson.optJSONArray("open");
          if (openJson != null)
            for (int k = 0; k < openJson.length(); k++) template.open.add(openJson.getString(k));
          category.templates.add(template);
        }
        result.add(category);
      }
    } catch (Exception ignored) {
    }
    return result;
  }

  /** أول اسم حر بنمط App/App2/App3 في المجلد الهدف — سلوك المرجع الحرفي. */
  private static String freeProjectName(File target) {
    for (int i = 1; i < 1000; i++) {
      String candidate = i == 1 ? "App" : "App" + i;
      if (!new File(target, candidate).exists()) return candidate;
    }
    return "App";
  }

  private static boolean isValidProjectName(String name) {
    return !name.isEmpty() && !name.matches(".*[\\\\/:*?\"<>|].*") && !name.startsWith(".");
  }

  private static boolean isValidPackage(String pkg) {
    return pkg.matches("[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+");
  }

  private static boolean isWritableDirectory(File directory) {
    try {
      if (!directory.exists() && !directory.mkdirs()) return false;
      File probe = new File(directory, ".shima_write_probe");
      if (probe.createNewFile()) {
        probe.delete();
        return true;
      }
    } catch (Throwable ignored) {
    }
    return false;
  }

  private static boolean isTextTemplate(String name) {
    String lower = name.toLowerCase(java.util.Locale.US);
    return !(lower.endsWith(".png")
        || lower.endsWith(".jpg")
        || lower.endsWith(".webp")
        || lower.endsWith(".jar")
        || lower.endsWith(".zip"));
  }

  private static byte[] readAll(InputStream in) throws Exception {
    java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
    byte[] buffer = new byte[16384];
    int read;
    while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
    return out.toByteArray();
  }

  private static int dp(Activity activity, int value) {
    return (int) (value * activity.getResources().getDisplayMetrics().density + 0.5f);
  }

  // ===== مهايئ قائمة القوالب: فئة قابلة للطي، وبند بعنوان ووصف (بنية المرجع) =====
  private static final class TemplateAdapter extends BaseExpandableListAdapter {
    private final Activity activity;
    private final List<Category> categories;

    TemplateAdapter(Activity activity, List<Category> categories) {
      this.activity = activity;
      this.categories = categories;
    }

    public int getGroupCount() {
      return categories.size();
    }

    public int getChildrenCount(int group) {
      return categories.get(group).templates.size();
    }

    public Object getGroup(int group) {
      return categories.get(group);
    }

    public Object getChild(int group, int child) {
      return categories.get(group).templates.get(child);
    }

    public long getGroupId(int group) {
      return group;
    }

    public long getChildId(int group, int child) {
      return group * 1000L + child;
    }

    public boolean hasStableIds() {
      return true;
    }

    public boolean isChildSelectable(int group, int child) {
      return true;
    }

    public View getGroupView(int group, boolean expanded, View convert, android.view.ViewGroup parent) {
      LinearLayout layout;
      if (convert instanceof LinearLayout) {
        layout = (LinearLayout) convert;
      } else {
        layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setMinimumHeight(dp(activity, 56));
        layout.setPadding(dp(activity, 40), dp(activity, 4), dp(activity, 12), dp(activity, 4));
        android.widget.ImageView icon = new android.widget.ImageView(activity);
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 34), dp(activity, 34)));
        TextView title = new TextView(activity);
        title.setTextSize(17);
        title.setPadding(dp(activity, 14), 0, 0, 0);
        layout.addView(icon);
        layout.addView(title);
      }
      Category category = categories.get(group);
      ((android.widget.ImageView) layout.getChildAt(0)).setImageResource(iconResource(category.icon));
      ((TextView) layout.getChildAt(1)).setText(category.title);
      return layout;
    }

    public View getChildView(
        int group, int child, boolean last, View convert, android.view.ViewGroup parent) {
      LinearLayout layout;
      if (convert instanceof LinearLayout) {
        layout = (LinearLayout) convert;
      } else {
        // بنية صف المرجع createproject_entry: أيقونة 40dp + عمود عنوان/وصف، ارتفاع 60dp.
        layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setMinimumHeight(dp(activity, 60));
        layout.setPadding(dp(activity, 40), dp(activity, 5), dp(activity, 12), dp(activity, 5));
        android.widget.ImageView icon = new android.widget.ImageView(activity);
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 40), dp(activity, 40)));
        LinearLayout texts = new LinearLayout(activity);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(activity, 10), 0, 0, 0);
        TextView title = new TextView(activity);
        title.setTextSize(15);
        TextView description = new TextView(activity);
        description.setTextSize(12);
        description.setTextColor(Color.GRAY);
        description.setPadding(0, dp(activity, 2), 0, 0);
        texts.addView(title);
        texts.addView(description);
        layout.addView(icon);
        layout.addView(texts);
      }
      Template template = categories.get(group).templates.get(child);
      ((android.widget.ImageView) layout.getChildAt(0)).setImageResource(iconResource(template.icon));
      LinearLayout texts = (LinearLayout) layout.getChildAt(1);
      ((TextView) texts.getChildAt(0)).setText(template.title);
      ((TextView) texts.getChildAt(1)).setText(template.description);
      return layout;
    }
  }
}
