package com.almlkid.kay.ui;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Thread-safe lightweight Java symbol index used for cross-file diagnostics and quick fixes. */
public final class ProjectSymbolIndex {
  private static final Map<String, Set<String>> METHODS = new HashMap<>();
  private static final Map<String, LinkedHashMap<String, String>> METHOD_RETURNS = new HashMap<>();
  private static final Map<String, LinkedHashMap<String, String>> METHOD_PARAMETERS = new HashMap<>();
  private static final Map<String, LinkedHashMap<String, String>> CLASS_FIELDS = new HashMap<>();
  private static final Map<String, String> PARENTS = new HashMap<>();
  private static final Map<String, String> CLASS_FILES = new HashMap<>();
  private static final Map<String, String> CLASS_REFERENCES = new HashMap<>();
  private static final Map<String, Integer> CLASS_OFFSETS = new HashMap<>();
  private static final Map<String, LinkedHashMap<String, Integer>> METHOD_OFFSETS = new HashMap<>();
  private static final Map<String, LinkedHashMap<String, Integer>> FIELD_OFFSETS = new HashMap<>();
  private static final CompletionTrie<String> CLASS_TRIE = new CompletionTrie<>();
  private static final Map<String, CompletionTrie<String>> MEMBER_TRIES = new HashMap<>();
  private static final Pattern CLASS_PATTERN =
      Pattern.compile("\\b(?:class|interface|enum|record)\\s+([A-Za-z_$][A-Za-z0-9_$]*)");
  private static final Pattern METHOD_PATTERN =
      Pattern.compile(
          "(?m)(?:^|[;{}])\\s*(?:(?:public|protected|private|static|final|abstract|synchronized|native|default)\\s+)*(?:<[^>{}]+>\\s*)?([A-Za-z_$][A-Za-z0-9_$<>?,. \\t\\[\\]]*)\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\(");
  private static final Pattern VARIABLE_PATTERN =
      Pattern.compile(
          "\\b([A-Z][A-Za-z0-9_$.]*(?:\\s*<[^;=(){}]+>)?(?:\\[\\])*)\\s+([a-zA-Z_$][A-Za-z0-9_$]*)\\b");
  private static final Pattern FIELD_PATTERN =
      Pattern.compile(
          "(?m)(?:^|[;{}])\\s*(?:(?:public|protected|private|static|final|volatile|transient)\\s+)*"
              + "(?!(?:class|interface|enum|record)\\b)"
              + "((?:byte|short|int|long|float|double|boolean|char|String)|[A-Za-z_$][A-Za-z0-9_$.]*"
              + "(?:\\s*<[^;=(){}]+>)?(?:\\[\\])*)\\s+"
              + "([A-Za-z_$][A-Za-z0-9_$]*)\\s*(?:=|;|,)");
  private static final Pattern CALL_PATTERN =
      Pattern.compile("\\b([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\.\\s*([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\(");
  private static final Pattern CREATION_PATTERN =
      Pattern.compile("\\b([A-Za-z_$][A-Za-z0-9_$]*)\\s*=\\s*new\\s+([A-Z][A-Za-z0-9_$.]*)\\s*[<(]");
  private static final Pattern CAST_PATTERN =
      Pattern.compile("\\b([A-Za-z_$][A-Za-z0-9_$]*)\\s*=\\s*\\(\\s*([A-Z][A-Za-z0-9_$.]*)\\s*\\)");
  private static List<String> classNamesCache = Collections.emptyList();
  private static boolean classNamesDirty = true;

  static {
    seedBuiltIns();
  }

  private ProjectSymbolIndex() {}

  public static synchronized void clear() {
    METHODS.clear();
    METHOD_RETURNS.clear();
    METHOD_PARAMETERS.clear();
    CLASS_FIELDS.clear();
    PARENTS.clear();
    CLASS_FILES.clear();
    CLASS_REFERENCES.clear();
    CLASS_OFFSETS.clear();
    METHOD_OFFSETS.clear();
    FIELD_OFFSETS.clear();
    CLASS_TRIE.clear();
    MEMBER_TRIES.clear();
    classNamesCache = Collections.emptyList();
    classNamesDirty = true;
    seedBuiltIns();
  }

  private static synchronized void seedBuiltIns() {
    addBuiltIn("View", new String[][] {{"setVisibility", "void"}, {"getVisibility", "int"}, {"setOnClickListener", "void"}, {"findViewById", "View"}, {"requestLayout", "void"}, {"invalidate", "void"}, {"getContext", "Context"}});
    addBuiltIn("TextView", new String[][] {{"setText", "void"}, {"getText", "CharSequence"}, {"setTextColor", "void"}, {"setTextSize", "void"}, {"setGravity", "void"}, {"append", "void"}});
    addBuiltIn("EditText", new String[][] {{"setText", "void"}, {"getText", "Editable"}, {"setSelection", "void"}, {"setError", "void"}, {"requestFocus", "boolean"}});
    addBuiltIn("Activity", new String[][] {{"setContentView", "void"}, {"findViewById", "View"}, {"getIntent", "Intent"}, {"startActivity", "void"}, {"finish", "void"}, {"getResources", "Resources"}});
    addBuiltIn("Context", new String[][] {{"getResources", "Resources"}, {"getString", "String"}, {"getSystemService", "Object"}, {"getSharedPreferences", "SharedPreferences"}, {"startActivity", "void"}});
    addBuiltIn("String", new String[][] {{"length", "int"}, {"substring", "String"}, {"toLowerCase", "String"}, {"contains", "boolean"}, {"startsWith", "boolean"}, {"endsWith", "boolean"}, {"trim", "String"}, {"equals", "boolean"}});
    addBuiltIn("List", new String[][] {{"add", "boolean"}, {"get", "Object"}, {"size", "int"}, {"isEmpty", "boolean"}, {"clear", "void"}, {"remove", "Object"}});
    addBuiltIn("Map", new String[][] {{"put", "Object"}, {"get", "Object"}, {"containsKey", "boolean"}, {"keySet", "Set"}, {"values", "Collection"}, {"clear", "void"}});
    addBuiltIn("Intent", new String[][] {{"putExtra", "Intent"}, {"getStringExtra", "String"}, {"getData", "Uri"}, {"addFlags", "Intent"}});
    addBuiltIn("SharedPreferences", new String[][] {{"getString", "String"}, {"getBoolean", "boolean"}, {"getInt", "int"}, {"edit", "Editor"}, {"contains", "boolean"}});
    addBuiltIn("Bundle", new String[][] {{"putString", "void"}, {"getString", "String"}, {"putInt", "void"}, {"getInt", "int"}, {"containsKey", "boolean"}});
    inheritBuiltIn("TextView", "View");
    inheritBuiltIn("EditText", "TextView");
  }

  private static void inheritBuiltIn(String child, String parent) {
    LinkedHashMap<String, String> childMethods = METHOD_RETURNS.get(child);
    LinkedHashMap<String, String> parentMethods = METHOD_RETURNS.get(parent);
    if (childMethods != null && parentMethods != null) {
      for (Map.Entry<String, String> entry : parentMethods.entrySet())
        if (!childMethods.containsKey(entry.getKey())) childMethods.put(entry.getKey(), entry.getValue());
      METHODS.put(child, new HashSet<>(childMethods.keySet()));
      LinkedHashMap<String, String> childParameters = METHOD_PARAMETERS.get(child);
      LinkedHashMap<String, String> parentParameters = METHOD_PARAMETERS.get(parent);
      if (childParameters != null && parentParameters != null)
        for (Map.Entry<String, String> entry : parentParameters.entrySet())
          if (!childParameters.containsKey(entry.getKey()))
            childParameters.put(entry.getKey(), entry.getValue());
      PARENTS.put(child, parent);
      rebuildMemberTrie(child);
    }
  }

  private static void rebuildMemberTrie(String type) {
    CompletionTrie<String> trie = new CompletionTrie<>();
    LinkedHashMap<String, String> methods = METHOD_RETURNS.get(type);
    if (methods != null) for (String name : methods.keySet()) trie.put(name, name);
    LinkedHashMap<String, String> fields = CLASS_FIELDS.get(type);
    if (fields != null) for (String name : fields.keySet()) trie.put(name, name);
    MEMBER_TRIES.put(type, trie);
  }

  private static void addBuiltIn(String type, String[][] declarations) {
    LinkedHashMap<String, String> methods = new LinkedHashMap<>();
    for (String[] declaration : declarations) methods.put(declaration[0], declaration[1]);
    methods.put("toString", "String"); methods.put("hashCode", "int"); methods.put("equals", "boolean");
    METHOD_RETURNS.put(type, methods);
    LinkedHashMap<String, String> parameters = new LinkedHashMap<>();
    for (String method : methods.keySet()) parameters.put(method, "");
    METHOD_PARAMETERS.put(type, parameters);
    METHODS.put(type, new HashSet<>(methods.keySet()));
    CLASS_FIELDS.put(type, new LinkedHashMap<>());
    CLASS_TRIE.put(type, type);
    rebuildMemberTrie(type);
    classNamesDirty = true;
  }

  public static synchronized void registerSource(String fileName, String source) {
    registerSource(fileName, fileName, source);
  }

  /** Registers a source file while retaining its stable path/SAF URI for exact cross-file opens. */
  public static synchronized void registerSource(
      String fileName, String reference, String source) {
    String code = mask(source);
    Matcher classes = CLASS_PATTERN.matcher(code);
    ArrayList<String> classNames = new ArrayList<>();
    LinkedHashMap<String, Integer> classOffsets = new LinkedHashMap<>();
    while (classes.find()) {
      classNames.add(classes.group(1));
      classOffsets.put(classes.group(1), classes.start(1));
    }
    if (classNames.isEmpty() && fileName != null && fileName.endsWith(".java")) {
      String inferred = fileName.substring(0, fileName.length() - 5);
      classNames.add(inferred);
      classOffsets.put(inferred, 0);
    }
    HashSet<String> methods = new HashSet<>();
    LinkedHashMap<String, String> returns = new LinkedHashMap<>();
    LinkedHashMap<String, String> parameters = new LinkedHashMap<>();
    LinkedHashMap<String, Integer> methodOffsets = new LinkedHashMap<>();
    Matcher declarations = METHOD_PATTERN.matcher(code);
    while (declarations.find()) {
      String returnType = declarations.group(1).trim().replaceAll("\\s+", " ");
      String methodName = declarations.group(2);
      methods.add(methodName);
      returns.put(methodName, returnType);
      methodOffsets.put(methodName, declarations.start(2));
      int open = declarations.end() - 1;
      int close = matchingParenthesis(code, open);
      String args = close > open ? code.substring(open + 1, close).trim().replaceAll("\\s+", " ") : "";
      parameters.put(methodName, args);
    }
    returns.put("toString", "String");
    returns.put("hashCode", "int");
    returns.put("equals", "boolean");
    returns.put("clone", "Object");
    for (String method : returns.keySet())
      if (!parameters.containsKey(method)) parameters.put(method, "");
    methods.addAll(returns.keySet());
    LinkedHashMap<String, String> fields = new LinkedHashMap<>();
    LinkedHashMap<String, Integer> fieldOffsets = new LinkedHashMap<>();
    // Only declarations that begin after a class/member boundary are fields. The broader
    // VARIABLE_PATTERN is intentionally not used here because it would mistake method parameters
    // (for example String name) for fields.
    Matcher declaredFields = FIELD_PATTERN.matcher(code);
    while (declaredFields.find()) {
      fields.put(declaredFields.group(2), simpleType(declaredFields.group(1)));
      fieldOffsets.put(declaredFields.group(2), declaredFields.start(2));
    }
    for (String className : classNames) {
      methods.add(className);
      METHODS.put(className, new HashSet<>(methods));
      METHOD_RETURNS.put(className, new LinkedHashMap<>(returns));
      METHOD_PARAMETERS.put(className, new LinkedHashMap<>(parameters));
      CLASS_FIELDS.put(className, new LinkedHashMap<>(fields));
      METHOD_OFFSETS.put(className, new LinkedHashMap<>(methodOffsets));
      FIELD_OFFSETS.put(className, new LinkedHashMap<>(fieldOffsets));
      if (fileName != null) CLASS_FILES.put(className, fileName);
      if (reference != null) CLASS_REFERENCES.put(className, reference);
      CLASS_OFFSETS.put(className, classOffsets.getOrDefault(className, 0));
      Matcher parent =
          Pattern.compile("\\b(?:class|interface)\\s+" + Pattern.quote(className)
                  + "(?:\\s*<[^>{}]+>)?\\s+extends\\s+([A-Za-z_$][A-Za-z0-9_$.]*)")
              .matcher(code);
      if (parent.find()) PARENTS.put(className, simpleType(parent.group(1)));
      CLASS_TRIE.put(className, className);
      rebuildMemberTrie(className);
    }
    if (!classNames.isEmpty()) classNamesDirty = true;
  }

  /** Immutable parsed class snapshot used by the persistent project index. */
  public static final class CachedClass {
    public final String name, parent, fileName, reference;
    public final int offset;
    public final List<CachedMember> members;

    public CachedClass(
        String name,
        String parent,
        String fileName,
        String reference,
        int offset,
        List<CachedMember> members) {
      this.name = name == null ? "" : name;
      this.parent = parent == null ? "" : parent;
      this.fileName = fileName == null ? "" : fileName;
      this.reference = reference == null ? "" : reference;
      this.offset = Math.max(0, offset);
      this.members = members == null ? Collections.emptyList() : new ArrayList<>(members);
    }
  }

  public static final class CachedMember {
    public final String name, returnType, parameters;
    public final int offset;
    public final boolean method;

    public CachedMember(
        String name, String returnType, String parameters, int offset, boolean method) {
      this.name = name == null ? "" : name;
      this.returnType = returnType == null ? "Object" : returnType;
      this.parameters = parameters == null ? "" : parameters;
      this.offset = Math.max(0, offset);
      this.method = method;
    }
  }

  /** Exports only classes belonging to one already parsed source file; no source rescan occurs. */
  public static synchronized List<CachedClass> cachedClassesForFile(
      String fileName, String reference) {
    ArrayList<CachedClass> result = new ArrayList<>();
    for (Map.Entry<String, String> entry : CLASS_FILES.entrySet()) {
      String owner = entry.getKey();
      if (!Objects.equals(entry.getValue(), fileName)
          || !Objects.equals(CLASS_REFERENCES.get(owner), reference)) continue;
      ArrayList<CachedMember> members = new ArrayList<>();
      LinkedHashMap<String, String> returns = METHOD_RETURNS.get(owner);
      LinkedHashMap<String, String> parameters = METHOD_PARAMETERS.get(owner);
      LinkedHashMap<String, Integer> offsets = METHOD_OFFSETS.get(owner);
      if (returns != null) {
        for (Map.Entry<String, String> method : returns.entrySet()) {
          if (method.getKey().equals("toString")
              || method.getKey().equals("hashCode")
              || method.getKey().equals("equals")
              || method.getKey().equals("clone")) continue;
          members.add(
              new CachedMember(
                  method.getKey(),
                  method.getValue(),
                  parameters == null ? "" : parameters.getOrDefault(method.getKey(), ""),
                  offsets == null ? 0 : offsets.getOrDefault(method.getKey(), 0),
                  true));
        }
      }
      LinkedHashMap<String, String> fields = CLASS_FIELDS.get(owner);
      LinkedHashMap<String, Integer> fieldOffsets = FIELD_OFFSETS.get(owner);
      if (fields != null) {
        for (Map.Entry<String, String> field : fields.entrySet()) {
          members.add(
              new CachedMember(
                  field.getKey(),
                  field.getValue(),
                  "",
                  fieldOffsets == null ? 0 : fieldOffsets.getOrDefault(field.getKey(), 0),
                  false));
        }
      }
      result.add(
          new CachedClass(
              owner,
              PARENTS.getOrDefault(owner, ""),
              fileName,
              reference,
              CLASS_OFFSETS.getOrDefault(owner, 0),
              members));
    }
    return result;
  }

  /** Restores one parsed class directly into RAM without reading or parsing its source. */
  public static synchronized void registerCachedClass(CachedClass cached) {
    if (cached == null || cached.name.isEmpty()) return;
    LinkedHashMap<String, String> returns = new LinkedHashMap<>();
    LinkedHashMap<String, String> parameters = new LinkedHashMap<>();
    LinkedHashMap<String, Integer> methodOffsets = new LinkedHashMap<>();
    LinkedHashMap<String, String> fields = new LinkedHashMap<>();
    LinkedHashMap<String, Integer> fieldOffsets = new LinkedHashMap<>();
    HashSet<String> methods = new HashSet<>();
    for (CachedMember member : cached.members) {
      if (member == null || member.name.isEmpty()) continue;
      if (member.method) {
        methods.add(member.name);
        returns.put(member.name, member.returnType);
        parameters.put(member.name, member.parameters);
        methodOffsets.put(member.name, member.offset);
      } else {
        fields.put(member.name, simpleType(member.returnType));
        fieldOffsets.put(member.name, member.offset);
      }
    }
    returns.put("toString", "String");
    returns.put("hashCode", "int");
    returns.put("equals", "boolean");
    returns.put("clone", "Object");
    for (String method : returns.keySet())
      if (!parameters.containsKey(method)) parameters.put(method, "");
    methods.addAll(returns.keySet());
    METHODS.put(cached.name, methods);
    METHOD_RETURNS.put(cached.name, returns);
    METHOD_PARAMETERS.put(cached.name, parameters);
    CLASS_FIELDS.put(cached.name, fields);
    METHOD_OFFSETS.put(cached.name, methodOffsets);
    FIELD_OFFSETS.put(cached.name, fieldOffsets);
    CLASS_FILES.put(cached.name, cached.fileName);
    CLASS_REFERENCES.put(cached.name, cached.reference);
    CLASS_OFFSETS.put(cached.name, cached.offset);
    if (!cached.parent.isEmpty()) PARENTS.put(cached.name, simpleType(cached.parent));
    CLASS_TRIE.put(cached.name, cached.name);
    rebuildMemberTrie(cached.name);
    classNamesDirty = true;
  }

  public static synchronized boolean knowsClass(String className) {
    return METHODS.containsKey(simpleType(className));
  }

  /** Snapshot of indexed project/library classes for strict `new Type` completion. */
  public static synchronized List<String> classNames() {
    if (classNamesDirty) {
      ArrayList<String> result = new ArrayList<>(METHODS.keySet());
      result.sort(String::compareToIgnoreCase);
      classNamesCache = Collections.unmodifiableList(result);
      classNamesDirty = false;
    }
    return classNamesCache;
  }

  /** Trie-backed class prefix lookup used by `new Type` completion. */
  public static synchronized List<String> classNamesMatching(String prefix, int maxResults) {
    return CLASS_TRIE.prefix(prefix, Math.max(1, Math.min(256, maxResults)));
  }

  /** Resolves a receiver variable using declarations, assignments, and simple casts. */
  public static synchronized String resolveVariableType(String source, String variable) {
    if (source == null || variable == null || variable.isEmpty()) return "";
    return variableTypes(mask(source)).getOrDefault(variable, "");
  }

  /**
   * Resolves a completion receiver such as a variable, a class name, this.field, or a short
   * chained expression. Class names are accepted as static receivers so `MyClass.` can expose the
   * indexed methods instead of returning an empty popup.
   */
  public static synchronized String resolveExpressionType(String source, String expression) {
    if (source == null || expression == null) return "";
    String value = expression.trim();
    if (value.isEmpty()) return "";
    String code = mask(source);
    String[] parts = value.split("\\s*\\.\\s*");
    if (parts.length == 0) return "";
    Map<String, String> variables = variableTypes(code);
    String current;
    if ("this".equals(parts[0])) {
      Matcher owner = CLASS_PATTERN.matcher(code);
      current = owner.find() ? owner.group(1) : "";
    } else {
      current = variables.getOrDefault(parts[0], simpleType(parts[0]));
    }
    if (current == null || current.isEmpty() || !knowsClass(current)) return "";
    for (int i = 1; i < parts.length; i++) {
      String member = parts[i].trim();
      String next = memberType(current, member);
      if (next.isEmpty()) return "";
      current = next;
    }
    return simpleType(current);
  }

  private static String memberType(String type, String member) {
    String current = simpleType(type);
    HashSet<String> visited = new HashSet<>();
    while (!current.isEmpty() && visited.add(current)) {
      LinkedHashMap<String, String> fields = CLASS_FIELDS.get(current);
      if (fields != null && fields.containsKey(member)) return fields.get(member);
      LinkedHashMap<String, String> returns = METHOD_RETURNS.get(current);
      if (returns != null && returns.containsKey(member)) return returns.get(member);
      current = PARENTS.getOrDefault(current, "");
    }
    return "";
  }

  /** Returns only members of the requested type, including inherited members. */
  public static synchronized List<CompletionItem> members(String type, String prefix) {
    LinkedHashMap<String, CompletionItem> output = new LinkedHashMap<>();
    addMembers(output, simpleType(type), prefix == null ? "" : prefix);
    ArrayList<CompletionItem> result = new ArrayList<>(output.values());
    result.sort(
        (a, b) -> {
          int score = Integer.compare(matchScore(a.label, prefix), matchScore(b.label, prefix));
          if (score != 0) return score;
          int kind = Integer.compare(a.kind, b.kind);
          return kind != 0 ? kind : a.label.compareToIgnoreCase(b.label);
        });
    return result;
  }

  public static synchronized boolean hasMethod(String className, String method) {
    String type = simpleType(className);
    HashSet<String> visited = new HashSet<>();
    while (!type.isEmpty() && visited.add(type)) {
      Set<String> values = METHODS.get(type);
      if (values != null && values.contains(method)) return true;
      type = PARENTS.getOrDefault(type, "");
    }
    return false;
  }

  public static List<CompletionItem> complete(
      String fileName, String source, int cursorOffset) {
    String lower = fileName == null ? "" : fileName.toLowerCase(Locale.US);
    if (lower.endsWith(".gradle") || lower.endsWith(".gradle.kts"))
      return languageItems(
          source,
          cursorOffset,
          CompletionItem.BUILD,
          new String[] {"plugins", "id", "android", "namespace", "compileSdk", "defaultConfig", "applicationId", "minSdk", "targetSdk", "versionCode", "versionName", "buildTypes", "debug", "release", "dependencies", "implementation", "api", "compileOnly", "runtimeOnly", "testImplementation", "androidTestImplementation", "repositories", "mavenCentral", "google", "project", "sourceSets", "signingConfigs", "minifyEnabled", "proguardFiles"});
    if (lower.endsWith(".xml")) {
      boolean values = source.contains("<resources") || source.contains("<string ") || source.contains("<style ");
      boolean keyboard = source.contains("<Keyboard") || source.contains("<Row") || source.contains("<Key ");
      String[] words = values
          ? new String[] {"resources", "string", "color", "dimen", "style", "item", "array", "string-array", "integer", "bool", "declare-styleable", "attr", "plurals", "name", "parent", "@string/", "@color/", "@dimen/", "@style/"}
          : keyboard
              ? new String[] {"Keyboard", "Row", "Key", "android:keyLabel", "android:codes", "android:keyWidth", "android:keyHeight", "android:horizontalGap", "android:verticalGap", "android:keyEdgeFlags", "android:isRepeatable", "android:popupCharacters", "android:popupKeyboard"}
              : new String[] {"LinearLayout", "RelativeLayout", "FrameLayout", "ScrollView", "TextView", "EditText", "Button", "ImageView", "ListView", "RecyclerView", "android:id", "android:layout_width", "android:layout_height", "android:layout_margin", "android:padding", "android:orientation", "android:gravity", "android:text", "android:textColor", "android:textSize", "android:background", "android:visibility", "android:onClick", "match_parent", "wrap_content", "@+id/", "@string/", "@drawable/", "@color/"};
      return languageItems(source, cursorOffset, CompletionItem.XML, words);
    }
    return complete(source, cursorOffset);
  }

  private static List<CompletionItem> languageItems(
      String source, int cursor, int kind, String[] words) {
    int start = Math.max(0, Math.min(cursor, source.length()));
    while (start > 0 && (Character.isJavaIdentifierPart(source.charAt(start - 1))
        || source.charAt(start - 1) == '-' || source.charAt(start - 1) == '/')) start--;
    String prefix = source.substring(start, Math.max(start, Math.min(cursor, source.length())));
    boolean afterAndroid = start > 0 && source.substring(Math.max(0, start - 8), start).endsWith("android:");
    boolean afterAt = start > 0 && source.charAt(start - 1) == '@';
    ArrayList<CompletionItem> result = new ArrayList<>();
    for (String word : words) {
      String compared = afterAndroid && word.startsWith("android:") ? word.substring(8)
          : afterAt && word.startsWith("@") ? word.substring(1) : word;
      if (matches(compared, prefix)) result.add(new CompletionItem(kind, word, compared, kind == CompletionItem.BUILD ? "DSL" : "XML"));
    }
    if (result.size() > 50) return new ArrayList<>(result.subList(0, 50));
    return result;
  }

  public static List<CompletionItem> complete(String source, int cursorOffset) {
    int cursor = Math.max(0, Math.min(cursorOffset, source.length()));
    int start = cursor;
    while (start > 0 && Character.isJavaIdentifierPart(source.charAt(start - 1))) start--;
    String prefix = source.substring(start, cursor);
    int before = start - 1;
    while (before >= 0 && Character.isWhitespace(source.charAt(before))) before--;
    LinkedHashMap<String, CompletionItem> result = new LinkedHashMap<>();
    Map<String, String> variables = variableTypes(mask(source));
    if (before >= 0 && source.charAt(before) == '.') {
      int receiverEnd = before;
      int receiverStart = receiverEnd;
      while (receiverStart > 0
          && Character.isJavaIdentifierPart(source.charAt(receiverStart - 1))) receiverStart--;
      String receiver = source.substring(receiverStart, receiverEnd);
      String type = resolveExpressionType(source, receiver);
      addMembers(result, type, prefix);
    } else {
      for (Map.Entry<String, String> variable : variables.entrySet()) {
        if (matches(variable.getKey(), prefix))
          result.put(
              "v:" + variable.getKey(),
              new CompletionItem(
                  CompletionItem.VARIABLE,
                  variable.getKey(),
                  variable.getKey(),
                  variable.getValue()));
      }
      synchronized (ProjectSymbolIndex.class) {
        List<String> classCandidates = CLASS_TRIE.prefix(prefix, 256);
        if (classCandidates.isEmpty() && !prefix.isEmpty())
          classCandidates = new ArrayList<>(METHODS.keySet());
        for (String className : classCandidates) {
          if (matches(className, prefix))
            result.put(
                "c:" + className,
                new CompletionItem(
                    CompletionItem.CLASS, className, className, "class"));
        }
      }
      Matcher owner = CLASS_PATTERN.matcher(mask(source));
      if (owner.find()) addMembers(result, owner.group(1), prefix);
    }
    ArrayList<CompletionItem> values = new ArrayList<>(result.values());
    values.sort(
        (a, b) -> {
          int score = Integer.compare(matchScore(a.label, prefix), matchScore(b.label, prefix));
          if (score != 0) return score;
          int kind = Integer.compare(a.kind, b.kind);
          return kind != 0 ? kind : a.label.compareToIgnoreCase(b.label);
        });
    if (values.size() > 60) return new ArrayList<>(values.subList(0, 60));
    return values;
  }

  private static synchronized void addMembers(
      Map<String, CompletionItem> output, String type, String prefix) {
    String current = simpleType(type);
    String wanted = prefix == null ? "" : prefix;
    HashSet<String> visited = new HashSet<>();
    while (!current.isEmpty() && visited.add(current)) {
      CompletionTrie<String> trie = MEMBER_TRIES.get(current);
      List<String> candidates = trie == null ? new ArrayList<>() : trie.prefix(wanted, 256);
      if (candidates.isEmpty() && !wanted.isEmpty()) {
        // Preserve fuzzy/camel-case matching only as a fallback; normal dot completion is trie-only.
        ArrayList<String> fuzzy = new ArrayList<>();
        LinkedHashMap<String, String> methods = METHOD_RETURNS.get(current);
        if (methods != null) fuzzy.addAll(methods.keySet());
        LinkedHashMap<String, String> fields = CLASS_FIELDS.get(current);
        if (fields != null) fuzzy.addAll(fields.keySet());
        candidates = fuzzy;
      }
      for (String name : candidates) addMember(output, current, name, wanted);
      current = PARENTS.getOrDefault(current, "");
    }
  }

  private static void addMember(
      Map<String, CompletionItem> output, String owner, String name, String prefix) {
    LinkedHashMap<String, String> methods = METHOD_RETURNS.get(owner);
    if (methods != null && methods.containsKey(name) && matches(name, prefix)) {
      LinkedHashMap<String, String> parameters = METHOD_PARAMETERS.get(owner);
      String args = parameters == null ? "" : parameters.getOrDefault(name, "");
      output.put(
          "m:" + name,
          new CompletionItem(
              CompletionItem.METHOD,
              name + "(" + args + ")",
              name + "()",
              methods.get(name)));
    }
    LinkedHashMap<String, String> fields = CLASS_FIELDS.get(owner);
    if (fields != null && fields.containsKey(name) && matches(name, prefix))
      output.put(
          "f:" + name,
          new CompletionItem(
              CompletionItem.VARIABLE, name, name, fields.get(name)));
  }

  /** AndroidIDE-style match levels: exact/prefix, camel-case subsequence, then fuzzy subsequence. */
  public static int matchScore(String value, String query) {
    if (value == null) return Integer.MAX_VALUE;
    String candidate = value.toLowerCase(Locale.US);
    String wanted = query == null ? "" : query.trim().toLowerCase(Locale.US);
    if (wanted.isEmpty()) return 0;
    if (candidate.equals(wanted)) return 0;
    if (candidate.startsWith(wanted)) return 10 + candidate.length() - wanted.length();
    if (candidate.contains(wanted)) return 40 + candidate.indexOf(wanted);
    int wantedAt = 0;
    int boundaryHits = 0;
    boolean previousWord = false;
    for (int i = 0; i < candidate.length() && wantedAt < wanted.length(); i++) {
      char c = candidate.charAt(i);
      boolean boundary = i == 0 || (!previousWord && Character.isLetterOrDigit(c)) || Character.isUpperCase(value.charAt(i));
      if (c == wanted.charAt(wantedAt)) {
        if (boundary) boundaryHits++;
        wantedAt++;
      }
      previousWord = Character.isLetterOrDigit(c) || c == '_' || c == '$';
    }
    if (wantedAt == wanted.length()) return (boundaryHits > 0 ? 20 : 60) + candidate.length() - wanted.length();
    return Integer.MAX_VALUE;
  }

  private static boolean matches(String value, String prefix) {
    return matchScore(value, prefix) != Integer.MAX_VALUE;
  }

  public static List<CodeLanguageTools.Diagnostic> inspectCalls(String source) {
    ArrayList<CodeLanguageTools.Diagnostic> result = new ArrayList<>();
    String code = mask(source);
    Map<String, String> variables = variableTypes(code);
    Matcher calls = CALL_PATTERN.matcher(code);
    while (calls.find()) {
      String receiver = calls.group(1), method = calls.group(2);
      String type = variables.get(receiver);
      if (type == null || !knowsClass(type) || hasMethod(type, method)) continue;
      int start = calls.start(2), end = calls.end(2);
      int[] position = positionAt(source, start);
      result.add(
          new CodeLanguageTools.Diagnostic(
              start,
              end,
              position[0],
              position[1],
              "الدالة غير موجودة: " + simpleType(type) + "." + method));
    }
    return result;
  }

  /** Builds a small in-memory symbol snapshot for the currently open file. */
  public static List<DefinitionTarget> extractSourceSymbols(
      String fileName, String reference, String source) {
    String code = mask(source == null ? "" : source);
    ArrayList<DefinitionTarget> output = new ArrayList<>();
    HashSet<String> seen = new HashSet<>();
    ArrayList<String> owners = new ArrayList<>();
    LinkedHashMap<String, Integer> ownerOffsets = new LinkedHashMap<>();
    Matcher classes = CLASS_PATTERN.matcher(code);
    while (classes.find()) {
      owners.add(classes.group(1));
      ownerOffsets.put(classes.group(1), classes.start(1));
    }
    if (owners.isEmpty() && fileName != null && fileName.endsWith(".java")) {
      String inferred = fileName.substring(0, fileName.length() - 5);
      owners.add(inferred);
      ownerOffsets.put(inferred, 0);
    }
    for (String owner : owners)
      output.add(new DefinitionTarget(fileName, owner, owner, null,
          ownerOffsets.getOrDefault(owner, 0), false, reference));

    Matcher methods = METHOD_PATTERN.matcher(code);
    while (methods.find()) {
      String owner = owners.isEmpty() ? "" : owners.get(0);
      addSourceSymbol(output, seen, fileName, reference, owner, methods.group(2),
          methods.start(2));
    }
    Matcher fields = FIELD_PATTERN.matcher(code);
    while (fields.find()) {
      String owner = owners.isEmpty() ? "" : owners.get(0);
      addSourceSymbol(output, seen, fileName, reference, owner, fields.group(2),
          fields.start(2));
    }
    output.sort((a, b) -> {
      int aOffset = a.offset, bOffset = b.offset;
      if (aOffset != bOffset) return Integer.compare(aOffset, bOffset);
      return (a.className + "." + a.symbol).compareToIgnoreCase(b.className + "." + b.symbol);
    });
    return output;
  }

  private static void addSourceSymbol(
      List<DefinitionTarget> output, Set<String> seen, String file, String reference,
      String owner, String symbol, int offset) {
    String key = owner + "." + symbol + "|" + offset;
    if (seen.add(key))
      output.add(new DefinitionTarget(file, owner, symbol, null, offset, false, reference));
  }

  /** Filters an already parsed symbol snapshot without rescanning source text. */
  public static List<DefinitionTarget> filterSymbols(
      List<DefinitionTarget> symbols, String query, int maxResults) {
    String wanted = query == null ? "" : query.trim();
    if (symbols == null || wanted.isEmpty()) return Collections.emptyList();
    ArrayList<DefinitionTarget> result = new ArrayList<>();
    for (DefinitionTarget target : symbols) {
      if (target == null) continue;
      if (symbolScore(target, wanted) != Integer.MAX_VALUE) result.add(target);
    }
    sortSymbols(result, wanted);
    int limit = Math.max(1, Math.min(500, maxResults));
    return result.size() > limit ? new ArrayList<>(result.subList(0, limit)) : result;
  }

  private static void sortSymbols(List<DefinitionTarget> symbols, String query) {
    symbols.sort((a, b) -> {
      int aScore = symbolScore(a, query), bScore = symbolScore(b, query);
      if (aScore != bScore) return Integer.compare(aScore, bScore);
      if (a.system != b.system) return a.system ? 1 : -1;
      String aName = a.className + "." + a.symbol;
      String bName = b.className + "." + b.symbol;
      return aName.compareToIgnoreCase(bName);
    });
  }

  /**
   * Searches indexed classes, methods, and fields for the Go To Element palette. Results are
   * ranked by exact/prefix/camel-case/subsequence score and keep their source offsets, so opening
   * a result never requires another full-project scan.
   */
  public static synchronized List<DefinitionTarget> searchSymbols(String query, int maxResults) {
    return searchSymbols(query, maxResults, true);
  }

  public static synchronized List<DefinitionTarget> searchSymbols(
      String query, int maxResults, boolean includeSystem) {
    String wanted = query == null ? "" : query.trim();
    if (wanted.isEmpty()) return Collections.emptyList();
    int limit = Math.max(1, Math.min(500, maxResults));
    ArrayList<DefinitionTarget> results = new ArrayList<>();
    HashSet<String> seen = new HashSet<>();
    for (Map.Entry<String, String> entry : CLASS_FILES.entrySet()) {
      addSymbolResult(results, seen, entry.getKey(), entry.getKey(), entry.getValue(),
          CLASS_OFFSETS.getOrDefault(entry.getKey(), 0), false, wanted);
    }
    if (includeSystem) {
      for (String className : METHODS.keySet()) {
        if (CLASS_FILES.containsKey(className)) continue;
        addSymbolResult(results, seen, className, className, null,
            CLASS_OFFSETS.getOrDefault(className, 0), true, wanted);
      }
    }
    for (Map.Entry<String, LinkedHashMap<String, Integer>> entry : METHOD_OFFSETS.entrySet()) {
      String owner = entry.getKey();
      String file = CLASS_FILES.get(owner);
      for (Map.Entry<String, Integer> method : entry.getValue().entrySet())
        addSymbolResult(results, seen, owner, method.getKey(), file, method.getValue(), false, wanted);
    }
    for (Map.Entry<String, LinkedHashMap<String, Integer>> entry : FIELD_OFFSETS.entrySet()) {
      String owner = entry.getKey();
      String file = CLASS_FILES.get(owner);
      for (Map.Entry<String, Integer> field : entry.getValue().entrySet())
        addSymbolResult(results, seen, owner, field.getKey(), file, field.getValue(), false, wanted);
    }
    sortSymbols(results, wanted);
    return results.size() > limit ? new ArrayList<>(results.subList(0, limit)) : results;
  }

  private static void addSymbolResult(
      List<DefinitionTarget> output,
      Set<String> seen,
      String owner,
      String symbol,
      String file,
      int offset,
      boolean system,
      String query) {
    String qualified = owner == null || owner.isEmpty() ? symbol : owner + "." + symbol;
    if (matchScore(symbol, query) == Integer.MAX_VALUE
        && matchScore(qualified, query) == Integer.MAX_VALUE) return;
    String key = qualified + "|" + (file == null ? "system" : file) + "|" + offset;
    if (!seen.add(key)) return;
    if (system) {
      DefinitionTarget target = targetFor(owner, symbol);
      if (target != null) output.add(target);
    } else {
      output.add(new DefinitionTarget(
          file, owner, symbol, null, offset, false, CLASS_REFERENCES.get(owner)));
    }
  }

  private static int symbolScore(DefinitionTarget target, String query) {
    int symbol = matchScore(target.symbol, query);
    int qualified = matchScore(target.className + "." + target.symbol, query);
    return Math.min(symbol, qualified);
  }

  public static final class DefinitionTarget {
    public final String fileName, className, symbol, source, reference;
    public final int offset;
    public final boolean system;

    public DefinitionTarget(
        String file, String owner, String selected, String virtualSource, int at, boolean builtIn) {
      this(file, owner, selected, virtualSource, at, builtIn, null);
    }

    public DefinitionTarget(
        String file,
        String owner,
        String selected,
        String virtualSource,
        int at,
        boolean builtIn,
        String stableReference) {
      fileName = file;
      className = owner;
      symbol = selected;
      source = virtualSource;
      offset = Math.max(0, at);
      system = builtIn;
      reference = stableReference == null ? "" : stableReference;
    }
  }

  public static synchronized DefinitionTarget resolveDefinition(
      String fileName, String source, int selectionStart, int selectionEnd) {
    int start = Math.max(0, Math.min(selectionStart, source.length()));
    int end = Math.max(start, Math.min(selectionEnd, source.length()));
    while (start < end && !Character.isJavaIdentifierStart(source.charAt(start))) start++;
    while (end > start && !Character.isJavaIdentifierPart(source.charAt(end - 1))) end--;
    if (start >= end) return null;
    String symbol = source.substring(start, end);
    String code = mask(source);

    int dot = start - 1;
    while (dot >= 0 && Character.isWhitespace(source.charAt(dot))) dot--;
    if (dot >= 0 && source.charAt(dot) == '.') {
      int receiverEnd = dot, receiverStart = receiverEnd;
      while (receiverStart > 0
          && Character.isJavaIdentifierPart(source.charAt(receiverStart - 1))) receiverStart--;
      String receiver = source.substring(receiverStart, receiverEnd);
      String type = variableTypes(code).get(receiver);
      if (type != null) return targetFor(type, symbol);
    }

    Matcher local = VARIABLE_PATTERN.matcher(code);
    int nearest = -1;
    while (local.find()) {
      if (local.group(2).equals(symbol) && local.start(2) != start && local.start(2) <= start)
        nearest = local.start(2);
    }
    if (nearest < 0) {
      Matcher declaration =
          Pattern.compile(
                  "\\b(?:byte|short|int|long|float|double|boolean|char|var|[A-Za-z_$][A-Za-z0-9_$<>?,.\\[\\]]*)\\s+"
                      + Pattern.quote(symbol)
                      + "\\b")
              .matcher(code);
      while (declaration.find() && declaration.start() <= start)
        nearest = declaration.end() - symbol.length();
    }
    if (nearest >= 0)
      return new DefinitionTarget(fileName, "", symbol, null, nearest, false);

    if (METHODS.containsKey(simpleType(symbol))) return targetFor(symbol, symbol);
    Matcher owner = CLASS_PATTERN.matcher(code);
    if (owner.find()) {
      DefinitionTarget target = targetFor(owner.group(1), symbol);
      if (target != null) return target;
    }
    return null;
  }

  private static DefinitionTarget targetFor(String requestedType, String symbol) {
    String type = simpleType(requestedType);
    String current = type;
    HashSet<String> visited = new HashSet<>();
    while (!current.isEmpty() && visited.add(current)) {
      if (symbol.equals(current) || symbol.equals(type)) {
        String file = CLASS_FILES.get(current);
        if (file != null)
          return new DefinitionTarget(
              file, current, symbol, null, CLASS_OFFSETS.getOrDefault(current, 0), false,
              CLASS_REFERENCES.get(current));
      }
      LinkedHashMap<String, Integer> methods = METHOD_OFFSETS.get(current);
      if (methods != null && methods.containsKey(symbol))
        return new DefinitionTarget(
            CLASS_FILES.get(current), current, symbol, null, methods.get(symbol), false,
            CLASS_REFERENCES.get(current));
      LinkedHashMap<String, Integer> fields = FIELD_OFFSETS.get(current);
      if (fields != null && fields.containsKey(symbol))
        return new DefinitionTarget(
            CLASS_FILES.get(current), current, symbol, null, fields.get(symbol), false,
            CLASS_REFERENCES.get(current));
      current = PARENTS.getOrDefault(current, "");
    }
    if (!METHODS.containsKey(type)) return null;
    String virtual = systemSource(type);
    int offset = virtual.indexOf(" " + symbol + "(");
    if (offset >= 0) offset++;
    else {
      offset = virtual.indexOf(" " + symbol + ";");
      if (offset >= 0) offset++;
      else offset = Math.max(0, virtual.indexOf("class " + type) + 6);
    }
    return new DefinitionTarget(type + " [نظام].java", type, symbol, virtual, offset, true);
  }

  private static String systemSource(String type) {
    StringBuilder out = new StringBuilder("// تعريف نظام للقراءة فقط\npublic class ")
        .append(type).append(" {");
    LinkedHashMap<String, String> fields = CLASS_FIELDS.get(type);
    if (fields != null)
      for (Map.Entry<String, String> field : fields.entrySet())
        out.append("\n    public ").append(field.getValue()).append(' ')
            .append(field.getKey()).append(';');
    LinkedHashMap<String, String> returns = METHOD_RETURNS.get(type);
    LinkedHashMap<String, String> parameters = METHOD_PARAMETERS.get(type);
    if (returns != null)
      for (Map.Entry<String, String> method : returns.entrySet())
        out.append("\n    public ").append(method.getValue()).append(' ')
            .append(method.getKey()).append('(')
            .append(parameters == null ? "" : parameters.getOrDefault(method.getKey(), ""))
            .append(") { } ");
    out.append("\n}\n");
    return out.toString();
  }

  public static MissingMember analyzeSelection(String source, int selectionStart, int selectionEnd) {
    int start = Math.max(0, Math.min(selectionStart, source.length()));
    int end = Math.max(start, Math.min(selectionEnd, source.length()));
    while (start < end && !Character.isJavaIdentifierStart(source.charAt(start))) start++;
    while (end > start && !Character.isJavaIdentifierPart(source.charAt(end - 1))) end--;
    if (start >= end) return null;
    String method = source.substring(start, end);
    int dot = start - 1;
    while (dot >= 0 && Character.isWhitespace(source.charAt(dot))) dot--;
    if (dot < 0 || source.charAt(dot) != '.') return null;
    int receiverEnd = dot;
    int receiverStart = receiverEnd;
    while (receiverStart > 0 && Character.isJavaIdentifierPart(source.charAt(receiverStart - 1)))
      receiverStart--;
    if (receiverStart == receiverEnd) return null;
    String receiver = source.substring(receiverStart, receiverEnd);
    String type = variableTypes(mask(source)).get(receiver);
    if (type == null || !knowsClass(type) || hasMethod(type, method)) return null;
    int open = end;
    while (open < source.length() && Character.isWhitespace(source.charAt(open))) open++;
    if (open >= source.length() || source.charAt(open) != '(') return null;
    int close = matchingParenthesis(source, open);
    if (close < 0) return null;
    List<Parameter> parameters = inferParameters(source.substring(open + 1, close), source);
    String returnType = inferReturnType(source, receiverStart);
    return new MissingMember(simpleType(type), method, returnType, parameters);
  }

  private static Map<String, String> variableTypes(String code) {
    HashMap<String, String> values = new HashMap<>();
    Matcher variables = VARIABLE_PATTERN.matcher(code);
    while (variables.find()) values.put(variables.group(2), simpleType(variables.group(1)));
    Matcher creations = CREATION_PATTERN.matcher(code);
    while (creations.find()) values.put(creations.group(1), simpleType(creations.group(2)));
    Matcher casts = CAST_PATTERN.matcher(code);
    while (casts.find()) values.put(casts.group(1), simpleType(casts.group(2)));
    return values;
  }

  private static List<Parameter> inferParameters(String arguments, String source) {
    ArrayList<Parameter> result = new ArrayList<>();
    List<String> parts = splitArguments(arguments);
    Map<String, String> variables = variableTypes(mask(source));
    for (int i = 0; i < parts.size(); i++) {
      String value = parts.get(i).trim();
      if (value.isEmpty()) continue;
      String type;
      if (value.startsWith("\"") && value.endsWith("\"")) type = "String";
      else if (value.startsWith("'") && value.endsWith("'")) type = "char";
      else if (value.equals("true") || value.equals("false")) type = "boolean";
      else if (value.matches("[-+]?\\d+[lL]")) type = "long";
      else if (value.matches("[-+]?(?:\\d+\\.\\d*|\\d*\\.\\d+)[fF]")) type = "float";
      else if (value.matches("[-+]?(?:\\d+\\.\\d*|\\d*\\.\\d+)(?:[dD])?")) type = "double";
      else if (value.matches("[-+]?\\d+")) type = "int";
      else if (value.equals("null")) type = "Object";
      else type = variables.getOrDefault(value, "Object");
      String name = value.matches("[A-Za-z_$][A-Za-z0-9_$]*") ? value : "arg" + (i + 1);
      result.add(new Parameter(type, name));
    }
    return result;
  }

  private static String inferReturnType(String source, int callStart) {
    int statementStart = Math.max(source.lastIndexOf(';', callStart - 1), source.lastIndexOf('{', callStart - 1)) + 1;
    String prefix = source.substring(statementStart, callStart);
    Matcher declaration =
        Pattern.compile("\\b([A-Z][A-Za-z0-9_$<>?., \\t\\[\\]]*|boolean|byte|short|int|long|float|double|char)\\s+[A-Za-z_$][A-Za-z0-9_$]*\\s*=\\s*$")
            .matcher(prefix);
    return declaration.find() ? declaration.group(1).trim() : "void";
  }

  private static List<String> splitArguments(String text) {
    ArrayList<String> parts = new ArrayList<>();
    int start = 0, round = 0, square = 0, curly = 0;
    char quote = 0;
    boolean escape = false;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (quote != 0) {
        if (escape) escape = false;
        else if (c == '\\') escape = true;
        else if (c == quote) quote = 0;
      } else if (c == '"' || c == '\'') quote = c;
      else if (c == '(') round++;
      else if (c == ')') round--;
      else if (c == '[') square++;
      else if (c == ']') square--;
      else if (c == '{') curly++;
      else if (c == '}') curly--;
      else if (c == ',' && round == 0 && square == 0 && curly == 0) {
        parts.add(text.substring(start, i));
        start = i + 1;
      }
    }
    if (start < text.length()) parts.add(text.substring(start));
    return parts;
  }

  private static int matchingParenthesis(String text, int open) {
    int depth = 0;
    char quote = 0;
    boolean escape = false;
    for (int i = open; i < text.length(); i++) {
      char c = text.charAt(i);
      if (quote != 0) {
        if (escape) escape = false;
        else if (c == '\\') escape = true;
        else if (c == quote) quote = 0;
      } else if (c == '"' || c == '\'') quote = c;
      else if (c == '(') depth++;
      else if (c == ')' && --depth == 0) return i;
    }
    return -1;
  }

  private static int[] positionAt(String source, int offset) {
    int line = 1, column = 1;
    for (int i = 0; i < offset; i++) {
      if (source.charAt(i) == '\n') {
        line++;
        column = 1;
      } else column++;
    }
    return new int[] {line, column};
  }

  private static String simpleType(String type) {
    String value = type == null ? "" : type.trim();
    int generic = value.indexOf('<');
    if (generic >= 0) value = value.substring(0, generic);
    while (value.endsWith("[]")) value = value.substring(0, value.length() - 2);
    int dot = value.lastIndexOf('.');
    return dot >= 0 ? value.substring(dot + 1) : value;
  }

  private static String mask(String source) {
    StringBuilder out = new StringBuilder(source);
    boolean line = false, block = false, escape = false;
    char quote = 0;
    for (int i = 0; i < source.length(); i++) {
      char c = source.charAt(i), next = i + 1 < source.length() ? source.charAt(i + 1) : 0;
      if (c == '\n') {
        line = false;
        escape = false;
        continue;
      }
      if (line) out.setCharAt(i, ' ');
      else if (block) {
        out.setCharAt(i, ' ');
        if (c == '*' && next == '/') {
          out.setCharAt(++i, ' ');
          block = false;
        }
      } else if (quote != 0) {
        out.setCharAt(i, ' ');
        if (escape) escape = false;
        else if (c == '\\') escape = true;
        else if (c == quote) quote = 0;
      } else if (c == '/' && next == '/') {
        out.setCharAt(i, ' ');
        out.setCharAt(++i, ' ');
        line = true;
      } else if (c == '/' && next == '*') {
        out.setCharAt(i, ' ');
        out.setCharAt(++i, ' ');
        block = true;
      } else if (c == '"' || c == '\'' || c == '`') {
        out.setCharAt(i, ' ');
        quote = c;
      }
    }
    return out.toString();
  }

  public static final class CompletionItem {
    public static final int METHOD = 0, VARIABLE = 1, CLASS = 2, XML = 3, BUILD = 4;
    public final int kind;
    public final String label, insertText, detail;

    public CompletionItem(int kind, String label, String insertText, String detail) {
      this.kind = kind;
      this.label = label;
      this.insertText = insertText;
      this.detail = detail;
    }
  }

  public static final class Parameter {
    public final String type, name;

    Parameter(String type, String name) {
      this.type = type;
      this.name = name;
    }
  }

  public static final class MissingMember {
    public final String className, methodName, returnType;
    public final List<Parameter> parameters;

    MissingMember(String className, String methodName, String returnType, List<Parameter> parameters) {
      this.className = className;
      this.methodName = methodName;
      this.returnType = returnType;
      this.parameters = Collections.unmodifiableList(new ArrayList<>(parameters));
    }

    public String methodSource() {
      StringBuilder out = new StringBuilder();
      out.append("\n    public ").append(returnType).append(' ').append(methodName).append('(');
      for (int i = 0; i < parameters.size(); i++) {
        if (i > 0) out.append(", ");
        Parameter p = parameters.get(i);
        out.append(p.type).append(' ').append(p.name);
      }
      out.append(") {\n        // TODO: تنفيذ الدالة\n");
      if (!"void".equals(returnType)) out.append("        return ").append(defaultValue(returnType)).append(";\n");
      out.append("    }\n");
      return out.toString();
    }

    private String defaultValue(String type) {
      if ("boolean".equals(type)) return "false";
      if ("byte".equals(type) || "short".equals(type) || "int".equals(type) || "long".equals(type)
          || "float".equals(type) || "double".equals(type)) return "0";
      if ("char".equals(type)) return "'\\0'";
      return "null";
    }
  }
}
