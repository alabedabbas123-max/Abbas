package almlk;

import android.graphics.Paint;
import android.graphics.Typeface;
import java.util.HashMap;

/**
 * بند almlk ← دور حقول OConsole «f503VH / f534gn»: دهانات تُبنَى مرة واحدة لكل نمط
 * وتُستعمل في كل إطار — لا إنشاء Paint داخل onDraw إطلاقًا (واحد من أعمق أسباب سلاسة AIDE).
 */
public final class StylePaintCache {

  private final Typeface typeface;
  private final float textSize;
  private final HashMap<Integer, Paint> byColorAndStyle = new HashMap<>();
  private final Paint gutter;
  private final Paint caret;
  private final Paint currentLine;
  private final Paint selection;
  private final Paint bracketLine;
  private final Paint foldDot;

  private static final int STYLE_PLAIN = 0;
  private static final int STYLE_BOLD = 1;
  private static final int STYLE_UNDERLINE = 2;

  public StylePaintCache(Typeface typeface, float textSizePx) {
    this.typeface = typeface;
    this.textSize = textSizePx;
    gutter = decorate(new Paint(Paint.ANTI_ALIAS_FLAG), 0);
    caret = decorate(new Paint(), 0);
    currentLine = decorate(new Paint(), 0);
    selection = decorate(new Paint(), 0);
    bracketLine = decorate(new Paint(), 0);
    foldDot = decorate(new Paint(), 0);
  }

  private Paint decorate(Paint paint, int flags) {
    paint.setTypeface(typeface);
    paint.setTextSize(textSize);
    paint.setStyle(Paint.Style.FILL);
    return paint;
  }

  /** دهان نص بصيغة لون (+ غامق) — يُعاد استخدامه دائمًا لنفس النمط. */
  public Paint text(int argb, boolean bold) {
    int key = argb ^ (bold ? STYLE_BOLD : STYLE_PLAIN);
    Paint paint = byColorAndStyle.get(key);
    if (paint == null) {
      paint = decorate(new Paint(Paint.ANTI_ALIAS_FLAG), 0);
      if (bold)
        paint.setTypeface(Typeface.create(typeface, Typeface.BOLD));
      byColorAndStyle.put(key, paint);
    }
    paint.setColor(argb);
    return paint;
  }

  /** دهان خلفية ملوّنة (أشرطة أعلام السطور / التحديد): نمط واحد لكل لون. */
  public Paint fill(int argb) {
    int key = argb ^ STYLE_UNDERLINE;
    Paint paint = byColorAndStyle.get(key);
    if (paint == null) {
      paint = decorate(new Paint(), 0);
      byColorAndStyle.put(key, paint);
    }
    paint.setColor(argb);
    return paint;
  }

  public Paint gutter(int argb) {
    gutter.setColor(argb);
    return gutter;
  }

  public Paint caret(int argb) {
    caret.setColor(argb);
    return caret;
  }

  public Paint currentLine(int argb) {
    currentLine.setColor(argb);
    return currentLine;
  }

  public Paint selection(int argb) {
    selection.setColor(argb);
    return selection;
  }

  public Paint bracketLine(int argb) {
    bracketLine.setColor(argb);
    return bracketLine;
  }

  public Paint foldDot(int argb) {
    foldDot.setColor(argb);
    return foldDot;
  }

  /** ينظّف الذاكرة المخزنة عند ضغط النظام — تُعاد البنية عند الطلب. */
  public void clear() {
    byColorAndStyle.clear();
  }
}
