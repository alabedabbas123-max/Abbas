package com.mhd.absher;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;

public class TrafficFinesActivity extends AppCompatActivity {
    private View indicatorPaid;
    private View indicatorUnpaid;
    private TextView tabPaid;
    private TextView tabUnpaid;
    private TextView tvMain;
    private TextView tvSub;

    public void setTab(boolean z) {
        if (this.indicatorUnpaid != null) {
            this.indicatorUnpaid.setVisibility(z ? 0 : 4);
        }
        if (this.indicatorPaid != null) {
            this.indicatorPaid.setVisibility(z ? 4 : 0);
        }
        if (this.tabUnpaid != null) {
            this.tabUnpaid.setTextColor(z ? Color.parseColor(a.a("dmQDG3phEQ==")) : Color.parseColor(a.a("dmwHFXltFQ==")));
        }
        if (this.tabPaid != null) {
            this.tabPaid.setTextColor(z ? Color.parseColor(a.a("dmwHFXltFQ==")) : Color.parseColor(a.a("dmQDG3phEQ==")));
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.traffic_fines);
        View viewFindViewById = findViewById(R.id.btnBackTraffic);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TrafficFinesActivity.this.finish();
                }
            });
        }
        this.tabUnpaid = (TextView) findViewById(R.id.tvTabUnpaid);
        this.tabPaid = (TextView) findViewById(R.id.tvTabPaid);
        this.indicatorUnpaid = findViewById(R.id.indicatorUnpaid);
        this.indicatorPaid = findViewById(R.id.indicatorPaid);
        this.tvMain = (TextView) findViewById(R.id.tvEmptyMain);
        this.tvSub = (TextView) findViewById(R.id.tvEmptySub);
        if (this.tabUnpaid != null) {
            this.tabUnpaid.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TrafficFinesActivity.this.setTab(true);
                }
            });
        }
        if (this.tabPaid != null) {
            this.tabPaid.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TrafficFinesActivity.this.setTab(false);
                }
            });
        }
        setTab(true);
    }
}
