package almlk;

/** Immutable, line-relative diagnostic range consumed by the editor's drawing pass. */
public final class DiagnosticUnderline {
  public final int startColumn;
  public final int endColumn;
  public final boolean warning;

  public DiagnosticUnderline(int startColumn, int endColumn, boolean warning) {
    this.startColumn = Math.max(0, startColumn);
    this.endColumn = Math.max(this.startColumn + 1, endColumn);
    this.warning = warning;
  }
}
