# تقرير حفظ الجلسات والاستعادة وفتح الملفات

## الهدف
إعادة المستخدم إلى نفس المشروع والتبويبات والمواضع بسرعة دون حفظ نصوص ضخمة في ملف الجلسة أو انتظار الفهرسة الكاملة.

## نموذج الجلسة
```json
{
  "schema": 1,
  "projectId": "id",
  "activeTab": 0,
  "tabs": [{
    "path": "src/Main.java",
    "line": 120,
    "column": 8,
    "scrollY": 2200,
    "scrollX": 0,
    "selectionStart": 0,
    "selectionEnd": 0,
    "folds": []
  }],
  "drawerWidth": 300,
  "bottomPanel": "Problems"
}
```

يحفظ النص في الملف/recovery وليس داخل JSON الجلسة.

## الاستعادة
```text
قراءة session صغيرة
→ إظهار المشروع
→ إنشاء tab handles
→ فتح tab النشط وviewport الأول
→ التحقق من hash
→ استعادة بقية التبويبات عند الطلب
```

## الحفظ
- حفظ عند الخمول بعد 500–1000ms.
- حفظ عند `onStop`.
- snapshot لكل dirty document.
- temp ثم flush ثم atomic rename.
- الاحتفاظ بعدد محدود من recovery versions.

## فحص الاستعادة
يقارن التطبيق hash وtimestamp للمصدر مع recovery:

```text
recovery أحدث → Restore/Compare/Discard
source أحدث → Reload
متساويان → فتح طبيعي
```

## فتح الملفات والمجلدات
- SAF لاختيار مجلد أو ملف.
- حفظ URI permission.
- فحص metadata أولًا.
- lazy loading لأبناء المجلد.
- عدم قراءة كل الملفات عند فتح الشجرة.
- استثناء build/cache/generated افتراضيًا.
- فتح الملف في tab موجود بدل إنشاء نسخة.

## التنقل بين الملفات
تستخدم NavigationHistory:

```text
fileId, line, column, scrollX, scrollY, selection, symbolId
```

وتدعم Back/Forward وRecent Locations وQuick Open. عند فتح ملف من نتيجة بحث تسجل نقطة الرجوع قبل النقل.

## Room
يحفظ metadata فقط:

```text
projects, files, hashes, symbols, references, session metadata
```

ولا يحفظ محتوى كل ملف داخل قاعدة البيانات.

## إدارة الذاكرة
- LRU للوثائق غير النشطة.
- حفظ dirty قبل الإخلاء.
- إزالة token/layout cache عند `onTrimMemory`.
- Large File mode.
- عدم فتح binary كمحرر نص.

## أدوات التنفيذ
ViewModel، SavedStateHandle للحالة الخفيفة، Room، WorkManager، ExecutorService، AtomicFile/temporary files، WindowInsetsCompat، Activity Result API.

## معايير الأداء
- استعادة metadata بسرعة قبل التحليل.
- إظهار أول viewport قبل الفهرسة.
- إلغاء فتح/فهرسة ملف عند انتقال المستخدم لملف آخر.
- عدم تجميد Main Thread.
