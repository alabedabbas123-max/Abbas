package com.mhd.absher;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class VehiclesActivity extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.vehicles);
        ImageView imageView = (ImageView) findViewById(R.id.btnBack);
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    VehiclesActivity.this.finish();
                }
            });
        }
    }
}
