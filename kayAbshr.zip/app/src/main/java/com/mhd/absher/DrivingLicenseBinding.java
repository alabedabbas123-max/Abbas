package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class DrivingLicenseBinding {
    public final LinearLayout bottomNavDrivingLicense;
    public final ImageView btnBackDrivingLicense;
    public final ImageView imageview10;
    public final ImageView imageview11;
    public final ImageView imageview12;
    public final ImageView imageview13;
    public final ImageView imageview14;
    public final ImageView imageview9;
    public final LinearLayout linear20;
    public final LinearLayout linear21;
    public final LinearLayout linear23;
    public final LinearLayout linear25;
    public final LinearLayout linear26;
    public final LinearLayout linear27;
    public final LinearLayout linear28;
    public final LinearLayout linear29;
    public final LinearLayout linear30;
    public final LinearLayout linear31;
    public final LinearLayout linear32;
    public final LinearLayout linear34;
    public final LinearLayout linear35;
    public final LinearLayout linear36;
    public final LinearLayout linear37;
    public final LinearLayout linear38;
    public final RelativeLayout relativelayout2;
    public final RelativeLayout rootView;
    public final Space space22;
    public final Space space33;
    public final TextView textview18;
    public final TextView textview19;
    public final TextView textview20;
    public final TextView textview21;
    public final TextView textview22;
    public final TextView textview23;
    public final TextView textview24;
    public final TextView textview25;
    public final TextView textview26;
    public final TextView textview27;
    public final TextView textview28;
    public final TextView textview29;
    public final TextView textview30;
    public final TextView textview31;
    public final TextView textview32;
    public final TextView textview33;
    public final TextView textview34;
    public final RelativeLayout topHeaderLicense;
    public final TextView tvLicenseDob;
    public final TextView tvLicenseExpiryDate;
    public final TextView tvLicenseId;
    public final TextView tvLicenseIssueDate;
    public final TextView tvLicenseName;
    public final TextView tvLicenseNationality;
    public final TextView tvLicenseStatus;
    public final TextView tvLicenseType;
    public final View view10;
    public final ScrollView vscroll2;

    private DrivingLicenseBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, ScrollView scrollView, LinearLayout linearLayout, LinearLayout linearLayout2, TextView textView2, TextView textView3, Space space, LinearLayout linearLayout3, RelativeLayout relativeLayout3, ImageView imageView2, TextView textView4, View view, LinearLayout linearLayout4, TextView textView5, TextView textView6, LinearLayout linearLayout5, TextView textView7, TextView textView8, LinearLayout linearLayout6, TextView textView9, TextView textView10, LinearLayout linearLayout7, TextView textView11, TextView textView12, LinearLayout linearLayout8, TextView textView13, TextView textView14, LinearLayout linearLayout9, TextView textView15, TextView textView16, LinearLayout linearLayout10, TextView textView17, TextView textView18, LinearLayout linearLayout11, TextView textView19, TextView textView20, Space space2, LinearLayout linearLayout12, LinearLayout linearLayout13, ImageView imageView3, TextView textView21, LinearLayout linearLayout14, ImageView imageView4, TextView textView22, LinearLayout linearLayout15, ImageView imageView5, TextView textView23, LinearLayout linearLayout16, ImageView imageView6, TextView textView24, LinearLayout linearLayout17, ImageView imageView7, TextView textView25) {
        this.rootView = relativeLayout;
        this.topHeaderLicense = relativeLayout2;
        this.btnBackDrivingLicense = imageView;
        this.textview18 = textView;
        this.vscroll2 = scrollView;
        this.linear20 = linearLayout;
        this.linear21 = linearLayout2;
        this.textview19 = textView2;
        this.textview20 = textView3;
        this.space22 = space;
        this.linear23 = linearLayout3;
        this.relativelayout2 = relativeLayout3;
        this.imageview9 = imageView2;
        this.textview21 = textView4;
        this.view10 = view;
        this.linear25 = linearLayout4;
        this.textview22 = textView5;
        this.tvLicenseType = textView6;
        this.linear26 = linearLayout5;
        this.textview23 = textView7;
        this.tvLicenseIssueDate = textView8;
        this.linear27 = linearLayout6;
        this.textview24 = textView9;
        this.tvLicenseExpiryDate = textView10;
        this.linear28 = linearLayout7;
        this.textview25 = textView11;
        this.tvLicenseStatus = textView12;
        this.linear29 = linearLayout8;
        this.textview26 = textView13;
        this.tvLicenseName = textView14;
        this.linear30 = linearLayout9;
        this.textview27 = textView15;
        this.tvLicenseNationality = textView16;
        this.linear31 = linearLayout10;
        this.textview28 = textView17;
        this.tvLicenseId = textView18;
        this.linear32 = linearLayout11;
        this.textview29 = textView19;
        this.tvLicenseDob = textView20;
        this.space33 = space2;
        this.bottomNavDrivingLicense = linearLayout12;
        this.linear34 = linearLayout13;
        this.imageview10 = imageView3;
        this.textview30 = textView21;
        this.linear35 = linearLayout14;
        this.imageview11 = imageView4;
        this.textview31 = textView22;
        this.linear36 = linearLayout15;
        this.imageview12 = imageView5;
        this.textview32 = textView23;
        this.linear37 = linearLayout16;
        this.imageview13 = imageView6;
        this.textview33 = textView24;
        this.linear38 = linearLayout17;
        this.imageview14 = imageView7;
        this.textview34 = textView25;
    }

    public static DrivingLicenseBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topHeaderLicense);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBackDrivingLicense);
        TextView textView = (TextView) findChildViewById(view, R.id.textview18);
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.vscroll2);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear20);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear21);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview19);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview20);
        Space space = (Space) findChildViewById(view, R.id.space22);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear23);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.relativelayout2);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview9);
        TextView textView4 = (TextView) findChildViewById(view, R.id.textview21);
        View viewFindChildViewById = findChildViewById(view, R.id.view10);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.linear25);
        TextView textView5 = (TextView) findChildViewById(view, R.id.textview22);
        TextView textView6 = (TextView) findChildViewById(view, R.id.tvLicenseType);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.linear26);
        TextView textView7 = (TextView) findChildViewById(view, R.id.textview23);
        TextView textView8 = (TextView) findChildViewById(view, R.id.tvLicenseIssueDate);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.linear27);
        TextView textView9 = (TextView) findChildViewById(view, R.id.textview24);
        TextView textView10 = (TextView) findChildViewById(view, R.id.tvLicenseExpiryDate);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.linear28);
        TextView textView11 = (TextView) findChildViewById(view, R.id.textview25);
        TextView textView12 = (TextView) findChildViewById(view, R.id.tvLicenseStatus);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.linear29);
        TextView textView13 = (TextView) findChildViewById(view, R.id.textview26);
        TextView textView14 = (TextView) findChildViewById(view, R.id.tvLicenseName);
        LinearLayout linearLayout9 = (LinearLayout) findChildViewById(view, R.id.linear30);
        TextView textView15 = (TextView) findChildViewById(view, R.id.textview27);
        TextView textView16 = (TextView) findChildViewById(view, R.id.tvLicenseNationality);
        LinearLayout linearLayout10 = (LinearLayout) findChildViewById(view, R.id.linear31);
        TextView textView17 = (TextView) findChildViewById(view, R.id.textview28);
        TextView textView18 = (TextView) findChildViewById(view, R.id.tvLicenseId);
        LinearLayout linearLayout11 = (LinearLayout) findChildViewById(view, R.id.linear32);
        TextView textView19 = (TextView) findChildViewById(view, R.id.textview29);
        TextView textView20 = (TextView) findChildViewById(view, R.id.tvLicenseDob);
        Space space2 = (Space) findChildViewById(view, R.id.space33);
        LinearLayout linearLayout12 = (LinearLayout) findChildViewById(view, R.id.bottomNavDrivingLicense);
        LinearLayout linearLayout13 = (LinearLayout) findChildViewById(view, R.id.linear34);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.imageview10);
        TextView textView21 = (TextView) findChildViewById(view, R.id.textview30);
        LinearLayout linearLayout14 = (LinearLayout) findChildViewById(view, R.id.linear35);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.imageview11);
        TextView textView22 = (TextView) findChildViewById(view, R.id.textview31);
        LinearLayout linearLayout15 = (LinearLayout) findChildViewById(view, R.id.linear36);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.imageview12);
        TextView textView23 = (TextView) findChildViewById(view, R.id.textview32);
        LinearLayout linearLayout16 = (LinearLayout) findChildViewById(view, R.id.linear37);
        ImageView imageView6 = (ImageView) findChildViewById(view, R.id.imageview13);
        TextView textView24 = (TextView) findChildViewById(view, R.id.textview33);
        LinearLayout linearLayout17 = (LinearLayout) findChildViewById(view, R.id.linear38);
        ImageView imageView7 = (ImageView) findChildViewById(view, R.id.imageview14);
        TextView textView25 = (TextView) findChildViewById(view, R.id.textview34);
        if (relativeLayout2 == null || imageView == null || textView == null || scrollView == null || linearLayout == null || linearLayout2 == null || textView2 == null || textView3 == null || space == null || linearLayout3 == null || relativeLayout3 == null || imageView2 == null || textView4 == null || viewFindChildViewById == null || linearLayout4 == null || textView5 == null || textView6 == null || linearLayout5 == null || textView7 == null || textView8 == null || linearLayout6 == null || textView9 == null || textView10 == null || linearLayout7 == null || textView11 == null || textView12 == null || linearLayout8 == null || textView13 == null || textView14 == null || linearLayout9 == null || textView15 == null || textView16 == null || linearLayout10 == null || textView17 == null || textView18 == null || linearLayout11 == null || textView19 == null || textView20 == null || space2 == null || linearLayout12 == null || linearLayout13 == null || imageView3 == null || textView21 == null || linearLayout14 == null || imageView4 == null || textView22 == null || linearLayout15 == null || imageView5 == null || textView23 == null || linearLayout16 == null || imageView6 == null || textView24 == null || linearLayout17 == null || imageView7 == null || textView25 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new DrivingLicenseBinding(relativeLayout, relativeLayout2, imageView, textView, scrollView, linearLayout, linearLayout2, textView2, textView3, space, linearLayout3, relativeLayout3, imageView2, textView4, viewFindChildViewById, linearLayout4, textView5, textView6, linearLayout5, textView7, textView8, linearLayout6, textView9, textView10, linearLayout7, textView11, textView12, linearLayout8, textView13, textView14, linearLayout9, textView15, textView16, linearLayout10, textView17, textView18, linearLayout11, textView19, textView20, space2, linearLayout12, linearLayout13, imageView3, textView21, linearLayout14, imageView4, textView22, linearLayout15, imageView5, textView23, linearLayout16, imageView6, textView24, linearLayout17, imageView7, textView25);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static DrivingLicenseBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static DrivingLicenseBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.driving_license, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
