package com.google.zxing.aztec;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.Writer;
import com.google.zxing.aztec.encoder.AztecCode;
import com.google.zxing.aztec.encoder.Encoder;
import com.google.zxing.common.BitMatrix;
import java.nio.charset.Charset;
import java.util.Map;

public final class AztecWriter implements Writer {
    private static final Charset DEFAULT_CHARSET = Charset.forName("ISO-8859-1");

    private static BitMatrix encode(String str, BarcodeFormat barcodeFormat, int i, int i2, Charset charset, int i3, int i4) {
        if (barcodeFormat != BarcodeFormat.AZTEC) {
            throw new IllegalArgumentException("Can only encode AZTEC, but got " + barcodeFormat);
        }
        return renderResult(Encoder.encode(str.getBytes(charset), i3, i4), i, i2);
    }

    private static BitMatrix renderResult(AztecCode aztecCode, int i, int i2) {
        BitMatrix matrix = aztecCode.getMatrix();
        if (matrix == null) {
            throw new IllegalStateException();
        }
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        int iMax = Math.max(i, width);
        int iMax2 = Math.max(i2, height);
        int iMin = Math.min(iMax / width, iMax2 / height);
        int i3 = (iMax - (width * iMin)) / 2;
        BitMatrix bitMatrix = new BitMatrix(iMax, iMax2);
        int i4 = (iMax2 - (height * iMin)) / 2;
        for (int i5 = 0; i5 < height; i5++) {
            int i6 = i3;
            int i7 = 0;
            while (i7 < width) {
                if (matrix.get(i7, i5)) {
                    bitMatrix.setRegion(i6, i4, iMin, iMin);
                }
                i7++;
                i6 += iMin;
            }
            i4 += iMin;
        }
        return bitMatrix;
    }

    @Override
    public BitMatrix encode(String str, BarcodeFormat barcodeFormat, int i, int i2) {
        return encode(str, barcodeFormat, i, i2, null);
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0054 A[PHI: r0 r1
      0x0054: PHI (r0v1 java.nio.charset.Charset) = (r0v0 java.nio.charset.Charset), (r0v4 java.nio.charset.Charset) binds: [B:3:0x0005, B:11:0x0039] A[DONT_GENERATE, DONT_INLINE]
      0x0054: PHI (r1v1 int) = (r1v0 int), (r1v3 int) binds: [B:3:0x0005, B:11:0x0039] A[DONT_GENERATE, DONT_INLINE]] */
    @Override
    public BitMatrix encode(String str, BarcodeFormat barcodeFormat, int i, int i2, Map map) {
        int i3;
        Charset charset;
        Charset charsetForName = DEFAULT_CHARSET;
        int i4 = 33;
        int i5 = 0;
        if (map == null) {
            i3 = i4;
            charset = charsetForName;
        } else {
            if (map.containsKey(EncodeHintType.CHARACTER_SET)) {
                charsetForName = Charset.forName(map.get(EncodeHintType.CHARACTER_SET).toString());
            }
            i4 = map.containsKey(EncodeHintType.ERROR_CORRECTION) ? Integer.parseInt(map.get(EncodeHintType.ERROR_CORRECTION).toString()) : 33;
            if (map.containsKey(EncodeHintType.AZTEC_LAYERS)) {
                i5 = Integer.parseInt(map.get(EncodeHintType.AZTEC_LAYERS).toString());
                i3 = i4;
                charset = charsetForName;
            } else {
                i3 = i4;
                charset = charsetForName;
            }
        }
        return encode(str, barcodeFormat, i, i2, charset, i3, i5);
    }
}
