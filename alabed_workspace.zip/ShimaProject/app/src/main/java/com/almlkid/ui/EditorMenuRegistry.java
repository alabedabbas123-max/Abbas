package com.almlkid.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * سجل أوامر سياق المحرر. شريط التحديد والجذر والفروع والقائمة المصغرة تستعلم التعريفات نفسها؛
 * الواجهة لا تنشئ صفوفًا موازية ولا تعيد شروط اللغة/الأهلية.
 */
public final class EditorMenuRegistry {
  public static final String PAGE_TOOLBAR = "toolbar";
  public static final String PAGE_ROOT = "root";
  public static final String PAGE_FIX = "fix";
  public static final String PAGE_TOOLS = "tools";
  public static final String PAGE_REFACTOR = "refactor";
  public static final String PAGE_CODE = "code";
  public static final String PAGE_FORMAT = "format";
  public static final String PAGE_FIND = "find";
  public static final String PAGE_SMALL = "small";

  /** مساهمة حية (Fix أو أداة تحديد)؛ لا تظهر إن لم يوردها المزود في لقطة السياق. */
  public static final class DynamicCommand {
    public final String id;
    public final String title;
    public final boolean enabled;
    public final String disabledReason;
    public final Runnable action;

    public DynamicCommand(
        String id, String title, boolean enabled, String disabledReason, Runnable action) {
      this.id = id;
      this.title = title;
      this.enabled = enabled;
      this.disabledReason = disabledReason == null ? "" : disabledReason;
      this.action = action;
    }
  }

  /** لقطة ذرية تُبنى قبل العرض/التحضير؛ لا تحتفظ بها الواجهة بين حدثين. */
  public static final class Context {
    public boolean xml;
    public boolean layoutXml;
    public boolean writable = true;
    public boolean hasOpenFile;
    public boolean hasSelection;
    public boolean hasColor;
    public boolean hasClipboardText;
    public boolean canExpand;
    public List<DynamicCommand> fixes = Collections.emptyList();
    public List<DynamicCommand> tools = Collections.emptyList();
  }

  /** أمر محلول للعرض الآن، شامل سبب التعطيل والمسار الفرعي أو الفعل الديناميكي. */
  public static final class Entry {
    public final String id;
    public final String title;
    public final boolean enabled;
    public final String disabledReason;
    public final String subpage;
    public final Runnable dynamicAction;

    Entry(
        String id,
        String title,
        boolean enabled,
        String disabledReason,
        String subpage,
        Runnable dynamicAction) {
      this.id = id;
      this.title = title;
      this.enabled = enabled;
      this.disabledReason = disabledReason == null ? "" : disabledReason;
      this.subpage = subpage;
      this.dynamicAction = dynamicAction;
    }

    public boolean isSubmenu() {
      return subpage != null;
    }
  }

  private interface Rule {
    boolean test(Context context);
  }

  private interface Reason {
    String text(Context context);
  }

  private static final class Spec {
    final String id, title, subpage;
    final Rule visible, enabled;
    final Reason reason;

    Spec(
        String id,
        String title,
        String subpage,
        Rule visible,
        Rule enabled,
        Reason reason) {
      this.id = id;
      this.title = title;
      this.subpage = subpage;
      this.visible = visible;
      this.enabled = enabled;
      this.reason = reason;
    }
  }

  private static final Rule ALWAYS = context -> true;
  private final LinkedHashMap<String, ArrayList<Spec>> pages = new LinkedHashMap<>();

  public EditorMenuRegistry() {
    // شريط ActionMode: التعريف نفسه يضبط الأهلية الحية في onPrepareActionMode.
    add(PAGE_TOOLBAR, "expand", "توسيع التحديد", null, ALWAYS, c -> c.canExpand,
        c -> "لا يوجد نطاق أكبر");
    add(PAGE_TOOLBAR, "cut", "قص", null, ALWAYS,
        c -> c.hasSelection && c.writable,
        c -> !c.hasSelection ? "لا يوجد تحديد" : "الملف للقراءة فقط");
    add(PAGE_TOOLBAR, "copy", "نسخ", null, ALWAYS, c -> c.hasSelection,
        c -> "لا يوجد تحديد");
    add(PAGE_TOOLBAR, "paste", "لصق", null, ALWAYS,
        c -> c.hasClipboardText && c.writable,
        c -> !c.hasClipboardText ? "الحافظة لا تحتوي نصًا" : "الملف للقراءة فقط");
    add(PAGE_TOOLBAR, "more", "المزيد", PAGE_ROOT, ALWAYS, ALWAYS, c -> "");

    // الجذر: Color أول عنصر إذا وفقط إذا حل الفهرس literal واحدًا.
    add(PAGE_ROOT, "color", "اللون…", null, c -> c.hasColor, c -> c.writable,
        c -> "الملف للقراءة فقط");
    add(PAGE_ROOT, "fix", "إصلاح…", PAGE_FIX, c -> hasDisplayableDynamic(c.fixes), ALWAYS,
        c -> "");
    add(PAGE_ROOT, "tools", "أدوات..", PAGE_TOOLS, c -> hasDisplayableDynamic(c.tools), ALWAYS,
        c -> "");
    add(PAGE_ROOT, "goto", "الانتقال إلى", null, ALWAYS, c -> !c.xml,
        c -> "حل مراجع XML سيُفعّل في المرحلة السابعة");
    add(PAGE_ROOT, "documentation", "التوثيق", null, ALWAYS, c -> !c.xml,
        c -> "توثيق عناصر وسمات XML سيُفعّل في المرحلة السابعة");
    add(PAGE_ROOT, "breakpoint", "نقطة توقف", null, ALWAYS, c -> false,
        c -> c.xml ? "نقطة التوقف غير متاحة لملفات XML" : "غير متاحة في هذا المحرر");
    add(PAGE_ROOT, "refactor", "إعادة البناء…", PAGE_REFACTOR, ALWAYS, ALWAYS, c -> "");
    add(PAGE_ROOT, "code", "كود…", PAGE_CODE, ALWAYS, ALWAYS, c -> "");
    add(PAGE_ROOT, "format", "تنسيق…", PAGE_FORMAT, ALWAYS, ALWAYS, c -> "");
    add(PAGE_ROOT, "find", "بحث…", PAGE_FIND, ALWAYS, ALWAYS, c -> "");
    add(PAGE_ROOT, "close", "إغلاق الملف", null, ALWAYS, c -> c.hasOpenFile,
        c -> "لا يوجد ملف مفتوح");

    add(PAGE_REFACTOR, "rename", "إعادة التسمية", null, ALWAYS, c -> false,
        c -> c.xml ? "إعادة تسمية موارد XML ضمن المرحلة السادسة" : "غير متاحة حاليًا");
    add(PAGE_REFACTOR, "inline", "تضمين المتغير", null, ALWAYS, c -> false,
        c -> c.xml ? "أمر Java فقط" : "غير متاح حاليًا");
    add(PAGE_REFACTOR, "introduce", "استخراج متغير", null, ALWAYS, c -> false,
        c -> c.xml ? "أمر Java فقط" : "غير متاح حاليًا");
    add(PAGE_REFACTOR, "extract_method", "استخراج دالة", null, ALWAYS, c -> false,
        c -> c.xml ? "أمر Java فقط" : "غير متاح حاليًا");

    add(PAGE_CODE, "organize_imports", "تنظيم الاستيرادات", null, ALWAYS,
        c -> !c.xml && c.writable,
        c -> c.xml ? "أمر Java فقط" : "الملف للقراءة فقط");
    add(PAGE_CODE, "surround_try", "الإحاطة بـ try/catch", null, ALWAYS,
        c -> !c.xml && c.writable,
        c -> c.xml ? "أمر Java فقط" : "الملف للقراءة فقط");
    add(PAGE_CODE, "comment", "تعليق الكود", null, ALWAYS,
        c -> !c.xml && c.writable,
        c -> c.xml ? "تعليق XML الآمن سيُفعّل في المرحلة السادسة" : "الملف للقراءة فقط");
    add(PAGE_CODE, "uncomment", "فك تعليق الكود", null, ALWAYS,
        c -> !c.xml && c.writable,
        c -> c.xml ? "فك تعليق XML الآمن سيُفعّل في المرحلة السادسة" : "الملف للقراءة فقط");
    add(PAGE_CODE, "create_setters", "إنشاء Setters وGetters", null, ALWAYS, c -> false,
        c -> c.xml ? "أمر Java فقط" : "غير متاح حاليًا");
    add(PAGE_CODE, "create_constructor", "إنشاء الباني", null, ALWAYS, c -> false,
        c -> c.xml ? "أمر Java فقط" : "غير متاح حاليًا");
    add(PAGE_CODE, "extract_resources", "استخراج الموارد", null, ALWAYS, c -> false,
        c -> c.xml ? "سيُفعّل لألوان ونصوص XML في المرحلة السادسة" : "غير متاح لهذا السياق");
    add(PAGE_CODE, "replace", "استبدال نصي", null, ALWAYS,
        c -> c.hasSelection && c.writable,
        c -> !c.hasSelection ? "لا يوجد تحديد" : "الملف للقراءة فقط");

    add(PAGE_FORMAT, "format_code", "تنسيق الكود", null, ALWAYS,
        c -> !c.xml && c.writable,
        c -> c.xml ? "منسق XML الآمن سيُفعّل في المرحلة السادسة" : "الملف للقراءة فقط");
    add(PAGE_FORMAT, "learn_style", "تعلم نمط الكود", null, ALWAYS, c -> false,
        c -> "غير متاح حاليًا");
    add(PAGE_FORMAT, "configure_style", "إعداد نمط الكود", null, ALWAYS, c -> false,
        c -> "إعدادات النمط ضمن المرحلة الثامنة");

    add(PAGE_FIND, "find_usages", "استعراض الاستخدامات", null, ALWAYS, c -> !c.xml,
        c -> "استخدامات موارد XML ضمن المرحلة السابعة");
    add(PAGE_FIND, "find_extended", "الاستخدامات الموسعة", null, ALWAYS, c -> !c.xml,
        c -> "الاستخدامات الموسعة لموارد XML ضمن المرحلة السابعة");
    add(PAGE_FIND, "find_text", "بحث نصي", null, ALWAYS, c -> c.hasSelection,
        c -> "لا يوجد تحديد");

    // القائمة المصغرة بلا تحديد تقرأ Fix الديناميكي نفسه ولا تحمل ستة عناصر صلبة.
    add(PAGE_SMALL, "edit", "تحرير", null, ALWAYS, c -> c.writable,
        c -> "الملف للقراءة فقط");
    add(PAGE_SMALL, "fix", "إصلاح…", PAGE_FIX, c -> hasDisplayableDynamic(c.fixes), ALWAYS,
        c -> "");
    add(PAGE_SMALL, "design", "تصميم", null, c -> c.layoutXml, c -> c.writable,
        c -> "الملف للقراءة فقط");
  }

  private void add(
      String page,
      String id,
      String title,
      String subpage,
      Rule visible,
      Rule enabled,
      Reason reason) {
    ArrayList<Spec> specs = pages.get(page);
    if (specs == null) {
      specs = new ArrayList<>();
      pages.put(page, specs);
    }
    specs.add(new Spec(id, title, subpage, visible, enabled, reason));
  }

  public List<Entry> entries(String page, Context context) {
    if (PAGE_FIX.equals(page)) return dynamicEntries(context == null ? null : context.fixes, 6);
    if (PAGE_TOOLS.equals(page)) return dynamicEntries(context == null ? null : context.tools, Integer.MAX_VALUE);
    ArrayList<Spec> specs = pages.get(page);
    if (specs == null || context == null) return Collections.emptyList();
    ArrayList<Entry> result = new ArrayList<>();
    for (Spec spec : specs) {
      if (!spec.visible.test(context)) continue;
      boolean enabled = spec.enabled.test(context);
      result.add(new Entry(
          spec.id,
          spec.title,
          enabled,
          enabled ? "" : spec.reason.text(context),
          spec.subpage,
          null));
    }
    return result;
  }

  private static List<Entry> dynamicEntries(List<DynamicCommand> values, int maximum) {
    ArrayList<Entry> result = new ArrayList<>();
    List<DynamicCommand> source = safe(values);
    for (int i = 0; i < source.size() && result.size() < maximum; i++) {
      DynamicCommand item = source.get(i);
      if (!isDisplayable(item)) continue;
      result.add(new Entry(
          item.id,
          item.title,
          item.enabled,
          item.enabled ? "" : item.disabledReason,
          null,
          item.action));
    }
    return result;
  }

  private static boolean hasDisplayableDynamic(List<DynamicCommand> values) {
    for (DynamicCommand item : safe(values)) if (isDisplayable(item)) return true;
    return false;
  }

  private static boolean isDisplayable(DynamicCommand item) {
    return item != null && item.title != null && !item.title.trim().isEmpty();
  }

  private static <T> List<T> safe(List<T> values) {
    return values == null ? Collections.emptyList() : values;
  }

  public String titleForPage(String page) {
    if (PAGE_FIX.equals(page)) return "إصلاح…";
    if (PAGE_TOOLS.equals(page)) return "أدوات..";
    if (PAGE_REFACTOR.equals(page)) return "إعادة البناء…";
    if (PAGE_CODE.equals(page)) return "كود…";
    if (PAGE_FORMAT.equals(page)) return "تنسيق…";
    if (PAGE_FIND.equals(page)) return "بحث…";
    return null;
  }
}
