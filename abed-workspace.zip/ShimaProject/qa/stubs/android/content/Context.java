package android.content;

/** بديل اختياري — يكفي {@code getApplicationContext()} الذي تستخدمه شيفرتنا. */
public class Context {
  public Context getApplicationContext() {
    return this;
  }

  public SharedPreferences getSharedPreferences(String name, int mode) {
    return null;
  }
}
