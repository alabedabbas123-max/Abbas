# تقرير التنقل الرمزي وتحديد الكلاسات والدوال

## الهدف
عند تحديد class أو method أو field أو resource، ينتقل التطبيق إلى تعريفه أو يعرض أماكن استخدامه بسرعة، سواء كان محليًا أو تابعًا لمكتبة مفهرسة.

## الفهرس الموحد
```text
LocalSymbolIndex
+ ExternalLibraryIndex
+ ResourceIndex
+ ManifestIndex
+ ReferenceGraph
```

مفتاح الرمز:

```text
owner + name + descriptor + module + source
```

مثال method:

```text
com.example.UserRepository#getUser(String):User
```

## مراحل بناء الفهرس
```text
scan metadata
→ parse declarations
→ store definitions
→ parse references
→ resolve local symbols
→ resolve external symbols
→ build reverse references
```

الفهرس incremental حسب `fileHash` و`dependencyVersion`.

## تحديد العنصر
عند تحديد token:

1. استخراج range.
2. معرفة اللغة والسياق.
3. تحويله إلى SymbolKey.
4. البحث المحلي.
5. البحث في module.
6. البحث في dependency indexes.
7. عرض النتيجة مع source/owner.

## Go to Class
```text
class token
→ exact local match
→ module match
→ external index
→ Android API index
→ open target
```

يعرض popup النتائج المتعددة المتشابهة مع المسار واسم المكتبة.

## Go to Method
عند method invocation يحلل:

```text
owner
method name
parameter types
a return type إن توفر
```

ثم يطابق descriptor لا الاسم وحده لتجنب فتح overload خاطئ.

## Find References
لكل definition قائمة reverse references:

```text
source file
line/column
reference kind
preview
confidence
```

إذا كان الرمز من مكتبة، يبحث الفهرس في project references دون فك أو تعديل المكتبة.

## Callers/Callees
يبنى Call Graph تدريجيًا. يبدأ بالدالة الحالية، ثم يضيف callers/callees عند الطلب، بدل حساب graph كامل عند فتح المشروع.

## السرعة
- exact lookup في HashMap.
- prefix lookup في Trie.
- reverse refs في inverted index.
- cache لآخر الرموز المطلوبة.
- تحميل صفحات النتائج.
- عدم فتح أكثر من tab لنفس location.
- بدء إظهار النتيجة الأولى قبل اكتمال باقي النتائج.

## عدم اليقين
عند Reflection أو dynamic dispatch:

```text
Exact
Likely
Possible
Unknown
```

تظهر درجة الثقة ولا ينفذ Rename أو jump قطعي بناءً على تخمين.

## أدوات التنفيذ
Room أو file-backed index، HashMap/Trie، parser/lexer لكل لغة، ExecutorService، DiffUtil لقائمة النتائج، NavigationHistory، ViewModel، Bottom Draw.

## تجربة الاستخدام
- click على class/method يبرز العنصر.
- Go to يظهر في context menu وCommand Palette.
- Ctrl/long press يفتح Definition.
- Back يعيد الموقع السابق بدقة.
- References تفتح اللوحة السفلية وتسمح بالتنقل المتتابع.
- يظهر owner والمكتبة للرموز الخارجية.

## معايير القياس
- exact local lookup شبه فوري.
- cached external lookup أقل من 100ms كهدف.
- أول reference يظهر قبل اكتمال القائمة.
- إلغاء البحث لا يترك worker أو listener.
- لا يتوقف المحرر عند فشل مكتبة خارجية.
