package com.mhd.absher;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.FirebaseApp;

public class NationalIdCardActivity extends AppCompatActivity {
    private NationalIdCardBinding binding;
    private Intent i = new Intent();

    private void initialize(Bundle bundle) {
    }

    private void initializeLogic() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = NationalIdCardBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        FirebaseApp.initializeApp(this);
        initializeLogic();
    }
}
