package almlk;

/**
 * بند almlk ← دور طريقة OConsole «m571j6»: تجميع المتتاليات المتساوية في مصفوفة أنماط
 * لكل حرف إلى «runs» — كل run = استدعاء رسم واحد، فيهبط عدد الاستدعاءات من عدد الأحرف
 * إلى عدد الأنماط الفعلية في السطر.
 */
public final class StyleRunBatcher {

  /** مستهلك run واحد: نمط موحّد من start (شامل) حتى end (حصري). */
  public interface RunConsumer {
    void onRun(int styleId, int start, int end);
  }

  /**
   * دفع مصفوفة أنماط نافذة [start, end) من أنماط السطر إلى runs متتالية، ويستدعي consumer
   * لكل run متصل بالترتيب.
   */
  public static void batch(int[] styles, int start, int end, RunConsumer consumer) {
    if (styles == null || consumer == null) return;
    end = Math.min(end, styles.length);
    if (start >= end) return;
    int runStyle = styles[start];
    int runStart = start;
    for (int i = start + 1; i < end; i++) {
      if (styles[i] != runStyle) {
        consumer.onRun(runStyle, runStart, i);
        runStyle = styles[i];
        runStart = i;
      }
    }
    consumer.onRun(runStyle, runStart, end);
  }

  /** عدّاد تشخيصي: كم run في نافذة ما (يُراقَب به انسجام الألوان الكلي). */
  public static int countRuns(int[] styles, int start, int end) {
    if (styles == null) return 0;
    end = Math.min(end, styles.length);
    if (start >= end) return 0;
    int runs = 1;
    int last = styles[start];
    for (int i = start + 1; i < end; i++) {
      if (styles[i] != last) {
        runs++;
        last = styles[i];
      }
    }
    return runs;
  }
}
