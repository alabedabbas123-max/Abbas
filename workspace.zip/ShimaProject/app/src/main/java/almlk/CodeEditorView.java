package almlk;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;

/**
 * بند almlk ← طبقة «OEditor»: الإدخال والتحرير فوق لوحة الرسم {@link CodeCanvasView}.
 *
 * <p>الأساليب المنقولة (بكودنا الخاص):
 *
 * <ul>
 *   <li>InputConnection مخصص (commit/delete/Enter بمسافة بادئة ذكية) كما في OEditor.onCreateInputConnection.
 *   <li>مفاتيح العتاد: أسهم تحرّك بالمؤشر، Shift+أسهم يمدّد التحديد، Delete/Enter عبر الأحداث.
 *   <li>تراجع/إعادة مدمجان بالموديل ({@link UndoRedoStack}) — لا مسار خارجي موازٍ.
 *   <li>قائمة التحديد (Cut/Copy/Paste/Select All) عند دخول وضع التحديد — مع نقطة ربط لعناصر
 *       مخصصة من المضيف (الانتقال/الاستخدامات...) عبر {@link #setActionModeContributor}.
 *   <li>إظهار الكيبورد عند نقر النص كسلوك محرر AIDE.
 * </ul>
 */
public class CodeEditorView extends CodeCanvasView {

  /** مستمع تغييرات النص بمستوى الاستبدالات — تنقل أحداث التحرير للواجهة (TextWatcher مكافئ). */
  public interface ReplacementListener {
    /**
     * بعد كل استبدال فعلي: start=الإزاحة، removedCount=ما خرج، insertedCount=ما دخل.
     * قبل الإشعار مباشرة كانت removed تملأ [start,start+removedCount).
     */
    void onTextReplaced(int start, int removedCount, int insertedCount);
  }

  /** مساهم خارجي بعناصر إضافية في قائمة وضع التحديد. */
  public interface ActionModeContributor {
    void onCreateMenu(ActionMode mode, Menu menu);

    boolean onMenuItem(ActionMode mode, MenuItem item);

    void onDestroy(ActionMode mode);
  }

  private static final int ID_CUT = 0xA10001;
  private static final int ID_COPY = 0xA10002;
  private static final int ID_PASTE = 0xA10003;
  private static final int ID_SELECT_ALL = 0xA10004;

  private final UndoRedoStack history = new UndoRedoStack();
  private ReplacementListener replacementListener;
  private ActionModeContributor actionModeContributor;
  private ActionMode selectionActionMode;
  private boolean muted; // أثناء undo/redo لا نسجل التاريخ

  public CodeEditorView(Context context) {
    super(context);
    setInteractionListener(
        new InteractionListener() {
          @Override
          public void onSelectionModeChanged(boolean active) {
            // القائمة تنبثق فقط لتحديد لمسي فعلي (مثل نظام أندرويد لا تفتح CAB برمجيًا
            // ولا فارغًا) — بحث/انتقال/setSelection البرمجية لا تُخرجها.
            if (active && hasSelection() && selectionFromTouch) startSelectionActionMode();
            else if (!active && selectionActionMode != null) selectionActionMode.finish();
          }

          @Override
          public void onContentScrolled(int x, int y) {
            onEditorScrolledExternal(x, y);
          }

          @Override
          public void onTextSizeChanged(float textSizePixels) {
            onEditorZoomedExternal(textSizePixels);
          }

          @Override
          public void onShowKeyboardRequested() {
            showSoftKeyboard();
          }

          @Override
          public void onCaretRepositioned() {}
        });
  }

  public void setReplacementListener(ReplacementListener listener) {
    replacementListener = listener;
  }

  /** hook محمي: يبث التمرير الخارجي للواجهات المضيفة (الـPager). */
  protected void onEditorScrolledExternal(int x, int y) {}

  /** hook محمي: يبث حجم الخط الجديد بعد التكبير. */
  protected void onEditorZoomedExternal(float textSizePixels) {}

  public void setActionModeContributor(ActionModeContributor contributor) {
    actionModeContributor = contributor;
  }

  // ---------------- التحرير بالإزاحات (الجوهر) ----------------

  /** استبدال [start,end) بالنص + تسجيل التراجع + تحريك المؤشر — نقطة الدخول الوحيدة للتحرير. */
  public final int replaceRange(int start, int end, String text) {
    int from = Math.max(0, Math.min(start, document.length()));
    int to = Math.max(from, Math.min(end, document.length()));
    String removed;
    synchronized (document) {
      removed = document.subText(from, to);
      int caretOffset = document.replace(from, to, text == null ? "" : text);
      int caretLine = document.lineForOffset(caretOffset);
      int caretColumn = caretOffset - document.lineStartOffset(caretLine);
      if (!muted) history.record(from, removed, text == null ? "" : text);
      setCaret(caretLine, caretColumn);
    }
    if (replacementListener != null)
      replacementListener.onTextReplaced(from, removed.length(), text == null ? 0 : text.length());
    return from + (text == null ? 0 : text.length());
  }

  public boolean undo() {
    UndoRedoStack.Applied op = history.popUndo();
    if (op == null) return false;
    muted = true;
    try {
      // عكس العملية: أزل المُدخَل وأعد المحذوف.
      replaceRange(op.start, op.start + op.inserted.length(), op.removed);
    } finally {
      muted = false;
    }
    return true;
  }

  public boolean redo() {
    UndoRedoStack.Applied op = history.popRedo();
    if (op == null) return false;
    muted = true;
    try {
      replaceRange(op.start, op.start + op.removed.length(), op.inserted);
    } finally {
      muted = false;
    }
    return true;
  }

  public boolean canUndo() {
    return history.canUndo();
  }

  public boolean canRedo() {
    return history.canRedo();
  }

  public void clearHistory() {
    history.clear();
  }

  // ---------------- الإدخال: IME ----------------

  @Override
  public boolean onCheckIsTextEditor() {
    return true;
  }

  @Override
  public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
    outAttrs.inputType =
        android.text.InputType.TYPE_CLASS_TEXT
            | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD;
    outAttrs.imeOptions =
        EditorInfo.IME_FLAG_NO_EXTRACT_UI
            | EditorInfo.IME_FLAG_NO_ENTER_ACTION
            | EditorInfo.IME_ACTION_NONE;
    return new CodeInputConnection(this);
  }

  public void showSoftKeyboard() {
    requestFocus();
    InputMethodManager imm =
        (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    if (imm != null) {
      imm.viewClicked(this);
      imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT);
    }
  }

  public void hideSoftKeyboard() {
    InputMethodManager imm =
        (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
  }

  /** نص مُدخَل من الكيبورد/اللصق/الإكمال: يستبدل التحديد (أو يُدرج عند المؤشر). */
  public final void commitInput(String text) {
    int[] sel = selectionOffsets();
    replaceRange(sel[0], sel[1], text);
    exitSelectionMode();
  }

  /** حذف قبل/بعد المؤشر (Backspace/Delete من الكيبورد). */
  public final void deleteSurrounding(int before, int after) {
    int[] sel = selectionOffsets();
    if (sel[0] != sel[1]) {
      replaceRange(sel[0], sel[1], "");
      exitSelectionMode();
      return;
    }
    int length = document.length();
    int from = Math.max(0, sel[0] - before);
    int to = Math.min(length, sel[1] + after);
    if (to > from) replaceRange(from, to, "");
  }

  /** إزاحات التحديد المرتبة [بداية، نهاية] — أو المؤشر مرتين. */
  public final int[] selectionOffsets() {
    int[] ordered = orderedSelection();
    int start = document.offsetFor(ordered[0], ordered[1]);
    int end = document.offsetFor(ordered[2], ordered[3]);
    return new int[] {start, end};
  }

  /** Enter بمسافة بادئة ذكية (أسلوب OEditor): نسخ بادئة السطر + وحدة إضافية بعد '{'. */
  public final void newlineWithIndent() {
    int[] sel = selectionOffsets();
    int caretOffset = sel[0] == sel[1] ? document.offsetFor(caretLine(), caretColumn()) : -1;
    if (caretOffset < 0) {
      commitInput("\n");
      return;
    }
    String lineText;
    synchronized (document) {
      lineText = document.line(caretLine()).toString();
    }
    StringBuilder indent = new StringBuilder("\n");
    int i = 0;
    while (i < lineText.length()
        && (lineText.charAt(i) == ' ' || lineText.charAt(i) == '\t')) {
      indent.append(lineText.charAt(i));
      i++;
    }
    // سياق فوري: حرف قبل المؤشر { ← بادئة إضافية، وإن كان } بعده مباشرة افتح السطر الأوسط.
    boolean openBrace = caretColumn() > 0
        && caretColumn() <= lineText.length()
        && lineText.charAt(caretColumn() - 1) == '{';
    boolean closeFollows = caretColumn() < lineText.length()
        && lineText.charAt(caretColumn()) == '}';
    if (openBrace) indent.append("    ");
    if (openBrace && closeFollows) {
      String mid = indent.toString();
      StringBuilder tail = new StringBuilder("\n");
      i = 0;
      while (i < lineText.length()
          && (lineText.charAt(i) == ' ' || lineText.charAt(i) == '\t')) {
        tail.append(lineText.charAt(i));
        i++;
      }
      tail.append('}');
      int insertAt = document.offsetFor(caretLine(), caretColumn());
      // { | } → {\n<بادئة+وحدة>\n<بادئة>} والمؤشر في نهاية السطر الأوسط.
      replaceRange(insertAt, insertAt + 1, mid + tail);
      int target = insertAt + mid.length();
      int targetLine = document.lineForOffset(target);
      setCaret(targetLine, target - document.lineStartOffset(targetLine));
    } else {
      String insertion = indent.toString();
      replaceRange(sel[0], sel[1], insertion);
    }
    exitSelectionMode();
  }

  // ---------------- مفاتيح العتاد ----------------

  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    boolean shift = (event.getMetaState() & KeyEvent.META_SHIFT_ON) != 0;
    switch (keyCode) {
      case KeyEvent.KEYCODE_DPAD_LEFT:
        moveCaretHorizontally(-1, shift);
        return true;
      case KeyEvent.KEYCODE_DPAD_RIGHT:
        moveCaretHorizontally(1, shift);
        return true;
      case KeyEvent.KEYCODE_DPAD_UP:
        moveCaretVertically(-1, shift);
        return true;
      case KeyEvent.KEYCODE_DPAD_DOWN:
        moveCaretVertically(1, shift);
        return true;
      case KeyEvent.KEYCODE_MOVE_HOME:
        if (shift) setCaretExtendingSelection(caretLine(), 0);
        else setCaret(caretLine(), 0);
        return true;
      case KeyEvent.KEYCODE_MOVE_END:
        if (shift) setCaretExtendingSelection(caretLine(), document.lineLength(caretLine()));
        else setCaret(caretLine(), document.lineLength(caretLine()));
        return true;
      case KeyEvent.KEYCODE_DEL:
        deleteSurrounding(1, 0);
        return true;
      case KeyEvent.KEYCODE_FORWARD_DEL:
        deleteSurrounding(0, 1);
        return true;
      case KeyEvent.KEYCODE_ENTER:
        newlineWithIndent();
        return true;
      case KeyEvent.KEYCODE_TAB:
        commitInput("\t");
        return true;
      case KeyEvent.KEYCODE_A:
        if (event.isCtrlPressed()) {
          selectAll();
          return true;
        }
        break;
      case KeyEvent.KEYCODE_C:
        if (event.isCtrlPressed() && hasSelection()) {
          copySelection();
          return true;
        }
        break;
      case KeyEvent.KEYCODE_X:
        if (event.isCtrlPressed() && hasSelection()) {
          cutSelection();
          return true;
        }
        break;
      case KeyEvent.KEYCODE_V:
        if (event.isCtrlPressed()) {
          pasteClipboard();
          return true;
        }
        break;
      case KeyEvent.KEYCODE_Z:
        if (event.isCtrlPressed()) {
          if (event.isShiftPressed()) redo();
          else undo();
          return true;
        }
        break;
      case KeyEvent.KEYCODE_Y:
        if (event.isCtrlPressed()) {
          redo();
          return true;
        }
        break;
      default:
        break;
    }
    return super.onKeyDown(keyCode, event);
  }

  private void moveCaretHorizontally(int delta, boolean extend) {
    int line = caretLine(), column = caretColumn();
    if (delta < 0) {
      if (column > 0) column--;
      else if (line > 0) {
        line--;
        column = document.lineLength(line);
      }
    } else {
      if (column < document.lineLength(line)) column++;
      else if (line < document.lineCount() - 1) {
        line++;
        column = 0;
      }
    }
    if (extend) {
      enterSelectionMode();
      setCaretExtendingSelection(line, column);
    } else {
      setCaret(line, column);
    }
    exitSelectionModeIfCollapsed();
  }

  private void moveCaretVertically(int delta, boolean extend) {
    int targetLine =
        Math.max(0, Math.min(caretLine() + delta, document.lineCount() - 1));
    int column = Math.max(0, Math.min(caretColumn(), document.lineLength(targetLine)));
    if (extend) {
      enterSelectionMode();
      setCaretExtendingSelection(targetLine, column);
    } else {
      setCaret(targetLine, column);
    }
    exitSelectionModeIfCollapsed();
  }

  private void exitSelectionModeIfCollapsed() {
    if (!hasSelection() && inSelectionMode()) exitSelectionMode();
  }

  // ---------------- الحافظة وقائمة وضع التحديد ----------------

  public final String selectedText() {
    int[] sel = selectionOffsets();
    return sel[0] == sel[1] ? "" : document.subText(sel[0], sel[1]);
  }

  /** يمرّر إزاحة إلى المرئي دون تحريك المؤشر (مكافئ EditText.bringPointIntoView للبحث/الانتقال). */
  public boolean scrollOffsetIntoView(int offset) {
    int clamped = Math.max(0, Math.min(offset, document.length()));
    int line = document.lineForOffset(clamped);
    int column = clamped - document.lineStartOffset(line);
    float pointX = gutterWidth() + metrics().columnToX(column);
    float lineTop = line * lineStride();
    float lineBottom = lineTop + lineStride();
    int newX = getScrollX(), newY = getScrollY();
    float margin = lineStride() * 2;
    if (lineTop < getScrollY() + margin)
      newY = (int) Math.max(0, lineTop - margin);
    else if (lineBottom > getScrollY() + getHeight() - margin)
      newY = (int) Math.min(contentHeightForScroll() - getHeight(), lineBottom - getHeight() + margin);
    float viewX = pointX - getScrollX();
    if (viewX < gutterWidth() + dp(16)) newX = (int) Math.max(0, pointX - gutterWidth() - dp(16));
    else if (viewX > getWidth() - dp(24)) newX = (int) Math.max(0, pointX - getWidth() + dp(48));
    if (newX != getScrollX() || newY != getScrollY()) {
      scrollTo(newX, newY);
      return true;
    }
    return false;
  }

  private float contentHeightForScroll() {
    return document.lineCount() * lineStride() + dp(12);
  }

  public final void cutSelection() {
    if (!hasSelection()) return;
    copySelection();
    int[] sel = selectionOffsets();
    replaceRange(sel[0], sel[1], "");
    exitSelectionMode();
  }

  public final void copySelection() {
    if (!hasSelection()) return;
    ClipboardManager clipboard =
        (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
    if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("code", selectedText()));
  }

  public final void pasteClipboard() {
    ClipboardManager clipboard =
        (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
    if (clipboard == null || !clipboard.hasPrimaryClip()) return;
    ClipData clip = clipboard.getPrimaryClip();
    if (clip == null || clip.getItemCount() == 0) return;
    CharSequence text = clip.getItemAt(0).coerceToText(getContext());
    if (text != null && text.length() > 0) commitInput(text.toString());
  }

  private void startSelectionActionMode() {
    if (selectionActionMode != null) return;
    selectionActionMode =
        startActionMode(
            new ActionMode.Callback() {
              @Override
              public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                menu.add(0, ID_CUT, 0, "قص")
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
                menu.add(0, ID_COPY, 1, "نسخ")
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
                menu.add(0, ID_PASTE, 2, "لصق")
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
                menu.add(0, ID_SELECT_ALL, 3, "تحديد الكل")
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
                ActionModeContributor contributor = actionModeContributor;
                if (contributor != null) contributor.onCreateMenu(mode, menu);
                return true;
              }

              @Override
              public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
              }

              @Override
              public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                switch (item.getItemId()) {
                  case ID_CUT:
                    cutSelection();
                    return true;
                  case ID_COPY:
                    copySelection();
                    mode.finish();
                    return true;
                  case ID_PASTE:
                    pasteClipboard();
                    mode.finish();
                    return true;
                  case ID_SELECT_ALL:
                    selectAll();
                    return true;
                  default:
                    ActionModeContributor contributor = actionModeContributor;
                    return contributor != null && contributor.onMenuItem(mode, item);
                }
              }

              @Override
              public void onDestroyActionMode(ActionMode mode) {
                selectionActionMode = null;
                ActionModeContributor contributor = actionModeContributor;
                if (contributor != null) contributor.onDestroy(mode);
                if (hasSelection()) exitSelectionMode();
              }
            });
  }

  /** إغلاق القائمة إن كانت مفتوحة عند مغادرة النافذة. */
  @Override
  protected void onDetachedFromWindow() {
    if (selectionActionMode != null) selectionActionMode.finish();
    super.onDetachedFromWindow();
  }
}
