package com.mhd.absher;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class PersonalInfoActivity extends AppCompatActivity {
    private DatabaseReference dbRef;
    private ValueEventListener userDataListener;

    public void applyBitmapToImageViews(View view, Bitmap bitmap) {
        if (view == null) {
            return;
        }
        if (!(view instanceof ImageView)) {
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i = 0; i < viewGroup.getChildCount(); i++) {
                    applyBitmapToImageViews(viewGroup.getChildAt(i), bitmap);
                }
                return;
            }
            return;
        }
        ImageView imageView = (ImageView) view;
        String lowerCase = "";
        try {
            lowerCase = getResources().getResourceEntryName(imageView.getId()).toLowerCase();
        } catch (Exception e) {
        }
        if (lowerCase.contains(a.a("NzUlRg==")) || lowerCase.contains(a.a("NCY0Qk8=")) || lowerCase.contains(a.a("PDcpQw==")) || lowerCase.contains(a.a("PDcZ"))) {
            return;
        }
        imageView.setImageBitmap(bitmap);
    }

    public String getSafeString(DataSnapshot dataSnapshot, String... strArr) {
        for (String str : strArr) {
            if (dataSnapshot.hasChild(str) && dataSnapshot.child(str).getValue() != null) {
                return String.valueOf(dataSnapshot.child(str).getValue());
            }
        }
        return null;
    }

    private String getSpStringMultipleKeys(SharedPreferences sharedPreferences, String... strArr) {
        for (String str : strArr) {
            String string = sharedPreferences.getString(str, "");
            if (string != null && !string.trim().isEmpty()) {
                return string;
            }
        }
        return "";
    }

    private void loadDataFromSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        String spStringMultipleKeys = getSpStringMultipleKeys(sharedPreferences, a.a("ICcjX3E4NSFI"), a.a("ICcjX2c8OSdKXQ=="), a.a("JSYpS1E5MQ9AWTIx"), a.a("PDknSl0="), a.a("JTwpWVc="), a.a("ICcjX2g9OzJC"));
        if (!spStringMultipleKeys.isEmpty()) {
            updateUserImageUI(spStringMultipleKeys);
        }
        String stringExtra = getIntent().getStringExtra(a.a("AAcDf2cbFQto"));
        String strA = a.a("OzUrSHkn");
        if (stringExtra == null) {
            stringExtra = a.a("je2fqeHfdJ6U4dGNzA3g7I3C9LJ1jP/0vIze");
        }
        String string = sharedPreferences.getString(strA, stringExtra);
        String string2 = sharedPreferences.getString(a.a("OzUrSH07"), "");
        String string3 = sharedPreferences.getString(a.a("PDAIWFU3MTQ="), "");
        String string4 = sharedPreferences.getString(a.a("Nz00WVARNTJI"), "");
        String string5 = sharedPreferences.getString(a.a("OzUyRFc7NSpETCw="), a.a("jfefrODkjOH1l3WM4fS8jNaeheDyjOD0vA=="));
        String string6 = sharedPreferences.getString(a.a("JSYpS10mJy9CVg=="), a.a("je2eiuHQjcI="));
        String string7 = sharedPreferences.getString(a.a("MCw2REosECdZXQ=="), "");
        String string8 = sharedPreferences.getString(a.a("PCc1WF0RNTJI"), "");
        String string9 = sharedPreferences.getString(a.a("JzEqRF88Oyg="), "");
        String string10 = sharedPreferences.getString(a.a("Nz00WVAFOCdOXQ=="), a.a("jeCenOHdjPf1kQ=="));
        String string11 = sharedPreferences.getString(a.a("NzgpQlwBLTZI"), a.a("eA=="));
        setTextIfNotNull(R.id.tvName, string);
        setTextIfNotNull(R.id.tvBirthPlace, string10);
        setTextIfNotNull(R.id.textview278, string5);
        setTextIfNotNull(R.id.tvDob, string4);
        setTextIfNotNull(R.id.textview27, string6);
        setTextIfNotNull(R.id.textview29, string6);
        setTextIfNotNull(R.id.tvBloodType, string11);
        setTextIfNotNull(a.a("ISIITFUwFTQ="), string);
        setTextIfNotNull(a.a("ISITXl0nGidAXQ=="), string);
        setTextIfNotNull(a.a("ISIITFUwESg="), string2);
        setTextIfNotNull(a.a("ISIPSXYgOSRISg=="), toArabicNumbers(string3));
        setTextIfNotNull(a.a("ISITXl0nHSI="), toArabicNumbers(string3));
        setTextIfNotNull(a.a("ISIITEw8OyhMVBww"), toArabicNumbers(string3));
        setTextIfNotNull(a.a("ISIEREohPAJMTDA="), toArabicNumbers(string4));
        setTextIfNotNull(a.a("ISIITEw8OyhMVDwgPw=="), string5);
        setTextIfNotNull(a.a("ISIWX1czMTVeUTo6"), string6);
        setTextIfNotNull(a.a("ISIDVUg8Jj9pWSEx"), toArabicNumbers(string7));
        setTextIfNotNull(a.a("ISIPXksgMQJMTDA="), toArabicNumbers(string8));
        setTextIfNotNull(a.a("ISIUSFQ8My9CVg=="), string9);
        setTextIfNotNull(a.a("ISIEREohPBZBWTYx"), string10);
    }

    private void setTextIfNotNull(int i, String str) {
        TextView textView = (TextView) findViewById(i);
        if (textView == null || str == null) {
            return;
        }
        textView.setText(str);
    }

    private void setTextIfNotNull(String str, String str2) {
        int identifier;
        TextView textView;
        if (str == null || str2 == null || (identifier = getResources().getIdentifier(str, a.a("PDA="), getPackageName())) == 0 || (textView = (TextView) findViewById(identifier)) == null) {
            return;
        }
        textView.setText(str2);
    }

    private void syncDataWithFirebase() {
        SharedPreferences sharedPreferences = getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0);
        SharedPreferences sharedPreferences2 = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        SharedPreferences sharedPreferences3 = getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
        String string = sharedPreferences.getString(a.a("ICcjX2swNzRITBww"), "");
        if (string.isEmpty()) {
            string = sharedPreferences3.getString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), "");
        }
        if (string.isEmpty()) {
            string = sharedPreferences2.getString(a.a("JjElX10hHyNU"), "");
        }
        if (string.isEmpty()) {
            string = sharedPreferences2.getString(a.a("ICcjX3MwLQ=="), "");
        }
        if (string.isEmpty()) {
            return;
        }
        try {
            this.dbRef = FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(string);
            this.userDataListener = new ValueEventListener() {
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }

                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        SharedPreferences.Editor editorEdit = PersonalInfoActivity.this.getSharedPreferences(a.a("ICcjX3w0ICc="), 0).edit();
                        String safeString = PersonalInfoActivity.this.getSafeString(dataSnapshot, a.a("ICcjX3E4NSFI"), a.a("ACcjX3E4NSFI"), a.a("ICcjX2c8OSdKXQ=="), a.a("JSYpS1E5MQ9AWTIx"), a.a("JSYpS1E5MRlEVTQzIw=="), a.a("PDknSl0="), a.a("HDknSl0="), a.a("JTwpWVc="), a.a("BTwpWVc="), a.a("ICcjX2g9OzJC"), a.a("ICcjX2clPClZVw=="), a.a("NCInWVkn"), a.a("JTE0Xlc7NSpkVTQzIw=="));
                        if (safeString != null && !safeString.trim().isEmpty()) {
                            editorEdit.putString(a.a("ICcjX3E4NSFI"), safeString);
                            PersonalInfoActivity.this.updateUserImageUI(safeString);
                        }
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSHkn"), a.a("GzUrSHkn"), R.id.tvName, false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Nz00WVAFOCdOXQ=="), a.a("Fz00WVAFOCdOXQ=="), R.id.tvBirthPlace, false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUyRFc7NSpETCw="), a.a("GzUyRFc7NSpETCw="), R.id.textview278, false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Nz00WVARNTJI"), a.a("Fz00WVARNTJI"), R.id.tvDob, false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("JSYpS10mJy9CVg=="), a.a("BSYpS10mJy9CVg=="), R.id.textview27, false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("JSYpS10mJy9CVg=="), a.a("BSYpS10mJy9CVg=="), R.id.textview29, false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("NzgpQlwBLTZI"), a.a("FzgpQlwBLTZI"), R.id.tvBloodType, false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSHkn"), a.a("GzUrSHkn"), a.a("ISIITFUwFTQ="), false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSHkn"), a.a("GzUrSHkn"), a.a("ISITXl0nGidAXQ=="), false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUrSH07"), a.a("GzUrSH07"), a.a("ISIITFUwESg="), false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("PDAIWFU3MTQ="), a.a("HDAIWFU3MTQ="), a.a("ISIPSXYgOSRISg=="), true);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("PDAIWFU3MTQ="), a.a("HDAIWFU3MTQ="), a.a("ISITXl0nHSI="), true);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("PDAIWFU3MTQ="), a.a("HDAIWFU3MTQ="), a.a("ISIITEw8OyhMVBww"), true);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Nz00WVARNTJI"), a.a("Fz00WVARNTJI"), a.a("ISIEREohPAJMTDA="), true);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("OzUyRFc7NSpETCw="), a.a("GzUyRFc7NSpETCw="), a.a("ISIITEw8OyhMVDwgPw=="), false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("JSYpS10mJy9CVg=="), a.a("BSYpS10mJy9CVg=="), a.a("ISIWX1czMTVeUTo6"), false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("MCw2REosECdZXQ=="), a.a("ECw2REosECdZXQ=="), a.a("ISIDVUg8Jj9pWSEx"), true);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("PCc1WF0RNTJI"), a.a("HCc1WF0RNTJI"), a.a("ISIPXksgMQJMTDA="), true);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("JzEqRF88Oyg="), a.a("BzEqRF88Oyg="), a.a("ISIUSFQ8My9CVg=="), false);
                        PersonalInfoActivity.this.updateFieldAndUI(dataSnapshot, editorEdit, a.a("Nz00WVAFOCdOXQ=="), a.a("Fz00WVAFOCdOXQ=="), a.a("ISIEREohPBZBWTYx"), false);
                        editorEdit.apply();
                    }
                }
            };
            this.dbRef.addValueEventListener(this.userDataListener);
        } catch (Exception e) {
        }
    }

    private String toArabicNumbers(String str) {
        return str == null ? "" : str.replace(a.a("ZQ=="), a.a("jPQ=")).replace(a.a("ZA=="), a.a("jPU=")).replace(a.a("Zw=="), a.a("jPY=")).replace(a.a("Zg=="), a.a("jPc=")).replace(a.a("YQ=="), a.a("jPA=")).replace(a.a("YA=="), a.a("jPE=")).replace(a.a("Yw=="), a.a("jPI=")).replace(a.a("Yg=="), a.a("jPM=")).replace(a.a("bQ=="), a.a("jPw=")).replace(a.a("bA=="), a.a("jP0="));
    }

    public void updateFieldAndUI(DataSnapshot dataSnapshot, SharedPreferences.Editor editor, String str, String str2, int i, boolean z) {
        String safeString = getSafeString(dataSnapshot, str, str2);
        if (safeString != null) {
            editor.putString(str, safeString);
            if (z) {
                safeString = toArabicNumbers(safeString);
            }
            setTextIfNotNull(i, safeString);
        }
    }

    public void updateFieldAndUI(DataSnapshot dataSnapshot, SharedPreferences.Editor editor, String str, String str2, String str3, boolean z) {
        String safeString = getSafeString(dataSnapshot, str, str2);
        if (safeString != null) {
            editor.putString(str, safeString);
            if (z) {
                safeString = toArabicNumbers(safeString);
            }
            setTextIfNotNull(str3, safeString);
        }
    }

    public void updateUserImageUI(final String str) {
        if (str == null || str.trim().isEmpty()) {
            return;
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                View viewFindViewById;
                try {
                    byte[] bArrDecode = Base64.decode(str, 0);
                    Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArrDecode, 0, bArrDecode.length);
                    if (bitmapDecodeByteArray == null || (viewFindViewById = PersonalInfoActivity.this.findViewById(android.R.id.content)) == null) {
                        return;
                    }
                    PersonalInfoActivity.this.applyBitmapToImageViews(viewFindViewById, bitmapDecodeByteArray);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.personal_info);
        getWindow().getDecorView().setLayoutDirection(1);
        View viewFindViewById = findViewById(R.id.btnBackPersonalInfo);
        if (viewFindViewById == null) {
            int identifier = getResources().getIdentifier(a.a("NyAob1k2Pw=="), a.a("PDA="), getPackageName());
            if (identifier == 0) {
                identifier = getResources().getIdentifier(a.a("PCIETFs+"), a.a("PDA="), getPackageName());
            }
            if (identifier != 0) {
                viewFindViewById = findViewById(identifier);
            }
        }
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    PersonalInfoActivity.this.finish();
                }
            });
        }
        loadDataFromSharedPreferences();
        syncDataWithFirebase();
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.dbRef == null || this.userDataListener == null) {
            return;
        }
        this.dbRef.removeEventListener(this.userDataListener);
    }
}
