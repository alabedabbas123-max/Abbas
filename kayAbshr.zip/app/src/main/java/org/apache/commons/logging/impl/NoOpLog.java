package org.apache.commons.logging.impl;

import java.io.Serializable;
import org.apache.commons.logging.Log;

@Deprecated
public class NoOpLog implements Log, Serializable {
    public NoOpLog() {
        throw new RuntimeException("Stub!");
    }

    public NoOpLog(String str) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void debug(Object obj) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void debug(Object obj, Throwable th) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void error(Object obj) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void error(Object obj, Throwable th) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void fatal(Object obj) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void fatal(Object obj, Throwable th) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void info(Object obj) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void info(Object obj, Throwable th) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public final boolean isDebugEnabled() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public final boolean isErrorEnabled() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public final boolean isFatalEnabled() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public final boolean isInfoEnabled() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public final boolean isTraceEnabled() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public final boolean isWarnEnabled() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void trace(Object obj) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void trace(Object obj, Throwable th) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void warn(Object obj) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void warn(Object obj, Throwable th) {
        throw new RuntimeException("Stub!");
    }
}
