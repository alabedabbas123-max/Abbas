package com.shima.editor.core;

/**
 * Mutable document contract used by the editor core. Implementations may keep the text in pieces
 * instead of a single String, so callers must use ranges and snapshots deliberately.
 */
public interface TextDocument {
  String uri();

  long length();

  CharSequence readRange(long start, long end);

  String snapshot();

  void insert(long offset, CharSequence text);

  void delete(long start, long end);

  void replace(long start, long end, CharSequence text);

  int lineOf(long offset);

  long offsetOfLine(int line);

  int lineCount();

  long version();

  boolean isReadOnly();
}
