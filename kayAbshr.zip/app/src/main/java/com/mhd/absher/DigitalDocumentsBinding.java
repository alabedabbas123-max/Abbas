package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import com.a.a.a.a.a;

public final class DigitalDocumentsBinding {
    public final RelativeLayout documentCard1;
    public final RelativeLayout documentCard2;
    public final CardView documentCardCitizen;
    public final RelativeLayout documentCardVisitor;
    public final FrameLayout frameCitizenQrcode;
    public final FrameLayout frameLicenseQrcode;
    public final FrameLayout frameQrcode;
    public final FrameLayout frameVisitorQrcode;
    public final ImageView imageviewIdPhoto;
    public final ImageView imageviewLicenseBarcode;
    public final ImageView imageviewLicensePhoto;
    public final ImageView imageviewLicenseQrLogo;
    public final ImageView imageviewQrLogo;
    public final ImageView imageviewQrcode;
    public final ImageView imgCardBg;
    public final ImageView imgCitizenCardBg;
    public final ImageView imgCitizenQrLogo;
    public final ImageView imgCitizenQrcode;
    public final ImageView imgCitizenUserPhoto;
    public final ImageView imgUserPhoto;
    public final ImageView imgVisitorQrLogo;
    public final ImageView imgVisitorQrcode;
    public final ImageView ivDocument1Background;
    public final ImageView ivDocument2;
    public final LinearLayout linear8;
    public final RelativeLayout relativelayout6;
    public final ScrollView rootView;
    public final TextView textview14;
    public final TextView textview15;
    public final TextView textview16;
    public final TextView textviewCitizenTitle;
    public final TextView textviewRefresh;
    public final TextView tvBirthDate;
    public final TextView tvBloodType;
    public final TextView tvCardBirthDate;
    public final TextView tvCardBirthPlace;
    public final TextView tvCardCopyNumber;
    public final TextView tvCardEmployerId;
    public final TextView tvCardEmployerName;
    public final TextView tvCardExpiryDate;
    public final TextView tvCardIdHome;
    public final TextView tvCardIssuePlace;
    public final TextView tvCardNameEn;
    public final TextView tvCardNameHome;
    public final TextView tvCardNationality;
    public final TextView tvCardProfession;
    public final TextView tvCardReligion;
    public final TextView tvCitizenBirthDate;
    public final TextView tvCitizenBirthDateEn;
    public final TextView tvCitizenBirthPlace;
    public final TextView tvCitizenCopyNumber;
    public final TextView tvCitizenExpiryDate;
    public final TextView tvCitizenExpiryDateEn;
    public final TextView tvCitizenIdNumber;
    public final TextView tvCitizenIdNumberEn;
    public final TextView tvCitizenNameAr;
    public final TextView tvCitizenNameEn;
    public final TextView tvExpiryDate;
    public final TextView tvIdNumber;
    public final TextView tvIssueDate;
    public final TextView tvIssuePlace;
    public final TextView tvLicenseBirthDateAr;
    public final TextView tvLicenseBirthDateEn;
    public final TextView tvLicenseBloodTypeAr;
    public final TextView tvLicenseBloodTypeEn;
    public final TextView tvLicenseExpiryDateAr;
    public final TextView tvLicenseExpiryDateEn;
    public final TextView tvLicenseIdNumberAr;
    public final TextView tvLicenseIdNumberEn;
    public final TextView tvLicenseIssueDateAr;
    public final TextView tvLicenseIssueDateEn;
    public final TextView tvLicenseNameAr;
    public final TextView tvLicenseNameEn;
    public final TextView tvLicenseNationalityAr;
    public final TextView tvLicenseNationalityEn;
    public final TextView tvLicenseTypeAr;
    public final TextView tvLicenseTypeEn;
    public final TextView tvNameAr;
    public final TextView tvNameEn;
    public final TextView tvNationality;
    public final TextView tvUpdateTime;
    public final TextView tvVersionNumber;
    public final TextView tvVisitPurpose;

    private DigitalDocumentsBinding(ScrollView scrollView, LinearLayout linearLayout, TextView textView, TextView textView2, TextView textView3, TextView textView4, CardView cardView, RelativeLayout relativeLayout, ImageView imageView, FrameLayout frameLayout, ImageView imageView2, ImageView imageView3, TextView textView5, TextView textView6, TextView textView7, TextView textView8, TextView textView9, TextView textView10, TextView textView11, TextView textView12, TextView textView13, TextView textView14, ImageView imageView4, TextView textView15, RelativeLayout relativeLayout2, ImageView imageView5, TextView textView16, ImageView imageView6, FrameLayout frameLayout2, ImageView imageView7, ImageView imageView8, TextView textView17, TextView textView18, TextView textView19, TextView textView20, TextView textView21, TextView textView22, TextView textView23, TextView textView24, TextView textView25, TextView textView26, TextView textView27, TextView textView28, RelativeLayout relativeLayout3, ImageView imageView9, ImageView imageView10, FrameLayout frameLayout3, ImageView imageView11, ImageView imageView12, TextView textView29, TextView textView30, TextView textView31, TextView textView32, TextView textView33, TextView textView34, TextView textView35, TextView textView36, TextView textView37, TextView textView38, TextView textView39, TextView textView40, RelativeLayout relativeLayout4, ImageView imageView13, ImageView imageView14, FrameLayout frameLayout4, ImageView imageView15, ImageView imageView16, TextView textView41, TextView textView42, TextView textView43, TextView textView44, TextView textView45, TextView textView46, TextView textView47, TextView textView48, TextView textView49, TextView textView50, TextView textView51, TextView textView52, TextView textView53, TextView textView54, TextView textView55, TextView textView56) {
        this.rootView = scrollView;
        this.linear8 = linearLayout;
        this.textview14 = textView;
        this.tvUpdateTime = textView2;
        this.textviewRefresh = textView3;
        this.textviewCitizenTitle = textView4;
        this.documentCardCitizen = cardView;
        this.relativelayout6 = relativeLayout;
        this.imgCitizenCardBg = imageView;
        this.frameCitizenQrcode = frameLayout;
        this.imgCitizenQrcode = imageView2;
        this.imgCitizenQrLogo = imageView3;
        this.tvCitizenCopyNumber = textView5;
        this.tvCitizenNameAr = textView6;
        this.tvCitizenNameEn = textView7;
        this.tvCitizenIdNumber = textView8;
        this.tvCitizenIdNumberEn = textView9;
        this.tvCitizenBirthDate = textView10;
        this.tvCitizenBirthDateEn = textView11;
        this.tvCitizenExpiryDate = textView12;
        this.tvCitizenExpiryDateEn = textView13;
        this.tvCitizenBirthPlace = textView14;
        this.imgCitizenUserPhoto = imageView4;
        this.textview15 = textView15;
        this.documentCard1 = relativeLayout2;
        this.ivDocument1Background = imageView5;
        this.tvCardCopyNumber = textView16;
        this.imageviewIdPhoto = imageView6;
        this.frameQrcode = frameLayout2;
        this.imageviewQrcode = imageView7;
        this.imageviewQrLogo = imageView8;
        this.tvCardNameHome = textView17;
        this.tvCardNameEn = textView18;
        this.tvCardIdHome = textView19;
        this.tvCardBirthDate = textView20;
        this.tvCardExpiryDate = textView21;
        this.tvCardBirthPlace = textView22;
        this.tvCardReligion = textView23;
        this.tvCardNationality = textView24;
        this.tvCardProfession = textView25;
        this.tvCardEmployerId = textView26;
        this.tvCardIssuePlace = textView27;
        this.tvCardEmployerName = textView28;
        this.documentCardVisitor = relativeLayout3;
        this.imgCardBg = imageView9;
        this.imgUserPhoto = imageView10;
        this.frameVisitorQrcode = frameLayout3;
        this.imgVisitorQrcode = imageView11;
        this.imgVisitorQrLogo = imageView12;
        this.tvVersionNumber = textView29;
        this.tvNameAr = textView30;
        this.tvNameEn = textView31;
        this.tvIdNumber = textView32;
        this.tvIssuePlace = textView33;
        this.tvIssueDate = textView34;
        this.tvExpiryDate = textView35;
        this.tvBirthDate = textView36;
        this.tvNationality = textView37;
        this.tvVisitPurpose = textView38;
        this.tvBloodType = textView39;
        this.textview16 = textView40;
        this.documentCard2 = relativeLayout4;
        this.ivDocument2 = imageView13;
        this.imageviewLicensePhoto = imageView14;
        this.frameLicenseQrcode = frameLayout4;
        this.imageviewLicenseBarcode = imageView15;
        this.imageviewLicenseQrLogo = imageView16;
        this.tvLicenseNameAr = textView41;
        this.tvLicenseNameEn = textView42;
        this.tvLicenseIdNumberAr = textView43;
        this.tvLicenseIdNumberEn = textView44;
        this.tvLicenseTypeAr = textView45;
        this.tvLicenseTypeEn = textView46;
        this.tvLicenseIssueDateAr = textView47;
        this.tvLicenseIssueDateEn = textView48;
        this.tvLicenseBirthDateAr = textView49;
        this.tvLicenseBirthDateEn = textView50;
        this.tvLicenseNationalityAr = textView51;
        this.tvLicenseNationalityEn = textView52;
        this.tvLicenseExpiryDateAr = textView53;
        this.tvLicenseExpiryDateEn = textView54;
        this.tvLicenseBloodTypeAr = textView55;
        this.tvLicenseBloodTypeEn = textView56;
    }

    public static DigitalDocumentsBinding bind(View view) {
        ScrollView scrollView = (ScrollView) view;
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear8);
        TextView textView = (TextView) findChildViewById(view, R.id.textview14);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvUpdateTime);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview_refresh);
        TextView textView4 = (TextView) findChildViewById(view, R.id.textview_citizen_title);
        CardView cardViewFindChildViewById = findChildViewById(view, R.id.documentCardCitizen);
        RelativeLayout relativeLayout = (RelativeLayout) findChildViewById(view, R.id.relativelayout6);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.img_citizen_card_bg);
        FrameLayout frameLayout = (FrameLayout) findChildViewById(view, R.id.frame_citizen_qrcode);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.img_citizen_qrcode);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.img_citizen_qr_logo);
        TextView textView5 = (TextView) findChildViewById(view, R.id.tv_citizen_copy_number);
        TextView textView6 = (TextView) findChildViewById(view, R.id.tv_citizen_name_ar);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tv_citizen_name_en);
        TextView textView8 = (TextView) findChildViewById(view, R.id.tv_citizen_id_number);
        TextView textView9 = (TextView) findChildViewById(view, R.id.tv_citizen_id_number_en);
        TextView textView10 = (TextView) findChildViewById(view, R.id.tv_citizen_birth_date);
        TextView textView11 = (TextView) findChildViewById(view, R.id.tv_citizen_birth_date_en);
        TextView textView12 = (TextView) findChildViewById(view, R.id.tv_citizen_expiry_date);
        TextView textView13 = (TextView) findChildViewById(view, R.id.tv_citizen_expiry_date_en);
        TextView textView14 = (TextView) findChildViewById(view, R.id.tv_citizen_birth_place);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.img_citizen_user_photo);
        TextView textView15 = (TextView) findChildViewById(view, R.id.textview15);
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.documentCard1);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.ivDocument1Background);
        TextView textView16 = (TextView) findChildViewById(view, R.id.tvCardCopyNumber);
        ImageView imageView6 = (ImageView) findChildViewById(view, R.id.imageview_id_photo);
        FrameLayout frameLayout2 = (FrameLayout) findChildViewById(view, R.id.frame_qrcode);
        ImageView imageView7 = (ImageView) findChildViewById(view, R.id.imageview_qrcode);
        ImageView imageView8 = (ImageView) findChildViewById(view, R.id.imageview_qr_logo);
        TextView textView17 = (TextView) findChildViewById(view, R.id.tvCardNameHome);
        TextView textView18 = (TextView) findChildViewById(view, R.id.tvCardNameEn);
        TextView textView19 = (TextView) findChildViewById(view, R.id.tvCardIdHome);
        TextView textView20 = (TextView) findChildViewById(view, R.id.tvCardBirthDate);
        TextView textView21 = (TextView) findChildViewById(view, R.id.tvCardExpiryDate);
        TextView textView22 = (TextView) findChildViewById(view, R.id.tvCardBirthPlace);
        TextView textView23 = (TextView) findChildViewById(view, R.id.tvCardReligion);
        TextView textView24 = (TextView) findChildViewById(view, R.id.tvCardNationality);
        TextView textView25 = (TextView) findChildViewById(view, R.id.tvCardProfession);
        TextView textView26 = (TextView) findChildViewById(view, R.id.tvCardEmployerId);
        TextView textView27 = (TextView) findChildViewById(view, R.id.tvCardIssuePlace);
        TextView textView28 = (TextView) findChildViewById(view, R.id.tvCardEmployerName);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.documentCardVisitor);
        ImageView imageView9 = (ImageView) findChildViewById(view, R.id.img_card_bg);
        ImageView imageView10 = (ImageView) findChildViewById(view, R.id.img_user_photo);
        FrameLayout frameLayout3 = (FrameLayout) findChildViewById(view, R.id.frame_visitor_qrcode);
        ImageView imageView11 = (ImageView) findChildViewById(view, R.id.img_visitor_qrcode);
        ImageView imageView12 = (ImageView) findChildViewById(view, R.id.img_visitor_qr_logo);
        TextView textView29 = (TextView) findChildViewById(view, R.id.tv_version_number);
        TextView textView30 = (TextView) findChildViewById(view, R.id.tv_name_ar);
        TextView textView31 = (TextView) findChildViewById(view, R.id.tv_name_en);
        TextView textView32 = (TextView) findChildViewById(view, R.id.tv_id_number);
        TextView textView33 = (TextView) findChildViewById(view, R.id.tv_issue_place);
        TextView textView34 = (TextView) findChildViewById(view, R.id.tv_issue_date);
        TextView textView35 = (TextView) findChildViewById(view, R.id.tv_expiry_date);
        TextView textView36 = (TextView) findChildViewById(view, R.id.tv_birth_date);
        TextView textView37 = (TextView) findChildViewById(view, R.id.tv_nationality);
        TextView textView38 = (TextView) findChildViewById(view, R.id.tv_visit_purpose);
        TextView textView39 = (TextView) findChildViewById(view, R.id.tv_blood_type);
        TextView textView40 = (TextView) findChildViewById(view, R.id.textview16);
        RelativeLayout relativeLayout4 = (RelativeLayout) findChildViewById(view, R.id.documentCard2);
        ImageView imageView13 = (ImageView) findChildViewById(view, R.id.ivDocument2);
        ImageView imageView14 = (ImageView) findChildViewById(view, R.id.imageview_license_photo);
        FrameLayout frameLayout4 = (FrameLayout) findChildViewById(view, R.id.frame_license_qrcode);
        ImageView imageView15 = (ImageView) findChildViewById(view, R.id.imageview_license_barcode);
        ImageView imageView16 = (ImageView) findChildViewById(view, R.id.imageview_license_qr_logo);
        TextView textView41 = (TextView) findChildViewById(view, R.id.tvLicenseNameAr);
        TextView textView42 = (TextView) findChildViewById(view, R.id.tvLicenseNameEn);
        TextView textView43 = (TextView) findChildViewById(view, R.id.tvLicenseIdNumberAr);
        TextView textView44 = (TextView) findChildViewById(view, R.id.tvLicenseIdNumberEn);
        TextView textView45 = (TextView) findChildViewById(view, R.id.tvLicenseTypeAr);
        TextView textView46 = (TextView) findChildViewById(view, R.id.tvLicenseTypeEn);
        TextView textView47 = (TextView) findChildViewById(view, R.id.tvLicenseIssueDateAr);
        TextView textView48 = (TextView) findChildViewById(view, R.id.tvLicenseIssueDateEn);
        TextView textView49 = (TextView) findChildViewById(view, R.id.tvLicenseBirthDateAr);
        TextView textView50 = (TextView) findChildViewById(view, R.id.tvLicenseBirthDateEn);
        TextView textView51 = (TextView) findChildViewById(view, R.id.tvLicenseNationalityAr);
        TextView textView52 = (TextView) findChildViewById(view, R.id.tvLicenseNationalityEn);
        TextView textView53 = (TextView) findChildViewById(view, R.id.tvLicenseExpiryDateAr);
        TextView textView54 = (TextView) findChildViewById(view, R.id.tvLicenseExpiryDateEn);
        TextView textView55 = (TextView) findChildViewById(view, R.id.tvLicenseBloodTypeAr);
        TextView textView56 = (TextView) findChildViewById(view, R.id.tvLicenseBloodTypeEn);
        if (linearLayout == null || textView == null || textView2 == null || textView3 == null || textView4 == null || cardViewFindChildViewById == null || relativeLayout == null || imageView == null || frameLayout == null || imageView2 == null || imageView3 == null || textView5 == null || textView6 == null || textView7 == null || textView8 == null || textView9 == null || textView10 == null || textView11 == null || textView12 == null || textView13 == null || textView14 == null || imageView4 == null || textView15 == null || relativeLayout2 == null || imageView5 == null || textView16 == null || imageView6 == null || frameLayout2 == null || imageView7 == null || imageView8 == null || textView17 == null || textView18 == null || textView19 == null || textView20 == null || textView21 == null || textView22 == null || textView23 == null || textView24 == null || textView25 == null || textView26 == null || textView27 == null || textView28 == null || relativeLayout3 == null || imageView9 == null || imageView10 == null || frameLayout3 == null || imageView11 == null || imageView12 == null || textView29 == null || textView30 == null || textView31 == null || textView32 == null || textView33 == null || textView34 == null || textView35 == null || textView36 == null || textView37 == null || textView38 == null || textView39 == null || textView40 == null || relativeLayout4 == null || imageView13 == null || imageView14 == null || frameLayout4 == null || imageView15 == null || imageView16 == null || textView41 == null || textView42 == null || textView43 == null || textView44 == null || textView45 == null || textView46 == null || textView47 == null || textView48 == null || textView49 == null || textView50 == null || textView51 == null || textView52 == null || textView53 == null || textView54 == null || textView55 == null || textView56 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new DigitalDocumentsBinding(scrollView, linearLayout, textView, textView2, textView3, textView4, cardViewFindChildViewById, relativeLayout, imageView, frameLayout, imageView2, imageView3, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13, textView14, imageView4, textView15, relativeLayout2, imageView5, textView16, imageView6, frameLayout2, imageView7, imageView8, textView17, textView18, textView19, textView20, textView21, textView22, textView23, textView24, textView25, textView26, textView27, textView28, relativeLayout3, imageView9, imageView10, frameLayout3, imageView11, imageView12, textView29, textView30, textView31, textView32, textView33, textView34, textView35, textView36, textView37, textView38, textView39, textView40, relativeLayout4, imageView13, imageView14, frameLayout4, imageView15, imageView16, textView41, textView42, textView43, textView44, textView45, textView46, textView47, textView48, textView49, textView50, textView51, textView52, textView53, textView54, textView55, textView56);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static DigitalDocumentsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static DigitalDocumentsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.digital_documents, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public ScrollView getRoot() {
        return this.rootView;
    }
}
