package android.net.http;

import java.io.File;

public class HttpsConnection extends Connection {
    protected SslCertificate mCertificate;
    protected AndroidHttpClientConnection mHttpClientConnection;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    HttpsConnection() {
        super(null, null, null);
        throw new RuntimeException("Stub!");
    }

    public static void initializeEngine(File file) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
