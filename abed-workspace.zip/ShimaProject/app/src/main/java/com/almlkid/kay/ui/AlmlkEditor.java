package com.almlkid.kay.ui;

import android.content.Context;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import almlk.CodeEditorView;
import almlk.DiagnosticUnderline;
import almlk.IdentifierBounds;
import almlk.LineDocument;
import almlk.LineStyler;
import almlk.XmlColorLiteral;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.shima.demo.ThemeConfig;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * واجهة المحرر الرسمية للتطبيق — نفس اسم الكلاس والـAPI العام كما كان، لكنها بعد بند الإحلال
 * (البند 4) يقودها محرك almlk الكامل: لوحة رسم مخصصة + موديل أسطر + ملوّن تزايدي خلفي +
 * إدخال OEditor + تراجع مدمج. حُذف مسار EditText/Spans القديم نهائيًا (لا مساران متوازيان).
 *
 * <p>محوّلات التوافق الباقية (adapters — يسمح بها البند 4): التشخيصات والإكمال والتنسيق عبر
 * {@link CodeLanguageTools}، وفهرسة الرموز عبر ProjectSymbolIndex من طبقة الـPager كما كانت.
 */
public class AlmlkEditor extends CodeEditorView {

  public interface DiagnosticsListener {
    void onDiagnostics(List<CodeLanguageTools.Diagnostic> items);
  }

  public interface ChangeListener {
    void onChanged(long documentVersion);
  }

  public interface ScrollListener {
    void onEditorScroll(int x, int y);

    void onEditorZoom(float textSizePixels);
  }

  /** نتيجة تأكيد معاملة لون: تطبيق واحد، أو لا تغيير، أو إلغاء لأن المصدر صار بائتًا. */
  public enum ColorLiteralEditResult {
    APPLIED,
    UNCHANGED,
    STALE
  }

  /** لقطة غير قابلة للتعديل لهوية literal عند فتح المنتقي. */
  public static final class ColorLiteralEdit {
    private final long documentVersion;
    private final int startOffset;
    private final int endOffset;
    private final int line;
    private final int startColumn;
    private final int endColumn;
    private final int originalArgb;
    private final XmlColorLiteral.Format format;
    private final XmlColorLiteral literal;
    private final String originalText;

    private ColorLiteralEdit(
        long documentVersion,
        int startOffset,
        int endOffset,
        XmlColorLiteral literal,
        String originalText) {
      this.documentVersion = documentVersion;
      this.startOffset = startOffset;
      this.endOffset = endOffset;
      this.line = literal.line;
      this.startColumn = literal.startColumn;
      this.endColumn = literal.endColumn;
      this.originalArgb = literal.argb;
      this.format = literal.format;
      this.literal = literal;
      this.originalText = originalText;
    }

    public int originalArgb() {
      return originalArgb;
    }
  }

  // ---------------- الحقول ----------------

  private int keyword, string, comment, number, annotation, tag, identifier, function, variable,
      operator, namespace, separator;
  private int plainColor = 0xFFECEFF1;

  private String fileName = "";
  private volatile boolean analysisPaused;

  private final LineStyler styler;
  private final ExecutorService diagnosticsWorker = Executors.newSingleThreadExecutor();
  private final Runnable diagnosticsTask = this::runDiagnostics;
  private List<CodeLanguageTools.Diagnostic> diagnostics = Collections.emptyList();
  private List<ProjectDiagnostic> projectDiagnostics = Collections.emptyList();
  private final HashMap<Integer, Integer> lineFlags = new HashMap<>();
  private final HashMap<Integer, DiagnosticUnderline[]> diagnosticUnderlines = new HashMap<>();
  // المرحلة 5: نقاط توقف منفصلة عن أعلام التشخيص فلا تمسحها updateDiagnostics.
  private final java.util.HashSet<Integer> breakpoints = new java.util.HashSet<>();

  private ChangeListener changeListener;
  private ScrollListener scrollListener;
  private DiagnosticsListener diagnosticsListener;
  private final ArrayList<TextWatcher> watchers = new ArrayList<>();

  /** مخزن النص الكامل بالإصدار — يبنى مرة لكل إصدار (callers تقرأه بلا كلفة متكررة). */
  private String textCache = "";
  private long textCacheVersion = -1;
  private String lastDispatchedText = "";

  public AlmlkEditor(Context context) {
    this(context, null);
  }

  public AlmlkEditor(Context context, AttributeSet attrs) {
    this(context, attrs, 0);
  }

  public AlmlkEditor(Context context, AttributeSet attrs, int style) {
    super(context);
    styler = new LineStyler(getDocument());
    styler.setListener((from, to) -> postInvalidate());
    setStyleProvider(
        new StyleProvider() {
          @Override
          public int[] lineStyles(LineDocument document, int line) {
            return styler.stylesForLine(line);
          }

          @Override
          public int colorFor(int styleId) {
            return AlmlkEditor.this.colorFor(styleId);
          }
        });
    setColorDecorationProvider((document, line) -> styler.colorLiteralsForLine(line));
    setDiagnosticDecorationProvider(
        (document, line) -> diagnosticUnderlines.get(line));
    setLineFlagProvider(
        line -> {
          int flags;
          synchronized (lineFlags) {
            Integer f = lineFlags.get(line);
            flags = f == null ? 0 : f;
          }
          synchronized (breakpoints) {
            if (breakpoints.contains(line)) flags |= FLAG_BREAKPOINT;
          }
          return flags;
        });
    setReplacementListener(this::onContentReplaced);
    applyEditorInteraction();
    applyTheme();
  }

  // ---------------- التوصيل بطبقة الإدخال (hooks من CodeEditorView) ----------------

  private void applyEditorInteraction() {
    // CodeEditorView يملك بالفعل مستمع تفاعلات للوحة (قائمة التحديد/الكيبورد)؛ هنا نضيف
    // بثّ التمرير/التكبير الخارجي عبر hooks محمية في الأب.
  }

  @Override
  protected void onEditorScrolledExternal(int x, int y) {
    ScrollListener listener = scrollListener;
    if (listener != null) listener.onEditorScroll(x, y);
  }

  @Override
  protected void onEditorZoomedExternal(float textSizePixels) {
    ScrollListener listener = scrollListener;
    if (listener != null) listener.onEditorZoom(textSizePixels);
  }

  // ---------------- نص الواجهة (CharSequence المقروء) ----------------

  public String currentText() {
    long version = getDocument().version();
    if (version != textCacheVersion) {
      textCacheVersion = version;
      textCache = getDocument().toString();
    }
    return textCache;
  }

  /** متوافق مع EditText.getText() — للقراءة فقط. التحرير يمر بـ replaceRange/الإدخال. */
  public CharSequence getText() {
    return currentText();
  }

  public void setText(CharSequence text) {
    String before = currentText();
    getDocument().setAll(text == null ? "" : text.toString());
    clearHistory();
    clearSelection();
    setCaret(0, 0);
    styler.request(0, Integer.MAX_VALUE);
    scrollTo(0, 0);
    dispatchTextChanged(before, currentText(), 0, before.length());
    scheduleDiagnostics(120);
  }

  public int length() {
    return getDocument().length();
  }

  // ---------------- التحديد بالإزاحات (واجهة TextView) ----------------

  public int getSelectionStart() {
    return selectionOffsets()[0];
  }

  public int getSelectionEnd() {
    return selectionOffsets()[1];
  }

  public void setSelection(int index) {
    int offset = Math.max(0, Math.min(index, length()));
    int line = getDocument().lineForOffset(offset);
    setCaret(line, offset - getDocument().lineStartOffset(line));
  }

  public void setSelection(int start, int end) {
    int from = Math.max(0, Math.min(Math.min(start, end), length()));
    int to = Math.max(from, Math.min(Math.max(start, end), length()));
    if (from == to) {
      setSelection(from);
      return;
    }
    int startLine = getDocument().lineForOffset(from);
    int endLine = getDocument().lineForOffset(to);
    setSelectionRange(
        startLine, from - getDocument().lineStartOffset(startLine),
        endLine, to - getDocument().lineStartOffset(endLine));
  }

  /**
   * قيمة اللون التي تحتوي المؤشر المطوي أو التحديد كله. النهاية حصرية، والتحديد العابر لسطر
   * أو لاقتباس/قيمة ثانية لا يطابق. هذه هي بوابة الأهلية الموحدة؛ لا فحص Hex نصي موازٍ.
   */
  public XmlColorLiteral colorLiteralForSelection() {
    int start = getSelectionStart();
    int end = getSelectionEnd();
    int from = Math.min(start, end);
    int to = Math.max(start, end);
    LineDocument document = getDocument();
    int startLine = document.lineForOffset(from);
    int endLine = document.lineForOffset(to);
    if (startLine != endLine) return null;
    int lineStart = document.lineStartOffset(startLine);
    int startColumn = from - lineStart;
    int endColumn = to - lineStart;
    XmlColorLiteral[] literals = styler.colorLiteralsForLine(startLine);
    return from == to
        ? XmlColorLiteral.atColumn(literals, startColumn)
        : XmlColorLiteral.containingRange(literals, startColumn, endColumn);
  }

  /** مدى القيمة الحالية كإزاحتين مطلقتين، أو null إن كان المؤشر/التحديد خارج قيمة واحدة. */
  public int[] colorLiteralSelectionRange() {
    XmlColorLiteral literal = colorLiteralForSelection();
    if (literal == null) return null;
    int lineStart = getDocument().lineStartOffset(literal.line);
    return new int[] {lineStart + literal.startColumn, lineStart + literal.endColumn};
  }

  /** يطبّع المؤشر أو التحديد الجزئي داخل اللون إلى القيمة كاملة شاملة #. */
  public boolean normalizeSelectionToColorLiteral() {
    int[] range = colorLiteralSelectionRange();
    if (range == null) return false;
    if (getSelectionStart() != range[0] || getSelectionEnd() != range[1])
      setSelection(range[0], range[1]);
    return true;
  }

  /** يبدأ معاملة اللون من الفهرس الحالي بعد تطبيع المدى؛ لا يغيّر النص أو سجل التراجع. */
  public ColorLiteralEdit beginColorLiteralEdit() {
    if (!normalizeSelectionToColorLiteral()) return null;
    LineDocument document = getDocument();
    synchronized (document) {
      XmlColorLiteral literal = colorLiteralForSelection();
      if (literal == null) return null;
      int start = document.lineStartOffset(literal.line) + literal.startColumn;
      int end = document.lineStartOffset(literal.line) + literal.endColumn;
      return new ColorLiteralEdit(
          document.version(), start, end, literal, document.subText(start, end));
    }
  }

  /**
   * يؤكد معاملة اللون ذريًا بالنسبة للمستند. أي تغير بعد فتح الحوار، أو اختلاف في المدى/الفهرس،
   * يعيد STALE بلا كتابة. النجاح يستدعي replaceRange مرة واحدة فقط، لذلك Undo خطوة واحدة.
   */
  public ColorLiteralEditResult applyColorLiteralEdit(ColorLiteralEdit edit, int newArgb) {
    if (edit == null) return ColorLiteralEditResult.STALE;
    LineDocument document = getDocument();
    synchronized (document) {
      if (document.version() != edit.documentVersion) return ColorLiteralEditResult.STALE;
      if (edit.line < 0 || edit.line >= document.lineCount()) return ColorLiteralEditResult.STALE;
      int lineStart = document.lineStartOffset(edit.line);
      if (lineStart + edit.startColumn != edit.startOffset
          || lineStart + edit.endColumn != edit.endOffset)
        return ColorLiteralEditResult.STALE;
      XmlColorLiteral current = XmlColorLiteral.atColumn(
          styler.colorLiteralsForLine(edit.line), edit.startColumn);
      if (current == null
          || current.startColumn != edit.startColumn
          || current.endColumn != edit.endColumn
          || current.argb != edit.originalArgb
          || current.format != edit.format
          || !document.subText(edit.startOffset, edit.endOffset).equals(edit.originalText))
        return ColorLiteralEditResult.STALE;

      String replacement = edit.literal.formatReplacement(newArgb);
      if (replacement.equals(edit.originalText)) return ColorLiteralEditResult.UNCHANGED;
      replaceRange(edit.startOffset, edit.endOffset, replacement);
      return ColorLiteralEditResult.APPLIED;
    }
  }

  public int[] selectionOrIdentifier() {
    // اللون يسبق IdentifierBounds: خاناته الرقمية ليست معرفًا منفصلًا، و# جزء من الكيان.
    int[] colorRange = colorLiteralSelectionRange();
    if (colorRange != null) return colorRange;
    int start = getSelectionStart(), end = getSelectionEnd();
    if (start != end) return new int[] {start, end};
    String text = currentText();
    if (text.isEmpty() || start >= text.length())
      return new int[] {Math.max(0, Math.min(start, text.length())),
          Math.max(0, Math.min(start, text.length()))};
    int from = IdentifierBounds.start(text, start);
    int to = IdentifierBounds.end(text, start);
    return new int[] {from, to};
  }

  public void normalizeSelectionToTouchedIdentifier() {
    int selectionStart = getSelectionStart();
    int selectionEnd = getSelectionEnd();
    int[] range = colorLiteralSelectionRange();
    if (range == null && selectionStart != selectionEnd) {
      range = IdentifierBounds.wholeIdentifierForSelection(
          currentText(), selectionStart, selectionEnd);
      if (range == null) range = new int[] {selectionStart, selectionEnd};
    } else if (range == null) {
      range = selectionOrIdentifier();
    }
    // لا نعيد كتابة التحديد المطابق: setSelectionRange يغيّر provenance اللمس إلى برمجي.
    if (range[0] < range[1]
        && (range[0] != selectionStart || range[1] != selectionEnd)) {
      setSelection(range[0], range[1]);
    }
  }

  // ---------------- TextWatcher مكافئ (الـPager يعتمدها) ----------------

  public void addTextChangedListener(TextWatcher watcher) {
    if (!watchers.contains(watcher)) watchers.add(watcher);
  }

  public void removeTextChangedListener(TextWatcher watcher) {
    watchers.remove(watcher);
  }

  private void dispatchTextChanged(String before, String after, int start, int removedCount) {
    int addedCount = Math.max(0, after.length() - (before.length() - removedCount));
    for (int i = watchers.size() - 1; i >= 0; i--) {
      TextWatcher watcher = watchers.get(i);
      watcher.beforeTextChanged(before, start, removedCount, addedCount);
      watcher.onTextChanged(after, start, removedCount, addedCount);
      watcher.afterTextChanged(null);
    }
    lastDispatchedText = after;
  }

  private void onContentReplaced(int start, int removedCount, int insertedCount) {
    String before = lastDispatchedText;
    String after = currentText();
    dispatchTextChanged(before, after, start, removedCount);
    ChangeListener listener = changeListener;
    if (listener != null) listener.onChanged(getDocument().version());
    scheduleDiagnostics(600);
  }

  // ---------------- المستمعون الخارجيون ----------------

  public void setChangeListener(ChangeListener listener) {
    changeListener = listener;
  }

  public void setScrollListener(ScrollListener listener) {
    scrollListener = listener;
  }

  public void setDiagnosticsListener(DiagnosticsListener listener) {
    diagnosticsListener = listener;
  }

  /** Replaces external project/compiler markers for the current file without changing text state. */
  public void setProjectDiagnostics(List<ProjectDiagnostic> values) {
    projectDiagnostics =
        values == null || values.isEmpty()
            ? Collections.emptyList()
            : new ArrayList<>(values);
    rebuildDiagnosticDecorations();
    invalidate();
  }

  public void setAnalysisPaused(boolean paused) {
    analysisPaused = paused;
    styler.setPaused(paused);
    if (paused) removeCallbacks(diagnosticsTask);
    else refreshNow();
  }

  /** توافق واجهة EditText: عناصر قائمة تحديد مخصصة تُلحق بالقائمة المدمجة. */
  public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
    if (callback == null) {
      setActionModeContributor(null);
      return;
    }
    setActionModeContributor(
        new ActionModeContributor() {
          @Override
          public void onCreateMenu(ActionMode mode, Menu menu) {
            callback.onCreateActionMode(mode, menu);
          }

          @Override
          public boolean onPrepareMenu(ActionMode mode, Menu menu) {
            return callback.onPrepareActionMode(mode, menu);
          }

          @Override
          public boolean onMenuItem(ActionMode mode, MenuItem item) {
            return callback.onActionItemClicked(mode, item);
          }

          @Override
          public void onDestroy(ActionMode mode) {
            callback.onDestroyActionMode(mode);
          }
        });
  }

  /** توافق TextView.setLineSpacing (الإضافة بالبكسل تمرر لمقاسات اللوحة). */
  public void setLineSpacing(float add, float mult) {
    setLineSpacingExtra(mult <= 0 ? add : add * mult);
  }

  /** توافق TextView.setHint بمورد نصي. */
  public void setHint(int resource) {
    setHint(getContext().getString(resource));
  }

  /** توافق EditText.onTextContextMenuItem (قائمة السياق أندرويد من الـPager). */
  public boolean onTextContextMenuItem(int id) {
    if (id == android.R.id.selectAll) {
      selectAll();
      return true;
    }
    if (id == android.R.id.cut) {
      cutSelection();
      return true;
    }
    if (id == android.R.id.copy) {
      copySelection();
      return true;
    }
    if (id == android.R.id.paste) {
      pasteClipboard();
      return true;
    }
    return false;
  }

  /** توافق EditText.bringPointIntoView: التمرير حتى تظهر الإزاحة (بحث/انتقال). */
  public boolean bringPointIntoView(int offset) {
    return scrollOffsetIntoView(offset);
  }

  /** موضع إزاحة داخل الـView: [x أفقي، y أسفل السطر] — بديل Layout القديم لنوافذ الإكمال. */
  public int[] offsetToViewPosition(int offset) {
    int clamped = Math.max(0, Math.min(offset, length()));
    int line = getDocument().lineForOffset(clamped);
    int column = clamped - getDocument().lineStartOffset(line);
    float x = columnToContentX(line, column) - getScrollX();
    float y = (line + 1) * lineStride() - getScrollY();
    return new int[] {(int) x, (int) y};
  }

  // ---------------- الملف والتحليل ----------------

  public void setFileName(String name) {
    fileName = name == null ? "" : name;
    styler.setFileName(fileName);
    scheduleDiagnostics(150);
  }

  /**
   * توافق تاريخي مع استدعاء الـPager بعد الحفظ: الموديل الجديد هو المرجع الوحيد فلا شيء
   * يُعاد ربطه — يكتفي بتحديث اسم الملف.
   */
  public void resetCoreModel(String uri, CharSequence currentText) {
    setFileName(uri);
  }

  /** تنسيق بأسلوب جافا بإزاحة من تفضيل المستخدم — المرحلة الثامنة. */
  public String formatCode() {
    return CodeLanguageTools.format(
        currentText(), almlk.CodeStyle.indentSizeFor(getContext(), fileName));
  }

  public void refreshNow() {
    if (analysisPaused) return;
    styler.request(0, Integer.MAX_VALUE);
    scheduleDiagnostics(250);
  }

  public List<String> completions() {
    return CodeLanguageTools.complete(fileName, currentText(), getSelectionStart());
  }

  public void applyCompletion(String value) {
    String text = currentText();
    int cursor = Math.max(0, Math.min(getSelectionStart(), text.length()));
    int start =
        Math.max(0, Math.min(CodeLanguageTools.completionStart(fileName, text, cursor), cursor));
    replaceRange(start, cursor, value);
    int target = start + value.length();
    if (value.endsWith("()")) target--;
    setSelection(Math.min(target, length()));
    requestFocus();
  }

  /** المراحل 1-4: اقتراحات مُنمَّطة من فهرس الرموز (دالة/متغير/كلاس/XML/بناء). */
  public java.util.List<com.almlkid.kay.ui.ProjectSymbolIndex.CompletionItem> typedCompletions() {
    return com.almlkid.kay.ui.ProjectSymbolIndex.complete(
        fileName, currentText(), getSelectionStart());
  }

  /** التزام ذكي: يُدرج التوقيع ويضع المؤشر، وللكلاسات **يضيف import تلقائيًا** (المرحلة 3). */
  public void applyTypedCompletion(com.almlkid.kay.ui.ProjectSymbolIndex.CompletionItem item) {
    if (item == null) return;
    String text = currentText();
    int cursor = Math.max(0, Math.min(getSelectionStart(), text.length()));
    int start =
        Math.max(0, Math.min(CodeLanguageTools.completionStart(fileName, text, cursor), cursor));
    String insert = item.insertText == null ? item.label : item.insertText;
    boolean isMethod = item.kind == com.almlkid.kay.ui.ProjectSymbolIndex.CompletionItem.METHOD;
    String replacement = insert;
    int caret;
    if (isMethod && insert.indexOf('(') < 0) {
      replacement = insert + "()";
      caret = start + insert.length() + 1;
    } else if (insert.endsWith("()")) {
      caret = start + insert.length() - 1;
    } else {
      caret = start + insert.length();
    }
    replaceRange(start, cursor, replacement);
    if (item.kind == com.almlkid.kay.ui.ProjectSymbolIndex.CompletionItem.CLASS) {
      addImportIfNeeded(item.label);
    }
    setSelection(Math.min(caret, length()));
    requestFocus();
  }

  /** يُدرج {@code import حزمة.كلاس;} بعد آخر استيراد إن كان الصنف من حزمة أخرى غير مستوردة. */
  private void addImportIfNeeded(String className) {
    String simple = className.contains(".")
        ? className.substring(className.lastIndexOf('.') + 1)
        : className;
    String pkg = com.almlkid.kay.ui.ProjectSymbolIndex.packageOf(simple);
    if (pkg == null || pkg.isEmpty() || pkg.equals("java.lang")) return;
    String text = currentText();
    String currentPkg = parsePackage(text);
    if (pkg.equals(currentPkg)) return;
    if (text.contains("import " + pkg + "." + simple + ";")
        || text.contains("import " + pkg + ".*;")) return;
    int insertAt;
    int lastImport = text.lastIndexOf("import ");
    if (lastImport >= 0) {
      int end = text.indexOf(';', lastImport);
      insertAt = end >= 0 ? end + 1 : lastImport;
    } else {
      int pkgLine = text.indexOf("package ");
      if (pkgLine >= 0) {
        int end = text.indexOf(';', pkgLine);
        insertAt = end >= 0 ? end + 1 : 0;
      } else {
        insertAt = 0;
      }
    }
    replaceRange(insertAt, insertAt, "\nimport " + pkg + "." + simple + ";");
  }

  private static String parsePackage(String text) {
    int idx = text.indexOf("package ");
    if (idx < 0) return null;
    int end = text.indexOf(';', idx);
    if (end < 0) return null;
    return text.substring(idx + 8, end).trim();
  }

  // ---------------- التشخيصات (محوّل — كما كانت، خلفية + أعلام سطور بدل Spans) ----------------

  private void scheduleDiagnostics(long delayMs) {
    if (analysisPaused) return;
    removeCallbacks(diagnosticsTask);
    postDelayed(diagnosticsTask, delayMs);
  }

  private void runDiagnostics() {
    if (analysisPaused) return;
    final String name = fileName;
    final long documentVersion = getDocument().version();
    final String text = currentText();
    if (text.length() > CodeLanguageTools.MAX_CHECKED_CHARS || name.isEmpty()) {
      // سياسة الملفات الضخمة: فوق السقف لا تشخيص كامل — يبقى التلوين التزايدي وحده.
      updateDiagnostics(Collections.<CodeLanguageTools.Diagnostic>emptyList());
      return;
    }
    diagnosticsWorker.execute(
        () -> {
          try {
            final List<CodeLanguageTools.Diagnostic> found = CodeLanguageTools.inspect(name, text);
            post(
                () -> {
                  if (!name.equals(fileName) || documentVersion != getDocument().version()) return;
                  updateDiagnostics(found);
                });
          } catch (Throwable error) {
            Log.w("AlmlkEditor", "diagnostics failed", error);
          }
        });
  }

  private void updateDiagnostics(List<CodeLanguageTools.Diagnostic> found) {
    if (analysisPaused) return;
    diagnostics = found == null ? Collections.emptyList() : new ArrayList<>(found);
    rebuildDiagnosticDecorations();
    invalidate();
    DiagnosticsListener listener = diagnosticsListener;
    if (listener != null) listener.onDiagnostics(getDiagnostics());
  }

  private void rebuildDiagnosticDecorations() {
    HashMap<Integer, ArrayList<DiagnosticUnderline>> collected = new HashMap<>();
    HashMap<Integer, Integer> flagsByLine = new HashMap<>();
    java.util.HashSet<String> seenRanges = new java.util.HashSet<>();
    for (CodeLanguageTools.Diagnostic item : diagnostics) {
      if (item != null)
        addDiagnosticRange(
            collected, flagsByLine, seenRanges, item.line, item.column,
            item.column + Math.max(1, item.end - item.offset), item.severity);
    }
    for (ProjectDiagnostic item : projectDiagnostics) {
      if (item == null || item.diagnostic == null) continue;
      addDiagnosticRange(
          collected, flagsByLine, seenRanges, item.diagnostic.line,
          item.diagnostic.column, item.endColumn, item.diagnostic.severity);
    }
    diagnosticUnderlines.clear();
    for (java.util.Map.Entry<Integer, ArrayList<DiagnosticUnderline>> entry : collected.entrySet())
      diagnosticUnderlines.put(
          entry.getKey(), entry.getValue().toArray(new DiagnosticUnderline[0]));
    synchronized (lineFlags) {
      lineFlags.clear();
      lineFlags.putAll(flagsByLine);
    }
  }

  private void addDiagnosticRange(
      HashMap<Integer, ArrayList<DiagnosticUnderline>> collected,
      HashMap<Integer, Integer> flagsByLine,
      java.util.Set<String> seenRanges,
      int oneBasedLine,
      int oneBasedColumn,
      int oneBasedEndColumn,
      CodeLanguageTools.Diagnostic.Severity severity) {
    int line = Math.max(0, oneBasedLine - 1);
    int start = Math.max(0, oneBasedColumn - 1);
    int end = Math.max(start + 1, oneBasedEndColumn - 1);
    boolean warning = severity == CodeLanguageTools.Diagnostic.Severity.WARNING;
    String key = line + ":" + start + ":" + end + ":" + warning;
    if (seenRanges.add(key)) {
      ArrayList<DiagnosticUnderline> ranges = collected.get(line);
      if (ranges == null) {
        ranges = new ArrayList<>();
        collected.put(line, ranges);
      }
      ranges.add(new DiagnosticUnderline(start, end, warning));
    }
    int flag = warning ? FLAG_WARNING : FLAG_ERROR;
    Integer current = flagsByLine.get(line);
    flagsByLine.put(line, (current == null ? 0 : current) | flag);
  }

  public List<CodeLanguageTools.Diagnostic> getDiagnostics() {
    return new ArrayList<>(diagnostics);
  }

  // ---------------- المرحلة 5: نقاط التوقف ----------------
  /** يبدّل نقطة توقف عند سطر المؤشر؛ يعيد true إن صارت مضبوطة. */
  public boolean toggleBreakpointAtCaret() {
    int line = lineOfOffset(getSelectionStart());
    boolean nowSet;
    synchronized (breakpoints) {
      if (breakpoints.contains(line)) { breakpoints.remove(line); nowSet = false; }
      else { breakpoints.add(line); nowSet = true; }
    }
    invalidate();
    return nowSet;
  }

  public boolean hasBreakpoint(int line) {
    synchronized (breakpoints) { return breakpoints.contains(line); }
  }

  private int lineOfOffset(int offset) {
    String t = currentText();
    int n = Math.max(0, Math.min(offset, t.length()));
    int line = 0;
    for (int i = 0; i < n; i++) if (t.charAt(i) == '\n') line++;
    return line;
  }

  // ---------------- الثيم والألوان ----------------

  public void applyTheme() {
    ThemeConfig theme = new ThemeConfig(getContext());
    keyword = theme.color(ThemeConfig.KEYWORD);
    string = theme.color(ThemeConfig.LITERAL);
    comment = theme.color(ThemeConfig.COMMENT);
    number = theme.color(ThemeConfig.LITERAL);
    annotation = theme.color(ThemeConfig.TYPE); // @Annotation اسم نوع — أزرق كما في المصدر
    tag = theme.color(ThemeConfig.TYPE);
    identifier = theme.color(ThemeConfig.IDENTIFIER);
    function = theme.color(ThemeConfig.FUNCTION);
    variable = theme.color(ThemeConfig.VARIABLE);
    operator = theme.color(ThemeConfig.OPERATOR);
    namespace = theme.color(ThemeConfig.NAMESPACE);
    separator = theme.color(ThemeConfig.SEPARATOR);
    plainColor = theme.color(ThemeConfig.PLAIN);

    int background = theme.color(ThemeConfig.BACKGROUND);
    int backgroundRgb = background | 0xFF000000;
    int gutterBackground =
        (((int) ((backgroundRgb & 0xFF) * 1.15f) & 0xFF))
            | (((int) (((backgroundRgb >> 8) & 0xFF) * 1.15f) & 0xFF) << 8)
            | (((int) (((backgroundRgb >> 16) & 0xFF) * 1.15f) & 0xFF) << 16)
            | 0xFF000000;
    setEditorColors(
        plainColor,
        theme.color(ThemeConfig.LINE_NUMBER),
        background,
        gutterBackground,
        theme.color(ThemeConfig.SELECTED_LINE),
        theme.color(ThemeConfig.SELECTED_TEXT),
        plainColor,
        theme.color(ThemeConfig.OPERATOR));
    setFlagColors(0xFFEF5350, 0xFFFFA726, 0xFFEC407A, 0xFF42A5F5);
    refreshNow();
  }

  public int colorFor(int type) {
    switch (type) {
      case CodeLanguageTools.KEYWORD:
        return keyword;
      case CodeLanguageTools.STRING:
        return string;
      case CodeLanguageTools.COMMENT:
        return comment;
      case CodeLanguageTools.NUMBER:
        return number;
      case CodeLanguageTools.ANNOTATION:
        return annotation;
      case CodeLanguageTools.TAG:
        return tag;
      case CodeLanguageTools.IDENTIFIER:
        return identifier;
      case CodeLanguageTools.FUNCTION:
        return function;
      case CodeLanguageTools.VARIABLE:
        return variable;
      case CodeLanguageTools.OPERATOR:
        return operator;
      case CodeLanguageTools.NAMESPACE:
        return namespace;
      case CodeLanguageTools.SEPARATOR:
        return separator;
      default:
        return plainColor;
    }
  }

  // ---------------- دورة الحياة ----------------

  @Override
  protected void onDetachedFromWindow() {
    removeCallbacks(diagnosticsTask);
    styler.shutdown();
    diagnosticsWorker.shutdownNow();
    super.onDetachedFromWindow();
  }
}
