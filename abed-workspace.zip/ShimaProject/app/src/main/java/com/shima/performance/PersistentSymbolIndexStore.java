package com.shima.performance;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Small SQLite persistence layer for parsed project symbols.
 *
 * <p>Only source fingerprints and parsed symbols are stored. Source text is never copied into the
 * database. A matching fingerprint restores the in-memory index without opening or parsing Java
 * files during the next project open.
 */
public final class PersistentSymbolIndexStore implements AutoCloseable {
  private static final String DB_NAME = "shima-symbol-index.db";
  private static final int DB_VERSION = 2;
  private final Helper helper;

  public PersistentSymbolIndexStore(Context context) {
    helper = new Helper(context.getApplicationContext());
  }

  public List<ProjectSymbolIndex.CachedClass> loadIfFresh(
      String projectKey,
      String fileKey,
      String fileName,
      String reference,
      long size,
      long modified) {
    if (projectKey == null || projectKey.isEmpty() || fileKey == null || fileKey.isEmpty())
      return null;
    SQLiteDatabase db = helper.getReadableDatabase();
    String[] columns = {"file_name", "reference"};
    String where = "project_key=? AND file_key=? AND size=? AND modified=?";
    String[] args = {projectKey, fileKey, Long.toString(size), Long.toString(modified)};
    try (Cursor state = db.query("file_state", columns, where, args, null, null, null)) {
      if (!state.moveToFirst()) return null;
      if (!fileName.equals(state.getString(0)) || !reference.equals(state.getString(1))) return null;
    }

    ArrayList<ProjectSymbolIndex.CachedClass> classes = new ArrayList<>();
    String classWhere = "project_key=? AND file_key=?";
    String[] classArgs = {projectKey, fileKey};
    try (Cursor rows =
        db.query(
            "class_symbol",
            new String[] {"class_name", "parent", "package_name", "class_offset"},
            classWhere,
            classArgs,
            null,
            null,
            "class_name COLLATE NOCASE")) {
      while (rows.moveToNext()) {
        String className = rows.getString(0);
        ArrayList<ProjectSymbolIndex.CachedMember> members = new ArrayList<>();
        try (Cursor symbols =
            db.query(
                "member_symbol",
                new String[] {"name", "return_type", "parameters", "offset", "is_method"},
                "project_key=? AND file_key=? AND class_name=?",
                new String[] {projectKey, fileKey, className},
                null,
                null,
                "offset ASC")) {
          while (symbols.moveToNext()) {
            members.add(
                new ProjectSymbolIndex.CachedMember(
                    symbols.getString(0),
                    symbols.getString(1),
                    symbols.getString(2),
                    symbols.getInt(3),
                    symbols.getInt(4) != 0));
          }
        }
        classes.add(
            new ProjectSymbolIndex.CachedClass(
                className, rows.getString(1), fileName, reference, rows.getString(2),
                rows.getInt(3), members));
      }
    }
    return classes;
  }

  public void save(
      String projectKey,
      String fileKey,
      String fileName,
      String reference,
      long size,
      long modified,
      List<ProjectSymbolIndex.CachedClass> classes) {
    if (projectKey == null || projectKey.isEmpty() || fileKey == null || fileKey.isEmpty()) return;
    SQLiteDatabase db = helper.getWritableDatabase();
    db.beginTransaction();
    try {
      String where = "project_key=? AND file_key=?";
      String[] args = {projectKey, fileKey};
      db.delete("member_symbol", where, args);
      db.delete("class_symbol", where, args);
      db.delete("file_state", where, args);

      ContentValues state = new ContentValues();
      state.put("project_key", projectKey);
      state.put("file_key", fileKey);
      state.put("file_name", fileName == null ? "" : fileName);
      state.put("reference", reference == null ? "" : reference);
      state.put("size", size);
      state.put("modified", modified);
      db.insertOrThrow("file_state", null, state);

      if (classes != null) {
        for (ProjectSymbolIndex.CachedClass cached : classes) {
          if (cached == null) continue;
          ContentValues owner = new ContentValues();
          owner.put("project_key", projectKey);
          owner.put("file_key", fileKey);
          owner.put("class_name", cached.name);
          owner.put("parent", cached.parent);
          owner.put("package_name", cached.packageName);
          owner.put("class_offset", cached.offset);
          db.insertOrThrow("class_symbol", null, owner);
          for (ProjectSymbolIndex.CachedMember member : cached.members) {
            if (member == null) continue;
            ContentValues symbol = new ContentValues();
            symbol.put("project_key", projectKey);
            symbol.put("file_key", fileKey);
            symbol.put("class_name", cached.name);
            symbol.put("name", member.name);
            symbol.put("return_type", member.returnType);
            symbol.put("parameters", member.parameters);
            symbol.put("offset", member.offset);
            symbol.put("is_method", member.method ? 1 : 0);
            db.insertOrThrow("member_symbol", null, symbol);
          }
        }
      }
      db.setTransactionSuccessful();
    } finally {
      db.endTransaction();
    }
  }

  public void pruneProject(String projectKey, Set<String> activeFileKeys) {
    if (projectKey == null || projectKey.isEmpty()) return;
    SQLiteDatabase db = helper.getWritableDatabase();
    ArrayList<String> stale = new ArrayList<>();
    try (Cursor rows =
        db.query(
            "file_state",
            new String[] {"file_key"},
            "project_key=?",
            new String[] {projectKey},
            null,
            null,
            null)) {
      while (rows.moveToNext()) {
        String fileKey = rows.getString(0);
        if (activeFileKeys == null || !activeFileKeys.contains(fileKey)) stale.add(fileKey);
      }
    }
    db.beginTransaction();
    try {
      for (String fileKey : stale) {
        String where = "project_key=? AND file_key=?";
        String[] args = {projectKey, fileKey};
        db.delete("member_symbol", where, args);
        db.delete("class_symbol", where, args);
        db.delete("file_state", where, args);
      }
      db.setTransactionSuccessful();
    } finally {
      db.endTransaction();
    }
  }

  public void clearProject(String projectKey) {
    if (projectKey == null || projectKey.isEmpty()) return;
    SQLiteDatabase db = helper.getWritableDatabase();
    db.beginTransaction();
    try {
      String where = "project_key=?";
      String[] args = {projectKey};
      db.delete("member_symbol", where, args);
      db.delete("class_symbol", where, args);
      db.delete("file_state", where, args);
      db.setTransactionSuccessful();
    } finally {
      db.endTransaction();
    }
  }

  @Override
  public void close() {
    helper.close();
  }

  private static final class Helper extends SQLiteOpenHelper {
    Helper(Context context) {
      super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
      db.execSQL(
          "CREATE TABLE file_state ("
              + "project_key TEXT NOT NULL, file_key TEXT NOT NULL, file_name TEXT NOT NULL, "
              + "reference TEXT NOT NULL, size INTEGER NOT NULL, modified INTEGER NOT NULL, "
              + "PRIMARY KEY(project_key, file_key))");
      db.execSQL(
          "CREATE TABLE class_symbol ("
              + "project_key TEXT NOT NULL, file_key TEXT NOT NULL, class_name TEXT NOT NULL, "
              + "parent TEXT NOT NULL, package_name TEXT NOT NULL, class_offset INTEGER NOT NULL, "
              + "PRIMARY KEY(project_key, file_key, class_name))");
      db.execSQL(
          "CREATE TABLE member_symbol ("
              + "project_key TEXT NOT NULL, file_key TEXT NOT NULL, class_name TEXT NOT NULL, "
              + "name TEXT NOT NULL, return_type TEXT NOT NULL, parameters TEXT NOT NULL, "
              + "offset INTEGER NOT NULL, is_method INTEGER NOT NULL, "
              + "PRIMARY KEY(project_key, file_key, class_name, name, is_method))");
      db.execSQL("CREATE INDEX idx_class_name ON class_symbol(project_key, class_name)");
      db.execSQL(
          "CREATE INDEX idx_member_name ON member_symbol(project_key, class_name, name)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
      db.execSQL("DROP TABLE IF EXISTS member_symbol");
      db.execSQL("DROP TABLE IF EXISTS class_symbol");
      db.execSQL("DROP TABLE IF EXISTS file_state");
      onCreate(db);
    }
  }
}
