package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import com.a.a.a.a.a;

public final class ProfileBinding {
    public final LinearLayout bottomNavProfile;
    public final ImageView btnBackProfile;
    public final LinearLayout cardMyNationalId;
    public final LinearLayout cardMyPassport;
    public final CardView cardview6;
    public final ImageView imageview200;
    public final ImageView imageview201;
    public final ImageView imageview202;
    public final ImageView imageview203;
    public final ImageView imageview204;
    public final ImageView imageview205;
    public final ImageView imageview206;
    public final ImageView imageview207;
    public final ImageView imageview208;
    public final ImageView imageview209;
    public final ImageView imageview210;
    public final ImageView imgTravelHistory;
    public final ImageView ivUserPhotoProfile;
    public final LinearLayout layoutProfileCard;
    public final LinearLayout linear100;
    public final LinearLayout linear93;
    public final LinearLayout linear95;
    public final LinearLayout linear96;
    public final LinearLayout linear98;
    public final LinearLayout navFamily;
    public final LinearLayout navHome;
    public final LinearLayout navMyServices;
    public final LinearLayout navOtherServices;
    public final LinearLayout navWorkers;
    public final RelativeLayout relativelayout12;
    public final RelativeLayout rootView;
    public final LinearLayout rowDrivingLicense;
    public final LinearLayout rowFamilyRecord;
    public final LinearLayout rowRecruitmentRequests;
    public final ScrollView scrollProfile;
    public final Space space102;
    public final Space space103;
    public final Space space104;
    public final Space space94;
    public final Space space97;
    public final Space space99;
    public final TextView textview200;
    public final TextView textview201;
    public final TextView textview202;
    public final TextView textview203;
    public final TextView textview204;
    public final TextView textview205;
    public final TextView textview206;
    public final TextView textview207;
    public final TextView textview208;
    public final TextView textview209;
    public final TextView textview210;
    public final RelativeLayout topBarProfile;
    public final TextView tvGoToPersonalInfo;
    public final TextView tvInsideKingdom;
    public final TextView tvProfileTitle;
    public final TextView tvUserIdProfile;
    public final TextView tvUserNameProfile;
    public final View view101;

    private ProfileBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, LinearLayout linearLayout, LinearLayout linearLayout2, ImageView imageView2, TextView textView2, LinearLayout linearLayout3, ImageView imageView3, TextView textView3, LinearLayout linearLayout4, ImageView imageView4, TextView textView4, LinearLayout linearLayout5, ImageView imageView5, TextView textView5, LinearLayout linearLayout6, ImageView imageView6, TextView textView6, ScrollView scrollView, LinearLayout linearLayout7, Space space, LinearLayout linearLayout8, CardView cardView, ImageView imageView7, TextView textView7, LinearLayout linearLayout9, TextView textView8, ImageView imageView8, LinearLayout linearLayout10, TextView textView9, TextView textView10, Space space2, LinearLayout linearLayout11, LinearLayout linearLayout12, ImageView imageView9, TextView textView11, LinearLayout linearLayout13, ImageView imageView10, TextView textView12, Space space3, LinearLayout linearLayout14, LinearLayout linearLayout15, ImageView imageView11, TextView textView13, View view, LinearLayout linearLayout16, ImageView imageView12, TextView textView14, Space space4, RelativeLayout relativeLayout3, ImageView imageView13, TextView textView15, Space space5, LinearLayout linearLayout17, ImageView imageView14, TextView textView16, Space space6) {
        this.rootView = relativeLayout;
        this.topBarProfile = relativeLayout2;
        this.btnBackProfile = imageView;
        this.tvProfileTitle = textView;
        this.bottomNavProfile = linearLayout;
        this.navHome = linearLayout2;
        this.imageview200 = imageView2;
        this.textview200 = textView2;
        this.navMyServices = linearLayout3;
        this.imageview201 = imageView3;
        this.textview201 = textView3;
        this.navFamily = linearLayout4;
        this.imageview202 = imageView4;
        this.textview202 = textView4;
        this.navWorkers = linearLayout5;
        this.imageview203 = imageView5;
        this.textview203 = textView5;
        this.navOtherServices = linearLayout6;
        this.imageview204 = imageView6;
        this.textview204 = textView6;
        this.scrollProfile = scrollView;
        this.linear93 = linearLayout7;
        this.space94 = space;
        this.layoutProfileCard = linearLayout8;
        this.cardview6 = cardView;
        this.ivUserPhotoProfile = imageView7;
        this.tvUserNameProfile = textView7;
        this.linear95 = linearLayout9;
        this.tvUserIdProfile = textView8;
        this.imageview205 = imageView8;
        this.linear96 = linearLayout10;
        this.tvGoToPersonalInfo = textView9;
        this.textview205 = textView10;
        this.space97 = space2;
        this.linear98 = linearLayout11;
        this.cardMyNationalId = linearLayout12;
        this.imageview206 = imageView9;
        this.textview206 = textView11;
        this.cardMyPassport = linearLayout13;
        this.imageview207 = imageView10;
        this.textview207 = textView12;
        this.space99 = space3;
        this.linear100 = linearLayout14;
        this.rowFamilyRecord = linearLayout15;
        this.imageview208 = imageView11;
        this.textview208 = textView13;
        this.view101 = view;
        this.rowDrivingLicense = linearLayout16;
        this.imageview209 = imageView12;
        this.textview209 = textView14;
        this.space102 = space4;
        this.relativelayout12 = relativeLayout3;
        this.imgTravelHistory = imageView13;
        this.tvInsideKingdom = textView15;
        this.space103 = space5;
        this.rowRecruitmentRequests = linearLayout17;
        this.imageview210 = imageView14;
        this.textview210 = textView16;
        this.space104 = space6;
    }

    public static ProfileBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBarProfile);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBackProfile);
        TextView textView = (TextView) findChildViewById(view, R.id.tvProfileTitle);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.bottomNavProfile);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.navHome);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview200);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview200);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.navMyServices);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.imageview201);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview201);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.navFamily);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.imageview202);
        TextView textView4 = (TextView) findChildViewById(view, R.id.textview202);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.navWorkers);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.imageview203);
        TextView textView5 = (TextView) findChildViewById(view, R.id.textview203);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.navOtherServices);
        ImageView imageView6 = (ImageView) findChildViewById(view, R.id.imageview204);
        TextView textView6 = (TextView) findChildViewById(view, R.id.textview204);
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.scrollProfile);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.linear93);
        Space space = (Space) findChildViewById(view, R.id.space94);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.layoutProfileCard);
        CardView cardViewFindChildViewById = findChildViewById(view, R.id.cardview6);
        ImageView imageView7 = (ImageView) findChildViewById(view, R.id.ivUserPhotoProfile);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tvUserNameProfile);
        LinearLayout linearLayout9 = (LinearLayout) findChildViewById(view, R.id.linear95);
        TextView textView8 = (TextView) findChildViewById(view, R.id.tvUserIdProfile);
        ImageView imageView8 = (ImageView) findChildViewById(view, R.id.imageview205);
        LinearLayout linearLayout10 = (LinearLayout) findChildViewById(view, R.id.linear96);
        TextView textView9 = (TextView) findChildViewById(view, R.id.tvGoToPersonalInfo);
        TextView textView10 = (TextView) findChildViewById(view, R.id.textview205);
        Space space2 = (Space) findChildViewById(view, R.id.space97);
        LinearLayout linearLayout11 = (LinearLayout) findChildViewById(view, R.id.linear98);
        LinearLayout linearLayout12 = (LinearLayout) findChildViewById(view, R.id.cardMyNationalId);
        ImageView imageView9 = (ImageView) findChildViewById(view, R.id.imageview206);
        TextView textView11 = (TextView) findChildViewById(view, R.id.textview206);
        LinearLayout linearLayout13 = (LinearLayout) findChildViewById(view, R.id.cardMyPassport);
        ImageView imageView10 = (ImageView) findChildViewById(view, R.id.imageview207);
        TextView textView12 = (TextView) findChildViewById(view, R.id.textview207);
        Space space3 = (Space) findChildViewById(view, R.id.space99);
        LinearLayout linearLayout14 = (LinearLayout) findChildViewById(view, R.id.linear100);
        LinearLayout linearLayout15 = (LinearLayout) findChildViewById(view, R.id.rowFamilyRecord);
        ImageView imageView11 = (ImageView) findChildViewById(view, R.id.imageview208);
        TextView textView13 = (TextView) findChildViewById(view, R.id.textview208);
        View viewFindChildViewById = findChildViewById(view, R.id.view101);
        LinearLayout linearLayout16 = (LinearLayout) findChildViewById(view, R.id.rowDrivingLicense);
        ImageView imageView12 = (ImageView) findChildViewById(view, R.id.imageview209);
        TextView textView14 = (TextView) findChildViewById(view, R.id.textview209);
        Space space4 = (Space) findChildViewById(view, R.id.space102);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.relativelayout12);
        ImageView imageView13 = (ImageView) findChildViewById(view, R.id.imgTravelHistory);
        TextView textView15 = (TextView) findChildViewById(view, R.id.tvInsideKingdom);
        Space space5 = (Space) findChildViewById(view, R.id.space103);
        LinearLayout linearLayout17 = (LinearLayout) findChildViewById(view, R.id.rowRecruitmentRequests);
        ImageView imageView14 = (ImageView) findChildViewById(view, R.id.imageview210);
        TextView textView16 = (TextView) findChildViewById(view, R.id.textview210);
        Space space6 = (Space) findChildViewById(view, R.id.space104);
        if (relativeLayout2 == null || imageView == null || textView == null || linearLayout == null || linearLayout2 == null || imageView2 == null || textView2 == null || linearLayout3 == null || imageView3 == null || textView3 == null || linearLayout4 == null || imageView4 == null || textView4 == null || linearLayout5 == null || imageView5 == null || textView5 == null || linearLayout6 == null || imageView6 == null || textView6 == null || scrollView == null || linearLayout7 == null || space == null || linearLayout8 == null || cardViewFindChildViewById == null || imageView7 == null || textView7 == null || linearLayout9 == null || textView8 == null || imageView8 == null || linearLayout10 == null || textView9 == null || textView10 == null || space2 == null || linearLayout11 == null || linearLayout12 == null || imageView9 == null || textView11 == null || linearLayout13 == null || imageView10 == null || textView12 == null || space3 == null || linearLayout14 == null || linearLayout15 == null || imageView11 == null || textView13 == null || viewFindChildViewById == null || linearLayout16 == null || imageView12 == null || textView14 == null || space4 == null || relativeLayout3 == null || imageView13 == null || textView15 == null || space5 == null || linearLayout17 == null || imageView14 == null || textView16 == null || space6 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new ProfileBinding(relativeLayout, relativeLayout2, imageView, textView, linearLayout, linearLayout2, imageView2, textView2, linearLayout3, imageView3, textView3, linearLayout4, imageView4, textView4, linearLayout5, imageView5, textView5, linearLayout6, imageView6, textView6, scrollView, linearLayout7, space, linearLayout8, cardViewFindChildViewById, imageView7, textView7, linearLayout9, textView8, imageView8, linearLayout10, textView9, textView10, space2, linearLayout11, linearLayout12, imageView9, textView11, linearLayout13, imageView10, textView12, space3, linearLayout14, linearLayout15, imageView11, textView13, viewFindChildViewById, linearLayout16, imageView12, textView14, space4, relativeLayout3, imageView13, textView15, space5, linearLayout17, imageView14, textView16, space6);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static ProfileBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static ProfileBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.profile, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
