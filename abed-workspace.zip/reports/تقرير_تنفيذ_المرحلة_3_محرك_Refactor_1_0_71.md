# تقرير تنفيذ — المرحلة 3: محرك إعادة البناء Refactor (1.0.71)

> ثالث مراحل خطة الـ5. الحالة: **تم الشحن** — `BUILD SUCCESSFUL`، `RegressionSuite 338/338`،
> `Acceptance 22/22`، حزمة موقّعة V2.

---

## 1) المحرك الجديد `almlk/Refactor` (نقي — بند 3)

| الدالة | السلوك |
|---|---|
| `inlineVariable(src, var)` | يحذف إعلان `Type var = init;` ويستبدل الاستخدامات بـ`(init)`؛ `null` عند غياب الإعلان/الاستخدامات. |
| `introduceVariable(src,s,e,name)` | يضيف `var name = expr;` قبل السطر الحاوي ويستبدل التعبير المحدد بالاسم. |
| `extractMethod(src,s,e,name)` | يلفّ العبارات المحددة بدالة `private void name()` قبل آخر `}` ويستبدلها بنداء `name();`. |

**بوابات وظيفية (قسم «ن»=5):** Inline يحذف+يستبدل / null عند غياب استخدامات؛ Introduce يضيف var ويستبدل / يرفض محجوزًا؛ Extract يستبدل بنداء ويضيف الدالة بجسم سليم. ✔

## 2) الربط (بند 4: لا ميت)
- السجل: `inline/introduce/extract_method` **مفعّلة** (`!xml && hasSelection && writable`) بدل `c->false`.
- `executeEditorMenuCommand` + `dispatch` + القائمة الرئيسية (`commandEntry` بدل `disabledEntry`)
  → `refactorInline/Introduce/Extract()` (حوار اسم عبر `promptRefactorName` ثم `replaceRange` بتراجع واحد).

## 3) التحقق
| الفحص | النتيجة |
|---|---|
| البناء | **BUILD SUCCESSFUL** |
| انحدار | **338/0** («ن»=5 + «س»=4) |
| قبول | **22/0** |
| التوقيع | V2 — `40655b0b…` |

## 4) مُعلَن صراحةً
- بلا محاكي.
- التحويلات **نصية محافظة**: Extract يُنتج دالة `void` بلا معاملات (بلا تحليل أنواع/معاملات كامل) — حدود معلنة.

**التالي (بانتظار «ابدأ»): المرحلة 4 — توليد الكود (Setters/Constructor/Extract Resources).**
