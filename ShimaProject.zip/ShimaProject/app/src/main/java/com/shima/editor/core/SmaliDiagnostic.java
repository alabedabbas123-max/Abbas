package com.shima.editor.core;

public final class SmaliDiagnostic {
  public enum Severity { INFO, WARNING, ERROR }

  public final int offset;
  public final int end;
  public final int line;
  public final int column;
  public final Severity severity;
  public final String code;
  public final String message;

  public SmaliDiagnostic(
      int offset,
      int end,
      int line,
      int column,
      Severity severity,
      String code,
      String message) {
    this.offset = Math.max(0, offset);
    this.end = Math.max(this.offset + 1, end);
    this.line = Math.max(1, line);
    this.column = Math.max(1, column);
    this.severity = severity == null ? Severity.ERROR : severity;
    this.code = code == null ? "SMALI" : code;
    this.message = message == null ? "خطأ" : message;
  }
}
