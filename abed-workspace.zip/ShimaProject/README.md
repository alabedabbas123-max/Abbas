# ShimaExact

> البنية التنفيذية الجديدة للمحرر موثقة في [EDITOR_ARCHITECTURE.md](EDITOR_ARCHITECTURE.md)، وتطبق نموذج Piece Table وLineIndex وSmali services والحفظ الذري وفق مواصفات Almlk_AR. 1.8 Expanded Tree

## إصلاح المجلدات الفارغة

- عند فتح مشروع، يعرض درج الملفات محتويات المشروع كاملة بصورة متداخلة.
- يتم فحص جميع المجلدات الفرعية recursively، وليس المستوى الأول فقط.
- يظهر كل مجلد ببادئة داخلية توضح مستواه في الشجرة.
- مجلد `AppProjects` يعرض المشاريع فقط لتجنب تحميل جميع المشاريع دفعة واحدة.
- بعد فتح مشروع مثل `Absher` يتم عرض `app/src/main/java` و`res` وجميع الملفات التابعة داخل القائمة نفسها.
- تستخدم الشجرة SAF/DocumentFile عند اختيار المشروع من منتقي Android.
- يستخدم File API عند توفر صلاحية جميع الملفات.
- إذا تعذر الوصول إلى مجلد فرعي، يظهر عنصر واضح لاختيار المشروع عبر منتقي المجلدات بدل عرضه فارغًا.
- لا يتم إنشاء أي ملفات افتراضية.

## العمليات

الفتح، الإنشاء، إعادة التسمية، الحذف، نسخ المسار والتحديث تعمل مع عناصر الشجرة الحقيقية.

## هندسة الأداء الجديدة

أضيفت طبقة أداء مستقلة في `app/src/main/java/com/shima/performance`:

- `InstantSessionStore`: يحفظ في `SharedPreferences` بيانات وصفية فقط: اسم التبويب، مسار الملف أو SAF URI، المؤشر، والتمرير. لا يتم حفظ محتوى الملفات.
- `FileSystemRepository`: نقطة الدخول الوحيدة لقراءة وكتابة النصوص، وتنفذ I/O على خيوط خلفية مع `ExecutorService` وتعيد النتائج إلى Main Handler.
- `FileContentCache`: ذاكرة LRU موزونة بحجم النص بالبايتات، وتمنع ملفًا ضخمًا من طرد كامل الذاكرة المؤقتة.
- `EncodingManager`: UTF-8 صارم مع إزالة BOM ورفض البايتات غير الصالحة بدل استبدالها بصمت، لمنع Mojibake.
- `LineArrayModel` و`ViewportCodeEditorView`: أساس محرر يعتمد على مصفوفة أسطر ويرسم الأسطر الموجودة داخل الـ viewport فقط، مع تمرير وتحديد وتكبير.

تم ربط `AIDEEditorPager` بالجلسة الجديدة: عند الإقلاع تُرسم التبويبات فورًا، ولا تتم قراءة محتوى الملف إلا عند اختيار التبويب. كما أصبحت مراجع الملفات القادمة من File API أو SAF محفوظة حتى يمكن استعادة التبويب بعد إعادة تشغيل التطبيق.

### تدفق العمل

```text
MainActivity
  ├── BrowserPager: فهرسة المجلدات وقراءة الملف على worker
  ├── AIDEEditorPager: تبويبات metadata-only + lazy selection
  │     └── FileSystemRepository: UTF-8 + LRU + background I/O
  └── ProjectSymbolIndex: تحليل وفهرسة على worker مستقل

InstantSessionStore → أسماء/مراجع/مؤشرات فقط
ViewportCodeEditorView → يرسم الأسطر المرئية فقط
```

### مثال القراءة الآمنة

```java
fileRepository.readTextAsync(reference, fileName, 8 * 1024 * 1024,
    (path, text, error) -> {
      if (error != null) showEncodingError(error);
      else editor.setText(text);
    });
```

لا تستدعِ `readTextBlocking` من Main Thread؛ هي مخصصة لخيط I/O فقط.

## التحليل الدلالي واللوحات المتتالية

أضيف `KayStyleCompletionEngine` لإكمال Java السياقي:

- بعد `new` تظهر الكلاسات فقط.
- بعد `receiver.` يتم حل النوع ثم إظهار methods وfields الخاصة بالنوع والأنواع الموروثة فقط.
- `UsageSearchEngine` يبحث عن الاستخدامات مع تجاهل التعليقات والنصوص، ويعيد الملف والسطر والعمود والـ preview.
- الانتقال إلى التعريف يستخدم فهرس الرموز ثم fallback لمسح declarations عند عدم اكتمال الفهرسة.
- `SequentialPanelHost` يوفر صفحات أخطاء، Search Results، Build/Run، Debugger وLogCat مع swipe وحفظ الحالة.

التفاصيل والخوارزميات موجودة في `PERFORMANCE_ARCHITECTURE.md`.

## توافق Android والألوان

- `compileSdk = 37` و`targetSdk = 37` — Android 17.
- Android Gradle Plugin `9.4.0` مع Gradle `9.6.0` وJDK 17.
- Build Tools `37.0.0` وAndroidX Core `1.19.1`.
- تم نقل مكونات DrawerLayout وViewPager وDocumentFile إلى AndroidX.
- تم الإبقاء على `minSdk 23` للمحافظة على دعم الأجهزة القديمة.
- ألوان المحرر تحفظ فور الضغط على موافق باستخدام `commit()`، ولكل نظام ألوان مساحة حفظ مستقلة. تغيير الوضع الداكن/الفاتح لا يمسح الألوان المخصصة.
- أمر `انتقال إلى...` أصبح يفتح قائمة مستقلة لتعريف الرمز، مع البحث في النطاق المحلي وفهرس المشروع ومصادر المكتبات المعروفة.
- لوحات الأخطاء ونتائج البحث والبناء والمصحح وLogCat تعمل داخل درج جانبي حقيقي مع scrim وحركة سحب، وتحافظ على حالة كل لوحة.
- البحث الاحترافي يعمل داخل الملف أو المشروع كاملًا، مع دعم حالة الأحرف والكلمة الكاملة وRegex، وحدود للنتائج والملفات وإلغاء آمن لمنع التهنيج.
- البحث يتجاوز مجلدات البناء والكاش، ويقرأ الملفات النصية lazy في worker thread، ثم يعرض النتيجة مع الملف والسطر والعمود ويفتحها مباشرة.
- تم تحسين الإكمال والتنقل بأسلوب مستوحى من بنية AndroidIDE: فهرس ملفات metadata، cache سياق الإكمال، ترتيب exact/prefix/camel-case، دعم receiver للكلاسات والكائنات، وخوارزمية Boyer-Moore/Horspool للبحث الحرفي.
- نتائج البحث في Java/Kotlin/XML/Gradle وغيرها مرتبطة بمرجع الملف الحقيقي، لذلك يمكن فتح الملف غير النشط مباشرة دون إعادة اجتياز المشروع.

## الإصدار والتوقيع

- versionCode: 41
- versionName: `4.4.0`
- تم تحديث التطبيق ليستهدف Android API 37 مع الحفاظ على `minSdk 23`.

تم اختبار البناء والتوقيع للإصدار الجديد بنجاح باستخدام Android API 37.

### تسريع الإكمال والمحرر

يستخدم مسار الإكمال الحالي `EditorTextSnapshot` و`CompletionLookupCache` و`Future` قابلة للإلغاء لمنع تراكم طلبات الاقتراحات. كما يستخدم `EditorEditHistory` تعديلات نطاقية للـ undo/redo، وينقل نسخ النص وتحليل اللغة إلى worker. هذه Java مملوكة لتطبيق Shima وتدخل DEX البناء العادي تدريجيًا، من دون ربط أو نسخ DEX خارجي.

### فهرس الرموز الدائم وAutocomplete الفوري

يستخدم الإكمال `PersistentSymbolIndexStore` و`CompletionTrie`: يتم تحميل رموز الملفات غير المعدلة من SQLite إلى RAM عند فتح المشروع، بينما يعاد تحليل الملفات الجديدة أو المعدلة فقط. ويُحل سياق `object.` من النوع المفهرس ثم تُستخرج أعضاء النوع من Trie على worker مع debounce وإلغاء الطلبات القديمة.
