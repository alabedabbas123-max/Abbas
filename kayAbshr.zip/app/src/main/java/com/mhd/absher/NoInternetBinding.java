package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class NoInternetBinding {
    public final LinearLayout rootNoInternet;
    public final TextView textview79;
    public final TextView textview80;
    public final WebView webview48;

    private NoInternetBinding(LinearLayout linearLayout, WebView webView, TextView textView, TextView textView2) {
        this.rootNoInternet = linearLayout;
        this.webview48 = webView;
        this.textview79 = textView;
        this.textview80 = textView2;
    }

    public static NoInternetBinding bind(View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        WebView webView = (WebView) findChildViewById(view, R.id.webview48);
        TextView textView = (TextView) findChildViewById(view, R.id.textview79);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview80);
        if (webView == null || textView == null || textView2 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new NoInternetBinding(linearLayout, webView, textView, textView2);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static NoInternetBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static NoInternetBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.no_internet, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public LinearLayout getRoot() {
        return this.rootNoInternet;
    }
}
