package com.shima.editor.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Lightweight, incremental-friendly Smali diagnostics for the active file/method. */
public final class SmaliDiagnosticsEngine {
  private static final Pattern REGISTER = Pattern.compile("\\b([vp])(\\d+)\\b");
  private static final Pattern LABEL = Pattern.compile("^\\s*:([A-Za-z0-9_.$-]+)");
  private static final Pattern BRANCH = Pattern.compile("\\b(?:goto(?:/\\d+)?|if-[^\\s]+)\\s+[^\\n]*(:[A-Za-z0-9_.$-]+)");
  private static final Pattern NUMBER = Pattern.compile("^\\s*\\.(?:locals|registers)\\s+(\\d+)");
  private static final Pattern METHOD_REF = Pattern.compile("L[^;\\s]+;->[A-Za-z0-9_$<>]+\\([^)]*\\).+");

  private SmaliDiagnosticsEngine() {}

  public static List<SmaliDiagnostic> inspect(CharSequence source) {
    ArrayList<SmaliDiagnostic> result = new ArrayList<>();
    if (source == null) return result;
    String text = source.toString();
    Map<String, Integer> labels = new HashMap<>();
    Set<String> referencedLabels = new HashSet<>();
    boolean inMethod = false;
    int methodStart = 0;
    int methodLine = 1;
    int registerLimit = -1;
    int offset = 0;
    int line = 1;
    for (String raw : text.split("\\n", -1)) {
      String content = stripComment(raw);
      String trimmed = content.trim();
      if (trimmed.startsWith(".method")) {
        if (inMethod) add(result, methodStart, methodStart + 7, methodLine, 1, "SMALI_METHOD_NESTED", "تعريف method قبل إغلاق method السابقة");
        inMethod = true;
        methodStart = offset;
        methodLine = line;
        registerLimit = -1;
      }
      if (trimmed.startsWith(".end method")) {
        if (!inMethod) add(result, offset, offset + Math.max(1, raw.length()), line, 1, "SMALI_METHOD_END", "إغلاق method بلا افتتاح");
        inMethod = false;
        registerLimit = -1;
      }
      Matcher limits = NUMBER.matcher(content);
      if (limits.find()) {
        try {
          registerLimit = Integer.parseInt(limits.group(1));
        } catch (NumberFormatException ignored) {
          add(result, offset + limits.start(1), offset + limits.end(1), line, limits.start(1) + 1, "SMALI_NUMBER", "قيمة register غير صالحة");
        }
      }
      Matcher label = LABEL.matcher(content);
      if (label.find()) {
        String name = label.group(1);
        if (labels.containsKey(name))
          add(result, offset + label.start(1), offset + label.end(1), line, label.start(1) + 1, "SMALI_LABEL_DUPLICATE", "label مكرر: " + name);
        else labels.put(name, offset + label.start(1));
      }
      Matcher branch = BRANCH.matcher(content);
      while (branch.find()) {
        String target = branch.group(1);
        if (target.charAt(0) == ':') target = target.substring(1);
        referencedLabels.add(target);
      }
      Matcher registers = REGISTER.matcher(content);
      while (registers.find()) {
        int number = parseInt(registers.group(2));
        if (number < 0) continue;
        if (registerLimit >= 0 && registers.group(1).charAt(0) == 'v' && number >= registerLimit)
          add(result, offset + registers.start(), offset + registers.end(), line, registers.start() + 1, "SMALI_REGISTER_RANGE", "register خارج نطاق .locals/.registers: " + registers.group());
      }
      if (trimmed.startsWith("invoke-") && !METHOD_REF.matcher(content).find())
        add(result, offset, offset + Math.max(1, raw.length()), line, 1, "SMALI_METHOD_DESCRIPTOR", "مرجع method أو descriptor غير صالح");
      offset += raw.length() + 1;
      line++;
    }
    if (inMethod) add(result, methodStart, methodStart + 7, methodLine, 1, "SMALI_METHOD_UNCLOSED", "‏.end method مفقود");
    for (String target : referencedLabels) {
      if (!labels.containsKey(target)) {
        int at = Math.max(0, text.indexOf(":" + target));
        add(result, at, at + Math.max(1, target.length()), line, 1, "SMALI_LABEL_MISSING", "label غير موجود: " + target);
      }
    }
    return result;
  }

  private static String stripComment(String value) {
    boolean quoted = false;
    boolean escaped = false;
    for (int i = 0; i < value.length(); i++) {
      char c = value.charAt(i);
      if (escaped) {
        escaped = false;
      } else if (c == '\\') {
        escaped = true;
      } else if (c == '"') {
        quoted = !quoted;
      } else if (c == '#' && !quoted) {
        return value.substring(0, i);
      }
    }
    return value;
  }

  private static int parseInt(String value) {
    try {
      return Integer.parseInt(value);
    } catch (NumberFormatException ignored) {
      return -1;
    }
  }

  private static void add(
      List<SmaliDiagnostic> result,
      int offset,
      int end,
      int line,
      int column,
      String code,
      String message) {
    result.add(new SmaliDiagnostic(offset, end, line, column, SmaliDiagnostic.Severity.ERROR, code, message));
  }
}
