# تقرير تحميل وفحص مكتبات dependencies

## الهدف
إدارة المكتبات الموجودة في ملفات البناء، اكتشاف المخزن منها، تحميل غير المخزن عند السماح، ثم فهرستها وإتاحة رموزها للاقتراح والتنقل دون إبطاء المحرر.

## مصادر dependencies
- Gradle build files.
- ملفات Maven coordinates.
- local `libs/`.
- AAR/JAR محلية.
- Android SDK/API stubs.
- modules داخل المشروع.

كل dependency تمثل:

```text
group:name:version
scope
source
artifact path
hash
status
index version
```

## الحالات
```text
DECLARED
LOCAL_FOUND
DOWNLOAD_REQUIRED
DOWNLOADING
CACHED
INDEXING
READY
FAILED
OUTDATED
```

## الفحص
1. parser يقرأ ملفات البناء دون تنفيذ Gradle داخل واجهة المستخدم.
2. يستخرج coordinates والـ scopes.
3. يفحص local cache و`libs/`.
4. يقارن metadata وhash/version.
5. ينشئ dependency plan.
6. يفهرس المتاح فورًا.
7. يقترح تحميل المفقود.

## التحميل
- HTTP(S) فقط.
- timeouts وحدود حجم.
- checksum إن توفر.
- تنزيل إلى temp.
- تحقق archive.
- atomic move إلى cache.
- إلغاء واستئناف اختياري.
- لا تحفظ credentials داخل المشروع.

## cache
هيكل مقترح:

```text
cache/
├── artifacts/group/name/version/
├── metadata/
├── checksums/
└── indexes/
```

يتم فصل artifact عن index. إذا كان artifact موجودًا وindex مفقودًا، يفهرس محليًا دون إعادة تنزيل.

## فحص المكتبة المخزنة
- وجود الملف.
- الحجم غير صفر.
- قابلية فتح JAR/AAR.
- manifest صحيح.
- checksum.
- توافق API/ABI.
- عدم وجود archive traversal عند فك AAR.
- تاريخ/نسخة metadata.

## فهرسة المكتبة
تستخرج:

- classes.
- methods.
- fields.
- annotations.
- packages.
- resources من AAR.
- documentation عند توفرها.

وتسجلها كـ external symbols حتى لا تظهر قبل رموز المشروع المحلي إلا عند الحاجة.

## عدم تعطيل المحرر
- التحميل والفهرسة في Worker.
- ظهور رموز محلية أولًا.
- إضافة المكتبة إلى الاقتراحات عند READY.
- progress في Bottom Draw.
- إلغاء dependency مستقلة دون إلغاء باقي المشروع.
- إعادة فهرسة المكتبة فقط عند تغيرها.

## فشل التحميل
يعرض:

```text
library
reason
retry
use local
ignore
open settings
```

ويستمر المشروع بالعمل مع تشخيص unresolved symbols بدل إيقاف المحرر.

## أدوات التنفيذ
OkHttp، Okio، Room، ExecutorService، WorkManager، ZipInputStream آمن، SHA-256، parser لملفات Gradle، index database.

## الأمان
- عدم تنفيذ scripts مجهولة.
- عدم تشغيل كود المكتبة أثناء الفهرسة.
- أقل صلاحيات شبكة.
- عرض المصدر والنسخة.
- حذف cache من الإعدادات.
