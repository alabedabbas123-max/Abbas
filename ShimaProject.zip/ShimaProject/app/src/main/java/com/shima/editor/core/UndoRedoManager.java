package com.shima.editor.core;

import java.util.ArrayDeque;

/** Command-based undo/redo with a short typing coalescing window. */
public final class UndoRedoManager {
  private static final long COALESCE_MS = 300L;
  private static final int MAX_COMMANDS = 500;
  private final ArrayDeque<EditCommand> undo = new ArrayDeque<>();
  private final ArrayDeque<EditCommand> redo = new ArrayDeque<>();
  private long lastEditTime;

  public synchronized void record(long start, String before, String after) {
    if (before == null) before = "";
    if (after == null) after = "";
    if (before.equals(after)) return;
    long now = System.currentTimeMillis();
    EditCommand previous = undo.peek();
    if (previous != null
        && now - lastEditTime <= COALESCE_MS
        && previous.canAppend(start, before, after)) {
      undo.pop();
      undo.push(previous.append(start, before, after));
    } else {
      undo.push(new EditCommand(start, before, after));
      while (undo.size() > MAX_COMMANDS) undo.removeLast();
    }
    lastEditTime = now;
    redo.clear();
  }

  public synchronized boolean undo(PieceTableDocument document) {
    if (document == null || undo.isEmpty()) return false;
    EditCommand command = undo.pop();
    document.replaceWithoutHistory(command.start, command.start + command.after.length(), command.before);
    redo.push(command);
    return true;
  }

  public synchronized boolean redo(PieceTableDocument document) {
    if (document == null || redo.isEmpty()) return false;
    EditCommand command = redo.pop();
    document.replaceWithoutHistory(command.start, command.start + command.before.length(), command.after);
    undo.push(command);
    return true;
  }

  public synchronized void clear() {
    undo.clear();
    redo.clear();
    lastEditTime = 0L;
  }

  public synchronized int undoCount() {
    return undo.size();
  }

  public synchronized int redoCount() {
    return redo.size();
  }

  public static final class EditCommand {
    public final long start;
    public final String before;
    public final String after;

    EditCommand(long start, String before, String after) {
      this.start = start;
      this.before = before;
      this.after = after;
    }

    boolean canAppend(long nextStart, String removed, String inserted) {
      // Adjacent insertion is the common keyboard case. Backspace coalescing is also supported.
      return removed.isEmpty() && nextStart == start + after.length()
          || inserted.isEmpty() && nextStart + removed.length() == start;
    }

    EditCommand append(long nextStart, String removed, String inserted) {
      if (removed.isEmpty() && nextStart == start + after.length())
        return new EditCommand(start, before, after + inserted);
      if (inserted.isEmpty() && nextStart + removed.length() == start)
        return new EditCommand(nextStart, removed + before, after);
      return new EditCommand(start, before, after);
    }
  }
}
