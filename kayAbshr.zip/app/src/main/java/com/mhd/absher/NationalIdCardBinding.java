package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class NationalIdCardBinding {
    public final RelativeLayout documentCard1;
    public final FrameLayout frameQrcode;
    public final ImageView imageviewIdPhoto;
    public final ImageView imageviewQrLogo;
    public final ImageView imageviewQrcode;
    public final ImageView ivDocument1Background;
    public final RelativeLayout rootView;
    public final TextView tvCardBirthDate;
    public final TextView tvCardBirthPlace;
    public final TextView tvCardCopyNumber;
    public final TextView tvCardEmployerId;
    public final TextView tvCardEmployerName;
    public final TextView tvCardExpiryDate;
    public final TextView tvCardIdHome;
    public final TextView tvCardIssuePlace;
    public final TextView tvCardNameEn;
    public final TextView tvCardNameHome;
    public final TextView tvCardNationality;
    public final TextView tvCardProfession;
    public final TextView tvCardReligion;

    private NationalIdCardBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, ImageView imageView2, FrameLayout frameLayout, ImageView imageView3, ImageView imageView4, TextView textView2, TextView textView3, TextView textView4, TextView textView5, TextView textView6, TextView textView7, TextView textView8, TextView textView9, TextView textView10, TextView textView11, TextView textView12, TextView textView13) {
        this.rootView = relativeLayout;
        this.documentCard1 = relativeLayout2;
        this.ivDocument1Background = imageView;
        this.tvCardCopyNumber = textView;
        this.imageviewIdPhoto = imageView2;
        this.frameQrcode = frameLayout;
        this.imageviewQrcode = imageView3;
        this.imageviewQrLogo = imageView4;
        this.tvCardNameHome = textView2;
        this.tvCardNameEn = textView3;
        this.tvCardIdHome = textView4;
        this.tvCardBirthDate = textView5;
        this.tvCardExpiryDate = textView6;
        this.tvCardBirthPlace = textView7;
        this.tvCardReligion = textView8;
        this.tvCardNationality = textView9;
        this.tvCardProfession = textView10;
        this.tvCardEmployerId = textView11;
        this.tvCardIssuePlace = textView12;
        this.tvCardEmployerName = textView13;
    }

    public static NationalIdCardBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.documentCard1);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.ivDocument1Background);
        TextView textView = (TextView) findChildViewById(view, R.id.tvCardCopyNumber);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview_id_photo);
        FrameLayout frameLayout = (FrameLayout) findChildViewById(view, R.id.frame_qrcode);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.imageview_qrcode);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.imageview_qr_logo);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvCardNameHome);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tvCardNameEn);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tvCardIdHome);
        TextView textView5 = (TextView) findChildViewById(view, R.id.tvCardBirthDate);
        TextView textView6 = (TextView) findChildViewById(view, R.id.tvCardExpiryDate);
        TextView textView7 = (TextView) findChildViewById(view, R.id.tvCardBirthPlace);
        TextView textView8 = (TextView) findChildViewById(view, R.id.tvCardReligion);
        TextView textView9 = (TextView) findChildViewById(view, R.id.tvCardNationality);
        TextView textView10 = (TextView) findChildViewById(view, R.id.tvCardProfession);
        TextView textView11 = (TextView) findChildViewById(view, R.id.tvCardEmployerId);
        TextView textView12 = (TextView) findChildViewById(view, R.id.tvCardIssuePlace);
        TextView textView13 = (TextView) findChildViewById(view, R.id.tvCardEmployerName);
        if (relativeLayout2 == null || imageView == null || textView == null || imageView2 == null || frameLayout == null || imageView3 == null || imageView4 == null || textView2 == null || textView3 == null || textView4 == null || textView5 == null || textView6 == null || textView7 == null || textView8 == null || textView9 == null || textView10 == null || textView11 == null || textView12 == null || textView13 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new NationalIdCardBinding(relativeLayout, relativeLayout2, imageView, textView, imageView2, frameLayout, imageView3, imageView4, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static NationalIdCardBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static NationalIdCardBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.national_id_card, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
