package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class FamilyBinding {
    public final LinearLayout bottomNavFamily;
    public final ImageButton btnChat;
    public final LinearLayout contentFamily;
    public final LinearLayout emptyState;
    public final ImageView imageview20;
    public final ImageView imageview21;
    public final ImageView imageview22;
    public final ImageView imageview23;
    public final ImageView imageview24;
    public final ImageView ivAbsherLogo;
    public final ImageView ivBell;
    public final ImageView ivFamilyIcon;
    public final ImageView ivInterior;
    public final ImageView ivSearch;
    public final ImageView ivSettings;
    public final LinearLayout navFamily;
    public final LinearLayout navHome;
    public final LinearLayout navMyServices;
    public final LinearLayout navOther;
    public final LinearLayout navWorkers;
    public final RelativeLayout rootFamily;
    public final ScrollView scrollFamily;
    public final RelativeLayout searchContainer;
    public final Space space40;
    public final TextView textview40;
    public final TextView textview41;
    public final TextView textview42;
    public final TextView textview43;
    public final TextView textview44;
    public final RelativeLayout topHeader;
    public final TextView tvMainMessage;
    public final TextView tvSearchHint;
    public final TextView tvSubMessage;
    public final TextView tvTitle;

    private FamilyBinding(RelativeLayout relativeLayout, ScrollView scrollView, LinearLayout linearLayout, RelativeLayout relativeLayout2, ImageView imageView, ImageView imageView2, ImageView imageView3, ImageView imageView4, TextView textView, RelativeLayout relativeLayout3, ImageView imageView5, TextView textView2, LinearLayout linearLayout2, ImageView imageView6, TextView textView3, TextView textView4, Space space, ImageButton imageButton, LinearLayout linearLayout3, LinearLayout linearLayout4, ImageView imageView7, TextView textView5, LinearLayout linearLayout5, ImageView imageView8, TextView textView6, LinearLayout linearLayout6, ImageView imageView9, TextView textView7, LinearLayout linearLayout7, ImageView imageView10, TextView textView8, LinearLayout linearLayout8, ImageView imageView11, TextView textView9) {
        this.rootFamily = relativeLayout;
        this.scrollFamily = scrollView;
        this.contentFamily = linearLayout;
        this.topHeader = relativeLayout2;
        this.ivBell = imageView;
        this.ivSettings = imageView2;
        this.ivAbsherLogo = imageView3;
        this.ivInterior = imageView4;
        this.tvTitle = textView;
        this.searchContainer = relativeLayout3;
        this.ivSearch = imageView5;
        this.tvSearchHint = textView2;
        this.emptyState = linearLayout2;
        this.ivFamilyIcon = imageView6;
        this.tvMainMessage = textView3;
        this.tvSubMessage = textView4;
        this.space40 = space;
        this.btnChat = imageButton;
        this.bottomNavFamily = linearLayout3;
        this.navHome = linearLayout4;
        this.imageview24 = imageView7;
        this.textview44 = textView5;
        this.navMyServices = linearLayout5;
        this.imageview23 = imageView8;
        this.textview43 = textView6;
        this.navFamily = linearLayout6;
        this.imageview22 = imageView9;
        this.textview42 = textView7;
        this.navWorkers = linearLayout7;
        this.imageview21 = imageView10;
        this.textview41 = textView8;
        this.navOther = linearLayout8;
        this.imageview20 = imageView11;
        this.textview40 = textView9;
    }

    public static FamilyBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.scrollFamily);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.contentFamily);
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topHeader);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.ivBell);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.ivSettings);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.ivAbsherLogo);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.ivInterior);
        TextView textView = (TextView) findChildViewById(view, R.id.tvTitle);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.searchContainer);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.ivSearch);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvSearchHint);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.emptyState);
        ImageView imageView6 = (ImageView) findChildViewById(view, R.id.ivFamilyIcon);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tvMainMessage);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tvSubMessage);
        Space space = (Space) findChildViewById(view, R.id.space40);
        ImageButton imageButton = (ImageButton) findChildViewById(view, R.id.btnChat);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.bottomNavFamily);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.navHome);
        ImageView imageView7 = (ImageView) findChildViewById(view, R.id.imageview24);
        TextView textView5 = (TextView) findChildViewById(view, R.id.textview44);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.navMyServices);
        ImageView imageView8 = (ImageView) findChildViewById(view, R.id.imageview23);
        TextView textView6 = (TextView) findChildViewById(view, R.id.textview43);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.navFamily);
        ImageView imageView9 = (ImageView) findChildViewById(view, R.id.imageview22);
        TextView textView7 = (TextView) findChildViewById(view, R.id.textview42);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.navWorkers);
        ImageView imageView10 = (ImageView) findChildViewById(view, R.id.imageview21);
        TextView textView8 = (TextView) findChildViewById(view, R.id.textview41);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.navOther);
        ImageView imageView11 = (ImageView) findChildViewById(view, R.id.imageview20);
        TextView textView9 = (TextView) findChildViewById(view, R.id.textview40);
        if (scrollView == null || linearLayout == null || relativeLayout2 == null || imageView == null || imageView2 == null || imageView3 == null || imageView4 == null || textView == null || relativeLayout3 == null || imageView5 == null || textView2 == null || linearLayout2 == null || imageView6 == null || textView3 == null || textView4 == null || space == null || imageButton == null || linearLayout3 == null || linearLayout4 == null || imageView7 == null || textView5 == null || linearLayout5 == null || imageView8 == null || textView6 == null || linearLayout6 == null || imageView9 == null || textView7 == null || linearLayout7 == null || imageView10 == null || textView8 == null || linearLayout8 == null || imageView11 == null || textView9 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new FamilyBinding(relativeLayout, scrollView, linearLayout, relativeLayout2, imageView, imageView2, imageView3, imageView4, textView, relativeLayout3, imageView5, textView2, linearLayout2, imageView6, textView3, textView4, space, imageButton, linearLayout3, linearLayout4, imageView7, textView5, linearLayout5, imageView8, textView6, linearLayout6, imageView9, textView7, linearLayout7, imageView10, textView8, linearLayout8, imageView11, textView9);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static FamilyBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static FamilyBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.family, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootFamily;
    }
}
