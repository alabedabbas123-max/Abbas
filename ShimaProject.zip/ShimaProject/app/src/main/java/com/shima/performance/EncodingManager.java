package com.shima.performance;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;

/**
 * Single encoding policy for source files.
 *
 * <p>Files default to strict UTF-8 and accept UTF-8/UTF-16 BOMs. Malformed UTF-8 input is reported
 * instead of being silently replaced, which prevents mojibake from being written back to source.
 */
public final class EncodingManager {
  public static final int DEFAULT_MAX_BYTES = 8 * 1024 * 1024;
  private static final Charset UTF8 = Charset.forName("UTF-8");

  private EncodingManager() {}

  public static String readUtf8(InputStream input) throws IOException {
    return readUtf8(input, DEFAULT_MAX_BYTES);
  }

  public static String readUtf8(InputStream input, int maxBytes) throws IOException {
    if (input == null) throw new IOException("Input stream is null");
    if (maxBytes <= 0) throw new IllegalArgumentException("maxBytes must be positive");
    try (InputStream source = input) {
      ByteArrayOutputStream output = new ByteArrayOutputStream(Math.min(maxBytes, 64 * 1024));
      byte[] buffer = new byte[16 * 1024];
      int total = 0;
      int read;
      while ((read = source.read(buffer)) != -1) {
        if (read == 0) continue;
        if (total > maxBytes - read) throw new FileTooLargeException(maxBytes);
        output.write(buffer, 0, read);
        total += read;
      }
      return decodeUtf8(output.toByteArray());
    }
  }

  public static String decodeUtf8(byte[] bytes) throws IOException {
    if (bytes == null) return "";
    if (hasUtf16LeBom(bytes)) return new String(bytes, 2, bytes.length - 2, Charset.forName("UTF-16LE"));
    if (hasUtf16BeBom(bytes)) return new String(bytes, 2, bytes.length - 2, Charset.forName("UTF-16BE"));
    int offset = hasUtf8Bom(bytes) ? 3 : 0;
    CharsetDecoder decoder =
        UTF8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT);
    try {
      CharBuffer value = decoder.decode(ByteBuffer.wrap(bytes, offset, bytes.length - offset));
      String text = value.toString();
      // A BOM is metadata, not source text. Remove a decoded BOM as well for defensive safety.
      return text.startsWith("\uFEFF") ? text.substring(1) : text;
    } catch (CharacterCodingException error) {
      throw new InvalidUtf8Exception(error);
    }
  }

  public static byte[] encodeUtf8(String text) {
    if (text == null) text = "";
    // Do not emit a BOM. UTF-8 is the explicit on-disk format for every write.
    return text.getBytes(UTF8);
  }

  public static boolean hasUtf8Bom(byte[] bytes) {
    return bytes != null
        && bytes.length >= 3
        && (bytes[0] & 0xFF) == 0xEF
        && (bytes[1] & 0xFF) == 0xBB
        && (bytes[2] & 0xFF) == 0xBF;
  }

  public static boolean hasUtf16LeBom(byte[] bytes) {
    return bytes != null && bytes.length >= 2 && (bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xFE;
  }

  public static boolean hasUtf16BeBom(byte[] bytes) {
    return bytes != null && bytes.length >= 2 && (bytes[0] & 0xFF) == 0xFE && (bytes[1] & 0xFF) == 0xFF;
  }

  public static final class InvalidUtf8Exception extends IOException {
    public InvalidUtf8Exception(Throwable cause) {
      super("الملف ليس UTF-8 صالحًا؛ تم رفض القراءة لمنع تلف النص", cause);
    }
  }

  public static final class FileTooLargeException extends IOException {
    public FileTooLargeException(int maxBytes) {
      super("الملف أكبر من الحد المدعوم للمحرر: " + maxBytes + " بايت");
    }
  }
}
