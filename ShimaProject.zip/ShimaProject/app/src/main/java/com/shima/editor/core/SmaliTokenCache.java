package com.shima.editor.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Line/version cache for incremental Smali highlighting. */
public final class SmaliTokenCache {
  private final Map<Integer, Entry> entries = new HashMap<>();

  public synchronized List<SmaliToken> line(
      CharSequence source, int line, int start, int end, long documentVersion) {
    Entry cached = entries.get(line);
    if (cached != null && cached.version == documentVersion) return cached.tokens;
    List<SmaliToken> parsed = SmaliTokenizer.tokenizeLine(source, start, end);
    ArrayList<SmaliToken> immutable = new ArrayList<>(parsed);
    entries.put(line, new Entry(documentVersion, immutable));
    return immutable;
  }

  public synchronized void invalidateFrom(int firstLine) {
    java.util.Iterator<Integer> iterator = entries.keySet().iterator();
    while (iterator.hasNext()) {
      if (iterator.next() >= firstLine) iterator.remove();
    }
  }

  public synchronized void clear() {
    entries.clear();
  }

  private static final class Entry {
    final long version;
    final List<SmaliToken> tokens;

    Entry(long version, List<SmaliToken> tokens) {
      this.version = version;
      this.tokens = tokens;
    }
  }
}
