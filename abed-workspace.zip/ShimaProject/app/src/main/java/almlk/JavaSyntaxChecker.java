package almlk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * فاحص الجمل النحوي لجافا (تحقق بنيوي بنزول تكراري دون بناء شجرة AST).
 *
 * <p>يغطي جافا 8 حتى 21: الوحدة والاستيرادات، كل تصريحات الأنواع (class/interface/enum/record/
 * @interface)، الأعضاء، كل أنواع الجمل بما فيها switch بالنقطتين والسهم وأنماط الحالات وtry-with-
 * resources والتسميات والـyield، وتسلسل أولوية التعبيرات كاملًا مع lambda وmethod reference
 * وcast وinstanceof بالنمط.
 *
 * <p>قواعد الإبلاغ (مطابقة لـjavac في الموضع):
 * <ul>
 *   <li>«X expected» تُوضع بعد آخر رمز سابق (كما يفعل javac).</li>
 *   <li>«illegal start of …» و«not a statement» تُوضع عند الرمز الحالي أو بداية التعبير.</li>
 *   <li>خطأ واحد على الأكثر لكل سطر، وأي خطأ معجمي يحجز سطره أولًا.</li>
 *   <li>بعد الخطأ يتعافى المحلل عند الفاصلة المنقوطة أو القوس المغلق للكتلة الحالية، فلا تنتشر
 *       الأخطاء إلى بقية الملف.</li>
 * </ul>
 *
 * <p>يعمل بجافا 8 (مستوى مشروعنا): بلا switch بالسهم ولا var ولا السجلات.
 */
public final class JavaSyntaxChecker {

  /** مشكلة نحوية أو معجمية: موضع بالإزاحة والسطر والعمود (1-based) ومفتاح رسالة مترجمة. */
  public static final class Problem {
    public final int offset;
    public final int end;
    public final int line;
    public final int column;
    public final String key;
    public final String fallback;
    public final Object[] arguments;

    Problem(int offset, int end, int line, int column, String key, String fallback, Object[] arguments) {
      this.offset = offset;
      this.end = end;
      this.line = line;
      this.column = column;
      this.key = key;
      this.fallback = fallback;
      this.arguments = arguments;
    }
  }

  static final String KEY_EXPECTED = "ui_diagnostic_expected_token";
  static final String FALLBACK_EXPECTED = "%1$s expected";
  static final String KEY_SEMICOLON = "ui_diagnostic_missing_semicolon";
  static final String FALLBACK_SEMICOLON = "End this statement with a semicolon (;).";
  static final String KEY_ILLEGAL_EXPRESSION = "ui_diagnostic_illegal_start_of_expression";
  static final String FALLBACK_ILLEGAL_EXPRESSION = "illegal start of expression";
  static final String KEY_ILLEGAL_TYPE = "ui_diagnostic_illegal_start_of_type";
  static final String FALLBACK_ILLEGAL_TYPE = "illegal start of type";
  static final String KEY_NOT_STATEMENT = "ui_diagnostic_not_a_statement";
  static final String FALLBACK_NOT_STATEMENT = "not a statement";
  static final String KEY_ELSE = "ui_diagnostic_else_without_if";
  static final String FALLBACK_ELSE = "'else' without 'if'";
  static final String KEY_ORPHANED = "ui_diagnostic_orphaned_keyword";
  static final String FALLBACK_ORPHANED = "orphaned %1$s";
  static final String KEY_END_OF_FILE = "ui_diagnostic_reached_end_of_file";
  static final String FALLBACK_END_OF_FILE = "reached end of file while parsing";
  static final String KEY_TYPE_EXPECTED = "ui_diagnostic_class_or_interface_expected";
  static final String FALLBACK_TYPE_EXPECTED = "class, interface, enum, or record expected";
  static final String KEY_CONSTRUCTOR_NAME = "ui_diagnostic_invalid_method_declaration";
  static final String FALLBACK_CONSTRUCTOR_NAME = "invalid method declaration; return type required";
  static final String KEY_DUPLICATE_TYPE = "ui_diagnostic_duplicate_class";
  static final String FALLBACK_DUPLICATE_TYPE = "Duplicate class name in this file: %1$s";
  static final String KEY_PUBLIC_NAME = "ui_diagnostic_public_class_name_mismatch";
  static final String FALLBACK_PUBLIC_NAME = "Public class %1$s must match the file name %2$s.";

  private static final int CONTEXT_TOP = 0;
  private static final int CONTEXT_MEMBER = 1;
  private static final int CONTEXT_LOCAL = 2;

  private static final int BODY_CLASS = 0;
  private static final int BODY_INTERFACE = 1;
  private static final int BODY_ENUM = 2;
  private static final int BODY_RECORD = 3;
  private static final int BODY_ANONYMOUS = 4;
  private static final int BODY_ANNOTATION = 5;

  private static final int FLAG_PUBLIC = 1;
  private static final int RELATIONAL_PRECEDENCE = 7;

  private static final Set<String> PRIMITIVES = new HashSet<>(Arrays.asList(
      "boolean", "byte", "short", "int", "long", "char", "float", "double"));
  private static final Set<String> ASSIGNMENT_OPERATORS = new HashSet<>(Arrays.asList(
      "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<="));

  /** خطأ نحوي داخلي يُلتقط على حدود الجمل فقط. */
  private static final class Failure extends RuntimeException {
    private static final long serialVersionUID = 1L;
    final int offset;
    final int end;
    final int token;
    final String key;
    final String fallback;
    final transient Object[] arguments;

    Failure(int offset, int end, int token, String key, String fallback, Object[] arguments) {
      super(null, null, false, false);
      this.offset = offset;
      this.end = end;
      this.token = token;
      this.key = key;
      this.fallback = fallback;
      this.arguments = arguments;
    }
  }

  /** ميزانية الخطوات: تضمن انتهاء التحليل حتى مع مدخلات مشوّهة بلا حلقات لانهائية. */
  private static final class Abort extends RuntimeException {
    private static final long serialVersionUID = 1L;

    Abort() {
      super(null, null, false, false);
    }
  }

  private final String fileName;
  private final String source;
  private final JavaTokenizer tokens;
  private final int count;
  private final List<Problem> problems = new ArrayList<>();
  private final Set<Integer> errorLines = new HashSet<>();
  private final List<Set<String>> typeScopes = new ArrayList<>();
  private int[] lineStarts;
  private int pos;
  private int budget;
  private boolean inCaseLabel;

  private JavaSyntaxChecker(String fileName, String source) {
    this.fileName = fileName == null ? "" : fileName;
    this.source = source;
    this.tokens = JavaTokenizer.tokenize(source);
    this.count = tokens.count();
    this.budget = 64 * count + 100000;
  }

  /** يفحص نص ملف جافا ويعيد مشكلاته مرتبةً بالموضع (قائمة فارغة إن كان صحيحًا نحويًا). */
  public static List<Problem> check(String fileName, String source) {
    String text = source == null ? "" : source;
    if (text.isEmpty() || "module-info.java".equals(fileName)) return new ArrayList<>();
    JavaSyntaxChecker checker = new JavaSyntaxChecker(fileName, text);
    checker.run();
    Collections.sort(checker.problems, new Comparator<Problem>() {
      @Override
      public int compare(Problem a, Problem b) {
        return a.offset != b.offset ? Integer.compare(a.offset, b.offset) : Integer.compare(a.end, b.end);
      }
    });
    return checker.problems;
  }

  private void run() {
    for (JavaTokenizer.Issue issue : tokens.issues()) {
      addProblem(issue.offset, issue.end, issue.key, issue.fallback, issue.arguments);
    }
    if (tokens.stoppedEarly()) return;
    typeScopes.add(new HashSet<String>());
    try {
      compilationUnit();
    } catch (Abort | StackOverflowError ignored) {
      // نكتفي بما وُجد حتى الآن: لا نُبلغ عن أخطاء لم يكتمل تحققها.
    }
  }

  // ---------------------------------------------------------------------------------------------
  // الوحدة والتصريحات
  // ---------------------------------------------------------------------------------------------

  private void compilationUnit() {
    if (isKeyword("package") || (isSymbol("@") && annotationsThenPackage())) {
      packageDeclaration();
    }
    while (!atEnd()) {
      int before = pos;
      try {
        if (isKeyword("import")) importDeclaration();
        else if (isSymbol(";")) consume();
        else typeDeclaration(CONTEXT_TOP);
      } catch (Failure failure) {
        report(failure);
        recover();
      }
      if (pos == before) consume();
    }
  }

  private boolean annotationsThenPackage() {
    int mark = pos;
    try {
      annotations();
      return isKeyword("package");
    } catch (Failure failure) {
      return false;
    } finally {
      pos = mark;
    }
  }

  private void packageDeclaration() {
    annotations();
    consume();
    qualifiedName();
    expectSemicolon();
  }

  private void importDeclaration() {
    consume();
    if (isKeyword("static")) consume();
    identifierDeclaration();
    while (isSymbol(".")) {
      consume();
      if (isSymbol("*")) {
        consume();
        break;
      }
      identifierDeclaration();
    }
    expectSemicolon();
  }

  private void qualifiedName() {
    identifierDeclaration();
    while (isSymbol(".") && isIdentifierAt(pos + 1)) {
      consume();
      consume();
    }
  }

  private void typeDeclaration(int context) {
    int flags = modifiers();
    typeDeclarationAfterModifiers(flags, context);
  }

  private void typeDeclarationAfterModifiers(int flags, int context) {
    if (isKeyword("class")) classDeclaration(flags, context);
    else if (isKeyword("interface")) interfaceDeclaration(flags, context);
    else if (isKeyword("enum")) enumDeclaration(flags, context);
    else if (isRecordStart()) recordDeclaration(flags, context);
    else if (isSymbol("@") && isKeywordAt(pos + 1, "interface")) annotationDeclaration(flags, context);
    else throw failAtCurrent(KEY_TYPE_EXPECTED, FALLBACK_TYPE_EXPECTED);
  }

  private boolean atTypeDeclaration() {
    return isKeyword("class") || isKeyword("interface") || isKeyword("enum") || isRecordStart()
        || (isSymbol("@") && isKeywordAt(pos + 1, "interface"));
  }

  private boolean isRecordStart() {
    return isIdentifierNamed("record")
        && isIdentifierAt(pos + 1)
        && (isSymbolAt(pos + 2, "(") || isSymbolAt(pos + 2, "<"));
  }

  private void classDeclaration(int flags, int context) {
    consume();
    String name = declareTypeName(flags, context);
    if (isSymbol("<")) typeParameters();
    if (isKeyword("extends")) {
      consume();
      typeAfterKeyword();
    }
    if (isKeyword("implements")) {
      consume();
      typeList();
    }
    if (isIdentifierNamed("permits")) {
      consume();
      typeList();
    }
    classBody(name, BODY_CLASS);
  }

  private void interfaceDeclaration(int flags, int context) {
    consume();
    String name = declareTypeName(flags, context);
    if (isSymbol("<")) typeParameters();
    if (isKeyword("extends")) {
      consume();
      typeList();
    }
    if (isIdentifierNamed("permits")) {
      consume();
      typeList();
    }
    classBody(name, BODY_INTERFACE);
  }

  private void enumDeclaration(int flags, int context) {
    consume();
    String name = declareTypeName(flags, context);
    if (isKeyword("implements")) {
      consume();
      typeList();
    }
    enumBody(name);
  }

  private void recordDeclaration(int flags, int context) {
    consume();
    String name = declareTypeName(flags, context);
    if (isSymbol("<")) typeParameters();
    parameters();
    if (isKeyword("implements")) {
      consume();
      typeList();
    }
    classBody(name, BODY_RECORD);
  }

  private void annotationDeclaration(int flags, int context) {
    consume();
    consume();
    String name = declareTypeName(flags, context);
    classBody(name, BODY_ANNOTATION);
  }

  /** يقرأ اسم النوع، ويتحقق من تطابق اسم الصنف العام مع الملف، ومن تكرار الاسم داخل نطاقه. */
  private String declareTypeName(int flags, int context) {
    int nameStart = pos;
    String name = identifierDeclaration();
    if (context == CONTEXT_TOP && (flags & FLAG_PUBLIC) != 0 && fileName.endsWith(".java")) {
      String expected = fileName.substring(0, fileName.length() - ".java".length());
      if (!expected.equals(name)) {
        addProblem(tokens.start(nameStart), tokens.end(nameStart), KEY_PUBLIC_NAME,
            FALLBACK_PUBLIC_NAME, name, expected);
      }
    }
    if (context != CONTEXT_LOCAL && !typeScopes.get(typeScopes.size() - 1).add(name)) {
      addProblem(tokens.start(nameStart), tokens.end(nameStart), KEY_DUPLICATE_TYPE,
          FALLBACK_DUPLICATE_TYPE, name);
    }
    return name;
  }

  /**
   * جسم الصنف. إن غاب "{" فالخطأ يُبلَّغ مرة واحدة ويُكمل تحليل الأعضاء كأن الجسم موجود (كما يفعل
   * javac)، فلا تتكرر الأخطاء على كل عضو بعدها، والإغلاق "}" للصنف يبقى كما هو.
   */
  private void classBody(String className, int kind) {
    if (isSymbol("{")) {
      consume();
    } else {
      report(expectedAfterPrevious("'{'"));
    }
    membersUntilClosingBrace(className, kind);
  }

  private void enumBody(String name) {
    if (isSymbol("{")) {
      consume();
    } else {
      report(expectedAfterPrevious("'{'"));
    }
    enumConstants();
    membersUntilClosingBrace(name, BODY_ENUM);
  }

  private void enumConstants() {
    while (isIdentifier() || isSymbol("@")) {
      annotations();
      identifierDeclaration();
      if (isSymbol("(")) arguments();
      if (isSymbol("{")) classBody(null, BODY_ANONYMOUS);
      if (!isSymbol(",")) break;
      consume();
    }
    if (isSymbol(";")) consume();
    else if (!isSymbol("}")) throw expectedAfterPrevious("',', '}', or ';'");
  }

  /** أعضاء الصنف حتى الإغلاق؛ يعالج كل عضو بتعافٍ مستقل كي لا يتوقف الملف عند أول خطأ. */
  private void membersUntilClosingBrace(String className, int kind) {
    typeScopes.add(new HashSet<String>());
    int problemsBefore = problems.size();
    try {
      while (!isSymbol("}")) {
        if (atEnd()) throw failAtEnd();
        int before = pos;
        try {
          member(className, kind);
        } catch (Failure failure) {
          // دالة بلا "{" تُترك جملها تحت الصنف: كل جملة منها خطأ مستقل شكليًا لكنها تبعة للأول.
          if (problems.size() == problemsBefore || !isStatementKeyword(pos)) report(failure);
          recover();
        }
        if (pos == before) consume();
      }
      consume();
    } finally {
      typeScopes.remove(typeScopes.size() - 1);
    }
  }

  private void member(String className, int kind) {
    if (isSymbol(";")) {
      consume();
      return;
    }
    int flags = modifiers();
    if (isSymbol("{")) {
      block();
      return;
    }
    if (atTypeDeclaration()) {
      typeDeclarationAfterModifiers(flags, CONTEXT_MEMBER);
      return;
    }
    if (isSymbol("<")) typeParameters();
    if (isIdentifier() && isSymbolAt(pos + 1, "(")) {
      if (!value(pos).equals(className)) throw failAtCurrent(KEY_CONSTRUCTOR_NAME, FALLBACK_CONSTRUCTOR_NAME);
      consume();
      methodRest(kind);
      return;
    }
    if (kind == BODY_RECORD && isIdentifier() && value(pos).equals(className) && isSymbolAt(pos + 1, "{")) {
      consume();
      block();
      return;
    }
    if (isKeyword("void")) consume();
    else type();
    identifierDeclaration();
    if (isSymbol("(")) {
      methodRest(kind);
      return;
    }
    variableDeclaratorsRest(kind == BODY_INTERFACE);
    expectSemicolon();
  }

  private boolean isStatementKeyword(int index) {
    if (kind(index) != JavaTokenizer.KEYWORD) return false;
    String word = value(index);
    return "if".equals(word) || "for".equals(word) || "while".equals(word) || "do".equals(word)
        || "try".equals(word) || "switch".equals(word) || "return".equals(word)
        || "throw".equals(word) || "break".equals(word) || "continue".equals(word)
        || "synchronized".equals(word) || "assert".equals(word) || "else".equals(word);
  }

  /**
   * ذيل الدالة. في أجسام الأصناف يُتوقَّع جسم، فإن غاب "{" يُبلَّغ بـ"; expected" كما يفعل javac
   * ويُكمل تحليل الجمل حتى الإغلاق "}" للدالة، فلا تتكرر الأخطاء على كل جملة من جملها.
   * في الواجهات والإشعارات الدالة المجردة تنتهي بـ";".
   */
  private void methodRest(int kind) {
    parameters();
    while (isSymbol("[")) {
      consume();
      expectSymbol("]", "']'");
    }
    if (isKeyword("throws")) {
      consume();
      typeList();
    }
    if (isKeyword("default")) {
      consume();
      elementValue();
    }
    if (isSymbol("{")) {
      block();
      return;
    }
    if (kind == BODY_INTERFACE || kind == BODY_ANNOTATION || isSymbol(";")) {
      expectSemicolon();
      return;
    }
    report(afterPrevious(KEY_SEMICOLON, FALLBACK_SEMICOLON));
    if (statementsUntil(false)) return;
    if (isSymbol("}")) consume();
  }

  private void parameters() {
    expectSymbol("(", "'('");
    if (!isSymbol(")")) {
      formalParameter();
      while (isSymbol(",")) {
        consume();
        formalParameter();
      }
    }
    expectSymbol(")", "')'");
  }

  private void formalParameter() {
    modifiersLite();
    type();
    if (isSymbol("...")) consume();
    if (isKeyword("this")) {
      consume();
      return;
    }
    identifierDeclaration();
    while (isSymbol("[")) {
      consume();
      expectSymbol("]", "']'");
    }
  }

  private void variableDeclaratorsRest() {
    variableDeclaratorsRest(false);
  }

  /** حقول الواجهات ثوابت لا بد لها من "=" (javac: = expected). */
  private void variableDeclaratorsRest(boolean requireInitializer) {
    while (true) {
      while (isSymbol("[")) {
        consume();
        expectSymbol("]", "']'");
      }
      if (isSymbol("=")) {
        consume();
        variableInitializer();
      } else if (requireInitializer) {
        throw expectedAfterPrevious("'='");
      }
      if (!isSymbol(",")) return;
      consume();
      identifierDeclaration();
    }
  }

  private void variableInitializer() {
    if (isSymbol("{")) arrayInitializer();
    else expression();
  }

  private void arrayInitializer() {
    expectSymbol("{", "'{'");
    while (!isSymbol("}")) {
      variableInitializer();
      if (!isSymbol(",")) break;
      consume();
    }
    expectSymbol("}", "'}'");
  }

  private void typeParameters() {
    expectSymbol("<", "'<'");
    while (true) {
      annotations();
      identifierDeclaration();
      if (isKeyword("extends")) {
        consume();
        type();
        while (isSymbol("&")) {
          consume();
          type();
        }
      }
      if (!isSymbol(",")) break;
      consume();
    }
    expectSymbol(">", "'>'");
  }

  private void typeList() {
    typeAfterKeyword();
    while (isSymbol(",")) {
      consume();
      typeAfterKeyword();
    }
  }

  private void typeAfterKeyword() {
    if (!isIdentifier()) throw expectedAfterPrevious("<identifier>");
    type();
  }

  // ---------------------------------------------------------------------------------------------
  // الأنواع والتعليقات والمعدِّلات
  // ---------------------------------------------------------------------------------------------

  private void type() {
    annotations();
    if (isPrimitive()) {
      consume();
    } else if (isIdentifier()) {
      classType();
    } else {
      throw failAtCurrent(KEY_ILLEGAL_TYPE, FALLBACK_ILLEGAL_TYPE);
    }
    arrayDimensions();
  }

  private void classType() {
    consume();
    if (isSymbol("<")) typeArguments();
    while (isSymbol(".") && (isIdentifierAt(pos + 1) || isSymbolAt(pos + 1, "@"))) {
      consume();
      annotations();
      identifierDeclaration();
      if (isSymbol("<")) typeArguments();
    }
  }

  private void typeArguments() {
    consume();
    if (isSymbol(">")) {
      consume();
      return;
    }
    while (true) {
      annotations();
      if (isSymbol("?")) {
        consume();
        if (isKeyword("extends") || isKeyword("super")) {
          consume();
          type();
        }
      } else {
        type();
      }
      if (!isSymbol(",")) break;
      consume();
    }
    expectSymbol(">", "'>'");
  }

  private void arrayDimensions() {
    while (isSymbol("[") && isSymbolAt(pos + 1, "]")) {
      consume();
      consume();
    }
  }

  private void annotations() {
    while (isSymbol("@") && !isKeywordAt(pos + 1, "interface")) annotation();
  }

  private void annotation() {
    consume();
    identifierDeclaration();
    while (isSymbol(".") && isIdentifierAt(pos + 1)) {
      consume();
      consume();
    }
    if (isSymbol("(")) annotationArguments();
  }

  /** (قيمة) أو (اسم = قيمة، ...): يتحقق من الفواصل والإغلاق كما يفعل javac. */
  private void annotationArguments() {
    consume();
    if (!isSymbol(")")) {
      annotationArgument();
      while (isSymbol(",")) {
        consume();
        annotationArgument();
      }
    }
    expectSymbol(")", "')'");
  }

  private void annotationArgument() {
    if (isIdentifier() && isSymbolAt(pos + 1, "=")) {
      consume();
      consume();
    }
    elementValue();
  }

  private void skipBalancedParentheses() {
    int depth = 0;
    do {
      if (atEnd()) throw failAtEnd();
      if (isSymbol("(")) depth++;
      else if (isSymbol(")")) depth--;
      consume();
    } while (depth > 0);
  }

  private int modifiers() {
    int flags = 0;
    while (true) {
      if (isSymbol("@") && !isKeywordAt(pos + 1, "interface")) {
        annotation();
      } else if (isKeyword("public")) {
        flags |= FLAG_PUBLIC;
        consume();
      } else if (isKeyword("protected") || isKeyword("private") || isKeyword("static")
          || isKeyword("abstract") || isKeyword("final") || isKeyword("native")
          || isKeyword("synchronized") || isKeyword("transient") || isKeyword("volatile")
          || isKeyword("strictfp") || isKeyword("default")) {
        consume();
      } else if (isIdentifierNamed("sealed") && isSealedFollower(pos + 1)) {
        consume();
      } else if (isIdentifierNamed("non") && isSymbolAt(pos + 1, "-")
          && isIdentifierNamedAt(pos + 2, "sealed") && adjacent(pos + 1) && adjacent(pos + 2)) {
        consume();
        consume();
        consume();
      } else {
        return flags;
      }
    }
  }

  private boolean isSealedFollower(int index) {
    return isKeywordAt(index, "class") || isKeywordAt(index, "interface") || isKeywordAt(index, "abstract")
        || isKeywordAt(index, "static") || isKeywordAt(index, "final") || isKeywordAt(index, "public")
        || isKeywordAt(index, "protected") || isKeywordAt(index, "private") || isIdentifierNamedAt(index, "non");
  }

  /** معدِّلات الجمل المحلية والمعاملات والأنماط: final والتعليقات فقط. */
  private void modifiersLite() {
    while (true) {
      if (isKeyword("final")) consume();
      else if (isSymbol("@") && !isKeywordAt(pos + 1, "interface")) annotation();
      else return;
    }
  }

  /** معدِّلات تسبق تصريح جملة محلية (صنف محلي أو متغير). */
  private void localModifiers() {
    while (true) {
      if (isSymbol("@") && !isKeywordAt(pos + 1, "interface")) annotation();
      else if (isKeyword("final") || isKeyword("abstract") || isKeyword("static") || isKeyword("strictfp")) consume();
      else return;
    }
  }

  private void elementValue() {
    if (isSymbol("@")) {
      annotation();
      return;
    }
    if (isSymbol("{")) {
      consume();
      while (!isSymbol("}")) {
        elementValue();
        if (!isSymbol(",")) break;
        consume();
      }
      expectSymbol("}", "'}'");
      return;
    }
    conditional();
  }

  // ---------------------------------------------------------------------------------------------
  // الجمل
  // ---------------------------------------------------------------------------------------------

  /** كتلة؛ تُعيد true إن انتهت عند عضو صنف (الإغلاق مفقود وقد أُبلغ عنه). */
  private boolean block() {
    expectSymbol("{", "'{'");
    if (statementsUntil(false)) return true;
    if (atEnd()) throw failAtEnd();
    consume();
    return false;
  }

  /**
   * جمل الكتلة أو حالات switch التقليدية حتى الإغلاق أو الحالة التالية، بتعافٍ لكل جملة.
   *
   * <p>إن ظهر عضو صنف (public/private/protected/static) داخل الجسم فالإغلاق مفقود: يُبلَّغ عن
   * الخطأ مرة واحدة ويُعاد التحكم لجسم الصنف، كما يفعل javac، فلا تتكرر الأخطاء على كل أعضاء الصنف.
   *
   * @return true إن انتهت الجمل عند عضو صنف لا عند الإغلاق.
   */
  private boolean statementsUntil(boolean switchLabels) {
    while (!isSymbol("}") && !atEnd() && !(switchLabels && (isKeyword("case") || isKeyword("default")))) {
      if (startsClassMember()) {
        report(failAtCurrent(KEY_ILLEGAL_EXPRESSION, FALLBACK_ILLEGAL_EXPRESSION));
        return true;
      }
      int before = pos;
      try {
        blockStatement();
      } catch (Failure failure) {
        report(failure);
        recover();
      }
      if (pos == before) consume();
    }
    return false;
  }

  /** معدِّلات لا تبدأ جملة داخل كتلة: وجودها يعني أن الدالة/الكتلة السابقة لم تُغلق. */
  private boolean startsClassMember() {
    return isKeyword("public") || isKeyword("private") || isKeyword("protected") || isKeyword("static");
  }

  private void blockStatement() {
    if (isIdentifierNamed("yield") && yieldFollows()) {
      statement();
      return;
    }
    if ((isSymbol("@") && !isKeywordAt(pos + 1, "interface")) || isKeyword("final") || isKeyword("abstract")
        || isKeyword("static") || isKeyword("strictfp")) {
      localModifiers();
      if (atTypeDeclaration()) {
        typeDeclarationAfterModifiers(0, CONTEXT_LOCAL);
        return;
      }
      localVariableDeclaration();
      return;
    }
    if (atTypeDeclaration()) {
      typeDeclarationAfterModifiers(0, CONTEXT_LOCAL);
      return;
    }
    if (startsLocalVariableDeclaration()) {
      localVariableDeclaration();
      return;
    }
    statement();
  }

  private void localVariableDeclaration() {
    type();
    identifierDeclaration();
    variableDeclaratorsRest();
    expectSemicolon();
  }

  /** نوع متبوع باسم: تصريح متغير لا تعبير. يتراجع المؤشر دائمًا بعد الاستكشاف. */
  private boolean startsLocalVariableDeclaration() {
    if (!isIdentifier() && !isPrimitive()) return false;
    int mark = pos;
    try {
      type();
      return isIdentifier();
    } catch (Failure failure) {
      return false;
    } finally {
      pos = mark;
    }
  }

  private boolean yieldFollows() {
    return !(isSymbolAt(pos + 1, "=") || isSymbolAt(pos + 1, ".") || isSymbolAt(pos + 1, "[")
        || isSymbolAt(pos + 1, "++") || isSymbolAt(pos + 1, "--") || assignmentLengthAt(pos + 1) > 0);
  }

  private void statement() {
    if (isSymbol("{")) {
      block();
    } else if (isSymbol(";")) {
      consume();
    } else if (isIdentifier() && isSymbolAt(pos + 1, ":")) {
      consume();
      consume();
      statement();
    } else if (isKeyword("if")) {
      consume();
      parenthesized();
      statement();
      if (isKeyword("else")) {
        consume();
        statement();
      }
    } else if (isKeyword("while")) {
      consume();
      parenthesized();
      statement();
    } else if (isKeyword("do")) {
      consume();
      statement();
      expectKeyword("while");
      parenthesized();
      expectSemicolon();
    } else if (isKeyword("for")) {
      forStatement();
    } else if (isKeyword("try")) {
      tryStatement();
    } else if (isKeyword("switch")) {
      consume();
      parenthesized();
      switchBody();
    } else if (isKeyword("synchronized")) {
      consume();
      parenthesized();
      block();
    } else if (isKeyword("return")) {
      consume();
      if (!isSymbol(";")) expression();
      expectSemicolon();
    } else if (isKeyword("throw")) {
      consume();
      expression();
      expectSemicolon();
    } else if (isKeyword("break") || isKeyword("continue")) {
      consume();
      if (isIdentifier()) consume();
      expectSemicolon();
    } else if (isKeyword("assert")) {
      consume();
      expression();
      if (isSymbol(":")) {
        consume();
        expression();
      }
      expectSemicolon();
    } else if (isIdentifierNamed("yield") && yieldFollows()) {
      consume();
      expression();
      expectSemicolon();
    } else if (isKeyword("else")) {
      throw failAtCurrent(KEY_ELSE, FALLBACK_ELSE);
    } else if (isKeyword("case") || isKeyword("default") || isKeyword("catch") || isKeyword("finally")) {
      throw failAtCurrent(KEY_ORPHANED, FALLBACK_ORPHANED, value(pos));
    } else {
      int start = pos;
      if (!expression()) throw failAt(start, KEY_NOT_STATEMENT, FALLBACK_NOT_STATEMENT);
      expectSemicolon();
    }
  }

  private void parenthesized() {
    expectSymbol("(", "'('");
    expression();
    expectSymbol(")", "')'");
  }

  private void forStatement() {
    consume();
    expectSymbol("(", "'('");
    if (isForEachHeader()) {
      modifiersLite();
      type();
      identifierDeclaration();
      expectSymbol(":", "':'");
      expression();
      expectSymbol(")", "')'");
      statement();
      return;
    }
    if (!isSymbol(";")) {
      if (isKeyword("final") || isSymbol("@") || startsLocalVariableDeclaration()) {
        modifiersLite();
        type();
        identifierDeclaration();
        variableDeclaratorsRest();
      } else {
        expressionStatementList();
      }
    }
    expectSemicolon();
    if (!isSymbol(";")) expression();
    expectSemicolon();
    if (!isSymbol(")")) expressionStatementList();
    expectSymbol(")", "')'");
    statement();
  }

  private boolean isForEachHeader() {
    int mark = pos;
    try {
      modifiersLite();
      type();
      identifierDeclaration();
      return isSymbol(":");
    } catch (Failure failure) {
      return false;
    } finally {
      pos = mark;
    }
  }

  private void expressionStatementList() {
    while (true) {
      int start = pos;
      if (!expression()) throw failAt(start, KEY_NOT_STATEMENT, FALLBACK_NOT_STATEMENT);
      if (!isSymbol(",")) return;
      consume();
    }
  }

  private void tryStatement() {
    int tryStart = pos;
    consume();
    boolean handled = false;
    if (isSymbol("(")) {
      resources();
      handled = true;
    }
    if (block()) return;
    while (isKeyword("catch")) {
      consume();
      expectSymbol("(", "'('");
      modifiersLite();
      type();
      while (isSymbol("|")) {
        consume();
        type();
      }
      identifierDeclaration();
      expectSymbol(")", "')'");
      if (block()) return;
      handled = true;
    }
    if (isKeyword("finally")) {
      consume();
      if (block()) return;
      handled = true;
    }
    if (!handled) throw failAt(tryStart, KEY_EXPECTED, FALLBACK_EXPECTED, "'catch' or 'finally'");
  }

  private void resources() {
    consume();
    while (!isSymbol(")")) {
      if (isKeyword("final") || isSymbol("@") || startsLocalVariableDeclaration()) {
        modifiersLite();
        type();
        identifierDeclaration();
        expectSymbol("=", "'='");
        expression();
      } else {
        expression();
      }
      if (!isSymbol(";")) break;
      consume();
    }
    expectSymbol(")", "')'");
  }

  private void switchBody() {
    expectSymbol("{", "'{'");
    while (!isSymbol("}")) {
      if (atEnd()) throw failAtEnd();
      int before = pos;
      try {
        if (startsClassMember()) {
          report(failAtCurrent(KEY_ILLEGAL_EXPRESSION, FALLBACK_ILLEGAL_EXPRESSION));
          return;
        }
        if (isKeyword("case")) {
          consume();
          caseLabels();
        } else if (isKeyword("default")) {
          consume();
        } else {
          throw failAtCurrent(KEY_EXPECTED, FALLBACK_EXPECTED, "'case', 'default', or '}'");
        }
        if (isSymbol("->")) {
          consume();
          switchArrowBody();
        } else if (isSymbol(":")) {
          consume();
          statementsUntil(true);
        } else {
          throw expectedAfterPrevious("':' or '->'");
        }
      } catch (Failure failure) {
        report(failure);
        recover();
      }
      if (pos == before) consume();
    }
    consume();
  }

  private void switchArrowBody() {
    if (isSymbol("{")) {
      block();
    } else if (isKeyword("throw")) {
      consume();
      expression();
      expectSemicolon();
    } else {
      expression();
      expectSemicolon();
    }
  }

  private void caseLabels() {
    boolean saved = inCaseLabel;
    inCaseLabel = true;
    try {
      caseLabel();
      while (isSymbol(",")) {
        consume();
        caseLabel();
      }
      if (isIdentifierNamed("when")) {
        consume();
        expression();
      }
    } finally {
      inCaseLabel = saved;
    }
  }

  private void caseLabel() {
    if (isKeyword("default")) {
      consume();
    } else if (startsPattern()) {
      pattern();
    } else {
      conditional();
    }
  }

  private boolean startsPattern() {
    int mark = pos;
    try {
      modifiersLite();
      type();
      return isIdentifier() || isSymbol("(");
    } catch (Failure failure) {
      return false;
    } finally {
      pos = mark;
    }
  }

  private void pattern() {
    modifiersLite();
    type();
    if (isSymbol("(")) {
      recordPatternComponents();
      return;
    }
    identifierDeclaration();
  }

  private void recordPatternComponents() {
    consume();
    if (!isSymbol(")")) {
      pattern();
      while (isSymbol(",")) {
        consume();
        pattern();
      }
    }
    expectSymbol(")", "')'");
  }

  // ---------------------------------------------------------------------------------------------
  // التعبيرات (تسلسل الأولوية). كل دالة تعيد هل التعبير "جملة تعبير" (يصح وحدها: تعيين، ++/--،
  // استدعاء، إنشاء كائن) لتحديد خطأ not a statement.
  // ---------------------------------------------------------------------------------------------

  private boolean expression() {
    if (startsLambda()) {
      lambda();
      return false;
    }
    boolean statement = conditional();
    int assignment = assignmentLengthAt(pos);
    if (assignment > 0) {
      consumeTokens(assignment);
      expression();
      return true;
    }
    return statement;
  }

  private boolean conditional() {
    boolean statement = binary(1);
    if (!isSymbol("?")) return statement;
    consume();
    expression();
    expectSymbol(":", "':'");
    if (startsLambda()) lambda();
    else conditional();
    return false;
  }

  private boolean binary(int minPrecedence) {
    boolean statement = unary();
    boolean applied = false;
    while (true) {
      if (isKeyword("instanceof")) {
        if (RELATIONAL_PRECEDENCE < minPrecedence) break;
        consume();
        instanceofTarget();
        applied = true;
        continue;
      }
      int precedence = binaryPrecedence(pos);
      if (precedence == 0 || precedence < minPrecedence) break;
      consumeTokens(binaryLength(pos));
      binary(precedence + 1);
      applied = true;
    }
    return applied ? false : statement;
  }

  private void instanceofTarget() {
    modifiersLite();
    type();
    if (isSymbol("(")) {
      recordPatternComponents();
      return;
    }
    if (isIdentifier()) consume();
  }

  private boolean unary() {
    if (isSymbol("+") || isSymbol("-") || isSymbol("!") || isSymbol("~")) {
      consume();
      unary();
      return false;
    }
    if (isSymbol("++") || isSymbol("--")) {
      consume();
      unary();
      return true;
    }
    if (isSymbol("(") && castAhead()) {
      cast();
      return false;
    }
    return postfix();
  }

  private boolean postfix() {
    boolean statement = primarySuffixes();
    boolean incremented = false;
    while (isSymbol("++") || isSymbol("--")) {
      consume();
      incremented = true;
    }
    return incremented || statement;
  }

  private boolean castAhead() {
    int mark = pos;
    try {
      consume();
      if (isPrimitive()) {
        type();
        return isSymbol(")");
      }
      if (!isIdentifier()) return false;
      type();
      while (isSymbol("&")) {
        consume();
        type();
      }
      if (!isSymbol(")")) return false;
      consume();
      return castOperandFollows();
    } catch (Failure failure) {
      return false;
    } finally {
      pos = mark;
    }
  }

  /** بعد ")" للقالب المرجعي: ما يبدأ تعبيرًا غير +/- (قاعدة JLS لأنواع المرجع). */
  private boolean castOperandFollows() {
    int kind = kind(pos);
    if (kind == JavaTokenizer.IDENTIFIER || kind == JavaTokenizer.LITERAL) return true;
    if (kind == JavaTokenizer.KEYWORD) {
      String word = value(pos);
      return "this".equals(word) || "super".equals(word) || "new".equals(word)
          || "switch".equals(word) || PRIMITIVES.contains(word) || "void".equals(word);
    }
    return isSymbol("(") || isSymbol("!") || isSymbol("~");
  }

  private void cast() {
    consume();
    type();
    while (isSymbol("&")) {
      consume();
      type();
    }
    expectSymbol(")", "')'");
    if (startsLambda()) lambda();
    else unary();
  }

  private boolean primarySuffixes() {
    boolean statement = primary();
    while (true) {
      if (isSymbol(".")) {
        consume();
        if (isIdentifier()) {
          consume();
          if (isSymbol("(")) {
            arguments();
            statement = true;
          } else {
            statement = false;
          }
        } else if (isSymbol("<")) {
          typeArguments();
          identifierDeclaration();
          arguments();
          statement = true;
        } else if (isKeyword("new")) {
          consume();
          creator();
          statement = true;
        } else if (isKeyword("super") && isSymbolAt(pos + 1, "(")) {
          consume();
          arguments();
          statement = true;
        } else if (isKeyword("this") || isKeyword("class") || isKeyword("super")) {
          consume();
          statement = false;
        } else {
          throw expectedAfterPrevious("<identifier>");
        }
      } else if (isSymbol("[") && isSymbolAt(pos + 1, "]")) {
        // نوع مصفوفة مؤهَّل: Map.Entry[].class أو Foo[]::new
        arrayDimensions();
        if (!isSymbol("::")) {
          expectSymbol(".", "'.'");
          expectKeyword("class");
        }
        statement = false;
      } else if (isSymbol("[")) {
        consume();
        expression();
        expectSymbol("]", "']'");
        statement = false;
      } else if (isSymbol("::")) {
        consume();
        if (isSymbol("<")) typeArguments();
        if (isKeyword("new")) consume();
        else identifierDeclaration();
        statement = false;
      } else {
        return statement;
      }
    }
  }

  private boolean primary() {
    if (kind(pos) == JavaTokenizer.LITERAL) {
      consume();
      return false;
    }
    if (isKeyword("this")) {
      consume();
      if (isSymbol("(")) {
        arguments();
        return true;
      }
      return false;
    }
    if (isKeyword("super")) {
      consume();
      if (isSymbol("(")) {
        arguments();
        return true;
      }
      if (!isSymbol(".") && !isSymbol("::")) throw expectedAfterPrevious("'.'");
      return false;
    }
    if (isKeyword("new")) {
      consume();
      creator();
      return true;
    }
    if (isSymbol("(")) {
      consume();
      expression();
      expectSymbol(")", "')'");
      return false;
    }
    if (isKeyword("switch")) {
      consume();
      parenthesized();
      switchBody();
      return false;
    }
    if (isPrimitive() || isKeyword("void")) {
      consume();
      arrayDimensions();
      if (isSymbol("::")) return false;
      expectSymbol(".", "'.'");
      expectKeyword("class");
      return false;
    }
    if (isIdentifier()) {
      if (startsLambda()) {
        lambda();
        return false;
      }
      if (isSymbolAt(pos + 1, "(")) {
        consume();
        arguments();
        return true;
      }
      if (isSymbolAt(pos + 1, "[") && isSymbolAt(pos + 2, "]")) {
        consume();
        arrayDimensions();
        if (isSymbol("::")) return false;
        expectSymbol(".", "'.'");
        expectKeyword("class");
        return false;
      }
      if (isSymbolAt(pos + 1, "<")) {
        int mark = pos;
        boolean methodReference = false;
        try {
          consume();
          typeArguments();
          arrayDimensions();
          methodReference = isSymbol("::");
        } catch (Failure failure) {
          methodReference = false;
        }
        if (methodReference) return false;
        pos = mark;
      }
      consume();
      return false;
    }
    throw failAtCurrent(KEY_ILLEGAL_EXPRESSION, FALLBACK_ILLEGAL_EXPRESSION);
  }

  private void creator() {
    annotations();
    if (isSymbol("<")) typeArguments();
    if (isPrimitive()) {
      consume();
      if (!isSymbol("[")) throw expectedAfterPrevious("'['");
      arrayCreatorRest();
      return;
    }
    if (!isIdentifier()) throw expectedAfterPrevious("<identifier>");
    classType();
    if (isSymbol("[")) {
      arrayCreatorRest();
      return;
    }
    arguments();
    if (isSymbol("{")) classBody(null, BODY_ANONYMOUS);
  }

  private void arrayCreatorRest() {
    while (isSymbol("[")) {
      consume();
      if (isSymbol("]")) {
        consume();
      } else {
        expression();
        expectSymbol("]", "']'");
      }
    }
    if (isSymbol("{")) arrayInitializer();
  }

  private void arguments() {
    expectSymbol("(", "'('");
    if (!isSymbol(")")) {
      expression();
      while (isSymbol(",")) {
        consume();
        expression();
      }
    }
    expectSymbol(")", "')'");
  }

  private boolean startsLambda() {
    if (inCaseLabel) return false;
    if (isIdentifier() && isSymbolAt(pos + 1, "->")) return true;
    if (isSymbol("(")) {
      int close = matchingParenthesis(pos);
      return close >= 0 && isSymbolAt(close + 1, "->");
    }
    return false;
  }

  private void lambda() {
    if (isIdentifier()) consume();
    else skipBalancedParentheses();
    expectSymbol("->", "'->'");
    if (isSymbol("{")) block();
    else expression();
  }

  /** فهرس القوس المغلق المقابل لقوس مفتوح عند {@code open}، أو -1. */
  private int matchingParenthesis(int open) {
    int depth = 0;
    for (int i = open; i < count - 1; i++) {
      if (tokens.kind(i) != JavaTokenizer.SYMBOL) continue;
      String v = tokens.value(i);
      if ("(".equals(v)) {
        depth++;
      } else if (")".equals(v)) {
        depth--;
        if (depth == 0) return i;
      }
    }
    return -1;
  }

  // ---------------------------------------------------------------------------------------------
  // المعاملة المشتركة للرموز والإبلاغ
  // ---------------------------------------------------------------------------------------------

  /** طول معامل التعيين المركّب عند الفهرس (أو 0). */
  private int assignmentLengthAt(int index) {
    if (kind(index) != JavaTokenizer.SYMBOL) return 0;
    String v = value(index);
    if ("=".equals(v) || ASSIGNMENT_OPERATORS.contains(v)) return 1;
    if (">".equals(v) && adjacentSymbol(index + 1, ">")) {
      if (adjacentSymbol(index + 2, "=")) return 3;
      if (adjacentSymbol(index + 2, ">") && adjacentSymbol(index + 3, "=")) return 4;
    }
    return 0;
  }

  /** أولوية المعامل الثنائي عند الفهرس أو 0؛ الرمز ">" يُركَّب من رموز متلاصقة (>> و>= و>>>). */
  private int binaryPrecedence(int index) {
    if (kind(index) != JavaTokenizer.SYMBOL) return 0;
    String v = value(index);
    if ("||".equals(v)) return 1;
    if ("&&".equals(v)) return 2;
    if ("|".equals(v)) return 3;
    if ("^".equals(v)) return 4;
    if ("&".equals(v)) return 5;
    if ("==".equals(v) || "!=".equals(v)) return 6;
    if ("<".equals(v) || "<=".equals(v)) return RELATIONAL_PRECEDENCE;
    if ("<<".equals(v)) return 8;
    if ("+".equals(v) || "-".equals(v)) return 9;
    if ("*".equals(v) || "/".equals(v) || "%".equals(v)) return 10;
    if (">".equals(v)) {
      if (adjacentSymbol(index + 1, ">")) {
        if (adjacentSymbol(index + 2, ">")) return adjacentSymbol(index + 3, "=") ? 0 : 8;
        return adjacentSymbol(index + 2, "=") ? 0 : 8;
      }
      return RELATIONAL_PRECEDENCE;
    }
    return 0;
  }

  private int binaryLength(int index) {
    if (">".equals(value(index))) {
      if (adjacentSymbol(index + 1, ">")) return adjacentSymbol(index + 2, ">") ? 3 : 2;
      if (adjacentSymbol(index + 1, "=")) return 2;
    }
    return 1;
  }

  /** {@code true} إن كان الرمز عند الفهرس ملاصقًا لسابقه (لا فراغ بينهما). */
  private boolean adjacent(int index) {
    return index > 0 && index < count && tokens.start(index) == tokens.end(index - 1);
  }

  private boolean adjacentSymbol(int index, String symbol) {
    return index < count && isSymbolAt(index, symbol) && adjacent(index);
  }

  private void consumeTokens(int n) {
    for (int k = 0; k < n; k++) consume();
  }

  private int kind(int index) {
    return index < count ? tokens.kind(index) : JavaTokenizer.END;
  }

  private String value(int index) {
    return index < count ? tokens.value(index) : null;
  }

  private boolean atEnd() {
    return kind(pos) == JavaTokenizer.END;
  }

  private boolean isSymbol(String symbol) {
    return isSymbolAt(pos, symbol);
  }

  private boolean isSymbolAt(int index, String symbol) {
    return kind(index) == JavaTokenizer.SYMBOL && symbol.equals(value(index));
  }

  private boolean isKeyword(String word) {
    return isKeywordAt(pos, word);
  }

  private boolean isKeywordAt(int index, String word) {
    return kind(index) == JavaTokenizer.KEYWORD && word.equals(value(index));
  }

  private boolean isIdentifier() {
    return isIdentifierAt(pos);
  }

  private boolean isIdentifierAt(int index) {
    return kind(index) == JavaTokenizer.IDENTIFIER;
  }

  private boolean isIdentifierNamed(String word) {
    return isIdentifierNamedAt(pos, word);
  }

  private boolean isIdentifierNamedAt(int index, String word) {
    return kind(index) == JavaTokenizer.IDENTIFIER && word.equals(value(index));
  }

  private boolean isPrimitive() {
    return kind(pos) == JavaTokenizer.KEYWORD && PRIMITIVES.contains(value(pos));
  }

  private void consume() {
    if (--budget < 0) throw new Abort();
    if (pos < count - 1) pos++;
  }

  private void expectSymbol(String symbol, String display) {
    if (isSymbol(symbol)) {
      consume();
      return;
    }
    throw expectedAfterPrevious(display);
  }

  private void expectKeyword(String word) {
    if (isKeyword(word)) {
      consume();
      return;
    }
    throw expectedAfterPrevious("'" + word + "'");
  }

  /**
   * الفاصلة المنقوطة المفقودة تُبلَّغ ويستمر التحليل من الرمز الحالي دون تخطٍّ: هكذا لا يخسر
   * الفاحص الجملة التالية (مثل بداية دالة بعد سطر ناقص الفاصلة) كما يفعل javac.
   */
  private void expectSemicolon() {
    if (isSymbol(";")) {
      consume();
      return;
    }
    if (atEnd()) throw failAtEnd();
    report(afterPrevious(KEY_SEMICOLON, FALLBACK_SEMICOLON));
  }

  private String identifierDeclaration() {
    if (!isIdentifier()) throw expectedAfterPrevious("<identifier>");
    String name = value(pos);
    consume();
    return name;
  }

  /** تعافٍ: يتخطى إلى فاصلة منقوطة أو قوس إغلاق للكتلة الحالية، مع تتبّع الأقواس المفتوحة. */
  private void recover() {
    int depth = 0;
    while (!atEnd()) {
      if (isSymbol("{")) {
        depth++;
      } else if (isSymbol("}")) {
        if (depth == 0) return;
        depth--;
        if (depth == 0) {
          consume();
          return;
        }
      } else if (isSymbol(";") && depth == 0) {
        consume();
        return;
      }
      consume();
    }
  }

  /** javac يكتم الخطأ النحوي الذي يقع على رمز معطوب معجميًا: الخطأ المعجمي هو السبب. */
  private void report(Failure failure) {
    if (tokens.isErroneous(failure.token)) return;
    addProblem(failure.offset, failure.end, failure.key, failure.fallback, failure.arguments);
  }

  private void addProblem(int offset, int end, String key, String fallback, Object... arguments) {
    int line = lineOf(offset);
    if (!errorLines.add(line)) return;
    int column = offset - lineStarts[line - 1] + 1;
    problems.add(new Problem(offset, Math.max(end, offset + 1), line, column, key, fallback, arguments));
  }

  private int lineOf(int offset) {
    if (lineStarts == null) lineStarts = lineStartOffsets(source);
    int index = Arrays.binarySearch(lineStarts, offset);
    return index >= 0 ? index + 1 : -index - 1;
  }

  private static int[] lineStartOffsets(String text) {
    int lines = 1;
    for (int i = 0; i < text.length(); i++) {
      if (text.charAt(i) == '\n') lines++;
    }
    int[] starts = new int[lines];
    int line = 1;
    for (int i = 0; i < text.length(); i++) {
      if (text.charAt(i) == '\n') starts[line++] = i + 1;
    }
    return starts;
  }

  private Failure failAtCurrent(String key, String fallback, Object... arguments) {
    if (atEnd()) return failAtEnd();
    return new Failure(tokens.start(pos), tokens.end(pos), pos, key, fallback, arguments);
  }

  private Failure failAt(int index, String key, String fallback, Object... arguments) {
    return new Failure(tokens.start(index), tokens.end(index), index, key, fallback, arguments);
  }

  /** javac يُبلغ عن نهاية الملف المفاجئة عند آخر رمز حقيقي. */
  private Failure failAtEnd() {
    int last = Math.max(0, count - 2);
    return new Failure(tokens.start(last), tokens.end(last), last, KEY_END_OF_FILE, FALLBACK_END_OF_FILE,
        new Object[0]);
  }

  private Failure expectedAfterPrevious(String what) {
    if (atEnd()) return failAtEnd();
    return afterPrevious(KEY_EXPECTED, FALLBACK_EXPECTED, what);
  }

  /** موضع "X expected": حرف آخر رمز سابق (كما يضع javac المؤشر بعد الرمز السابق). */
  private Failure afterPrevious(String key, String fallback, Object... arguments) {
    if (pos == 0) return new Failure(0, 1, 0, key, fallback, arguments);
    int previousEnd = tokens.end(pos - 1);
    return new Failure(Math.max(0, previousEnd - 1), Math.max(1, previousEnd), pos, key, fallback, arguments);
  }
}
