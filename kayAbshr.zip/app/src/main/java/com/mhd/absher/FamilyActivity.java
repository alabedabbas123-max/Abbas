package com.mhd.absher;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class FamilyActivity extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.family);
        View viewFindViewById = findViewById(R.id.navHome);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FamilyActivity.this.startActivity(new Intent((Context) FamilyActivity.this, (Class<?>) ActivityHomeActivity.class));
                    FamilyActivity.this.finish();
                }
            });
        }
        View viewFindViewById2 = findViewById(R.id.navWorkers);
        if (viewFindViewById2 != null) {
            viewFindViewById2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FamilyActivity.this.startActivity(new Intent((Context) FamilyActivity.this, (Class<?>) WorkersActivity.class));
                    FamilyActivity.this.finish();
                }
            });
        }
        View viewFindViewById3 = findViewById(R.id.navMyServices);
        if (viewFindViewById3 != null) {
            viewFindViewById3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FamilyActivity.this.startActivity(new Intent((Context) FamilyActivity.this, (Class<?>) MyServicesActivity.class));
                    FamilyActivity.this.finish();
                }
            });
        }
        View viewFindViewById4 = findViewById(R.id.navOther);
        if (viewFindViewById4 != null) {
            viewFindViewById4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FamilyActivity.this.startActivity(new Intent((Context) FamilyActivity.this, (Class<?>) OtherServicesActivity.class));
                    FamilyActivity.this.finish();
                }
            });
        }
    }
}
