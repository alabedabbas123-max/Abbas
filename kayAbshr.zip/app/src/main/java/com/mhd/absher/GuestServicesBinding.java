package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import com.a.a.a.a.a;

public final class GuestServicesBinding {
    public final Button btnAuthConfirm;
    public final LinearLayout btnLoginNow;
    public final CardView cardview4;
    public final EditText etAuthSecretId;
    public final LinearLayout footerGuest;
    public final RelativeLayout headerGuest;
    public final HorizontalScrollView hsServices;
    public final ImageView icon1;
    public final ImageView icon2;
    public final ImageView icon3;
    public final ImageView icon4;
    public final ImageView icon5;
    public final ImageView icon6;
    public final ImageView icon7;
    public final ImageView icon8;
    public final ImageView ivAbsherLogo;
    public final ImageView ivBell;
    public final ImageView ivEmblem;
    public final ImageView ivFooterIcon;
    public final ImageView ivPattern;
    public final ImageView ivSettings;
    public final RelativeLayout layoutAuthOverlay;
    public final RelativeLayout layoutLoadingOverlay;
    public final LinearLayout linear36;
    public final LinearLayout linear50;
    public final LinearLayout logosRow;
    public final RelativeLayout publicTitleRow;
    public final RelativeLayout rootView;
    public final LinearLayout rowBottom;
    public final LinearLayout rowTop;
    public final ScrollView scrollGuest;
    public final LinearLayout servicesContainer;
    public final TextView text1;
    public final TextView text2;
    public final TextView text3;
    public final TextView text4;
    public final TextView text5;
    public final TextView text6;
    public final TextView text7;
    public final TextView text8;
    public final TextView textview63;
    public final TextView textview64;
    public final TextView textview65;
    public final TextView textview66;
    public final LinearLayout tile1;
    public final LinearLayout tile2;
    public final LinearLayout tile3;
    public final LinearLayout tile4;
    public final LinearLayout tile5;
    public final LinearLayout tile6;
    public final LinearLayout tile7;
    public final LinearLayout tile8;
    public final LinearLayout topIcons;
    public final TextView tvFooterText;
    public final TextView tvHeaderText;
    public final TextView tvLoginNow;
    public final TextView tvPublicServices;
    public final TextView tvShowAll;
    public final WebView webviewLoadingGif;

    private GuestServicesBinding(RelativeLayout relativeLayout, ScrollView scrollView, LinearLayout linearLayout, RelativeLayout relativeLayout2, ImageView imageView, LinearLayout linearLayout2, ImageView imageView2, ImageView imageView3, LinearLayout linearLayout3, ImageView imageView4, ImageView imageView5, LinearLayout linearLayout4, TextView textView, TextView textView2, RelativeLayout relativeLayout3, TextView textView3, TextView textView4, HorizontalScrollView horizontalScrollView, LinearLayout linearLayout5, LinearLayout linearLayout6, LinearLayout linearLayout7, ImageView imageView6, TextView textView5, LinearLayout linearLayout8, ImageView imageView7, TextView textView6, LinearLayout linearLayout9, ImageView imageView8, TextView textView7, LinearLayout linearLayout10, ImageView imageView9, TextView textView8, LinearLayout linearLayout11, LinearLayout linearLayout12, ImageView imageView10, TextView textView9, LinearLayout linearLayout13, ImageView imageView11, TextView textView10, LinearLayout linearLayout14, ImageView imageView12, TextView textView11, LinearLayout linearLayout15, ImageView imageView13, TextView textView12, LinearLayout linearLayout16, ImageView imageView14, TextView textView13, RelativeLayout relativeLayout4, CardView cardView, LinearLayout linearLayout17, TextView textView14, TextView textView15, TextView textView16, EditText editText, Button button, TextView textView17, RelativeLayout relativeLayout5, WebView webView) {
        this.rootView = relativeLayout;
        this.scrollGuest = scrollView;
        this.linear36 = linearLayout;
        this.headerGuest = relativeLayout2;
        this.ivPattern = imageView;
        this.topIcons = linearLayout2;
        this.ivBell = imageView2;
        this.ivSettings = imageView3;
        this.logosRow = linearLayout3;
        this.ivAbsherLogo = imageView4;
        this.ivEmblem = imageView5;
        this.btnLoginNow = linearLayout4;
        this.tvLoginNow = textView;
        this.tvHeaderText = textView2;
        this.publicTitleRow = relativeLayout3;
        this.tvPublicServices = textView3;
        this.tvShowAll = textView4;
        this.hsServices = horizontalScrollView;
        this.servicesContainer = linearLayout5;
        this.rowTop = linearLayout6;
        this.tile2 = linearLayout7;
        this.icon2 = imageView6;
        this.text2 = textView5;
        this.tile1 = linearLayout8;
        this.icon1 = imageView7;
        this.text1 = textView6;
        this.tile4 = linearLayout9;
        this.icon4 = imageView8;
        this.text4 = textView7;
        this.tile3 = linearLayout10;
        this.icon3 = imageView9;
        this.text3 = textView8;
        this.rowBottom = linearLayout11;
        this.tile6 = linearLayout12;
        this.icon6 = imageView10;
        this.text6 = textView9;
        this.tile5 = linearLayout13;
        this.icon5 = imageView11;
        this.text5 = textView10;
        this.tile8 = linearLayout14;
        this.icon8 = imageView12;
        this.text8 = textView11;
        this.tile7 = linearLayout15;
        this.icon7 = imageView13;
        this.text7 = textView12;
        this.footerGuest = linearLayout16;
        this.ivFooterIcon = imageView14;
        this.tvFooterText = textView13;
        this.layoutAuthOverlay = relativeLayout4;
        this.cardview4 = cardView;
        this.linear50 = linearLayout17;
        this.textview63 = textView14;
        this.textview64 = textView15;
        this.textview65 = textView16;
        this.etAuthSecretId = editText;
        this.btnAuthConfirm = button;
        this.textview66 = textView17;
        this.layoutLoadingOverlay = relativeLayout5;
        this.webviewLoadingGif = webView;
    }

    public static GuestServicesBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.scrollGuest);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear36);
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.headerGuest);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.ivPattern);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.topIcons);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.ivBell);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.ivSettings);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.logosRow);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.ivAbsherLogo);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.ivEmblem);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.btnLoginNow);
        TextView textView = (TextView) findChildViewById(view, R.id.tvLoginNow);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvHeaderText);
        RelativeLayout relativeLayout3 = (RelativeLayout) findChildViewById(view, R.id.publicTitleRow);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tvPublicServices);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tvShowAll);
        HorizontalScrollView horizontalScrollView = (HorizontalScrollView) findChildViewById(view, R.id.hsServices);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.servicesContainer);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.rowTop);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.tile2);
        ImageView imageView6 = (ImageView) findChildViewById(view, R.id.icon2);
        TextView textView5 = (TextView) findChildViewById(view, R.id.text2);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.tile1);
        ImageView imageView7 = (ImageView) findChildViewById(view, R.id.icon1);
        TextView textView6 = (TextView) findChildViewById(view, R.id.text1);
        LinearLayout linearLayout9 = (LinearLayout) findChildViewById(view, R.id.tile4);
        ImageView imageView8 = (ImageView) findChildViewById(view, R.id.icon4);
        TextView textView7 = (TextView) findChildViewById(view, R.id.text4);
        LinearLayout linearLayout10 = (LinearLayout) findChildViewById(view, R.id.tile3);
        ImageView imageView9 = (ImageView) findChildViewById(view, R.id.icon3);
        TextView textView8 = (TextView) findChildViewById(view, R.id.text3);
        LinearLayout linearLayout11 = (LinearLayout) findChildViewById(view, R.id.rowBottom);
        LinearLayout linearLayout12 = (LinearLayout) findChildViewById(view, R.id.tile6);
        ImageView imageView10 = (ImageView) findChildViewById(view, R.id.icon6);
        TextView textView9 = (TextView) findChildViewById(view, R.id.text6);
        LinearLayout linearLayout13 = (LinearLayout) findChildViewById(view, R.id.tile5);
        ImageView imageView11 = (ImageView) findChildViewById(view, R.id.icon5);
        TextView textView10 = (TextView) findChildViewById(view, R.id.text5);
        LinearLayout linearLayout14 = (LinearLayout) findChildViewById(view, R.id.tile8);
        ImageView imageView12 = (ImageView) findChildViewById(view, R.id.icon8);
        TextView textView11 = (TextView) findChildViewById(view, R.id.text8);
        LinearLayout linearLayout15 = (LinearLayout) findChildViewById(view, R.id.tile7);
        ImageView imageView13 = (ImageView) findChildViewById(view, R.id.icon7);
        TextView textView12 = (TextView) findChildViewById(view, R.id.text7);
        LinearLayout linearLayout16 = (LinearLayout) findChildViewById(view, R.id.footerGuest);
        ImageView imageView14 = (ImageView) findChildViewById(view, R.id.ivFooterIcon);
        TextView textView13 = (TextView) findChildViewById(view, R.id.tvFooterText);
        RelativeLayout relativeLayout4 = (RelativeLayout) findChildViewById(view, R.id.layoutAuthOverlay);
        CardView cardViewFindChildViewById = findChildViewById(view, R.id.cardview4);
        LinearLayout linearLayout17 = (LinearLayout) findChildViewById(view, R.id.linear50);
        TextView textView14 = (TextView) findChildViewById(view, R.id.textview63);
        TextView textView15 = (TextView) findChildViewById(view, R.id.textview64);
        TextView textView16 = (TextView) findChildViewById(view, R.id.textview65);
        EditText editText = (EditText) findChildViewById(view, R.id.etAuthSecretId);
        Button button = (Button) findChildViewById(view, R.id.btnAuthConfirm);
        TextView textView17 = (TextView) findChildViewById(view, R.id.textview66);
        RelativeLayout relativeLayout5 = (RelativeLayout) findChildViewById(view, R.id.layoutLoadingOverlay);
        WebView webView = (WebView) findChildViewById(view, R.id.webviewLoadingGif);
        if (scrollView == null || linearLayout == null || relativeLayout2 == null || imageView == null || linearLayout2 == null || imageView2 == null || imageView3 == null || linearLayout3 == null || imageView4 == null || imageView5 == null || linearLayout4 == null || textView == null || textView2 == null || relativeLayout3 == null || textView3 == null || textView4 == null || horizontalScrollView == null || linearLayout5 == null || linearLayout6 == null || linearLayout7 == null || imageView6 == null || textView5 == null || linearLayout8 == null || imageView7 == null || textView6 == null || linearLayout9 == null || imageView8 == null || textView7 == null || linearLayout10 == null || imageView9 == null || textView8 == null || linearLayout11 == null || linearLayout12 == null || imageView10 == null || textView9 == null || linearLayout13 == null || imageView11 == null || textView10 == null || linearLayout14 == null || imageView12 == null || textView11 == null || linearLayout15 == null || imageView13 == null || textView12 == null || linearLayout16 == null || imageView14 == null || textView13 == null || relativeLayout4 == null || cardViewFindChildViewById == null || linearLayout17 == null || textView14 == null || textView15 == null || textView16 == null || editText == null || button == null || textView17 == null || relativeLayout5 == null || webView == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new GuestServicesBinding(relativeLayout, scrollView, linearLayout, relativeLayout2, imageView, linearLayout2, imageView2, imageView3, linearLayout3, imageView4, imageView5, linearLayout4, textView, textView2, relativeLayout3, textView3, textView4, horizontalScrollView, linearLayout5, linearLayout6, linearLayout7, imageView6, textView5, linearLayout8, imageView7, textView6, linearLayout9, imageView8, textView7, linearLayout10, imageView9, textView8, linearLayout11, linearLayout12, imageView10, textView9, linearLayout13, imageView11, textView10, linearLayout14, imageView12, textView11, linearLayout15, imageView13, textView12, linearLayout16, imageView14, textView13, relativeLayout4, cardViewFindChildViewById, linearLayout17, textView14, textView15, textView16, editText, button, textView17, relativeLayout5, webView);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static GuestServicesBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static GuestServicesBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.guest_services, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
