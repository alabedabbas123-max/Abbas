package almlk;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * توليد الكود النقي (بلا أندرويد): Setters/Getters + Constructor + Extract Resource كتحويلات
 * نصية قابلة للاختبار خارج الجهاز (بند 2/3). يعيد null عند تعذّر التوليد لعرض سبب ظاهر.
 */
public final class CodeGen {
  private CodeGen() {}

  private static final class Field {
    final String type, name;
    Field(String t, String n) { type = t; name = n; }
  }

  private static String cap(String s) {
    return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
  }

  /** يستخرج الحقول غير الثابتة (private/protected/public [final] Type name;) من الصنف. */
  private static List<Field> fields(String source) {
    List<Field> out = new ArrayList<>();
    Pattern p =
        Pattern.compile(
            "(?m)^[ \\t]*(?:private|protected|public)[ \\t]+(?!class\\b)(final[ \\t]+)?"
                + "(static[ \\t]+)?([A-Za-z_][\\w.]*(?:<[^>\\n]*>)?(?:\\[\\])?)[ \\t]+"
                + "([a-z_][\\w]*)[ \\t]*(?:=[^;\\n]*)?;");
    Matcher m = p.matcher(source);
    while (m.find()) {
      if (m.group(2) != null) continue; // static لا يُضمَّن في باني/حقول المثيل
      out.add(new Field(m.group(3), m.group(4)));
    }
    return out;
  }

  public static String className(String source) {
    Matcher m = Pattern.compile("(?:class|interface)\\s+([A-Za-z_]\\w*)").matcher(source);
    return m.find() ? m.group(1) : null;
  }

  /** يولّد Getters/Setters لكل حقول المثيل ويضيفها قبل آخر «}». null إن لا حقول/صنف. */
  public static String createSettersGetters(String source) {
    String cn = className(source);
    if (cn == null) return null;
    List<Field> fs = fields(source);
    if (fs.isEmpty()) return null;
    int brace = source.lastIndexOf('}');
    if (brace < 0) return null;
    StringBuilder sb = new StringBuilder("\n");
    boolean added = false;
    for (Field f : fs) {
      if (!source.contains(" get" + cap(f.name) + "(")) {
        sb.append("  public ").append(f.type).append(" get").append(cap(f.name)).append("() {\n");
        sb.append("    return ").append(f.name).append(";\n  }\n\n");
        added = true;
      }
      if (!source.contains(" set" + cap(f.name) + "(")) {
        sb.append("  public void set").append(cap(f.name)).append("(").append(f.type).append(" ")
            .append(f.name).append(") {\n");
        sb.append("    this.").append(f.name).append(" = ").append(f.name).append(";\n  }\n\n");
        added = true;
      }
    }
    if (!added) return null; // موجود بالفعل — لا تكرار
    return source.substring(0, brace) + sb + source.substring(brace);
  }

  /** يولّد بانيًا يهيّئ حقول المثيل بترتيبها ويضيفه قبل آخر «}». null إن لا صنف. */
  public static String createConstructor(String source) {
    String cn = className(source);
    if (cn == null) return null;
    if (source.contains("public " + cn + "(")) return null; // باني موجود — لا تكرار
    int brace = source.lastIndexOf('}');
    if (brace < 0) return null;
    List<Field> fs = fields(source);
    StringBuilder params = new StringBuilder();
    StringBuilder body = new StringBuilder();
    for (int i = 0; i < fs.size(); i++) {
      Field f = fs.get(i);
      if (i > 0) params.append(", ");
      params.append(f.type).append(" ").append(f.name);
      body.append("    this.").append(f.name).append(" = ").append(f.name).append(";\n");
    }
    StringBuilder sb = new StringBuilder("\n  public ").append(cn).append("(").append(params)
        .append(") {\n").append(body).append("  }\n");
    return source.substring(0, brace) + sb + source.substring(brace);
  }

  /**
   * استخراج مورد (XML): يستبدل القيمة النصية المحددة [start,end) داخل سمة بـ{@code @string/name}.
   * يعيد null لمدى غير صالح أو قيمة غير محاطة باقتباس.
   */
  public static String extractResource(String source, int start, int end, String name) {
    if (source == null || start < 0 || end > source.length() || start >= end) return null;
    if (!Renamer.isValidJavaIdentifier(name) || Renamer.isKeyword(name)) return null;
    int q1 = source.lastIndexOf('"', start - 1);
    int q2 = source.indexOf('"', end);
    if (q1 < 0 || q2 < 0 || q2 <= q1) return null;
    return source.substring(0, q1 + 1) + "@string/" + name + source.substring(q2);
  }

  /** يُنتج إدخال {@code <string name="...">...</string>} لإلحاقه بـres/values/strings.xml. */
  public static String stringEntry(String name, String value) {
    return "    <string name=\"" + name + "\">" + value + "</string>\n";
  }
}
