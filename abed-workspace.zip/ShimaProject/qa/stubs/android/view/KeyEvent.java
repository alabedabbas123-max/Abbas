package android.view;

/** بديل اختياري بثوابت رموز المفاتيح الحقيقية — لمجموعة الانحدار فقط. */
public class KeyEvent {
  public static final int ACTION_DOWN = 0;
  public static final int KEYCODE_0 = 7;
  public static final int KEYCODE_9 = 16;
  public static final int KEYCODE_A = 29;
  public static final int KEYCODE_K = 39;
  public static final int KEYCODE_S = 47;
  public static final int KEYCODE_Z = 54;
  public static final int KEYCODE_TAB = 61;
  public static final int KEYCODE_SPACE = 62;
  public static final int KEYCODE_ENTER = 66;
  public static final int KEYCODE_F1 = 131;
  public static final int KEYCODE_F5 = 135;
  public static final int KEYCODE_F12 = 142;
}
