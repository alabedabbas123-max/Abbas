package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import com.a.a.a.a.a;

public final class PersonalInfoBinding {
    public final ImageView btnBackPersonalInfo;
    public final CardView cardview2;
    public final ImageView imageview88;
    public final LinearLayout linear90;
    public final LinearLayout linear91;
    public final LinearLayout linear92;
    public final RelativeLayout rootPersonalInfo;
    public final Space space22;
    public final TextView textview154;
    public final TextView textview18;
    public final TextView textview19;
    public final TextView textview20;
    public final TextView textview21;
    public final TextView textview22;
    public final TextView textview23;
    public final TextView textview24;
    public final TextView textview25;
    public final TextView textview26;
    public final TextView textview27;
    public final TextView textview278;
    public final TextView textview28;
    public final TextView textview29;
    public final TextView textview30;
    public final TextView textview31;
    public final TextView textview32;
    public final TextView textview33;
    public final TextView textview34;
    public final RelativeLayout topBar;
    public final TextView tvBirthPlace;
    public final TextView tvBloodType;
    public final TextView tvDob;
    public final TextView tvName;
    public final TextView tvTitle;
    public final View view12;
    public final View view13;
    public final View view14;
    public final View view15;
    public final View view16;
    public final View view17;
    public final View view18;
    public final View view19;
    public final View view20;
    public final View view21;
    public final ScrollView vscroll4;

    private PersonalInfoBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, ScrollView scrollView, LinearLayout linearLayout, LinearLayout linearLayout2, CardView cardView, ImageView imageView2, TextView textView2, LinearLayout linearLayout3, TextView textView3, TextView textView4, View view, TextView textView5, TextView textView6, View view2, TextView textView7, TextView textView8, View view3, TextView textView9, TextView textView10, View view4, TextView textView11, TextView textView12, View view5, TextView textView13, TextView textView14, View view6, TextView textView15, TextView textView16, View view7, TextView textView17, TextView textView18, View view8, TextView textView19, TextView textView20, View view9, TextView textView21, TextView textView22, View view10, TextView textView23, TextView textView24, Space space) {
        this.rootPersonalInfo = relativeLayout;
        this.topBar = relativeLayout2;
        this.btnBackPersonalInfo = imageView;
        this.tvTitle = textView;
        this.vscroll4 = scrollView;
        this.linear90 = linearLayout;
        this.linear91 = linearLayout2;
        this.cardview2 = cardView;
        this.imageview88 = imageView2;
        this.textview154 = textView2;
        this.linear92 = linearLayout3;
        this.textview18 = textView3;
        this.tvName = textView4;
        this.view12 = view;
        this.textview19 = textView5;
        this.tvBirthPlace = textView6;
        this.view13 = view2;
        this.textview20 = textView7;
        this.textview278 = textView8;
        this.view14 = view3;
        this.textview21 = textView9;
        this.tvDob = textView10;
        this.view15 = view4;
        this.textview22 = textView11;
        this.textview23 = textView12;
        this.view16 = view5;
        this.textview24 = textView13;
        this.textview25 = textView14;
        this.view17 = view6;
        this.textview26 = textView15;
        this.textview27 = textView16;
        this.view18 = view7;
        this.textview28 = textView17;
        this.textview29 = textView18;
        this.view19 = view8;
        this.textview30 = textView19;
        this.textview31 = textView20;
        this.view20 = view9;
        this.textview32 = textView21;
        this.textview33 = textView22;
        this.view21 = view10;
        this.textview34 = textView23;
        this.tvBloodType = textView24;
        this.space22 = space;
    }

    public static PersonalInfoBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBar);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBackPersonalInfo);
        TextView textView = (TextView) findChildViewById(view, R.id.tvTitle);
        ScrollView scrollView = (ScrollView) findChildViewById(view, R.id.vscroll4);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear90);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear91);
        CardView cardViewFindChildViewById = findChildViewById(view, R.id.cardview2);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview88);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview154);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear92);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview18);
        TextView textView4 = (TextView) findChildViewById(view, R.id.tvName);
        View viewFindChildViewById = findChildViewById(view, R.id.view12);
        TextView textView5 = (TextView) findChildViewById(view, R.id.textview19);
        TextView textView6 = (TextView) findChildViewById(view, R.id.tvBirthPlace);
        View viewFindChildViewById2 = findChildViewById(view, R.id.view13);
        TextView textView7 = (TextView) findChildViewById(view, R.id.textview20);
        TextView textView8 = (TextView) findChildViewById(view, R.id.textview278);
        View viewFindChildViewById3 = findChildViewById(view, R.id.view14);
        TextView textView9 = (TextView) findChildViewById(view, R.id.textview21);
        TextView textView10 = (TextView) findChildViewById(view, R.id.tvDob);
        View viewFindChildViewById4 = findChildViewById(view, R.id.view15);
        TextView textView11 = (TextView) findChildViewById(view, R.id.textview22);
        TextView textView12 = (TextView) findChildViewById(view, R.id.textview23);
        View viewFindChildViewById5 = findChildViewById(view, R.id.view16);
        TextView textView13 = (TextView) findChildViewById(view, R.id.textview24);
        TextView textView14 = (TextView) findChildViewById(view, R.id.textview25);
        View viewFindChildViewById6 = findChildViewById(view, R.id.view17);
        TextView textView15 = (TextView) findChildViewById(view, R.id.textview26);
        TextView textView16 = (TextView) findChildViewById(view, R.id.textview27);
        View viewFindChildViewById7 = findChildViewById(view, R.id.view18);
        TextView textView17 = (TextView) findChildViewById(view, R.id.textview28);
        TextView textView18 = (TextView) findChildViewById(view, R.id.textview29);
        View viewFindChildViewById8 = findChildViewById(view, R.id.view19);
        TextView textView19 = (TextView) findChildViewById(view, R.id.textview30);
        TextView textView20 = (TextView) findChildViewById(view, R.id.textview31);
        View viewFindChildViewById9 = findChildViewById(view, R.id.view20);
        TextView textView21 = (TextView) findChildViewById(view, R.id.textview32);
        TextView textView22 = (TextView) findChildViewById(view, R.id.textview33);
        View viewFindChildViewById10 = findChildViewById(view, R.id.view21);
        TextView textView23 = (TextView) findChildViewById(view, R.id.textview34);
        TextView textView24 = (TextView) findChildViewById(view, R.id.tvBloodType);
        Space space = (Space) findChildViewById(view, R.id.space22);
        if (relativeLayout2 == null || imageView == null || textView == null || scrollView == null || linearLayout == null || linearLayout2 == null || cardViewFindChildViewById == null || imageView2 == null || textView2 == null || linearLayout3 == null || textView3 == null || textView4 == null || viewFindChildViewById == null || textView5 == null || textView6 == null || viewFindChildViewById2 == null || textView7 == null || textView8 == null || viewFindChildViewById3 == null || textView9 == null || textView10 == null || viewFindChildViewById4 == null || textView11 == null || textView12 == null || viewFindChildViewById5 == null || textView13 == null || textView14 == null || viewFindChildViewById6 == null || textView15 == null || textView16 == null || viewFindChildViewById7 == null || textView17 == null || textView18 == null || viewFindChildViewById8 == null || textView19 == null || textView20 == null || viewFindChildViewById9 == null || textView21 == null || textView22 == null || viewFindChildViewById10 == null || textView23 == null || textView24 == null || space == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new PersonalInfoBinding(relativeLayout, relativeLayout2, imageView, textView, scrollView, linearLayout, linearLayout2, cardViewFindChildViewById, imageView2, textView2, linearLayout3, textView3, textView4, viewFindChildViewById, textView5, textView6, viewFindChildViewById2, textView7, textView8, viewFindChildViewById3, textView9, textView10, viewFindChildViewById4, textView11, textView12, viewFindChildViewById5, textView13, textView14, viewFindChildViewById6, textView15, textView16, viewFindChildViewById7, textView17, textView18, viewFindChildViewById8, textView19, textView20, viewFindChildViewById9, textView21, textView22, viewFindChildViewById10, textView23, textView24, space);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static PersonalInfoBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static PersonalInfoBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.personal_info, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootPersonalInfo;
    }
}
