package com.almlkid.ui.preferences;

import android.os.Bundle;
import com.shima.demo.R;

/** قسم Application — اللغة والتبويبات والسحب والتحليلات والثيم. */
public class ApplicationPreferencesFragment extends BasePreferenceFragment {
  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    addPreferencesFromResource(R.xml.preferences_application);
  }
}
