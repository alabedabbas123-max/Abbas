package com.mhd.absher;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.a.a.a.a.a;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    private MainBinding binding;
    private TimerTask t;
    private Timer _timer = new Timer();
    private Intent in = new Intent();

    private void initialize(Bundle bundle) {
        this.binding.webviewLoadingGif.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView webView, String str) {
                super.onPageFinished(webView, str);
            }

            @Override
            public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
                super.onPageStarted(webView, str, bitmap);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initializeLogic() {
        LinearLayout.LayoutParams layoutParams;
        LinearLayout.LayoutParams layoutParams2;
        if (!getIntent().hasExtra(a.a("NjsrRFYyCyBfVzgLIVhdJiA="))) {
            Intent intent = new Intent((Context) this, (Class<?>) SplashActivity.class);
            intent.addFlags(65536);
            startActivity(intent);
            finish();
            return;
        }
        final EditText editText = (EditText) findViewById(R.id.etUsername);
        final EditText editText2 = (EditText) findViewById(R.id.etPassword);
        Button button = (Button) findViewById(R.id.btnLogin);
        final TextView textView = (TextView) findViewById(R.id.tvError);
        final CheckBox checkBox = (CheckBox) findViewById(R.id.cbRememberMe);
        ImageView imageView = (ImageView) findViewById(R.id.btnBack);
        ImageView imageView2 = (ImageView) findViewById(R.id.imageview22);
        ImageView imageView3 = (ImageView) findViewById(R.id.imageview23);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.boxUsername);
        LinearLayout linearLayout2 = (LinearLayout) findViewById(R.id.boxPassword);
        final RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.layoutLoadingOverlay);
        final WebView webView = (WebView) findViewById(R.id.webviewLoadingGif);
        final SharedPreferences sharedPreferences = getSharedPreferences(a.a("AAcDf2cFBgNraw=="), 0);
        final SharedPreferences sharedPreferences2 = getSharedPreferences(a.a("ICcjX3w0ICc="), 0);
        final SharedPreferences sharedPreferences3 = getSharedPreferences(a.a("ICcjX2cmMTVeUTo6"), 0);
        String string = sharedPreferences.getString(a.a("ICcjX2swNzRITBww"), "");
        if (string.isEmpty()) {
            string = sharedPreferences3.getString(a.a("JjUwSFwKJyNOSjAgGUZdLA=="), "");
        }
        if (string.isEmpty()) {
            string = sharedPreferences2.getString(a.a("JjElX10hHyNU"), "");
        }
        if (string.isEmpty()) {
            string = sharedPreferences2.getString(a.a("ICcjX3MwLQ=="), "");
        }
        String string2 = sharedPreferences2.getString(a.a("PDAIWFU3MTQ="), "");
        if (string2.isEmpty()) {
            string2 = sharedPreferences.getString(a.a("JjUwSFwKPSJyViA5JEhK"), "");
        }
        if (string2.isEmpty()) {
            string2 = sharedPreferences3.getString(a.a("JjUwSFwKPSJyViA5JEhK"), "");
        }
        final String[] strArr = {string2};
        if (!string.isEmpty()) {
            try {
                FirebaseDatabase.getInstance(a.a("PSAyXUtve2lMWiY8I18VN2R3T1p4MCNLWSA4MgBKITAkA10gJildXXgjI15MZHogREowNideXTE1MkxaNCcjA1klJA==")).getReference(a.a("ICcjX3w0ICc=")).child(string).addValueEventListener(new ValueEventListener() {
                    public void onCancelled(DatabaseError databaseError) {
                    }

                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Object value;
                        try {
                            if (dataSnapshot.exists() && dataSnapshot.hasChild(a.a("PDAIWFU3MTQ=")) && (value = dataSnapshot.child(a.a("PDAIWFU3MTQ=")).getValue()) != null) {
                                String strValueOf = String.valueOf(value);
                                strArr[0] = strValueOf;
                                sharedPreferences.edit().putString(a.a("JjUwSFwKPSJyViA5JEhK"), strValueOf).apply();
                                sharedPreferences2.edit().putString(a.a("PDAIWFU3MTQ="), strValueOf).apply();
                                sharedPreferences3.edit().putString(a.a("JjUwSFwKPSJyViA5JEhK"), strValueOf).apply();
                            }
                        } catch (Exception e) {
                        }
                    }
                });
            } catch (Exception e) {
            }
        }
        if (imageView != null) {
            try {
                imageView.setImageResource(R.drawable.ic_left_arrow2);
                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                imageView.setAdjustViewBounds(true);
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        try {
                            Intent intent2 = new Intent((Context) MainActivity.this, (Class<?>) GuestServicesActivity.class);
                            intent2.addFlags(603979776);
                            MainActivity.this.startActivity(intent2);
                            MainActivity.this.finish();
                        } catch (Exception e2) {
                        }
                    }
                });
            } catch (Exception e2) {
            }
        }
        if (imageView2 != null) {
            try {
                imageView2.setImageResource(R.drawable.hhn_1);
                imageView2.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView2.setAdjustViewBounds(true);
            } catch (Exception e3) {
            }
        }
        if (imageView3 != null) {
            try {
                imageView3.setImageResource(R.drawable.hhn_2);
                imageView3.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView3.setAdjustViewBounds(true);
            } catch (Exception e4) {
            }
        }
        try {
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(-1);
            gradientDrawable.setCornerRadius(12.0f * getResources().getDisplayMetrics().density);
            gradientDrawable.setStroke((int) (2.0f * getResources().getDisplayMetrics().density), -16025005);
            if (linearLayout != null) {
                linearLayout.setBackground(gradientDrawable);
            }
            GradientDrawable gradientDrawable2 = new GradientDrawable();
            gradientDrawable2.setColor(-1);
            gradientDrawable2.setCornerRadius(12.0f * getResources().getDisplayMetrics().density);
            gradientDrawable2.setStroke((int) (2.0f * getResources().getDisplayMetrics().density), -16025005);
            if (linearLayout2 != null) {
                linearLayout2.setBackground(gradientDrawable2);
            }
            if (linearLayout != null && (layoutParams2 = (LinearLayout.LayoutParams) linearLayout.getLayoutParams()) != null) {
                layoutParams2.height = (int) (60.0f * getResources().getDisplayMetrics().density);
                linearLayout.setLayoutParams(layoutParams2);
            }
            if (linearLayout2 != null && (layoutParams = (LinearLayout.LayoutParams) linearLayout2.getLayoutParams()) != null) {
                layoutParams.height = (int) (60.0f * getResources().getDisplayMetrics().density);
                linearLayout2.setLayoutParams(layoutParams);
            }
        } catch (Exception e5) {
        }
        if (editText != null) {
            editText.setSingleLine(true);
            editText.setGravity(21);
            editText.setTextSize(14.0f);
            editText.setTextColor(-16777216);
            editText.setTypeface(Typeface.DEFAULT, 1);
            editText.setPadding(0, 0, 0, 0);
        }
        if (editText2 != null) {
            editText2.setSingleLine(true);
            editText2.setGravity(21);
            editText2.setTextSize(14.0f);
            editText2.setTextColor(-16777216);
            editText2.setTypeface(Typeface.DEFAULT, 1);
            editText2.setPadding(0, 0, 0, 0);
            editText2.setInputType(129);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                GradientDrawable gradientDrawable3 = new GradientDrawable();
                gradientDrawable3.setColor(-16032453);
                gradientDrawable3.setSize((int) (3.0f * getResources().getDisplayMetrics().density), (int) (28.0f * getResources().getDisplayMetrics().density));
                if (editText != null) {
                    editText.setTextCursorDrawable(gradientDrawable3);
                }
                if (editText2 != null) {
                    editText2.setTextCursorDrawable(gradientDrawable3);
                }
            } catch (Exception e6) {
            }
        }
        try {
            GradientDrawable gradientDrawable4 = new GradientDrawable();
            gradientDrawable4.setColor(-16025005);
            gradientDrawable4.setCornerRadius(30.0f * getResources().getDisplayMetrics().density);
            if (button != null) {
                button.setBackground(gradientDrawable4);
                button.setTextColor(-1);
                button.setTextSize(16.0f);
                button.setGravity(17);
                button.setAllCaps(false);
            }
        } catch (Exception e7) {
        }
        if (button == null || editText == null || editText2 == null || textView == null) {
            return;
        }
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String strTrim = editText.getText().toString().trim();
                    String strTrim2 = editText2.getText().toString().trim();
                    if (!strTrim.equals(strArr[0]) || !strTrim2.equals(a.a("FDV3HwthYXA="))) {
                        textView.setText(a.a("jfqemuD2dJ+s4d90norg5o3DDeDyjcL0vY3nnofg+4zp9L11jOX0sHWNxfS8jNGehBiN85+p4dCM9/SwjeU="));
                        return;
                    }
                    textView.setText("");
                    InputMethodManager inputMethodManager = (InputMethodManager) MainActivity.this.getSystemService(a.a("PDo2WEwKOSNZUDow"));
                    if (inputMethodManager != null && view != null) {
                        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    }
                    if (relativeLayout != null) {
                        relativeLayout.setVisibility(0);
                        relativeLayout.setClickable(true);
                        relativeLayout.setFocusable(true);
                    }
                    if (webView != null) {
                        webView.setBackgroundColor(-1);
                        webView.getSettings().setLoadWithOverviewMode(true);
                        webView.getSettings().setUseWideViewPort(true);
                        webView.getSettings().setJavaScriptEnabled(true);
                        webView.setVerticalScrollBarEnabled(false);
                        webView.setHorizontalScrollBarEnabled(false);
                        webView.loadDataWithBaseURL(a.a("Mz0qSAJ6e2lMVjEmKURcCjU1Xl0hew=="), a.a("aTwyQFRraC5IWTFqel5MLDgjE1AhOSoBGDc7IlQYLnQrTEoyPSgXCG50NkxcMT0oSgJlb2ZaUTEgLhcJZWRjFhg9MS9KUCFudx0IcG9mT1k2PyFfVyA6IgBbOjgpXwJ2EgBrfhMSfQ1XIzE0S1Q6I3xFUTEwI0MDdTAvXkg5NT8XXjkxPhYYPyE1WVEzLWtOVzsgI0NMbzcjQ0wwJn0NWTk9IUMVPCAjQEtvNyNDTDAmfQ1FPDkhDUN1OSdVFSI9IllQb2V2HR1udCtMQHg8I0RfPSB8HAhlcX0NVzc+I05MeDIvWQI2OyhZWTw6fQ1MJzUoXl46JisXSzY1KkgQZ3pyBAN1IDRMViYyKV9VeDs0RF88OnxOXTsgI18YNjEoWV0nb2ZQBHonMlRUMGp6AlAwNSITBDc7IlQGaT0rShgmJiUQHzIyLwNfPDJhAgZpeyRCXCxqegJQITkqEw=="), a.a("ITE+WRc9ICtB"), a.a("AAAAAAA="), null);
                    }
                    final int iNextInt = new Random().nextInt(9000) + 1000;
                    final boolean z = checkBox != null && checkBox.isChecked();
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Intent intent2 = new Intent((Context) MainActivity.this, (Class<?>) OtpActivity.class);
                                intent2.putExtra(a.a("AxEUZH4cFwd5cRoaGW53ERE="), iNextInt);
                                intent2.putExtra(a.a("BxELaHUXERRydRA="), z);
                                MainActivity.this.startActivity(intent2);
                                MainActivity.this.finish();
                            } catch (Exception e8) {
                            }
                        }
                    }, 3500L);
                } catch (Exception e8) {
                }
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = MainBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        FirebaseApp.initializeApp(this);
        initializeLogic();
    }
}
