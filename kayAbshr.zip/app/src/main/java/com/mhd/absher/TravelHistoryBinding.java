package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class TravelHistoryBinding {
    public final ImageView btnBackTravelHistory;
    public final ImageView imgEmptyTravel;
    public final LinearLayout linear12;
    public final RelativeLayout rootView;
    public final RelativeLayout topBarTravelHistory;
    public final TextView tvNoDataSub;
    public final TextView tvNoDataTitle;
    public final TextView tvTravelHistoryTitle;

    private TravelHistoryBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, LinearLayout linearLayout, ImageView imageView2, TextView textView2, TextView textView3) {
        this.rootView = relativeLayout;
        this.topBarTravelHistory = relativeLayout2;
        this.btnBackTravelHistory = imageView;
        this.tvTravelHistoryTitle = textView;
        this.linear12 = linearLayout;
        this.imgEmptyTravel = imageView2;
        this.tvNoDataTitle = textView2;
        this.tvNoDataSub = textView3;
    }

    public static TravelHistoryBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBarTravelHistory);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnBackTravelHistory);
        TextView textView = (TextView) findChildViewById(view, R.id.tvTravelHistoryTitle);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear12);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imgEmptyTravel);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvNoDataTitle);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tvNoDataSub);
        if (relativeLayout2 == null || imageView == null || textView == null || linearLayout == null || imageView2 == null || textView2 == null || textView3 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new TravelHistoryBinding(relativeLayout, relativeLayout2, imageView, textView, linearLayout, imageView2, textView2, textView3);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static TravelHistoryBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static TravelHistoryBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.travel_history, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
