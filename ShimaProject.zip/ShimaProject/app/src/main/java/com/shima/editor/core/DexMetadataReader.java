package com.shima.editor.core;

import java.nio.charset.StandardCharsets;

/** Safe DEX header/metadata reader. It parses bytes only and never loads or executes classes. */
public final class DexMetadataReader {
  private DexMetadataReader() {}

  public static String describe(String path, long availableSize, byte[] data) {
    StringBuilder result = new StringBuilder();
    result.append("DEX metadata\n\nالمسار: ").append(path == null ? "" : path);
    result.append("\nالحجم المعلن: ").append(availableSize).append(" بايت");
    if (data == null || data.length < 112) return result.append("\n\nالملف أصغر من ترويسة DEX.").toString();
    String magic = new String(data, 0, 8, StandardCharsets.US_ASCII).replace('\0', ' ');
    result.append("\nmagic: ").append(magic.trim());
    if (!(magic.startsWith("dex\\n") || magic.startsWith("dex"))) return result.append("\nالترويسة غير صالحة.").toString();
    result.append("\nfile_size: ").append(u32(data, 32));
    result.append("\nheader_size: ").append(u32(data, 36));
    result.append("\nstring_ids: ").append(u32(data, 56)).append(" @ ").append(hex(u32(data, 60)));
    result.append("\ntype_ids: ").append(u32(data, 64)).append(" @ ").append(hex(u32(data, 68)));
    result.append("\nproto_ids: ").append(u32(data, 72)).append(" @ ").append(hex(u32(data, 76)));
    result.append("\nfield_ids: ").append(u32(data, 80)).append(" @ ").append(hex(u32(data, 84)));
    result.append("\nmethod_ids: ").append(u32(data, 88)).append(" @ ").append(hex(u32(data, 92)));
    result.append("\nclass_defs: ").append(u32(data, 96)).append(" @ ").append(hex(u32(data, 100)));
    result.append("\n\nلا يتم تنفيذ أي bytecode؛ هذه معاينة metadata للقراءة فقط.");
    return result.toString();
  }

  private static long u32(byte[] bytes, int offset) {
    return (bytes[offset] & 255L)
        | ((bytes[offset + 1] & 255L) << 8)
        | ((bytes[offset + 2] & 255L) << 16)
        | ((bytes[offset + 3] & 255L) << 24);
  }

  private static String hex(long value) {
    return String.format(java.util.Locale.US, "0x%08X", value);
  }
}
