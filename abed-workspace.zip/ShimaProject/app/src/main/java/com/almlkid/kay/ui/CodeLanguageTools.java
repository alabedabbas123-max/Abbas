package com.almlkid.kay.ui;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Small dependency-free language service used by the editor. */
public final class CodeLanguageTools {
  /**
   * أكبر نص يُفحص تشخيصيًا (المحرر وفحص المشروع). المحلل النحوي خطي: نحو 25 ملّي ثانية لـ475 ألف
   * حرف، فلم يعد الملف الكبير (مثل MainActivity بـ113 ألف حرف) خارج الفحص.
   */
  public static final int MAX_CHECKED_CHARS = 400_000;

  public static final int KEYWORD = 1,
      STRING = 2,
      COMMENT = 3,
      NUMBER = 4,
      ANNOTATION = 5,
      TAG = 6,
      IDENTIFIER = 7,
      OPERATOR = 8,
      NAMESPACE = 9,
      SEPARATOR = 10,
      FUNCTION = 11,
      VARIABLE = 12;
  private static final Set<String> JAVA_WORDS =
      set(
          "abstract assert boolean break byte case catch char class const continue default do"
              + " double else enum extends final finally float for goto if implements import"
              + " instanceof int interface long native new package private protected public return"
              + " short static strictfp super switch synchronized this throw throws transient try"
              + " void volatile while true false null record sealed permits var override fun val"
              + " object when is in as typealias suspend data companion");
  private static final Set<String> COMMON_WORDS =
      set(
          "android application activity service fragment view bundle string integer color style"
              + " layout id drawable manifest resources gradle implementation dependencies plugins"
              + " namespace compileSdk minSdk targetSdk versionCode versionName");
  private static final Pattern IDENTIFIER_PATTERN = Pattern.compile("[A-Za-z_$][A-Za-z0-9_$]*");

  private CodeLanguageTools() {}

  public static final class Range {
    public final int start, end, type;

    Range(int s, int e, int t) {
      start = s;
      end = e;
      type = t;
    }
  }

  public static final class Diagnostic {
    public enum Severity { INFO, WARNING, ERROR }

    public final int offset, end, line, column;
    public final Severity severity;
    public final String code;
    public final String message;
    public final String messageKey;
    public final Object[] messageArgs;

    Diagnostic(int o, int l, int c, String m) {
      this(o, o + 1, l, c, Severity.ERROR, "CODE", m, null, new Object[0]);
    }

    Diagnostic(int o, int e, int l, int c, String m) {
      this(o, e, l, c, Severity.ERROR, "CODE", m, null, new Object[0]);
    }

    Diagnostic(int o, int e, int l, int c, Severity severity, String code, String m) {
      this(o, e, l, c, severity, code, m, null, new Object[0]);
    }

    private Diagnostic(
        int o,
        int e,
        int l,
        int c,
        Severity severity,
        String code,
        String m,
        String messageKey,
        Object[] messageArgs) {
      offset = o;
      end = Math.max(o + 1, e);
      line = l;
      column = c;
      this.severity = severity == null ? Severity.ERROR : severity;
      this.code = code == null ? "CODE" : code;
      message = m;
      this.messageKey = messageKey;
      this.messageArgs = messageArgs == null ? new Object[0] : messageArgs.clone();
    }

    public static Diagnostic localized(
        int o,
        int e,
        int l,
        int c,
        Severity severity,
        String code,
        String messageKey,
        String fallback,
        Object... arguments) {
      String message = fallback;
      try {
        if (arguments != null && arguments.length > 0) message = String.format(Locale.US, fallback, arguments);
      } catch (RuntimeException ignored) {
      }
      return new Diagnostic(o, e, l, c, severity, code, message, messageKey, arguments);
    }

    @Override
    public String toString() {
      return "Line " + line + ", column " + column + ": " + message;
    }
  }

  private static final class Open {
    final char value;
    final int offset, line, column;

    Open(char v, int o, int l, int c) {
      value = v;
      offset = o;
      line = l;
      column = c;
    }
  }

  public static List<Range> highlight(String fileName, String text) {
    if (isSmali(fileName)) return SmaliLanguageAdapter.highlight(text);
    return isXml(fileName) ? highlightXml(text) : highlightCode(text);
  }

  private static List<Range> highlightCode(String text) {
    ArrayList<Range> out = new ArrayList<>();
    int n = text.length(), i = 0;
    boolean expectType = false;
    boolean qualifiedName = false;
    while (i < n) {
      char c = text.charAt(i);
      if (c == ';') qualifiedName = false;
      if (c == '/' && i + 1 < n && text.charAt(i + 1) == '/') {
        int s = i;
        i += 2;
        while (i < n && text.charAt(i) != '\n') i++;
        out.add(new Range(s, i, COMMENT));
        continue;
      }
      if (c == '/' && i + 1 < n && text.charAt(i + 1) == '*') {
        int s = i;
        i += 2;
        while (i + 1 < n && !(text.charAt(i) == '*' && text.charAt(i + 1) == '/')) i++;
        i = Math.min(n, i + 2);
        out.add(new Range(s, i, COMMENT));
        continue;
      }
      if (c == '"' || c == '\'') {
        int s = i++;
        char quote = c;
        boolean escape = false;
        while (i < n) {
          char x = text.charAt(i++);
          if (escape) {
            escape = false;
            continue;
          }
          if (x == '\\') {
            escape = true;
            continue;
          }
          if (x == quote) break;
        }
        out.add(new Range(s, i, STRING));
        continue;
      }
      if (c == '@' && i + 1 < n && Character.isJavaIdentifierStart(text.charAt(i + 1))) {
        int s = i++;
        while (i < n && Character.isJavaIdentifierPart(text.charAt(i))) i++;
        out.add(new Range(s, i, ANNOTATION));
        continue;
      }
      if (Character.isDigit(c)) {
        int s = i++;
        while (i < n
            && (Character.isLetterOrDigit(text.charAt(i)) || "._xX+-".indexOf(text.charAt(i)) >= 0))
          i++;
        out.add(new Range(s, i, NUMBER));
        continue;
      }
      if (Character.isJavaIdentifierStart(c)) {
        int s = i++;
        while (i < n && Character.isJavaIdentifierPart(text.charAt(i))) i++;
        String word = text.substring(s, i);
        if (JAVA_WORDS.contains(word)) {
          out.add(new Range(s, i, KEYWORD));
          if (word.equals("import") || word.equals("package")) qualifiedName = true;
          expectType =
              word.equals("class")
                  || word.equals("interface")
                  || word.equals("enum")
                  || word.equals("extends")
                  || word.equals("implements")
                  || word.equals("new");
        } else {
          int next = nextNonWhitespace(text, i);
          boolean function = next < n && text.charAt(next) == '(';
          if (qualifiedName && !Character.isUpperCase(word.charAt(0)))
            out.add(new Range(s, i, NAMESPACE));
          else if (expectType || Character.isUpperCase(word.charAt(0))) {
            out.add(new Range(s, i, TAG));
          } else if (function) {
            out.add(new Range(s, i, FUNCTION));
          } else {
            out.add(new Range(s, i, VARIABLE));
          }
          expectType = false;
        }
        continue;
      }
      if ("+-*/%=!<>?&|^~".indexOf(c) >= 0) {
        int start = i++;
        while (i < n && "+-*/%=!<>?&|^~".indexOf(text.charAt(i)) >= 0) i++;
        out.add(new Range(start, i, OPERATOR));
        continue;
      }
      if (".,;:()[]{}".indexOf(c) >= 0) {
        out.add(new Range(i, i + 1, SEPARATOR));
      }
      i++;
    }
    return out;
  }

  private static int nextNonWhitespace(String text, int offset) {
    int cursor = offset;
    while (cursor < text.length() && Character.isWhitespace(text.charAt(cursor))) cursor++;
    return cursor;
  }

  /** إسقاط المرجع (تقرير 1.0.24): عنصر KEYWORD، خاصية IDENTIFIER، قيمة STRING، = OPERATOR. */
  private static List<Range> highlightXml(String text) {
    ArrayList<Range> out = new ArrayList<>();
    int i = 0, n = text.length();
    boolean inTag = false, expectName = false;
    while (i < n) {
      char c = text.charAt(i);
      if (!inTag) {
        if (text.startsWith("<!--", i)) {
          int e = text.indexOf("-->", i + 4);
          e = e < 0 ? n : e + 3;
          out.add(new Range(i, e, COMMENT));
          i = e;
          continue;
        }
        if (text.startsWith("<![CDATA[", i)) {
          int e = text.indexOf("]]>", i + 9);
          e = e < 0 ? n : e + 3;
          out.add(new Range(i, e, STRING));
          i = e;
          continue;
        }
        if (c == '<') {
          out.add(new Range(i, i + 1, KEYWORD));
          inTag = true;
          expectName = true;
          i++;
        } else i++;
        continue;
      }
      if (c == '>') {
        out.add(new Range(i, i + 1, KEYWORD));
        inTag = false;
        i++;
      } else if (c == '/' || c == '?' || c == '!') {
        out.add(new Range(i, i + 1, KEYWORD));
        i++;
      } else if (c == '"' || c == '\'') {
        int s = i++;
        while (i < n && text.charAt(i) != c) i++;
        i = Math.min(n, i + 1);
        out.add(new Range(s, i, STRING));
      } else if (c == '=') {
        out.add(new Range(i, i + 1, OPERATOR));
        i++;
      } else if (Character.isJavaIdentifierStart(c) || c == ':') {
        int e = i + 1;
        while (e < n
            && (Character.isJavaIdentifierPart(text.charAt(e))
                || text.charAt(e) == '-' || text.charAt(e) == ':' || text.charAt(e) == '.')) e++;
        out.add(new Range(i, e, expectName ? KEYWORD : IDENTIFIER));
        expectName = false;
        i = e;
      } else i++;
    }
    return out;
  }

  /** نهاية الوسم مع تجاوز القيم المقتبسة — تستخدمها تشخيصات inspectXml. */
  private static int findTagEnd(String text, int from) {
    char quote = 0;
    for (int i = from; i < text.length(); i++) {
      char c = text.charAt(i);
      if (quote != 0) {
        if (c == quote) quote = 0;
      } else if (c == '"' || c == '\'') quote = c;
      else if (c == '>') return i + 1;
    }
    return text.length();
  }

  public static List<Diagnostic> inspect(String fileName, String text) {
    if (isSmali(fileName)) return SmaliLanguageAdapter.inspect(text);
    if (isXml(fileName)) return inspectXml(text);
    if (isJava(fileName)) return inspectJava(fileName, text);
    return inspectCode(fileName, text);
  }

  /**
   * الجافا تُفحص بمحلل نحوي حقيقي ({@link almlk.JavaSyntaxChecker}) يغطي الجمل والأقواس والنصوص
   * والتصريحات معًا. دلالات المفهرس (الدوال المفقودة) لا تُفحص إلا على ملف صحيح نحويًا، كما يفعل
   * المترجم: يُعرض الخطأ النحوي أولًا ولا تُضاف إليه تشخيصات دلالية مضلِّلة.
   */
  private static List<Diagnostic> inspectJava(String fileName, String text) {
    List<almlk.JavaSyntaxChecker.Problem> problems = almlk.JavaSyntaxChecker.check(fileName, text);
    ArrayList<Diagnostic> result = new ArrayList<>(problems.size());
    for (almlk.JavaSyntaxChecker.Problem problem : problems) {
      result.add(
          Diagnostic.localized(
              problem.offset,
              problem.end,
              problem.line,
              problem.column,
              Diagnostic.Severity.ERROR,
              "CODE",
              problem.key,
              problem.fallback,
              problem.arguments));
    }
    if (result.isEmpty()) result.addAll(ProjectSymbolIndex.inspectCalls(text));
    return result;
  }

  private static List<Diagnostic> inspectCode(String fileName, String text) {
    ArrayList<Diagnostic> result = new ArrayList<>();
    ArrayDeque<Open> stack = new ArrayDeque<>();
    HashSet<Integer> reportedDelimiterLines = new HashSet<>();
    int line = 1, col = 1, n = text.length();
    String lowerName = fileName == null ? "" : fileName.toLowerCase(Locale.US);
    boolean gradleScript = lowerName.endsWith(".gradle") || lowerName.endsWith(".gradle.kts");
    boolean lineComment = false, blockComment = false, escape = false, textBlock = false;
    char quote = 0, textBlockQuote = 0;
    int quoteOffset = -1,
        quoteLine = 1,
        quoteCol = 1,
        textBlockOffset = -1,
        textBlockLine = 1,
        textBlockCol = 1,
        blockOffset = -1,
        blockLine = 1,
        blockCol = 1;
    for (int i = 0; i < n; i++) {
      char c = text.charAt(i), next = i + 1 < n ? text.charAt(i + 1) : 0;
      if (c == '\n') {
        line++;
        col = 1;
        lineComment = false;
        if (!textBlock && quote != 0 && quote != '`') {
          result.add(
              Diagnostic.localized(
                  quoteOffset,
                  quoteOffset + 1,
                  quoteLine,
                  quoteCol,
                  Diagnostic.Severity.ERROR,
                  "CODE",
                  "ui_diagnostic_unclosed_string",
                  "Unclosed string literal."));
          quote = 0;
          escape = false;
        }
        continue;
      }
      if (lineComment) {
        col++;
        continue;
      }
      if (blockComment) {
        if (c == '*' && next == '/') {
          blockComment = false;
          i++;
          col += 2;
        } else col++;
        continue;
      }
      if (textBlock) {
        if (c == textBlockQuote
            && i + 2 < n
            && text.charAt(i + 1) == textBlockQuote
            && text.charAt(i + 2) == textBlockQuote
            && !isEscaped(text, i)) {
          textBlock = false;
          textBlockQuote = 0;
          i += 2;
          col += 3;
        } else col++;
        continue;
      }
      if (quote != 0) {
        if (escape) escape = false;
        else if (c == '\\') escape = true;
        else if (c == quote) quote = 0;
        col++;
        continue;
      }
      if (c == '/' && next == '/') {
        lineComment = true;
        i++;
        col += 2;
        continue;
      }
      if (c == '/' && next == '*') {
        blockComment = true;
        blockOffset = i;
        blockLine = line;
        blockCol = col;
        i++;
        col += 2;
        continue;
      }
      if ((c == '"' || (gradleScript && c == '\''))
          && i + 2 < n
          && text.charAt(i + 1) == c
          && text.charAt(i + 2) == c) {
        textBlock = true;
        textBlockQuote = c;
        textBlockOffset = i;
        textBlockLine = line;
        textBlockCol = col;
        i += 2;
        col += 3;
        continue;
      }
      if (c == '"' || c == '\'' || c == '`') {
        quote = c;
        quoteOffset = i;
        quoteLine = line;
        quoteCol = col;
        col++;
        continue;
      }
      if (c == '(' || c == '[' || c == '{') stack.push(new Open(c, i, line, col));
      else if (c == ')' || c == ']' || c == '}') {
        char expected = c == ')' ? '(' : c == ']' ? '[' : '{';
        if (stack.isEmpty()) {
          if (reportedDelimiterLines.add(line))
            result.add(
                Diagnostic.localized(
                    i,
                    i + 1,
                    line,
                    col,
                    Diagnostic.Severity.ERROR,
                    "CODE",
                    "ui_diagnostic_unmatched_closing_delimiter",
                    "Closing delimiter has no matching opener."));
        } else if (stack.peek().value != expected) {
          Open matching = null;
          for (Open open : stack) {
            if (open.value == expected) {
              matching = open;
              break;
            }
          }
          if (matching != null) {
            while (!stack.isEmpty() && stack.peek() != matching) stack.pop();
            stack.pop();
            if (reportedDelimiterLines.add(line))
              result.add(
                  Diagnostic.localized(
                      i,
                      i + 1,
                      line,
                      col,
                      Diagnostic.Severity.ERROR,
                      "CODE",
                      "ui_diagnostic_mismatched_delimiter",
                      "Closing delimiter does not match the opener on line %1$d.",
                      matching.line));
          } else if (reportedDelimiterLines.add(line)) {
            // Leave the opener stack intact: a stray closer must not turn later valid closers
            // into a chain of bogus mismatches.
            result.add(
                Diagnostic.localized(
                    i,
                    i + 1,
                    line,
                    col,
                    Diagnostic.Severity.ERROR,
                    "CODE",
                    "ui_diagnostic_unmatched_closing_delimiter",
                    "Closing delimiter has no matching opener."));
          }
        } else stack.pop();
      }
      col++;
    }
    if (blockComment)
      result.add(
          Diagnostic.localized(
              blockOffset,
              blockOffset + 2,
              blockLine,
              blockCol,
              Diagnostic.Severity.ERROR,
              "CODE",
              "ui_diagnostic_unclosed_block_comment",
              "Unclosed block comment."));
    if (textBlock)
      result.add(
          Diagnostic.localized(
              textBlockOffset,
              textBlockOffset + 3,
              textBlockLine,
              textBlockCol,
              Diagnostic.Severity.ERROR,
              "CODE",
              "ui_diagnostic_unclosed_text_block",
              "Unclosed text block."));
    else if (quote != 0)
      result.add(
          Diagnostic.localized(
              quoteOffset,
              quoteOffset + 1,
              quoteLine,
              quoteCol,
              Diagnostic.Severity.ERROR,
              "CODE",
              "ui_diagnostic_unclosed_string",
              "Unclosed string literal."));
    if (!stack.isEmpty()) {
      // A missing outer closer usually explains every nested opener left in the stack. Report its
      // earliest cause once instead of painting the rest of the file as a cascade.
      Open first = stack.peekLast();
      result.add(
          Diagnostic.localized(
              first.offset,
              first.offset + 1,
              first.line,
              first.column,
              Diagnostic.Severity.ERROR,
              "CODE",
              "ui_diagnostic_unclosed_opening_delimiter",
              "Unclosed opening delimiter: %1$s",
              String.valueOf(first.value)));
    }
    return result;
  }

  private static boolean isEscaped(String text, int offset) {
    int backslashes = 0;
    for (int i = offset - 1; i >= 0 && text.charAt(i) == '\\'; i--) backslashes++;
    return (backslashes & 1) != 0;
  }

  private static List<Diagnostic> inspectXml(String text) {
    ArrayList<Diagnostic> out = new ArrayList<>();
    ArrayDeque<String> names = new ArrayDeque<>();
    ArrayDeque<Integer> offsets = new ArrayDeque<>();
    int i = 0;
    while (i < text.length()) {
      int s = text.indexOf('<', i);
      if (s < 0) break;
      if (text.startsWith("<!--", s)) {
        int e = text.indexOf("-->", s + 4);
        if (e < 0) {
          addAtLocalized(out, text, s, "ui_diagnostic_unclosed_xml_comment", "Unclosed XML comment.");
          break;
        }
        i = e + 3;
        continue;
      }
      if (text.startsWith("<![CDATA[", s)) {
        int e = text.indexOf("]]>", s + 9);
        if (e < 0) {
          addAtLocalized(out, text, s, "ui_diagnostic_unclosed_cdata", "Unclosed CDATA section.");
          break;
        }
        i = e + 3;
        continue;
      }
      int e = findTagEnd(text, s + 1);
      if (e >= text.length() && text.charAt(text.length() - 1) != '>') {
        addAtLocalized(out, text, s, "ui_diagnostic_unclosed_xml_tag", "Unclosed XML tag.");
        break;
      }
      String body = text.substring(s + 1, e - 1).trim();
      if (body.startsWith("?") || body.startsWith("!")) {
        i = e;
        continue;
      }
      boolean closing = body.startsWith("/"), self = body.endsWith("/");
      String clean = closing ? body.substring(1).trim() : body;
      Matcher m = IDENTIFIER_PATTERN.matcher(clean);
      if (!m.find()) {
        addAtLocalized(out, text, s, "ui_diagnostic_invalid_xml_tag_name", "Invalid XML tag name.");
        i = e;
        continue;
      }
      String name = m.group();
      if (closing) {
        if (names.isEmpty()) addAtLocalized(out, text, s, "ui_diagnostic_closing_tag_without_opening", "No opening tag for %1$s.", name);
        else if (!names.peek().equals(name))
          addAtLocalized(out, text, s, "ui_diagnostic_mismatched_xml_tag", "Expected closing tag %1$s, not %2$s.", names.peek(), name);
        else {
          names.pop();
          offsets.pop();
        }
      } else if (!self) {
        names.push(name);
        offsets.push(s);
      }
      i = e;
    }
    while (!names.isEmpty()) {
      String name = names.removeLast();
      int offset = offsets.removeLast();
      addAtLocalized(out, text, offset, "ui_diagnostic_unclosed_xml_tag_named", "Unclosed XML tag: %1$s", name);
    }
    return out;
  }

  private static void addAtLocalized(
      List<Diagnostic> out, String text, int offset, String messageKey, String fallback, Object... args) {
    int line = 1, col = 1;
    for (int i = 0; i < offset && i < text.length(); i++) {
      if (text.charAt(i) == '\n') {
        line++;
        col = 1;
      } else col++;
    }
    out.add(Diagnostic.localized(offset, offset + 1, line, col, Diagnostic.Severity.ERROR, "CODE", messageKey, fallback, args));
  }

  /**
   * تنسيق المصدر بأسلوب جافا — المرحلة الثامنة: الإزاحة من تفضيل المستخدم لا ثابت مضمّن.
   *
   * <p>XML **لا يمرّ هنا**: منسّقه البنيوي المستقل {@code almlk.XmlCodeFormatter} منذ 1.0.61،
   * وقد حُذف مسار XML القديم من هذه الأداة في 1.0.63 (بند 4: بلا مسارين ولا بقايا ميتة).
   */
  public static String format(String source, int indentSize) {
    return formatCode(source, indentSize);
  }

  private static String formatCode(String source, int indentSize) {
    final int step = indentSize < 0 ? 0 : Math.min(indentSize, 16);
    String text = source.replace("\r", "");
    StringBuilder output = new StringBuilder();
    StringBuilder line = new StringBuilder();
    int indent = 0, parentheses = 0, brackets = 0;
    boolean pendingSpace = false;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i), next = i + 1 < text.length() ? text.charAt(i + 1) : 0;
      if (c == '/' && next == '/') {
        appendPendingSpace(line, pendingSpace);
        int end = text.indexOf('\n', i);
        if (end < 0) end = text.length();
        line.append(text, i, end);
        emitFormattedLine(output, line, indent, step);
        pendingSpace = false;
        i = end;
        continue;
      }
      if (c == '/' && next == '*') {
        appendPendingSpace(line, pendingSpace);
        int end = text.indexOf("*/", i + 2);
        if (end < 0) end = text.length() - 2;
        String comment = text.substring(i, Math.min(text.length(), end + 2));
        String[] parts = comment.split("\n", -1);
        for (int part = 0; part < parts.length; part++) {
          if (part > 0) emitFormattedLine(output, line, indent, step);
          line.append(parts[part].trim());
        }
        pendingSpace = true;
        i = Math.min(text.length() - 1, end + 1);
        continue;
      }
      if (c == '"' || c == '\'' || c == '`') {
        appendPendingSpace(line, pendingSpace);
        char quote = c;
        line.append(c);
        boolean escape = false;
        while (++i < text.length()) {
          char value = text.charAt(i);
          line.append(value);
          if (escape) escape = false;
          else if (value == '\\') escape = true;
          else if (value == quote) break;
        }
        pendingSpace = false;
        continue;
      }
      if (Character.isWhitespace(c)) {
        pendingSpace = line.length() > 0;
        continue;
      }
      if (c == '{') {
        if (line.length() > 0
            && line.charAt(line.length() - 1) != ' '
            && line.charAt(line.length() - 1) != '('
            && line.charAt(line.length() - 1) != '[') {
          line.append(' ');
        }
        line.append('{');
        emitFormattedLine(output, line, indent++, step);
        pendingSpace = false;
        continue;
      }
      if (c == '}') {
        emitFormattedLine(output, line, indent, step);
        indent = Math.max(0, indent - 1);
        line.append('}');
        int after = nextNonWhitespace(text, i + 1);
        boolean joinsWord =
            startsWord(text, after, "else")
                || startsWord(text, after, "catch")
                || startsWord(text, after, "finally")
                || startsWord(text, after, "while");
        boolean joinsPunctuation =
            after < text.length() && ");,.]".indexOf(text.charAt(after)) >= 0;
        if (joinsWord) pendingSpace = true;
        else if (joinsPunctuation) pendingSpace = false;
        else emitFormattedLine(output, line, indent, step);
        continue;
      }
      if (c == '(') parentheses++;
      else if (c == ')') parentheses = Math.max(0, parentheses - 1);
      else if (c == '[') brackets++;
      else if (c == ']') brackets = Math.max(0, brackets - 1);

      if (c == ';') {
        trimTrailingSpace(line);
        line.append(c);
        if (parentheses == 0 && brackets == 0) emitFormattedLine(output, line, indent, step);
        else line.append(' ');
        pendingSpace = false;
        continue;
      }
      if (c == ',') {
        trimTrailingSpace(line);
        line.append(", ");
        pendingSpace = false;
        continue;
      }
      if (").]".indexOf(c) >= 0) {
        trimTrailingSpace(line);
        line.append(c);
      } else {
        appendPendingSpace(line, pendingSpace);
        line.append(c);
      }
      pendingSpace = false;
    }
    emitFormattedLine(output, line, indent, step);
    while (output.length() > 0 && output.charAt(output.length() - 1) == '\n')
      output.setLength(output.length() - 1);
    return output.toString();
  }

  private static boolean startsWord(String text, int offset, String word) {
    if (offset < 0
        || offset + word.length() > text.length()
        || !text.regionMatches(offset, word, 0, word.length())) return false;
    int end = offset + word.length();
    return end == text.length() || !Character.isJavaIdentifierPart(text.charAt(end));
  }

  private static void appendPendingSpace(StringBuilder line, boolean pending) {
    if (pending && line.length() > 0 && line.charAt(line.length() - 1) != ' ') line.append(' ');
  }

  private static void trimTrailingSpace(StringBuilder line) {
    while (line.length() > 0 && Character.isWhitespace(line.charAt(line.length() - 1)))
      line.setLength(line.length() - 1);
  }

  private static void emitFormattedLine(
      StringBuilder output, StringBuilder line, int indent, int step) {
    trimTrailingSpace(line);
    int start = 0;
    while (start < line.length() && Character.isWhitespace(line.charAt(start))) start++;
    if (start >= line.length()) {
      line.setLength(0);
      return;
    }
    for (int i = Math.max(0, indent) * step; i > 0; i--) output.append(' ');
    output.append(line, start, line.length()).append('\n');
    line.setLength(0);
  }

  public static List<String> complete(String fileName, String text, int cursor) {
    if (isSmali(fileName)) return com.shima.editor.core.SmaliCompletionEngine.complete(text, cursor, 50);
    // المرحلة الرابعة: إكمال XML سياقي (وسم/سمة/قيمة) بدل كلمات جافا.
    if (isXml(fileName)) return almlk.XmlCompletionEngine.complete(text, cursor);
    int at = Math.max(0, Math.min(cursor, text.length())), start = at;
    while (start > 0 && Character.isJavaIdentifierPart(text.charAt(start - 1))) start--;
    String prefix = text.substring(start, at).toLowerCase(Locale.US);
    TreeSet<String> values = new TreeSet<>();
    values.addAll(JAVA_WORDS);
    values.addAll(COMMON_WORDS);
    Matcher m = IDENTIFIER_PATTERN.matcher(text);
    while (m.find()) if (m.group().length() > 1) values.add(m.group());
    ArrayList<String> out = new ArrayList<>();
    for (String value : values)
      if (prefix.isEmpty() || value.toLowerCase(Locale.US).startsWith(prefix)) out.add(value);
    if (out.size() > 80) return new ArrayList<>(out.subList(0, 80));
    return out;
  }

  public static int completionStart(String text, int cursor) {
    int start = Math.max(0, Math.min(cursor, text.length()));
    while (start > 0 && Character.isJavaIdentifierPart(text.charAt(start - 1))) start--;
    return start;
  }

  /** المرحلة الثالثة: بداية الرمز بوعيٍ بنوع الملف — قيم XML تشمل الأرقام والنقط و@ و#. */
  public static int completionStart(String fileName, String text, int cursor) {
    if (isXml(fileName)) return almlk.XmlCompletionEngine.completionStart(text, cursor);
    return completionStart(text, cursor);
  }

  private static boolean isJava(String name) {
    return name != null && name.toLowerCase(Locale.US).endsWith(".java");
  }

  private static boolean isSmali(String name) {
    if (name == null) return false;
    return name.toLowerCase(Locale.US).endsWith(".smali");
  }

  private static boolean isXml(String name) {
    if (name == null) return false;
    String n = name.toLowerCase(Locale.US);
    return n.endsWith(".xml") || n.endsWith(".html") || n.endsWith(".htm");
  }

  private static Set<String> set(String values) {
    return new HashSet<>(Arrays.asList(values.split(" ")));
  }
}
