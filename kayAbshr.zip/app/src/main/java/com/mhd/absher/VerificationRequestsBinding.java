package com.mhd.absher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.a.a.a;

public final class VerificationRequestsBinding {
    public final ImageView btnCloseVerification;
    public final ImageView imgFingerprint;
    public final LinearLayout linear2;
    public final RelativeLayout rootView;
    public final RelativeLayout topBarVerification;
    public final TextView tvNoPendingSub;
    public final TextView tvNoPendingTitle;
    public final TextView tvVerificationTitle;

    private VerificationRequestsBinding(RelativeLayout relativeLayout, RelativeLayout relativeLayout2, ImageView imageView, TextView textView, LinearLayout linearLayout, ImageView imageView2, TextView textView2, TextView textView3) {
        this.rootView = relativeLayout;
        this.topBarVerification = relativeLayout2;
        this.btnCloseVerification = imageView;
        this.tvVerificationTitle = textView;
        this.linear2 = linearLayout;
        this.imgFingerprint = imageView2;
        this.tvNoPendingTitle = textView2;
        this.tvNoPendingSub = textView3;
    }

    public static VerificationRequestsBinding bind(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        RelativeLayout relativeLayout2 = (RelativeLayout) findChildViewById(view, R.id.topBarVerification);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.btnCloseVerification);
        TextView textView = (TextView) findChildViewById(view, R.id.tvVerificationTitle);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear2);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imgFingerprint);
        TextView textView2 = (TextView) findChildViewById(view, R.id.tvNoPendingTitle);
        TextView textView3 = (TextView) findChildViewById(view, R.id.tvNoPendingSub);
        if (relativeLayout2 == null || imageView == null || textView == null || linearLayout == null || imageView2 == null || textView2 == null || textView3 == null) {
            throw new IllegalStateException(a.a("BzE3WFEnMSINTjwxMV4YNCYjDVU8JzVEVjI="));
        }
        return new VerificationRequestsBinding(relativeLayout, relativeLayout2, imageView, textView, linearLayout, imageView2, textView2, textView3);
    }

    private static View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }

    public static VerificationRequestsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static VerificationRequestsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.verification_requests, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}
