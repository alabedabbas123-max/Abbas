package com.almlkid.kay.aide.preference;

import android.content.Context;
import android.preference.ListPreference;
import android.util.AttributeSet;
import com.shima.demo.R;

/** Theme selector referenced by the original preference XML files. */
@SuppressWarnings("deprecation")
public class PreferenceTheme extends ListPreference {
  public PreferenceTheme(Context context) {
    super(context);
    init();
  }

  public PreferenceTheme(Context context, AttributeSet attrs) {
    super(context, attrs);
    init();
  }

  private void init() {
    setTitle(R.string.ui_preferences_theme_title);
    setEntries(
        new String[] {
          getContext().getString(R.string.ui_theme_material_dark),
          getContext().getString(R.string.ui_theme_material_light)
        });
    setEntryValues(new String[] {"dark", "light"});
    setDefaultValue("dark");
  }
}
