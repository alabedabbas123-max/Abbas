package com.mhd.absher;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class WorkersActivity extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.workers);
        View viewFindViewById = findViewById(R.id.navHome);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    WorkersActivity.this.startActivity(new Intent((Context) WorkersActivity.this, (Class<?>) ActivityHomeActivity.class));
                    WorkersActivity.this.finish();
                }
            });
        }
        View viewFindViewById2 = findViewById(R.id.navFamily);
        if (viewFindViewById2 != null) {
            viewFindViewById2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    WorkersActivity.this.startActivity(new Intent((Context) WorkersActivity.this, (Class<?>) FamilyActivity.class));
                    WorkersActivity.this.finish();
                }
            });
        }
        View viewFindViewById3 = findViewById(R.id.navMyServices);
        if (viewFindViewById3 != null) {
            viewFindViewById3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    WorkersActivity.this.startActivity(new Intent((Context) WorkersActivity.this, (Class<?>) MyServicesActivity.class));
                    WorkersActivity.this.finish();
                }
            });
        }
        View viewFindViewById4 = findViewById(R.id.navOther);
        if (viewFindViewById4 != null) {
            viewFindViewById4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    WorkersActivity.this.startActivity(new Intent((Context) WorkersActivity.this, (Class<?>) OtherServicesActivity.class));
                    WorkersActivity.this.finish();
                }
            });
        }
    }
}
